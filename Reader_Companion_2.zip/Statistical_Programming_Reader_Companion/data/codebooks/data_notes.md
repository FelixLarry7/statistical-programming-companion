# Data definitions and exchange

Use the listed chapter dictionary for the original measures, labels, missingness
rules and derivations. The machine-readable field index records types observed
in the frozen files alongside named keys and counts of empty fields. A
labelled sentinel remains a source value. Keep text identifiers as text. Use
UTF-8, a decimal point and the declared date or quarter fields when exchanging
the teaching data.

## Agricultural regression pilot

One record identifies a plot and season. Divide area in square metres by
10,000 to express it in hectares. Divide harvest in kilograms by this area
for kg/ha. The 16 source keys yield 12 eligible records. Valid zero harvest
and missing harvest receive different dispositions. Chapter 38 changes the
P011 harvest from 782.5 to 792.5 kg, retaining the same keys, area and sessions.

## FAOSTAT Ghana maize

The key comprises area code, item, element and calendar year. Area 81 is Ghana.
Item 56 is maize. Elements 5312, 5412 and 5510 record harvested area in
hectares, yield in kg/ha and production in metric tonnes. The extract uses
2010–2024 and carries the provider’s flags, units and notes. The provider
publishes yield and production with their own flags and denominators.

## FDIC BankFind quarterly extract

CERT identifies the FDIC institution and REPDTE is the financial reporting
date in YYYYMMDD. ASSET, LNLSGR, LNLSNET and NCLNLS give total assets, gross
loans and leases, net loans and leases, and noncurrent loans and leases.
These amounts are expressed in thousands of US dollars. NCLNLSR expresses
noncurrent loans and leases as a percentage of gross loans and leases. The
retrospective panel does not identify the information set at a decision date.
Chapter 31 supplies that timing structure in its synthetic exercise.

## GSPS Wave 3 agriculture

FPrimary identifies the household. Plot and crop levels use plotid and cropcode
as applicable. The selected field register records the provider labels and
observed null counts. Work from complete keys when checking join feasibility,
then document valid crop areas, harvest units and season for the estimand.

## Public synthetic domain release

One row identifies a welfare domain. Released estimates and 95% interval
bounds are proportions. Withheld and insufficient-precision rows retain their
status and use empty numerical cells. The detailed governance tier is synthetic.
