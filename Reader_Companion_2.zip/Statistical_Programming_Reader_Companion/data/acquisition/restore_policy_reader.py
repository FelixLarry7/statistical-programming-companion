"""Restore the Bank of Ghana input from its official effective-date table."""
import argparse
import csv
from datetime import date,timedelta
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.request import Request,urlopen
from zipfile import ZIP_DEFLATED,ZipFile

from context import bog

ROOT=Path(__file__).resolve().parents[2]
COMPANION=ROOT/"chapter_companions/Part_VIII/companion"


def restore(html):
    record=next(row for row in csv.DictReader((ROOT/"data/catalog/dataset_catalogue.csv").open())
                if Path(row["path"]).name=="policy29.csv")
    path=ROOT/record["path"]
    if path.exists():
        if sha256(path.read_bytes()).hexdigest()!=record["sha256"]:
            raise ValueError("Existing policy input differs from the frozen edition")
        print("The analytical policy input already matches the frozen edition.")
        return
    if html is None:
        provider=next(row for row in json.loads((ROOT/"data/catalog/provider_files.json").read_text()) if row["id"]=="D02-01")
        with urlopen(Request(provider["url"],headers={"User-Agent":"Mozilla/5.0"}),timeout=40) as response:
            page=response.read(8_000_001)
        if len(page)>8_000_000:
            raise ValueError("Unexpected size for the official historical page")
    else:
        page=html.read_bytes()
    with TemporaryDirectory() as dir_name:
        temp=Path(dir_name)/"source.html"
        temp.write_bytes(page)
        changes=[(date.fromisoformat(key),float(value)) for key,value in bog(temp)]
    stream=StringIO(newline="")
    writer=csv.writer(stream,lineterminator="\n")
    writer.writerow(("year","day","policy"))
    i=0
    for year in range(2003,2025):
        start=date(year,1,1)
        for elapsed in range((date(year+1,1,1)-start).days):
            day=start+timedelta(days=elapsed)
            while i+1<len(changes) and changes[i+1][0]<=day:
                i+=1
            writer.writerow((year,elapsed+1,changes[i][1]))
    analytical=stream.getvalue().encode("utf-8")
    if sha256(analytical).hexdigest()!=record["sha256"]:
        raise ValueError("The current provider series differs from the published version. Preserve it as a separate vintage.")
    archive=COMPANION/"evidence/stata/evidence_replay.zip"
    if not archive.is_file():
        with ZipFile(archive.with_name("evidence_reader.zip")) as before, ZipFile(archive.with_suffix(".tmp"),"w",ZIP_DEFLATED) as after:
            for name in before.namelist():
                after.writestr(name,before.read(name))
            after.writestr("input_policy29.csv",analytical)
        archive.with_suffix(".tmp").replace(archive)
    path.write_bytes(analytical)
    print("Restored the exact analytical input and completed the Part VIII licensed replay package.")


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--html",type=Path)
    restore(p.parse_args().html)
