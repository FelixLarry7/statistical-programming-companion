"""Retrieve the selected provider bytes and record their revision and fingerprint."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import tempfile
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from zipfile import is_zipfile

RECIPES = Path(__file__).resolve().parents[1] / 'catalog/provider_files.json'


def retrieve(item, output, accept_current):
    if item['route'] != 'download':
        raise ValueError(f"{item['id']} uses a {item['route']} route. See the register.")
    if urlparse(item['url']).scheme != 'https':
        raise ValueError('Provider downloads require HTTPS.')
    target = output / item['filename']
    receipt = output / f"{item['id']}.receipt.json"
    if target.exists() or receipt.exists():
        raise FileExistsError(target)
    session = tempfile.NamedTemporaryFile(dir=output, delete=False)
    temp = Path(session.name)
    try:
        request = Request(item['url'], headers={'User-Agent':'Mozilla/5.0', 'Accept':'*/*'})
        with session, urlopen(request, timeout=40) as response:
            if urlparse(response.geturl()).scheme != 'https':
                raise ValueError('Provider redirected outside HTTPS.')
            data = response.read(75_000_000)
            if len(data) >= 75_000_000:
                raise ValueError('Response exceeds the 75 MB transfer limit.')
            record = {'id':item['id'], 'request':item['url'], 'resolved':response.geturl(),
                      'retrieved_utc':datetime.now(timezone.utc).isoformat(),
                      'bytes':len(data), 'content_type':response.headers.get('Content-Type')}
            session.write(data)
        if item['format'] == 'zip' and not is_zipfile(temp):
            raise ValueError('The response lacks the expected ZIP structure.')
        if item['format'] == 'pdf' and not data.startswith(b'%PDF-'):
            raise ValueError('The response lacks the expected PDF signature.')
        if item['format'] == 'json':
            json.loads(data)
        digest = sha256(data).hexdigest()
        expected = item['retrieved_sha256']
        record.update(sha256=digest, expected_sha256=expected, exact_match=digest==expected)
        content=json.dumps(record,indent=2)+'\n'
        if digest != expected and not accept_current:
            (output/f"{item['id']}.mismatch.json").write_text(content)
            raise ValueError('Provider bytes differ from the verified response. See the mismatch record.')
        if 'published_md5' in item and digest == expected:
            record['provider_md5']=item['published_md5']
        temp.replace(target)
        receipt.write_text(json.dumps(record,indent=2)+'\n')
        print(f'{item["id"]} {target.name} {digest}')
    finally:
        temp.unlink(missing_ok=True)


def main():
    recipes = {item['id']:item for item in json.loads(RECIPES.read_text())}
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ids',nargs='*')
    parser.add_argument('--list',action='store_true')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--accept-current',action='store_true',help='Keep a newly retrieved provider revision.')
    args=parser.parse_args()
    if args.list:
        for item in recipes.values():
            print(item['id'], item['route'], item['title'], item['url'], sep='\t')
        return
    if not args.ids or args.output is None:
        parser.error('Supply a file ID and --output, or use --list.')
    if any(identifier not in recipes for identifier in args.ids):
        parser.error('Use --list to identify the file ID.')
    args.output.mkdir(parents=True,exist_ok=True)
    for identifier in args.ids:
        retrieve(recipes[identifier], args.output, args.accept_current)


if __name__ == '__main__':
    main()
