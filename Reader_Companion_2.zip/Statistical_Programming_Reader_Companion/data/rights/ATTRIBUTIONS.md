# Attribution and permission record

The teaching baselines use the included datasets. Access to controlled
microdata follows the routes in **custodian_access.md**. Carry forward
these attributions and applicable terms if you use a provider dataset.

| ID | Citation and terms |
| --- | --- |
| D00, D13 | Original synthetic fixtures and code prepared for the textbook by Felix Larry Essilfie, PhD. See **READER_USE.md** in the package root. |
| D01 | World Bank, *World Development Indicators*, version 11 November 2026. Credit the upstream sources in the indicator register. The World Bank describes its default terms and exceptions for third-party and derived material. Use the listed provider API rather than mirroring upstream bulk files where the terms call for separate review. [Dataset terms](https://www.worldbank.org/ext/en/legal/terms-conditions/datasets) |
| D02 | Bank of Ghana, *Monetary Policy Rate Trends*. Retain the effective-date record and attribution in the original textbook chart. The official site carries the provider chart and history. [Provider chart](https://www.bog.gov.gh/monetary-policy/%20policy-rate-trends/) |
| D03 | Ghana Statistical Service, *Ghana Living Standards Survey VII*, 2016–2017. Attribute the study, catalogue ID and published estimates. [GSS terms](https://www2.statsghana.gov.gh/nada/index.php/policies-and-procedures) |
| D04 | Ghana Statistical Service and ICF, *Ghana Demographic and Health Survey 2022*, FR387. Chapter 30 uses Table 9.7’s national live-birth comparator. [Final report](https://www.dhsprogram.com/pubs/pdf/FR387/FR387.pdf) |
| D05 | Transfer Project, UNICEF Innocenti, ISSER and study partners, *Ghana LEAP 1000 Programme*. Cite the relevant wave and report. [Study reports](https://www.unicef.org/innocenti/reports/ghana-leap-1000-programme) |
| D06 | Osei, Osei-Akoto, Aryeetey, Dzanku, Udry and Yale Economic Growth Center (2022), *ISSER-Northwestern-Yale Long Term Ghana Socioeconomic Panel Survey*. Dataverse version 1.2, CC0 1.0. [Dataset](https://doi.org/10.7910/DVN/E5QP0F) |
| D07 | Ghana Statistical Service and Ministry of Food and Agriculture, *Ghana Census of Agriculture 2017/18*. FAO, *FAOSTAT Crops and livestock products*, accessed 13 November 2026. The extract selects Ghana maize area, yield and production. Retain FAO’s terms and flags. Use the original-source route for the eight externally supplied X-flag values before mirroring the extract. [FAO terms](https://www.fao.org/contact-us/terms/db-terms-of-use/en) |
| D08 | Ghana Statistical Service and Ministry of Food and Agriculture with WFP and FAO (2021), *Ghana Comprehensive Food Security and Vulnerability Analysis 2020*. [Report publication](https://ghana.un.org/en/176300-2020-comprehensive-food-security-and-vulnerability-analysis-findings) |
| D09 | Chen, D. (2015), *Online Retail*. UCI Machine Learning Repository. CC BY 4.0. The retained adaptation selects 52 weeks and three UK products, recodes invoice and customer identifiers, omits descriptions and preserves quantity and cancellation signs. [Dataset and licence](https://doi.org/10.24432/C5BW33) |
| D10 | Federal Deposit Insurance Corporation, *BankFind Suite Financials*. The 64-row retrospective extract selects four institutions and seven fields. The public-domain notice in the federal catalogue applies to the FFIEC Call Report distributions identified there. [BankFind](https://api.fdic.gov/banks/docs) · [FFIEC catalogue](https://catalog.data.gov/dataset/ffiec-call-reports) |
| D11 | Ghana Statistical Service, *2021 Population and Housing Census, Volume 3M, Water and Sanitation*. Ghana ADM1 source geometry from geoBoundaries and OpenStreetMap contributors, record GHA-ADM1-69750345. The pinned release metadata records CC BY-SA 2.0 for the primary source. OpenStreetMap lists ODbL for its database. Retain the release notice and apply the relevant source terms to redistributed data and derived maps. [geoBoundaries](https://www.geoboundaries.org/api.html) · [OpenStreetMap copyright](https://www.openstreetmap.org/copyright) |
| D12 | Feenstra, Inklaar and Timmer (2025), *Penn World Table 11.0*, DataverseNL version 2.0, CC BY 4.0. The derived file selects a documented country-year window and five variables. Cite the methods and preserve their distinct price bases. [Dataset](https://doi.org/10.34894/FABVLR) · [Methods](https://doi.org/10.1257/aer.20130954) |

The supplied CSL file, software and dependencies retain their original notices.
