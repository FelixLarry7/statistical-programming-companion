# Empirical access routes

The teaching exercises reproduce the methods with included synthetic inputs or
published aggregates. Use the following routes to conduct a separate empirical
study. Record the permitted users, research question, requested files, storage,
retention, linked data and publishable outputs.

## D03 Ghana Living Standards Survey VII

Use study DDI-GHA-GSS-GLSS7-2017-v1 and the GSS account-based route. For
poverty analysis, identify the consumption aggregate, price deflator, household
size, poverty line, weights, strata and primary sampling units. Define whether
the estimand concerns households or persons. The original Chapters 12 and 36
teaching files illustrate the survey methods. [Access](https://microdata.statsghana.gov.gh/index.php/catalog/97/get-microdata)

## D04 Ghana Demographic and Health Survey 2022

Use study GHA_2022_DHS_v01_M or the DHS project approval route. Request the
recode appropriate to the birth, pregnancy, individual or household population.
Confirm the place-of-delivery codes, reference period and strata, PSU and
weight variables. Chapter 30 cites the national result for live births. Table
9.7 gives 86.2% for live births and 86.4% for its combined population including
stillbirths, both in the two years before the survey. [GSS access](https://microdata.statsghana.gov.gh/index.php/catalog/123/get-microdata) · [DHS terms](https://dhsprogram.com/data/terms-of-use.cfm) · [FR387](https://www.dhsprogram.com/pubs/pdf/FR387/FR387.pdf)

## D05 LEAP 1000

Consult the Transfer Project application, data-use agreement and security
pledge for the 2015 baseline and 2017 follow-up. The seven-year report uses the
2022 follow-up. Confirm eligibility for that file and the proposed linkage with
the custodian. State the study population, wave, outcome and intended
publication outputs. The companion includes a synthetic paired-village trial.
[Transfer Project](https://data.cpc.unc.edu/projects/13/view)

## D06 Ghana Socioeconomic Panel Survey Wave 3

Use the five file IDs and original downloads in **catalog/provider_files.json**.
Verify the original DTA files against the provider’s MD5 and the acquisition
SHA-256. Merge roster and agriculture on household and plot. For seed and
harvest, add crop code and audit incomplete keys before joining. Specify harvest
units, intercropping, crop area, season and seed-variety classification before
estimating yield or adoption. [Dataverse](https://doi.org/10.7910/DVN/E5QP0F)

## D07 and D08 Ghana agricultural census and food security

Use the Ghana Statistical Service publications for context. Submit any
household-file enquiry to GSS, specifying the reference year, questionnaire,
geography, variables, unit, use and intended outputs. Verify any partner
conditions with the responsible custodian. The food-security teaching
shortfall item and the CFSVA survey instruments have different definitions.
[Ghana agricultural census](https://www.statsghana.gov.gh/census-surveys/agricultural-census) · [GSS requests](https://statsghana.gov.gh/data-request/request-data)
