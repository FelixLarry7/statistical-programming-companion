# Part X computational companion

Run from the parent folder containing **companion/**. Use CPython 3.12, Git and
R 4.5.0 for the recorded public route. The reporting lab uses Quarto, and
the Word and full-book proof commands are documented in the parent README. The Python lock is for Linux x86-64.
R restoration checks sandwich 3.1-1, zoo 1.8-14 and lattice 0.22-7. If another
supported platform needs a distinct lock, record its environment and rerun the
checks. A licensed Stata binary is supplied by the institution or reader.

~~~sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install --require-hashes \
  -r companion/pilot/requirements-linux-x86_64.lock
Rscript --vanilla companion/pilot/ci/restore_r.R
python -m pip install -r companion/capstone/part_ix/requirements.txt
~~~

## Chapter 37. Repeat the pilot from tagged source

~~~sh
mkdir -p build
git clone companion/pilot/evidence/pilot-source.bundle build/pilot-1
git clone companion/pilot/evidence/pilot-source.bundle build/pilot-2
git -C build/pilot-1 switch --detach stage3-part-x-pilot-v1
git -C build/pilot-2 switch --detach stage3-part-x-pilot-v1
python build/pilot-1/ci/check.py --output build/public-1
python build/pilot-2/ci/check.py --output build/public-2
python companion/pilot/ci/compare_runs.py \
  build/public-1 build/public-2 build/stable-files.json
python build/pilot-1/ci/check.py --output build/licensed-replay \
  --licensed-evidence build/pilot-1/stata/evidence
~~~

Expect 15 stable files across both public runs. For the verified original
Stata-backed scope, expect 364 reference and 510 pairwise checks.
**pilot/evidence/pilot_summary.json** records the counts, tag and hashes.
The hosted CI file illustrates how to organise jobs. The observed run evidence
comes from local execution of the jobs' underlying checks. To test a local
licensed Stata 16 or 17 installation with the pilot, use **--stata** followed
by the absolute executable path in a separate output directory.

## Chapter 38. Rebuild the reporting record

~~~sh
python companion/reporting/build_reports.py build/licensed-replay \
  --output build/reports
~~~

The script reads the verified baseline and creates a separate corrected
dataset, the result registry, figure data, two reports and the discrepancy
audit. The baseline and corrected slopes are 80.00 and 81.43. Open
**reporting/reader_lab.qmd** to build the small worked example in Quarto. The
Jupyter and R Markdown examples expect the **reporting/** directory as their
working directory. Their code reads the same generated files in **outputs/**.
The checked distribution includes PDF and EPUB versions of the Quarto lab.

## Chapter 39. Test the public projection

~~~sh
python companion/governance/build_release.py --output build/disclosure
~~~

Inspect **disclosure_audit.json**, the public projection, and both ZIP
member lists. The planted notebook and log defects are found before the
corrected six-file public package is built. The mock authorised tier is a
synthetic teaching fixture. The data availability, permissions and code
provenance records describe the applicable scope.

## Chapter 40. Review the comparative development capstone

~~~sh
git clone companion/capstone/outputs/capstone-source.bundle build/capstone
git -C build/capstone switch --detach stage3-part-x-capstone-v1
python build/capstone/verify.py --output build/capstone-replay \
  --require-four --stata-evidence \
  build/capstone/evidence/stata/evidence_replay.zip
python companion/capstone/review_study.py --evidence build/capstone-replay \
  --output build/capstone-report
~~~

Expect 20,215 retained comparisons, including 1,282 for the country-panel
chapter. The report exercise detects the wrong model key and verifies the
24 corrected fields. The study and recorded archive are in **capstone/outputs/**.
Follow **capstone/second_reader_protocol.md** to assess the claim, uncertainty,
scope, documented deviations and amendment. The chapter distinguishes the
internal clean-checkout demonstration from independent review by a second reader.
