# Use the R library selected by the reader. Install lattice with the R distribution first.
install.packages("https://cran.r-project.org/src/contrib/Archive/zoo/zoo_1.8-14.tar.gz", repos = NULL,
                 type = "source")
install.packages("https://cran.r-project.org/src/contrib/Archive/sandwich/sandwich_3.1-1.tar.gz", repos = NULL,
                 type = "source")
