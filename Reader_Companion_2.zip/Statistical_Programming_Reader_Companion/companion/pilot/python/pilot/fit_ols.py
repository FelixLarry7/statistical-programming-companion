"""Fit the shared maize-yield OLS model using statsmodels."""

import argparse
import csv
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
import statsmodels
import statsmodels.api as sm
from threadpoolctl import threadpool_info

FIELDS = ['plot_id', 'season', 'area_ha', 'harvest_kg', 'sessions', 'yield_kg_ha']
PARAMETERS = ['intercept', 'sessions']


def write_csv(path, fields, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(fields)
        writer.writerows(rows)


def fit(input_path, out, cov_type='HC1'):
    with input_path.open(encoding='utf-8', newline='') as stream:
        data = csv.DictReader(stream)
        if data.fieldnames != FIELDS:
            raise ValueError('Unexpected analytical header')
        rows = list(data)
    keys = [(row['plot_id'], int(row['season'])) for row in rows]
    x = np.asarray([int(row['sessions']) for row in rows], dtype=np.float64)
    y = np.asarray([float(row['yield_kg_ha']) for row in rows], dtype=np.float64)
    if (len(keys) <= 2 or len(set(keys)) != len(keys) or len(set(x)) < 2
            or not np.isfinite(y).all()):
        raise ValueError('The extract must contain unique keys, finite yields and a full-rank design')

    design = sm.add_constant(x, has_constant='raise')
    model = sm.OLS(y, design, missing='raise', hasconst=True).fit(method='qr', use_t=True)
    robust = model.get_robustcov_results(cov_type=cov_type, use_t=True)
    coefficients = []
    covariances = []
    for name, result in [('classical', model), ('HC1', robust)]:
        intervals = result.conf_int(alpha=0.05)
        covariance = result.cov_params()
        for i, term in enumerate(PARAMETERS):
            coefficients.append((name, term, result.params[i], result.bse[i], result.tvalues[i],
                                 int(result.df_resid), result.pvalues[i], *intervals[i]))
            for j, other in enumerate(PARAMETERS):
                covariances.append((name, term, other, covariance[i, j]))

    out.mkdir(parents=True, exist_ok=True)
    write_csv(out / 'coefficients.csv', ['covariance', 'parameter', 'estimate', 'std_error', 't_value',
              'df_resid', 'p_value', 'ci_low', 'ci_high'], coefficients)
    write_csv(out / 'covariance.csv', ['covariance', 'parameter_1', 'parameter_2', 'value'], covariances)
    predictions = [(plot, season, int(x[i]), y[i], model.fittedvalues[i], model.resid[i])
                   for i, (plot, season) in enumerate(keys)]
    write_csv(out / 'predictions.csv', ['plot_id', 'season', 'sessions', 'yield_kg_ha', 'fitted', 'residual'],
              predictions)
    summary = dict(nobs=int(model.nobs), rank=int(model.model.rank), df_resid=int(model.df_resid),
                   sse=float(model.ssr), sst=float(model.centered_tss), r_squared=float(model.rsquared),
                   x_mean=float(x.mean()), y_mean=float(y.mean()), sxx=float(np.sum((x - x.mean()) ** 2)))
    (out / 'fit.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    libraries = [{k: lib.get(k) for k in ('user_api', 'internal_api', 'version', 'num_threads', 'threading_layer')}
                 for lib in threadpool_info()]
    environment = {'python': sys.version.split()[0], 'platform': platform.platform(), 'numpy': np.__version__,
                   'scipy': scipy.__version__, 'statsmodels': statsmodels.__version__,
                   'solver': 'QR', 'robust_covariance_computed': cov_type, 'numerical_libraries': libraries}
    (out / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n', encoding='utf-8')
    print(f'statsmodels {statsmodels.__version__}: n={summary["nobs"]}, df={summary["df_resid"]}, '
          f'robust covariance={cov_type}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('out', type=Path)
    args = parser.parse_args()
    fit(args.input, args.out)
