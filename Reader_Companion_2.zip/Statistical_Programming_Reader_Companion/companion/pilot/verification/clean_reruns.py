"""Compare two fresh run directories with the retained Stage 2 baseline."""

import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def numeric_rows(path):
    with path.open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def verify(baseline, reruns):
    base_manifest = read(baseline / 'run_manifest.json')
    base_validation = read(baseline / 'validation.json')
    file_names = ('duckdb/analytical.csv', 'duckdb/sample_audit.csv', 'reference_checks.csv',
                  'cross_environment.csv', 'analytical_reference.json')
    base_sha = {n: sha256((baseline / n).read_bytes()).hexdigest() for n in file_names}
    evidence = []
    for number, run in enumerate(reruns, 1):
        actual_manifest = read(run / 'run_manifest.json')
        actual_validation = read(run / 'validation.json')
        files_match = all(sha256((run / n).read_bytes()).hexdigest() == base_sha[n] for n in file_names)
        spec_match = base_manifest['inputs_and_code_sha256'] == actual_manifest['inputs_and_code_sha256']
        status_match = base_validation == actual_validation
        checks = numeric_rows(run / 'reference_checks.csv') + numeric_rows(run / 'cross_environment.csv')
        passed = files_match and spec_match and status_match and bool(checks) and all(row['passed'] == 'True' for row in checks)
        evidence.append({'run': number, 'engine_statuses': {e: v['status'] for e, v in actual_validation['engines'].items()},
                         'comparison_rows': len(checks), 'source_hashes_match': spec_match,
                         'artifacts_byte_identical': files_match, 'verification_status_matches': status_match,
                         'passed': passed})
    return {'all_passed': bool(evidence) and all(e['passed'] for e in evidence),
            'method': 'Fresh package and output folders using the same pinned runtimes',
            'baseline_extract_sha256': base_manifest['canonical_extract_sha256'], 'compared_file_sha256': base_sha,
            'reruns': evidence}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('reruns', type=Path, nargs=2)
    args = parser.parse_args()
    result = verify(args.baseline, args.reruns)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    raise SystemExit(0 if result['all_passed'] else 1)
