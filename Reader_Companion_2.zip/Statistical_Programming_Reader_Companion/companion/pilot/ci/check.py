"""Check the public pilot or its authorised licensed evidence route."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = {"DuckDB", "Python", "R"}


def verify_archive(path):
    meta = json.loads((path / "provenance.json").read_text())
    if meta["stage2_rc"] != "0" or meta["stata_version"] not in {"16", "17"}:
        raise ValueError("Expected completed Stata 16 or 17 evidence.")
    code = (path / "driver.do").read_bytes()
    if code != (ROOT / "stata/pilot/fit_ols.do").read_bytes():
        raise ValueError("Archived driver does not match the released driver.")
    if sha256(code).hexdigest() != meta["driver_sha256"]:
        raise ValueError("Invalid driver fingerprint.")
    digest = sha256((path / "analytical.csv").read_bytes()).hexdigest()
    if digest != meta["input_sha256"] or digest != (path / "outputs/input_sha256.txt").read_text().strip():
        raise ValueError("Analytical input does not match the archived run.")
    return path / "outputs"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--rscript", default="Rscript")
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--licensed-evidence", type=Path)
    mode.add_argument("--stata", type=Path)
    a = p.parse_args()
    subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
                   check=True, cwd=ROOT)
    dest = a.output.resolve()
    command = [sys.executable, str(ROOT / "run.py"), "--output", str(dest), "--rscript", a.rscript]
    required = set(PUBLIC)
    if a.licensed_evidence:
        command.extend(["--stata-results", str(verify_archive(a.licensed_evidence.resolve())), "--require-all"])
        required.add("Stata")
    if a.stata:
        command.extend(["--stata", str(a.stata.resolve()), "--require-all"])
        required.add("Stata")
    subprocess.run(command, check=True, cwd=ROOT)
    results = json.loads((dest / "validation.json").read_text())
    if any(results["engines"][engine]["status"] != "VERIFIED" for engine in required):
        raise ValueError(f"Required engine checks did not pass: {sorted(required)}")
    print("Required engine checks passed", sorted(required))


if __name__ == "__main__":
    main()
