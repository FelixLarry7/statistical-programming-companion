"""Check stable output bytes across two clean executions."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

STABLE = ("analytical_reference.json", "reference_checks.csv", "cross_environment.csv",
          "validation.json", "duckdb/analytical.csv", "duckdb/sample_audit.csv",
          "duckdb/coefficients.csv", "duckdb/covariance.csv", "duckdb/predictions.csv",
          "python/coefficients.csv", "python/covariance.csv", "python/predictions.csv",
          "r/coefficients.csv", "r/covariance.csv", "r/predictions.csv")


def compare(first, second):
    checks = {}
    for name in STABLE:
        expected = (first / name).read_bytes()
        if (second / name).read_bytes() != expected:
            raise ValueError(f"Stable artifact differs: {name}")
        checks[name] = sha256(expected).hexdigest()
    return checks


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("first", type=Path)
    p.add_argument("second", type=Path)
    p.add_argument("output", type=Path)
    a = p.parse_args()
    checks = compare(a.first, a.second)
    a.output.write_text(json.dumps(checks, indent=2) + "\n")
    print(f"{len(checks)} stable artifacts match")
