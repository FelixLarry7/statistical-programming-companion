"""Execute the SQL preparation and native simple OLS checks in DuckDB."""

import argparse
import csv
import json
from pathlib import Path

import duckdb

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def export_query(con, sql, path):
    cursor = con.execute(sql)
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow([col[0] for col in cursor.description])
        writer.writerows(cursor.fetchall())


def check_header(path, expected):
    with path.open(newline='', encoding='utf-8') as stream:
        header = next(csv.reader(stream), None)
    if header != expected:
        raise ValueError(f'{path.name} header differs from the declared schema: {header!r}')


def build(con, raw, target_season):
    plots = raw / 'plots.csv'
    seasons = raw / 'season_records.csv'
    check_header(plots, ['plot_id', 'area_m2'])
    check_header(seasons, ['plot_id', 'season', 'harvest_kg', 'sessions'])
    con.execute('SET threads = 1')
    con.execute('SET VARIABLE plots_path = ?', [str(plots.resolve())])
    con.execute('SET VARIABLE seasons_path = ?', [str(seasons.resolve())])
    con.execute('SET VARIABLE target_season = ?', [target_season])
    con.execute((HERE / 'build.sql').read_text(encoding='utf-8'))


def check_model(con, reverse_args=False):
    source = (HERE / 'check_ols.sql').read_text(encoding='utf-8')
    if reverse_args:
        source = source.replace('regr_slope(yield_kg_ha, sessions)', 'regr_slope(sessions, yield_kg_ha)')
    con.execute(source)


def run(raw, out, target_season):
    out.mkdir(parents=True, exist_ok=True)
    with duckdb.connect(':memory:') as con:
        build(con, raw, target_season)
        check_model(con)
        export_query(con, 'SELECT * FROM analytical ORDER BY plot_id, season', out / 'analytical.csv')
        export_query(con, "SELECT plot_id, season, reason = 'included' AS included, reason "
                          'FROM eligible_rows ORDER BY plot_id, season', out / 'sample_audit.csv')
        export_query(con, 'SELECT * FROM source_issues ORDER BY issue', out / 'source_issues.csv')
        export_query(con, 'SELECT * FROM ols_predictions ORDER BY plot_id, season', out / 'predictions.csv')
        export_query(con, 'SELECT * FROM ols_covariance ORDER BY covariance, parameter_1, parameter_2',
                     out / 'covariance.csv')
        export_query(con, 'SELECT * FROM ols_coefficients ORDER BY covariance, parameter', out / 'coefficients.csv')
        cur = con.execute('SELECT * FROM ols_fit')
        fit = dict(zip((c[0] for c in cur.description), cur.fetchone()))
        (out / 'fit.json').write_text(json.dumps(fit, indent=2, allow_nan=False) + '\n', encoding='utf-8')
        build_version = con.execute('PRAGMA version').fetchone()
        environment = {'duckdb_python': duckdb.__version__, 'engine_version': list(build_version), 'threads': 1,
                       'dialect': 'DuckDB SQL', 'additional_extensions': []}
        (out / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n', encoding='utf-8')
        print(f'DuckDB {duckdb.__version__}: {fit["nobs"]} eligible rows')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('raw', type=Path)
    parser.add_argument('out', type=Path)
    parser.add_argument('--spec', type=Path, default=ROOT / 'spec' / 'pilot.json')
    args = parser.parse_args()
    run(args.raw, args.out, json.loads(args.spec.read_text(encoding='utf-8'))['target_season'])
