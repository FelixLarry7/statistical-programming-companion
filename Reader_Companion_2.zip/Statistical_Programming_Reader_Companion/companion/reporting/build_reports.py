"""Regenerate and audit the baseline and one-record correction reports."""

import argparse
import csv
from hashlib import sha256
import json
import math
from pathlib import Path
import subprocess

import duckdb
import pandas as pd
import statsmodels.api as sm
from scipy.stats import t

ROOT = Path(__file__).resolve().parent
FIELDS = ("estimate", "std_error", "df_resid", "ci_low", "ci_high")
LABELS = {"baseline": "Baseline", "corrected": "Corrected harvest"}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def with_interval(b, se, df):
    q = t.ppf(.975, df)
    return dict(estimate=float(b), std_error=float(se), df_resid=int(df),
                ci_low=float(b-q*se), ci_high=float(b+q*se))


def changed_sample(source, destination):
    base = pd.read_csv(source)
    selected = base["plot_id"].eq("P011") & base["season"].eq(2025)
    if selected.sum() != 1 or base.loc[selected, "harvest_kg"].item() != 782.5:
        raise ValueError("P011 does not match the declared original measurement.")
    changed = base.copy()
    changed.loc[selected, "harvest_kg"] += 10
    changed["yield_kg_ha"] = changed["harvest_kg"] / changed["area_ha"]
    assert changed[["plot_id", "season", "area_ha", "sessions"]].equals(
        base[["plot_id", "season", "area_ha", "sessions"]])
    changed.to_csv(destination, index=False, lineterminator="\n")
    return changed


def fit_python(data):
    fit = sm.OLS(data["yield_kg_ha"], sm.add_constant(data["sessions"])).fit(
        cov_type="HC1", use_t=True)
    return with_interval(fit.params["sessions"], fit.bse["sessions"], fit.df_resid)


def fit_sql(path):
    with duckdb.connect(config={"threads": 1}) as db:
        db.read_csv(str(path)).create_view("data")
        b, variance, df = db.execute("""
            WITH design AS (
              SELECT count(*) AS n, avg(sessions) AS mx,
                     regr_sxx(yield_kg_ha, sessions) AS sxx,
                     regr_intercept(yield_kg_ha, sessions) AS a,
                     regr_slope(yield_kg_ha, sessions) AS b FROM data
            ), scores AS (
              SELECT *, (sessions-mx)*(yield_kg_ha-a-b*sessions) AS g
              FROM data CROSS JOIN design
            )
            SELECT b,n::DOUBLE/(n-2)*sum(g*g)/(sxx*sxx),n-2
            FROM scores GROUP BY b,n,sxx
        """).fetchone()
    return with_interval(b, math.sqrt(variance), df)


def fit_r(path, output, rscript):
    subprocess.run([rscript, "--vanilla", str(ROOT / "scenario_fit.R"), str(path), str(output)],
                   check=True)
    with output.open(newline="") as stream:
        row, = list(csv.DictReader(stream))
    return {k: float(row[k]) for k in FIELDS}


def baseline(b):
    check = json.loads((b / "validation.json").read_text())
    if check["status"] != "VERIFIED":
        raise ValueError("Use the four-environment pilot replay.")
    with (b / "python/coefficients.csv").open(newline="") as stream:
        row, = [r for r in csv.DictReader(stream)
                if r["covariance"] == "HC1" and r["parameter"] == "sessions"]
    return {k: float(row[k]) for k in FIELDS}


def row_values(v):
    return (str(v["n"]), f"{v['estimate']:.2f}", f"{v['std_error']:.2f}",
            f"{v['ci_low']:.2f}", f"{v['ci_high']:.2f}")


def table(registry):
    rows = ["| Scenario | Rows | Slope | HC1 SE | Lower | Upper |",
            "| --- | ---: | ---: | ---: | ---: | ---: |"]
    rows.extend("| " + " | ".join((label, *row_values(registry[key]))) + " |"
                for key, label in LABELS.items())
    return "\n".join(rows)


def audit(text, registry):
    for key, label in LABELS.items():
        match = [line for line in text.splitlines() if line.startswith(f"| {label} |")]
        expected = "| " + " | ".join((label, *row_values(registry[key]))) + " |"
        if match != [expected]:
            raise ValueError(f"Incorrect or duplicate result for scenario {key}")


def publish(base_dir, output, rscript):
    src = base_dir / "duckdb/analytical.csv"
    dst = output / "scenario_analytical.csv"
    data = changed_sample(src, dst)
    fits = {"Python": fit_python(data), "DuckDB": fit_sql(dst),
            "R": fit_r(dst, output / "scenario_r.csv", rscript)}
    checks = []
    for engine in ("DuckDB", "R"):
        for field in FIELDS:
            a, b = fits["Python"][field], fits[engine][field]
            passed = a == b if field == "df_resid" else math.isclose(a, b, abs_tol=1e-8, rel_tol=1e-10)
            checks.append({"engine": engine, "field": field, "reference": a, "value": b, "passed": passed})
    if not all(r["passed"] for r in checks):
        raise ValueError(checks)
    (output / "scenario.json").write_text(json.dumps({
        "input_change": "P011 harvest increases by 10 kg; eligible keys are identical.",
        "input_sha256": {"baseline": digest(src), "corrected": digest(dst)},
        "fits": fits, "comparisons": checks, "stata_scope": "Original baseline input.",
    }, indent=2) + "\n")
    shared = {"covariance": "HC1", "n": len(data), "unit": "kg/ha per recorded session"}
    registry = {
        "baseline": dict(**shared, **baseline(base_dir), input_sha256=digest(src),
                         checked=["Python", "R", "DuckDB", "Stata"]),
        "corrected": dict(**shared, **fits["Python"], input_sha256=digest(dst),
                          checked=["Python", "R", "DuckDB"]),
    }
    (output / "report_values.json").write_text(json.dumps(registry, indent=2) + "\n")
    with (output / "figure_data.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("scenario", "estimate", "lower_95", "upper_95"))
        writer.writerows((key, r["estimate"], r["ci_low"], r["ci_high"]) for key,r in registry.items())
    exhibit = table(registry)
    note = f"""Twelve eligible synthetic plot-seasons from 2025 support an unweighted OLS fit with intercept.
The revised scenario adds 10 kg to plot P011 at 0.5 ha. The eligible keys, area and sessions
are unchanged.

{exhibit}

The slope is in kg/ha per recorded session. Intervals use HC1 and a Student reference with
10 residual degrees of freedom. The original licensed Stata evidence covers the baseline.
Python, R and DuckDB independently check the revised result and its interval.
"""
    tech = ("# Technical note\n\n" + note +
            f"\nBaseline analytical SHA-256: {digest(src)}.\n\nCorrected analytical SHA-256: {digest(dst)}.\n")
    paper = f"""# Advisory sessions and synthetic maize yield

## Research question and methods

How does measured yield vary with recorded sessions in the teaching sample?
Fit an unweighted regression with intercept, using HC1 covariance and a Student reference.

## Results

{exhibit}

The observed slope rises from {registry['baseline']['estimate']:.2f} to {registry['corrected']['estimate']:.2f}
kg/ha per recorded session. Both estimates use the same 12 plot-seasons.

## Interpretation and availability

The fitted relationship describes the synthetic sample. A causal estimate in a real
programme needs independent evidence on attendance, conditions and identification.
The source, figure data and verification record accompany this report.
"""
    for filename, body in (("technical_note.md", tech), ("journal_report.md", paper), ("lab_excerpt.md", note)):
        audit(body, registry)
        (output / filename).write_text(body, encoding="utf-8")
    fault = tech.replace("| Baseline | 12 | 80.00 |", "| Baseline | 12 | 81.43 |", 1)
    try:
        audit(fault, registry)
    except ValueError as exc:
        (output / "audit.json").write_text(json.dumps({
            "generated_reports": 2, "validated_scenarios": 2, "seeded_overwrite_detected": True,
            "diagnostic": str(exc)}, indent=2) + "\n")
    else:
        raise RuntimeError("The reporting audit accepted the seeded overwrite.")
    print("Two reports and figure data generated; ten scenario checks passed; seeded overwrite rejected.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("baseline", type=Path)
    p.add_argument("--output", type=Path, default=ROOT / "outputs")
    p.add_argument("--rscript", default="Rscript")
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    publish(a.baseline.resolve(), a.output.resolve(), a.rscript)
