# Project marking and review notes

Use the common 100-point rubric in `projects/teaching.md`. Each submission must identify its design, population, input versions and executable route. The released worked report supports the baseline. A changed scenario needs its own result keys and evidence.

## P01 Economic growth and macroeconomic forecasting

The small one-year gain in Ghana does not carry over to two years. Choosing a model by target and horizon is more defensible than naming one winner. The conditional MA check is in index log points and uses a different training window. Historical-vintage lab scores do not establish real-time forecast performance.

For the assigned variation, change from the one-year to the two-year growth horizon. Then compare the 2024 calendar-day mean policy rate with the rate on 31 December. Treat the rate as contextual evidence with its own time basis.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P02 Household poverty and welfare measurement

The higher teaching line increases the weighted headcount and raises the average normalised gap. National household and person headcounts differ because the person target gives larger households more representation. These are synthetic teaching rates. The empirical GLSS VII route requires the official welfare and survey files under GSS terms. A higher GHS 3,000 teaching line is included in the sensitivity output.

For the assigned variation, raise the line from GHS 2,200 to GHS 2,600 with the household sample fixed. Then change the weights on the same line and document the target population for each statistic.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P03 Social protection impact evaluation

The observed-case contrast is positive. Its reference interval and the full cohort bounds cross the three-point decision threshold from the chapter protocol, and the latter include zero. Additional follow-up or a credible missingness assumption matters more for expansion than the nominal randomisation probability. LEAP 1000 provides programme context and has its own data access and design.

For the assigned variation, replace the observed-case interpretation with an eligible-cohort claim using the documented completion bounds. Trace what changes when assumptions about missing outcomes are relaxed.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P04 Public health risk and healthcare utilisation

The synthetic residence gap is substantial under the common observed-case definition. Changing the time window changes the sampled target, while the bounds keep the original window and vary the missing responses. Local service planning would require design-matched real data and contextual evidence about barriers and capacity.

For the assigned variation, expand the reference window to 0–35 months as a sensitivity. Compare this result and the missing-location bounds while retaining the primary denominator.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P05 Health insurance and health economics

Positive expenses and full-sample expenses answer different questions. The modelled spending contrast is associational in this fixture. Insurance selection, access to care and severity of need complicate interpretation. The coverage and expenditure estimates come from separate study files and should remain separate results.

For the assigned variation, exclude zero costs solely as a deliberate diagnostic. Compare the positive-only mean with the full mean and quantify the effect of switching the stated estimand.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P06 Bank credit risk and financial performance

The change from AUC 0.835 to 0.996 accompanies 138 future-feature rows. The stronger score is unusable for an ex-ante decision. The federal data are contextual and retrospective here. A live asset-quality deployment needs a time-stamped validation, prevalence monitoring and an independently justified operational threshold.

For the assigned variation, replace the time-valid file by the later restatement, keeping target keys fixed. Count future-feature rows and explain how the availability error changes the apparent score.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P07 Business intelligence and customer analytics

Corrected booked revenue is £295,491.85 in the scoped extract. Repeating balances overstates it by £75,156.93. The trailing mean has lower held-out MAE for the reported product, but transactional quantity may reflect lost sales and stock availability. A commercial rollout calls for fresh calibration.

For the assigned variation, score the last six holdout weeks separately, maintaining their observation keys, and compare with the original twelve-week loss. Trace the effect of counting repeated invoice balances as separate revenue.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P08 Agricultural productivity and technology adoption

Reported area gives a smaller yield ratio on the identical plots. That difference is a measurement effect. The synthetic adoption estimate has a separate paired encouragement design and additional assumptions. A Ghana productivity claim needs a specific survey frame, crop and seasonal measure.

For the assigned variation, substitute reported for GPS area while holding harvest and plot membership fixed. Next apply the positive-harvest restriction and label the sample change separately.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P09 Food security and rural household vulnerability

The frozen weighted shortfall is higher in the synthetic rural domain. The alternative threshold changes the screening rate by design. The exercise indicators do not stand in for a verified CFSVA measurement protocol. Conclusions about actual populations require approved source records and scope alignment.

For the assigned variation, raise the per-person expenditure threshold from 200 to 300 and then compare the change by domain. Retain the recorded shortfall outcome and its definition.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P10 Policy reform and difference-in-differences

The two admissible comparator routes agree at event time zero. The deliberately risky comparator gives a smaller estimate. Comparator choice changes the counterfactual and therefore should be resolved before fitting. A convincing policy design needs substantive evidence about anticipation, comparability and exposure.

For the assigned variation, admit municipal controls during their anticipation window as a controlled failure, then inspect the shock response and event-time estimates under the original eligibility definition.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P11 Regional inequality and spatial development

Both graphs suggest positive clustering in this 16-region display. The statistic changes with the neighbour definition. The inference is conditional on the chosen fixed permutation design and on region-level measures. Maintain the geoBoundaries and OpenStreetMap notices when reusing the geography.

For the assigned variation, switch from rook contiguity to symmetrised three-nearest neighbours on the same regions and percentages. Document the change in weights, edge count and statistic.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.

## P12 Integrated multi-software research publication

The weighted estimate reverses the sign of the equal-weight estimate. The intervals under the four specifications include zero. Ten balanced economies, selected coverage and time-varying confounding limit interpretation. The replication handoff preserves original licensed Stata results and specifies who can rerun each engine.

For the assigned variation, insert the weighted slope under the equal-weight key as a controlled error. Restore the original result and explain why its estimand and interval differ from the weighted fit.

The project pack provides `specification.json`, `inputs.csv`, `engine_routes.csv`, `baseline_results.csv` and `worksheet.md`. Match each result to those fields. Award interpretation credit for a conclusion that follows from the declared outcome, units, uncertainty and decision target.
