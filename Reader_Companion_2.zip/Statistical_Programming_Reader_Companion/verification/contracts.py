"""Check the fixed schemas and same-engine regression references."""

from collections import Counter
import csv
from decimal import Decimal, InvalidOperation
from hashlib import file_digest
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PARTS = "I II III IV V VI VII VIII IX X".split()
ENGINE_NAMES = ("python", "r", "duckdb", "stata")
EXPECTED_COMPARISONS = dict(zip(PARTS[:9], (449, 1720, 6870, 8232, 9514, 15687, 12149, 7074, 20215), strict=True))


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def table(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        columns = next(reader, [])
        if not columns or any(not key.strip() for key in columns) or len(columns) != len(set(columns)):
            raise ValueError(f"Invalid header in {path}.")
        records = []
        for line, row in enumerate(reader, 2):
            if len(row) != len(columns):
                raise ValueError(f"Incorrect field count in {path}, line {line}.")
            records.append(dict(zip(columns, row, strict=True)))
    return columns, records


def number(value):
    try:
        numeric = Decimal(value)
    except InvalidOperation as error:
        raise ValueError(f"Invalid number: {value}") from error
    if not numeric.is_finite():
        raise ValueError(f"Non-finite number: {value}")
    return numeric


def keyed(path, columns, keys, numbers):
    observed, rows = table(path)
    if observed != list(columns):
        raise ValueError(f"Unexpected CSV header in {path}: {observed}.")
    indexed = {}
    for row in rows:
        identity = tuple(row[field] for field in keys)
        if any(field == "" for field in identity):
            raise ValueError(f"Missing key in {path}: {identity}.")
        if identity in indexed:
            raise ValueError(f"Duplicate key in {path}: {identity}.")
        indexed[identity] = tuple(number(row[field]) for field in numbers)
    return indexed


def compare_keys(current, expected, limits, name):
    if current.keys() != expected.keys():
        raise ValueError(f"{name} key set changed. Missing {sorted(expected.keys()-current.keys())[:3]}, "
                         f"extra {sorted(current.keys()-expected.keys())[:3]}.")
    max_error = Decimal(0)
    for identity, old in expected.items():
        differences = [abs(a-b) for a, b in zip(current[identity], old, strict=True)]
        if any(error > limit for error, limit in zip(differences, limits[identity], strict=True)):
            raise ValueError(f"{name} value changed beyond the recorded limit at {identity}.")
        max_error = max(max_error, *differences)
    return str(max_error)


def metric_layout(part):
    if part == "I":
        return ("chapter", "metric", "grp"), "{engine}.csv"
    if part in {"II", "III"}:
        return ("chapter", "metric", "key"), "{engine}.csv" if part == "II" else "{engine}/metrics.csv"
    return ("chapter", "model", "quantity", "key"), "{engine}/metrics.csv"


def part3_limits(base):
    # These metrics use the Part III verifier's exact rule.
    exact = set("count missing yield_id pair_n pair_id group_n bin interval_n interval_df shifted_rainfed universe_id domain_n denominator weighted_total design_df trimmed_psus".split())
    return {key: (Decimal(0) if key[1] in exact else Decimal("1e-8") + Decimal("1e-10") * abs(value[0]),)
            for key, value in base.items()}


def metric_limits(part, base, comparison_rows, key_fields):
    if part == "III":
        return part3_limits(base)
    limits = {}
    for row in comparison_rows:
        key = tuple(row[name] for name in key_fields)
        allowance = number(row["tolerance"])
        limits[key] = min(allowance, limits.get(key, allowance))
    if not base.keys() <= limits.keys():
        raise ValueError(f"The Part {part} reference lacks a tolerance for a metric.")
    return {key: (limits[key],) for key in base}


def chapter_counts(part, comparisons):
    counts = Counter()
    for row in comparisons:
        if part != "III":
            counts[row["chapter"]] += 1
        elif row["group"] == "fixed":
            counts["CH11"] += 1
        else:
            label = row["key"].split("/", 1)[0]
            if label in {"CH09", "CH10", "CH11", "CH12"}:
                counts[label] += 1
            else:
                raise ValueError(f"Unknown Chapter 9–12 result key: {row['key']}.")
    return dict(sorted(counts.items()))


def verify_part(part, result, reference):
    structure, comparisons = table(result / "comparisons.csv")
    old_structure, old_comparisons = table(reference / "comparisons.csv")
    expected = EXPECTED_COMPARISONS[part]
    if structure != old_structure or len(comparisons) != expected or len(old_comparisons) != expected:
        raise ValueError(f"Part {part} comparison ledger changed scope or schema.")
    for row in comparisons:
        if "passed" in row and row["passed"].lower() != "true":
            raise ValueError(f"Unpassed comparison in Part {part}: {row}.")
        for field in ("observed", "expected", "reference", "value", "python", "difference",
                      "absolute_difference", "abs_error", "tolerance"):
            if field in row:
                number(row[field])
    key_fields, pattern = metric_layout(part)
    results = {}
    for engine in ENGINE_NAMES:
        artifact = pattern.format(engine=engine)
        current_file, reference_file = result / artifact, reference / artifact
        if engine == "stata" and digest(current_file) != digest(reference_file):
            raise ValueError(f"Licensed outputs changed for Part {part}.")
        fields = (*key_fields, "value")
        current = keyed(current_file, fields, key_fields, ("value",))
        base = keyed(reference_file, fields, key_fields, ("value",))
        limit = metric_limits(part, base, old_comparisons, key_fields)
        maximum = compare_keys(current, base, limit, f"Part {part}, {engine}")
        results[engine] = {"rows": len(current), "sha256": digest(current_file),
                           "byte_identical": digest(current_file) == digest(reference_file),
                           "max_same_engine_difference": maximum,
                           "status": "archived_licensed_evidence" if engine == "stata" else "executed"}
    return {"comparisons": expected, "failures": 0, "comparisons_by_chapter": chapter_counts(part, comparisons),
            "metrics": results, "comparison_schema": structure}


def json_value(path):
    return json.loads(path.read_text())


def part10_checks(result):
    pilot = json_value(result / "pilot_licensed/validation.json")
    if (pilot["reference_check_count"], pilot["pairwise_check_count"],
        pilot["failed_pairwise_checks"], pilot["sample"]["included"]) != (364, 510, 0, 12):
        raise ValueError("Pilot verification counts differ from the baseline.")
    for filename, count in (("reference_checks.csv", 364), ("cross_environment.csv", 510)):
        _, rows = table(result / "pilot_licensed" / filename)
        if len(rows) != count or any(row["passed"].lower() != "true" for row in rows):
            raise ValueError(f"Pilot comparison failed in {filename}.")
    stable = json_value(result / "pilot_stability.json")
    if len(stable) != 15:
        raise ValueError("The pilot clean-run file count changed.")
    reporting = json_value(result / "reporting/audit.json")
    if not reporting.get("seeded_overwrite_detected") or reporting["generated_reports"] != 2:
        raise ValueError("The reporting negative control failed.")
    values = json_value(result / "reporting/report_values.json")
    actual = tuple(round(values[name]["estimate"], 2) for name in ("baseline", "corrected"))
    if actual != (80.00, 81.43):
        raise ValueError("The two published scenario values changed.")
    disclosure = json_value(result / "disclosure/disclosure_audit.json")
    if (len(disclosure["seeded_faults_detected"]) != 2 or disclosure["corrected_archive_issues"] or
            len(disclosure["public_members"]) != 6):
        raise ValueError("The disclosure acceptance criteria failed.")
    corrected = json_value(result / "capstone_report/review_record.json")
    if (corrected["corrected_comparisons"], corrected["correction_failures"]) != (24, 0):
        raise ValueError("The capstone report correction failed.")
    return {"pilot_reference": 364, "pilot_pairwise": 510, "pilot_stable_files": 15,
            "reporting_values": list(actual), "reporting_seeded_overwrite_rejected": True,
            "disclosure_seeded_faults_rejected": 2, "disclosure_public_files": 6,
            "capstone_corrected_fields": 24, "capstone_replay_comparisons": 20215}
