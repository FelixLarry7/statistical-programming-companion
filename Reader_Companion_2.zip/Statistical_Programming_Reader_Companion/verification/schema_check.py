"""Validate the versioned CSV output interfaces against a completed run."""

import argparse
from itertools import product
import json
from pathlib import Path

from contracts import number, table


HERE = Path(__file__).resolve().parent


def expand(item):
    dimensions = [key for key in ("part", "engine") if key in item]
    for values in product(*(item[key] for key in dimensions)):
        yield item["path"].format(**dict(zip(dimensions, values, strict=True)))


def validate_value(value, kind):
    if kind == "text":
        return value.strip() != ""
    if kind == "flag":
        return value in {"0", "1", "0.0", "1.0"}
    if kind == "boolean":
        return value.lower() in {"true", "false", "0", "1"}
    if kind == "nullable_number" and value == "":
        return True
    result = number(value)
    return kind != "integer" or result == result.to_integral_value()


def check_output(output, require_forest):
    spec = json.loads((HERE/"output_schema.json").read_text())
    counts = {}
    for interface in spec["interfaces"]:
        if interface["path"].startswith("ch28_causal_forest/") and not require_forest:
            continue
        fields = interface["fields"]
        for name in expand(interface):
            columns, rows = table(output/name)
            if columns != list(fields) or not rows:
                raise ValueError(f"Unexpected header or empty output in {name}.")
            seen = set()
            for row in rows:
                key = tuple(row[field] for field in interface["key"])
                if key in seen or not all(k.strip() for k in key):
                    raise ValueError(f"Missing or duplicate output key in {name}: {key}.")
                seen.add(key)
                for field, kind in fields.items():
                    if not validate_value(row[field], kind):
                        raise ValueError(f"Invalid {kind} in {name}: {field} at {key}.")
                if name == "disclosure/public_domains.csv":
                    present = [bool(row[field]) for field in ("estimate","lower_95","upper_95")]
                    if present != [row["status"] == "Released"] * 3:
                        raise ValueError(f"Disclosure fields disagree with release status for {key}.")
            counts[name] = len(rows)
    return counts


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--forest", action="store_true")
    args = parser.parse_args()
    counts = check_output(args.output, args.forest)
    print(json.dumps({"validated_csvs": len(counts), "validated_rows": sum(counts.values()),
                      "rows_by_file": counts}, indent=2))
