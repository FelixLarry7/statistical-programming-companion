"""Run the data-reading cells distributed with the Chapter 38 reports."""

import json
from pathlib import Path
import re
import shutil

from contracts import ROOT


def check(job):
    docs = ROOT / "companion/reporting"
    rendered = job.output / "reporting"
    workspace = job.scratch / "report_examples"
    workspace.mkdir()
    (workspace / "outputs").mkdir()
    for name in ("report_values.json", "figure_data.csv"):
        shutil.copy2(rendered/name, workspace/"outputs"/name)
    notebook = json.loads((docs/"read_evidence.ipynb").read_text())
    cells = [cell for cell in notebook["cells"] if cell["cell_type"] == "code"]
    if not cells or any(cell["outputs"] or cell["execution_count"] is not None for cell in cells):
        raise ValueError("The teaching notebook needs clean, executable cells.")
    script = workspace/"read_evidence.py"
    script.write_text("\n\n".join("".join(cell["source"]) for cell in cells) + "\n")
    nb = job.run("ch38_notebook_cells", [job.python, script], cwd=workspace)
    if not all(line in nb.read_text().splitlines() for line in ("baseline 80.0", "corrected 81.43")):
        raise ValueError("The notebook reported incorrect scenario values.")
    source = (docs/"read_evidence.Rmd").read_text()
    chunks = re.findall(r"(?ms)^~~~\{r[^\n]*\}\n(.*?)^~~~$", source)
    if not chunks:
        raise ValueError("No R Markdown code chunk found.")
    rfile = workspace/"read_evidence.R"
    rfile.write_text('params <- list(evidence="outputs/figure_data.csv")\n' + "\n".join(chunks))
    rlog = job.run("ch38_r_markdown_chunks", [job.rscript, "--vanilla", rfile], cwd=workspace)
    if not all(re.search(rf"(?m)^\s*{name}\s+{value}\b", rlog.read_text())
               for name, value in (("baseline", r"80\.00"), ("corrected", r"81\.43"))):
        raise ValueError("The R Markdown example reported incorrect scenario values.")
    text = (docs/"reader_lab.qmd").read_text()
    blocks = re.findall(r"(?ms)^~~~python\n(.*?)^~~~$", text)
    if not blocks:
        raise ValueError("No Python listing in the reader lab.")
    lab = workspace/"reader_lab.py"
    lab.write_text("\n".join(blocks))
    qmd = job.run("ch38_quarto_listing", [job.python, lab], cwd=workspace)
    if "80.00" not in qmd.read_text().splitlines():
        raise ValueError("The reader lab reported an incorrect baseline.")
    return {"notebook_code_cells":len(cells), "r_markdown_code_chunks":len(chunks),
            "quarto_python_listings":len(blocks)}
