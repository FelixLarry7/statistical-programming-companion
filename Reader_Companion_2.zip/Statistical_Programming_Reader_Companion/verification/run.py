"""Run the book companion in fresh directories with matched licensed evidence."""

import argparse
import csv
from datetime import datetime, timezone
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from time import monotonic

from contracts import PARTS, ROOT, compare_keys, digest, keyed, part10_checks, table, verify_part
from chapter_coverage import build_coverage, listing_checks
from decimal import Decimal
from document_examples import check as check_documents


FIRST = dict(zip(PARTS, range(1, 41, 4), strict=True))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


class Execution:
    def __init__(self, output, rscript, python):
        self.output = output
        self.rscript = rscript
        self.python = python
        self.env = os.environ | {"TZ": "UTC", "PYTHONDONTWRITEBYTECODE": "1", "MPLBACKEND": "Agg",
                                 "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        self.jobs = []
        self.started = datetime.now(timezone.utc).isoformat()
        self.scratch = None
        output.mkdir(parents=True, exist_ok=False)
        (output / "logs").mkdir()

    def run(self, name, command, cwd=None):
        if any(r["job"] == name for r in self.jobs):
            raise ValueError(f"Duplicate execution job: {name}")
        cwd = cwd or ROOT
        log = self.output / "logs" / f"{name}.log"
        command = list(map(str, command))
        start = monotonic()
        with log.open("wb") as stream:
            stream.write((f"Command: {shlex.join(command)}\nWorking directory: {cwd}\n\n").encode())
            stream.flush()
            try:
                result = subprocess.run(command, cwd=cwd, env=self.env, stdout=stream,
                                        stderr=subprocess.STDOUT, check=False)
                status = result.returncode
            except OSError as error:
                stream.write(str(error).encode())
                status = 127
        self.jobs.append({"job": name, "exit_code": status, "elapsed_seconds": round(monotonic()-start, 3),
                          "log": log.relative_to(self.output).as_posix()})
        write_json(self.output / "execution_log.json", self.jobs)
        if status:
            raise RuntimeError(f"{name} exited with status {status}. Read {log}.")
        return log

    def restore_tag(self, label, bundle, tag):
        checkout = self.scratch / label
        self.run(f"{label}_checkout", ["git", "clone", "--quiet", "--branch", tag, bundle, checkout])
        commit = subprocess.check_output(["git", "-C", checkout, "rev-parse", "HEAD"], text=True).strip()
        return checkout, {"tag": tag, "commit": commit, "bundle_sha256": digest(bundle)}

    def record_environment(self):
        names = dict(sorted((d.metadata["Name"], d.version) for d in metadata.distributions()))
        sys_record = {"system": platform.system(), "architecture": platform.machine(),
                      "release": platform.release(), "python": platform.python_version(),
                      "executable": sys.executable, "packages": names, "sqlite": sqlite3.sqlite_version,
                      "locale": self.env.get("LC_ALL") or self.env.get("LANG"),
                      "timezone": self.env["TZ"], "omp_threads": self.env["OMP_NUM_THREADS"]}
        write_json(self.output / "environment.json", sys_record)
        self.run("r_runtime", [self.rscript, "--vanilla", ROOT/"environments/session.R"])


def validate_frozen_inputs():
    _, snapshot = table(ROOT / "data/catalog/dataset_catalogue.csv")
    for table_row in snapshot:
        path = ROOT / table_row["path"]
        if digest(path) != table_row["sha256"]:
            raise ValueError(f"Stage 4 input changed: {table_row['path']}")
    return len(snapshot)


def part_run(job, part):
    project = ROOT / "chapter_companions" / f"Part_{part}"
    source = project / "companion"
    results = job.output / f"Part_{part}"
    driver = "run.py" if FIRST[part] < 13 else "verify.py"
    if part == "I":
        evidence = ["--stata-results", source/"evidence/local_stata"]
    else:
        replay = "evidence/stata_evidence_replay.zip" if part == "II" else "evidence/stata/evidence_replay.zip"
        evidence = ["--require-four", "--stata-evidence", source/replay]
    job.run(f"part_{part}", [job.python, source/driver, "--output", results,
                           "--rscript", job.rscript, *evidence], cwd=source)
    result = verify_part(part, results, source/"evidence")
    result["chapter_range"] = [FIRST[part], FIRST[part] + 3]
    result["runner"] = (source/driver).relative_to(ROOT).as_posix()
    if part == "II":
        job.run("ch07_sqlite", [job.python, source/"sqlite_ch07.py", "--duckdb-output", results/"sample_ledger",
                              "--output", job.output/"ch07_sqlite"])
    if part == "VII":
        job.run("part_VII_diagnostics", [job.python, source/"teaching_diagnostics.py", source/"data",
                                      results, results/"diagnostics"])
    if part == "IX":
        job.run("part_IX_reports", [job.python, project/"projects/build_reports.py", "--metrics",
                                 results/"python/metrics.csv", "--output", job.output/"project_reports"])
    return result


def forest_run(job):
    source = ROOT / "chapter_companions/Part_VII/companion"
    forest = job.output / "ch28_causal_forest"
    job.run("ch28_forest", [job.rscript, "--vanilla", source/"causal_forest.R", source/"data", forest])
    job.run("ch28_forest_audit", [job.python, source/"forest_audit.py", source/"data",
                                job.output/"Part_VII/python/metrics.csv", forest/"forest_holdout.csv",
                                forest/"audit"])
    keys = ("person", "fold")
    items = ("effect", "se")
    base = keyed(source/"evidence/optional_forest/forest_holdout.csv", (*keys,*items), keys, items)
    current = keyed(forest/"forest_holdout.csv", (*keys,*items), keys, items)
    allowed = {k: tuple(Decimal("2e-8") * (1 + abs(value)) for value in numbers)
               for k, numbers in base.items()}
    difference = compare_keys(current, base, allowed, "Chapter 28 optional forest")
    return {"rows": len(current), "max_difference": difference,
            "tolerance": "2e-8 + 2e-8 times absolute reference value"}


def part10_run(job):
    source = ROOT / "companion"
    info = {}
    pilot, info["pilot"] = job.restore_tag("pilot_source", source/"pilot/evidence/pilot-source.bundle",
                                           "stage3-part-x-pilot-v1")
    capstone, info["capstone"] = job.restore_tag("capstone_source", source/"capstone/outputs/capstone-source.bundle",
                                                 "stage3-part-x-capstone-v1")
    for name in ("pilot_first", "pilot_second", "pilot_licensed"):
        evidence = ["--licensed-evidence", pilot/"stata/evidence"] if name == "pilot_licensed" else []
        job.run(name, [job.python, pilot/"ci/check.py", "--rscript", job.rscript,
                       "--output", job.output/name, *evidence], cwd=pilot)
    job.run("pilot_compare", [job.python, pilot/"ci/compare_runs.py", job.output/"pilot_first",
                            job.output/"pilot_second", job.output/"pilot_stability.json"])
    job.run("ch38_reports", [job.python, source/"reporting/build_reports.py", job.output/"pilot_licensed",
                           "--output", job.output/"reporting", "--rscript", job.rscript])
    job.run("ch39_disclosure", [job.python, source/"governance/build_release.py",
                              "--output", job.output/"disclosure"])
    job.run("ch40_tagged_replay", [job.python, capstone/"verify.py", "--output", job.output/"capstone_replay",
                                 "--rscript", job.rscript, "--require-four", "--stata-evidence",
                                 capstone/"evidence/stata/evidence_replay.zip"])
    verify_part("IX", job.output/"capstone_replay", source/"capstone/part_ix/evidence")
    job.run("ch40_corrected_report", [job.python, source/"capstone/review_study.py", "--evidence",
                                    job.output/"capstone_replay", "--output", job.output/"capstone_report"])
    reports = check_documents(job)
    return part10_checks(job.output) | {"source_tags": info, "document_examples": reports}


def artifact_index(output):
    path = output / "artifacts.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["path", "sha256", "bytes"])
        for file in sorted(output.rglob("*")):
            if file.is_file() and file != path:
                writer.writerow([file.relative_to(output).as_posix(), digest(file), file.stat().st_size])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New execution directory.")
    parser.add_argument("--part", action="append", choices=PARTS, help="Repeat to select several parts.")
    parser.add_argument("--rscript", default=shutil.which("Rscript"), help="Path to an installed Rscript.")
    parser.add_argument("--forest", action="store_true", help="Run the optional Chapter 28 grf example.")
    args = parser.parse_args()
    selected = [p for p in PARTS if not args.part or p in args.part]
    if not args.rscript:
        parser.error("Supply an Rscript executable with --rscript.")
    if args.forest and "VII" not in selected:
        parser.error("--forest requires Part VII.")
    if args.output.exists():
        parser.error("Choose a new output directory.")
    rscript = str(Path(args.rscript).resolve())
    job = Execution(args.output.resolve(), rscript, Path(sys.executable))
    result = {"started_utc": job.started, "status": "RUNNING", "selected_parts": selected, "parts": {},
              "fresh_engines": ["Python", "R", "DuckDB"],
              "stata_scope": "Original licensed Stata evidence validated against the matching inputs and driver"}
    try:
        result["frozen_tables"] = validate_frozen_inputs()
        job.run("regression_tests", [job.python, "-m", "unittest", "discover", "-s",
                                     ROOT/"verification/tests", "-v"])
        job.record_environment()
        with tempfile.TemporaryDirectory(prefix="textbook-stage5-") as scratch:
            job.scratch = Path(scratch)
            for part in selected:
                result["parts"][part] = part10_run(job) if part == "X" else part_run(job, part)
            if args.forest:
                result["optional_causal_forest"] = forest_run(job)
            if selected == PARTS:
                listing_checks(job)
                result["coverage"] = build_coverage(job.output, result["parts"])
                self_check = ROOT/"verification/schema_check.py"
                arguments = ["--forest"] if args.forest else []
                schema_log = job.run("output_schema", [job.python, self_check, job.output, *arguments])
                result["output_schema"] = json.loads(schema_log.read_text().split("\n\n", 1)[1])
        result["primary_comparisons_parts_I_to_IX"] = sum(r["comparisons"] for p, r in result["parts"].items() if p != "X")
        result["status"] = "PASSED"
    except Exception as error:
        result["status"] = "FAILED"
        result["error"] = str(error)
        raise
    finally:
        write_json(job.output/"run_summary.json", result)
        artifact_index(job.output)
    print(f"{result['status']}: {len(selected)} part(s), {result['primary_comparisons_parts_I_to_IX']:,} primary comparisons.")


if __name__ == "__main__":
    main()
