# Chapter code and testing

The book runner executes each part's original independent entry points.
It guarantees a fresh output directory, captures the effective Python and
R environments and checks the case input fingerprints before fitting.
It uses the original licensed Stata archives for the matched inputs and
drivers. The Stata outputs are checked byte for byte against the earlier
release. Their execution status means archived licensed evidence in the
Stage 5 report and coverage register.

| File or directory | What to inspect |
| --- | --- |
| run.py | End-to-end execution including the tagged pilot and capstone |
| tests/ | Failure cases for malformed ledgers, wrong keys, nonfinite values and SQLite reconciliation |
| contracts.py | Same-engine regression against the archived results with the existing limits |
| output_schema.json | Declared output types, order, keys and rules |
| schema_check.py | Checks the actual CSV interfaces |
| evidence/run_summary.json | Counts, status, per-engine differences and tag hashes |
| evidence/chapter_coverage.csv | Every chapter's source, job, method scope and primary comparisons |
| evidence/listing_coverage.csv | Mapping for the 79 printed listings including contextual excerpts |
| evidence/logs/ | Commands, standard output and diagnostics |
| evidence/artifacts.csv | Observed output fingerprints |
| evidence/Part_I through Part_IX | Engine-specific results and comparisons |
| evidence/pilot_licensed through capstone_report | Pilot, reporting, disclosure and capstone evidence |

The core count adds the original cross-environment checks and independent
anchors for Parts I–IX once. The repeated tagged Part IX capstone replay
and the 24 corrected report fields are recorded separately. In Chapter 11,
shared-draw checks compare pointwise finite quantities. The independent
simulation streams retain separate seeds and coverage diagnostics.
The dedicated Linux wheel lock applies to the observed platform.

Run the schema verifier against fresh output by passing its directory.
Add **--forest** when the optional Chapter 28
prediction job was part of that run.

~~~sh
python verification/schema_check.py build/clean-check
python -m unittest discover -s verification/tests -v
~~~

Case workbooks and scientific validity are addressed by their own design
documents and the subsequent blueprint stages.
