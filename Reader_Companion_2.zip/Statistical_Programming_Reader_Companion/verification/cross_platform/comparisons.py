"""Rebuild the numerical comparison records from identified engine outputs."""
from collections import Counter
from decimal import Decimal
from itertools import combinations
import json
from pathlib import Path
import runpy
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from contracts import EXPECTED_COMPARISONS, ROOT, keyed, metric_layout, number, table

EXACT = {
    "I": set("""invoices net_minor valid_keys distinct_keys usable rank_code value_state float32_loss
                draw_lt_half eligible sample_n settled_events gross_minor refund_minor join_rows
                inflated_net_minor excess_minor design_rank sum_order target_n missing_outcome""".split()),
    "III": set("""count missing yield_id pair_n pair_id group_n bin interval_n interval_df shifted_rainfed
                  universe_id domain_n denominator weighted_total design_df trimmed_psus""".split()),
    "VII": set("""n events n_all n_train n_train_id n_test_id tp fp tn fn missing missing_labels non_events
                  chosen publish bin_n validation_n last_label_month first_test_month future_violations
                  fold_n fold_train fold_treat fold_train_treat treated group_tp group_fp group_tn group_fn""".split()),
    "VIII": set("""available selected days records window missing observed n df events censor risk bin_n filings
                   quarter_rows outcome_rows excluded merged_in_scope rename_in_scope n_train train_events
                   late_features tp fp tn fn buyers repeat households plots maize usable missing_harvest zero
                   intercropped bag_units n_rural missing_rural pairs n_association positive""".split()),
    "IX": set("""n obs lines sales cancel other omitted anonymous invoices gross cancel_value net repeated_total
                 overcount booked returned void linked valid_originals changed_n screened eligible observed
                 missing reason demand invoice pairs villages wdi pwt good unmatched countries k df yes psus
                 households need known covered status events""".split()),
}
RULES = {
    "exact": ("0", "0", "exact"),
    "part_II": ("1e-10", "1e-12", "symmetric"),
    "general": ("1e-8", "1e-10", "symmetric"),
    "part_IV_anchor_ols": ("2e-8", "1e-9", "reference"),
    "part_IV_duckdb": ("1.5e-5", "2e-8", "reference"),
    "part_IV_native": ("2e-6", "2e-5", "reference"),
    "part_V": ("3e-8", "3e-8", "reference"),
    "parts_VI_IX": ("2e-8", "2e-8", "reference"),
    "pilot_probability": ("1e-12", "1e-8", "symmetric"),
}
ENGINES = ("duckdb", "python", "r", "stata")
PILOT_EXACT = {"nobs", "rank", "df_resid", "sessions", "yield_kg_ha", "reject_at_alpha"}


def metrics(part, folder, engine):
    columns, template = metric_layout(part)
    path = folder / template.format(engine=engine)
    return {k: v[0] for k, v in keyed(path, (*columns, "value"), columns, ("value",)).items()}


def anchor_values(part, folder):
    base = ROOT / f"chapter_companions/Part_{part}/companion"
    module = {"I": "run.py", "II": "anchors.py", "III": "reference.py"}.get(part, "verify.py")
    sys.path.insert(0, str(base))
    try:
        symbols = runpy.run_path(str(base / module))
        function = {"II": "reference", "IV": "hand_anchors"}.get(part, "anchors")
        values = symbols["ANCHORS"] if part == "I" else symbols[function]()
    finally:
        sys.path.remove(str(base))
    anchor = {key: number(str(value)) for key, value in values.items()}
    if part == "II" and metrics(part, folder, "reference") != anchor:
        raise ValueError("Part II reference output differs from the design-derived answers")
    return anchor


def rule_for(part, identity, candidate):
    if part == "I":
        return "exact" if identity[1] in EXACT[part] else "general"
    if part == "II":
        return "part_II" if identity[1] in {"scale", "z_train", "z_full", "share"} else "exact"
    if part == "III":
        return "exact" if identity[1] in EXACT[part] | {"cover_t", "cover_z"} else "general"
    chapter, _, quantity, key = identity
    name = key if quantity == "scalar" else quantity
    if part == "IV":
        if quantity in {"risk", "events", "censored"} or (quantity == "scalar" and key in {"n", "rank", "df", "groups"}):
            return "exact"
        if candidate == "anchor" or chapter == "CH13":
            return "part_IV_anchor_ols"
        return "part_IV_duckdb" if candidate == "duckdb" else "part_IV_native"
    if part == "V":
        exact = {"target_n", "control_n", "event_n", "support", "left_n", "right_n", "arm_n", "arm_measured"}
        counts = {"n", "roster", "villages", "permutations", "extreme", "treated", "treated_villages"}
        return "exact" if quantity in exact or (quantity == "scalar" and key in counts) else "part_V"
    if part == "VI":
        counts = {"n", "groups", "singletons", "df", "edges", "clusters", "extreme", "ri_extreme", "wild_extreme"}
        return "exact" if quantity in {"n", "used"} or (quantity == "scalar" and key in counts) else "parts_VI_IX"
    if part == "IX" and quantity in {"scalar", "value", "endpoint", "snapshot"}:
        name = key.rsplit("/", 1)[-1]
    return "exact" if name in EXACT[part] else "parts_VI_IX"


def precision_agrees(stored, expected):
    # Prior verifier CSVs display binary floats. This allowance applies only to
    # checking their recorded arithmetic, independently of the comparison gate.
    return abs(number(stored) - expected) <= Decimal("2e-14") * abs(expected)


def result(scope, identity, ref, other, expected, observed, rule, source, recorded=None, decimal_input=False):
    chapter, *fields = identity
    model, quantity, key = fields if len(fields) == 3 else ("", *fields)
    absolute, relative, method = RULES[rule]
    symmetric = max(abs(expected), abs(observed))
    bound = Decimal(absolute) + Decimal(relative) * (abs(expected) if method == "reference" else symmetric)
    symmetric_bound = Decimal(absolute) + Decimal(relative) * symmetric
    gap = abs(expected - observed)
    label = f"{scope} {identity} {ref}/{other}"
    if gap > bound:
        raise ValueError(f"{label}: observed error {gap} exceeds the frozen limit {bound}")
    if recorded:
        left, right, stated_gap, stated_limit, passed = recorded
        cast = Decimal if decimal_input else float
        if tuple(map(cast, (left, right))) != tuple(map(cast, (expected, observed))):
            raise ValueError(f"{label}: recorded values differ from the keyed outputs")
        original_gap = gap if decimal_input else Decimal(str(abs(float(left) - float(right))))
        if not precision_agrees(stated_gap, original_gap):
            raise ValueError(f"{label}: recorded arithmetic differs")
        if passed != "True" or (stated_limit is not None and not precision_agrees(stated_limit, bound)):
            raise ValueError(f"{label}: recorded decision or limit differs")
    return dict(scope=scope, chapter=chapter, model=model, quantity=quantity, key=key,
                reference=ref, candidate=other, expected=expected, observed=observed, abs_error=gap,
                rule=rule, limit=bound, symmetric_limit=symmetric_bound,
                fraction_of_limit=f"{gap / bound:.12g}" if bound else "0", passed=True, source=source)


def lookup_specs(part, folder):
    raw = {e: metrics(part, folder, e) for e in ENGINES}
    anchor = anchor_values(part, folder)
    base = raw["duckdb" if part in {"I", "II", "III"} else "python"]
    if not anchor.keys() <= base.keys():
        raise ValueError(f"Part {part}: anchor key has no equivalent engine output")
    for engine, data in raw.items():
        if engine == "duckdb" and part not in {"I", "II", "III"}:
            assert data.keys() <= base.keys()
        else:
            assert data.keys() == base.keys(), (part, engine)
    if part in {"I", "II"}:
        ref = "anchor" if part == "I" else "reference"
        anchors = {(ref, e): (anchor, raw[e], anchor.keys()) for e in ENGINES}
        pairs = (("duckdb", e) for e in ENGINES[1:]) if part == "I" else combinations(ENGINES, 2)
        return anchors | {(a, b): (raw[a], raw[b], base.keys()) for a, b in pairs}
    if part == "III":
        return {("anchor", "duckdb"): (anchor, base, anchor.keys())} | {
            ("duckdb", e): (base, raw[e], base.keys()) for e in ENGINES[1:]
        }
    return {("python", "anchor"): (base, anchor, anchor.keys())} | {
        ("python", e): (base, raw[e], raw[e].keys()) for e in ("r", "duckdb", "stata")
    }


def primary_row(part, row):
    if part in {"I", "II"}:
        left, right = (s.lower() for s in row["comparison"].split(" vs "))
        ref, cand = (("anchor" if right == "anchors" else right), left) if part == "I" or right == "reference" else (left, right)
        identity = (row["chapter"], row["metric"], row["grp" if part == "I" else "key"])
        return ref, cand, identity, (row["expected"], row["observed"],
                                    row["absolute_difference" if part == "I" else "difference"], row["tolerance"], row["passed"])
    if part == "III":
        ref = "anchor" if row["group"] == "anchor" else "duckdb"
        identity = tuple(row["key"].split("/", 2))
        if row["group"] == "fixed":
            replicate, quantity = row["key"].rsplit("/", 1)
            identity = ("CH11", "fixed draws", quantity, replicate)
        return ref, row["engine"], identity, (row["reference"], row["observed"], row["abs_error"], None, "True")
    identity = tuple(row[s] for s in ("chapter", "model", "quantity", "key"))
    return "python", row["engine"], identity, (row["python"], row["value"], row["abs_error"], row["tolerance"], row["passed"])


def fixed_draws(folder):
    keys = ("design", "n", "replicate")
    fields = ("mean", "sd", "lower_t", "upper_t", "lower_z", "upper_z", "cover_t", "cover_z")
    raw = {e: keyed(folder / e / "fixed.csv", (*keys, *fields), keys, fields) for e in ENGINES}
    base = raw["duckdb"]
    if len(base) != 256 or any(values.keys() != base.keys() for values in raw.values()):
        raise ValueError("Part III fixed draws lack the full shared key set")
    flat = {e: {("CH11", "fixed draws", field, "/".join(k)): v
                for k, data in pairs.items() for field, v in zip(fields, data, strict=True)}
            for e, pairs in raw.items()}
    return {("duckdb", e): (flat["duckdb"], flat[e], flat[e].keys()) for e in ENGINES[1:]}


def audit_primary(part, base, scope, required_count):
    folder = base / scope
    routes = lookup_specs(part, folder)
    expected = {(a,b,k) for (a,b), (_,_,keys) in routes.items() for k in keys}
    fixed = fixed_draws(folder) if part == "III" else {}
    expected |= {(a,b,k) for (a,b), (_,_,keys) in fixed.items() for k in keys}
    _, original_rows = table(folder / "comparisons.csv")
    reconstructed = []
    for row in original_rows:
        ref, cand, identity, recorded = primary_row(part, row)
        expected.remove((ref, cand, identity))
        x, y, _ = (fixed if part == "III" and row["group"] == "fixed" else routes)[ref, cand]
        rule_id = rule_for(part, (identity[0], identity[2], identity[3]) if len(identity) == 4 and part == "III" else identity, cand)
        reconstructed.append(result(scope, identity, ref, cand, x[identity], y[identity], rule_id,
                                    f"{scope}/comparisons.csv", recorded, decimal_input=(part == "II")))
    if expected or len(reconstructed) != required_count:
        raise ValueError(f"{scope}: incomplete comparison identities or inconsistent count")
    return reconstructed


def pilot_tables(directory):
    fit = json.loads((directory / "fit.json").read_text())
    result = {"fit": {"": fit}}
    for name, fields in (
        ("coefficients", ("covariance", "parameter")),
        ("covariance", ("covariance", "parameter_1", "parameter_2")),
        ("predictions", ("plot_id", "season")),
    ):
        _, rows = table(directory / f"{name}.csv")
        result[name] = {"/".join(row[k].strip() for k in fields): {k: v for k, v in row.items() if k not in fields}
                        for row in rows}
        if len(rows) != len(result[name]):
            raise ValueError(f"Pilot has duplicate {name} identity in {directory}")
    return result


def audit_pilot(base):
    folder = base / "pilot_licensed"
    control = json.loads((folder / "analytical_reference.json").read_text())
    control["fit"] = {"": control["fit"]}
    control["predictions"] = {}
    for sessions in range(6):
        fitted = 1200 + 80 * sessions
        for position, sign in enumerate((-1, 1), 1):
            residual = sign * (10 + 5 * sessions)
            control["predictions"][f"P{2*sessions+position:03}/2025"] = {
                "sessions": sessions, "yield_kg_ha": fitted + residual, "fitted": fitted, "residual": residual,
            }
    data = {e: pilot_tables(folder / e) for e in ENGINES}
    data["design reference"] = control
    out = {}
    for name, expected in (
        ("reference_checks", {("design reference", e): 73 if e == "duckdb" else 97 for e in ENGINES}),
        ("cross_environment", {(a, b): 73 if a == "duckdb" else 97 for a, b in combinations(ENGINES, 2)}),
    ):
        scope, source = f"pilot_{name}", f"pilot_licensed/{name}.csv"
        _, old = table(base / source)
        required = set()
        for a, b in expected:
            for t in data[a]:
                assert data[a][t].keys() == data[b][t].keys(), (a, b, t)
                for k, left in data[a][t].items():
                    for field in set(left) & data[b][t][k].keys():
                        required.add((a, b, t, k, field))
                        if field == "p_value":
                            required.add((a, b, t, k, "reject_at_alpha"))
        rows = []
        pairs = Counter()
        for row in old:
            a, b = (row[k].lower() for k in ("left_engine", "right_engine"))
            t, k, field = (row[k] for k in ("table", "key", "field"))
            required.remove((a, b, t, k, field))
            actual_field = "p_value" if field == "reject_at_alpha" else field
            x, y = (number(str(data[engine][t][k][actual_field])) for engine in (a,b))
            lvalue, rvalue = row["left_value"], row["right_value"]
            if field == "reject_at_alpha":
                x, y = (Decimal(int(float(v) < (1.0 - 0.95))) for v in (x,y))
                assert (lvalue, rvalue) == tuple(str(bool(v)) for v in (x,y))
                lvalue, rvalue = str(x), str(y)
            rule = "exact" if field in PILOT_EXACT else "pilot_probability" if field == "p_value" else "general"
            recorded = (lvalue, rvalue, row["absolute_difference"], row["limit"], row["passed"])
            rows.append(result(scope, ("CH37",t,field,k), a,b,x,y,rule,source,recorded))
            pairs[a,b] += 1
        if required or pairs != expected:
            raise ValueError(f"Pilot {source}: incomplete coverage")
        out[scope] = rows
    return out


def all_comparisons(evidence):
    primary = {f"Part_{part}": audit_primary(part, evidence, f"Part_{part}", count)
               for part, count in EXPECTED_COMPARISONS.items()}
    return primary | {"capstone_replay": audit_primary("IX", evidence, "capstone_replay", 20215)} | audit_pilot(evidence)
