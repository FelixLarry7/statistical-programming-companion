"""Independently recompute worked estimates and stochastic diagnostics."""
from collections import Counter, defaultdict
from decimal import Decimal
from fractions import Fraction
from itertools import combinations, product
import math

from scipy.stats import t

from comparisons import ENGINES, metrics, pilot_tables, precision_agrees, result
from contracts import ROOT, table


def source(part, name):
    folder = ROOT / f"chapter_companions/Part_{part}/companion/data"
    path, = folder.rglob(f"{name}.csv")
    return table(path)[1]


def audit_formulas(evidence, fresh_pilot):
    results = []
    pilot_path = "pilot_licensed/duckdb/analytical.csv"
    _, records = table(evidence/pilot_path)
    x = [Fraction(row["sessions"]) for row in records]
    y = [Fraction(row["yield_kg_ha"]) for row in records]
    n, df = len(x), len(x) - 2
    dx = [v - sum(x)/n for v in x]
    sxx = sum(d*d for d in dx)
    slope = sum(d*v for d,v in zip(dx,y,strict=True))/sxx
    intercept = sum(y)/n - slope*sum(x)/n
    residuals = [b - intercept - slope*a for a,b in zip(x,y,strict=True)]
    hc0 = sum((e*d)**2 for e,d in zip(residuals,dx,strict=True)) / sxx**2
    variance = {"classical": sum(e*e for e in residuals)/df/sxx, "HC1": hc0*Fraction(n,df)}
    assert slope == 80 and variance == {"classical":Fraction(139,7), "HC1":Fraction(759,35)}
    for e in ENGINES:
        output = pilot_tables(fresh_pilot / e)["coefficients"]
        for covariance, var in variance.items():
            row = output[f"{covariance}/sessions"]
            se = math.sqrt(var)
            quantities = {"estimate": float(slope), "std_error": se}
            if e != "duckdb":
                statistic = float(slope)/se
                half = t.ppf(0.975,df)*se
                quantities |= {"df_resid": df, "t_value": statistic, "p_value": 2*t.sf(abs(statistic),df),
                               "ci_low": float(slope)-half, "ci_high": float(slope)+half}
            for k,v in quantities.items():
                rule = "pilot_probability" if k == "p_value" else "exact" if k == "df_resid" else "general"
                results.append(result("independent anchor",("CH13",covariance,k,"sessions"),"sample algebra",e,
                                      Decimal(str(v)), Decimal(row[k]), rule, pilot_path))

    villages = {v["village"]: v for v in source("V","villages17")}
    observed = defaultdict(list)
    for household in source("V","households17"):
        if household["eligible"] == "1":
            observed[household["village"]].append(Fraction(household["admin"]))
    means = {k: sum(v)/len(v) for k,v in observed.items()}
    blocks = defaultdict(list)
    for k, v in villages.items():
        blocks[v["block"]].append(k)
    def difference(offer, roster):
        comparison = set(roster) - set(offer)
        return sum(means[v] for v in offer)/len(offer) - sum(means[v] for v in comparison)/len(comparison)

    def block_contrasts(roster):
        return [difference(group, roster) for group in combinations(roster,3)]

    treated = {k for k, v in villages.items() if v["offer"] == "1"}
    itt = sum(difference(treated & set(v),v) for v in blocks.values())/len(blocks)
    randomization = [sum(pair)/len(blocks) for pair in product(*(block_contrasts(v) for v in blocks.values()))]
    extreme = sum(abs(x)>=abs(itt) for x in randomization)
    assert (itt,extreme,len(randomization)) == (Fraction(85,16),60,400)
    for engine in ENGINES:
        ledger = metrics("V",evidence/"Part_V",engine)
        for name,value in (("itt",float(itt)),("permutations",len(randomization)),("extreme",extreme),("ri_p",extreme/len(randomization))):
            target = Decimal(str(value))
            results.append(result("independent anchor",("CH17","trial","scalar",name),"allocation enumeration",engine,
                                  target,ledger["CH17","trial","scalar",name],
                                  "exact" if name in {"permutations","extreme"} else "part_V", "Part_V/verification.json"))

    psus = defaultdict(lambda: [Fraction(0), Fraction(0)])
    for row in source("VIII","births30"):
        totals = psus[row["stratum"],row["psu"]]
        if row["live"] == "1" and int(row["months"]) < 24 and row["facility"] in {"0","1"}:
            totals[0] += Fraction(row["weight"])*int(row["facility"])
            totals[1] += Fraction(row["weight"])
    numerator = sum(a for a,_ in psus.values())
    denominator = sum(b for _,b in psus.values())
    ratio = numerator/denominator
    strata = defaultdict(list)
    for (h,_),(a,b) in psus.items():
        strata[h].append((a-ratio*b)/denominator)
    variance = sum(len(s) * sum((v-sum(s)/len(s))**2 for v in s)/(len(s)-1) for s in strata.values())
    df = len(psus)-len(strata)
    se = math.sqrt(variance)
    half = t.ppf(0.975,df)*se
    coverage = {"numerator":float(numerator),"denominator":float(denominator),"estimate":float(ratio),
                "se":se,"lo":float(ratio)-half,"hi":float(ratio)+half,"df":df}
    assert (numerator,denominator,len(psus),len(strata)) == (Fraction("363.03"),Fraction("523.05"),20,4)
    for engine in ENGINES:
        ledger = metrics("VIII",evidence/"Part_VIII",engine)
        for name,value in coverage.items():
            results.append(result("independent anchor",("CH30","all","scalar",name),"stratified ratio algebra",engine,
                                  Decimal(str(value)),ledger["CH30","all","scalar",name],
                                  "exact" if name == "df" else "parts_VI_IX","Part_VIII/verification.json"))
    return results


def audit_streams(evidence):
    folder = evidence / "Part_III"
    aggregates = {}
    for engine in ("python","r","stata"):
        _, rows = table(folder/engine/"simulation.csv")
        universe = {(r["design"],int(r["n"]),int(r["replicate"])) for r in rows}
        expected = set(product(("normal","skewed"),(8,32),range(1,2001)))
        assert len(rows) == len(universe) == 8000 and universe == expected
        hits = Counter()
        for row in rows:
            for m in ("t","z"):
                indicator = int(row[f"cover_{m}"])
                expected_indicator = int(float(row[f"lower_{m}"])<=1<=float(row[f"upper_{m}"]))
                assert indicator == expected_indicator, (engine,row["replicate"],m)
                hits[row["design"],row["n"],m] += indicator
        for (design,n,method), count in hits.items():
            aggregates[engine,design,n,method] = count/2000
    _, originals = table(folder/"stream_diagnostics.csv")
    result_rows = []
    identities = set()
    for row in originals:
        left,right,design,n,method = (row[key] for key in ("left","right","design","n","method"))
        x, y = (aggregates[e,design,n,method] for e in (left,right))
        mcse = math.hypot(math.sqrt(x*(1-x)/2000),math.sqrt(y*(1-y)/2000))
        gap = abs(x-y)
        assert precision_agrees(row["absolute_coverage_difference"], Decimal(str(gap)))
        assert precision_agrees(row["pooled_mcse"], Decimal(str(mcse)))
        if gap > 4*mcse or row["within_4_mcse"] != "True":
            raise ValueError(f"Independent stream gap exceeds the limit for {left}/{right}/{design}/{n}/{method}")
        identities.add((design,n,method,*sorted((left,right))))
        result_rows.append(dict(design=design,n=n,method=method,left=left,right=right,
                                left_coverage=x,right_coverage=y,abs_error=gap,pooled_mcse=mcse,
                                limit=4*mcse,fraction_of_limit=gap/(4*mcse),status="Passed"))
    assert len(result_rows) == len(identities) == 24
    return result_rows
