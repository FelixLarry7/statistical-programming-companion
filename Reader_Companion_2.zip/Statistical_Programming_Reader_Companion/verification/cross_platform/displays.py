"""Check selected printed values in every chapter against machine-readable evidence."""
from decimal import Decimal
import json
import re

from comparisons import metrics, pilot_tables
from contracts import EXPECTED_COMPARISONS, ROOT, digest, number, table

# Each tuple names chapter, unique row label, published cell, and engine key(s).
# A cell can contain several independently checked numeric fields.
METRIC_CELLS = (
    (1, "Fitted slope", 1, ("slope", "full")),
    (2, "Agent", 1, ("invoices", "agent")),
    (2, "Agent", 2, ("net_minor", "agent")),
    (3, "Usable measurements", 1, ("usable", "all")),
    (4, "Crude contrast", 2, ("difference", "crude")),
    (5, "Distinct source text IDs", 1, ("count", "text_ids")),
    (6, "I01", 3, ("net_minor", "I01")),
    (7, "Source headers", 1, ("count", "headers")),
    (7, "Source headers", 2, ("total", "headers_minor")),
    (8, "Eligible households", 1, ("count", "eligible_households")),
    (9, "Yield", 1, ("count", "yield")),
    (10, "[2, 3)", 2, ("bin", "Rainfed/2")),
    (11, "Type 7", 1, ("bootstrap_type7", "lower")),
    (11, "Type 7", 2, ("bootstrap_type7", "upper")),
    (12, "Rural", 4, ("mean", "wr/rural")),
    (14, "Logit", 4, ("logit", "scalar", "ll")),
    (15, "1", 1, ("riskset", "risk", "1")),
    (15, "1", 4, ("riskset", "km", "1")),
    (16, "Unbalanced", 1, ("unbalanced", "beta", "intercept")),
    (16, "Unbalanced", 2, ("unbalanced", "beta", "baseline")),
    (16, "Unbalanced", 3, ("unbalanced", "scalar", "tau2")),
    (16, "Unbalanced", 4, ("unbalanced", "scalar", "sigma2")),
    (16, "Unbalanced", 5, ("unbalanced", "scalar", "ll")),
    (17, "Offer effect on administrative score", 1, ("trial", "scalar", "itt")),
    (17, "Blocked Neyman standard error", 1, ("trial", "scalar", "se_neyman")),
    (17, "Exact sharp-null probability", 1, ("trial", "scalar", "ri_p")),
    (17, "Exact sharp-null probability", 2, ("trial", "scalar", "extreme"), ("trial", "scalar", "permutations")),
    (18, "3 and 3", 2, ("notyet", "control_n", "3/3")),
    (18, "3 and 3", 4, ("never", "att", "3/3")),
    (19, "Strong", 3, ("strong", "scalar", "first_t2")),
    (19, "Weak", 4, ("weak", "scalar", "effect")),
    (20, "Treated ESS", 1, ("full", "scalar", "ess1")),
    (20, "Treated ESS", 2, ("trim", "scalar", "ess1")),
    (21, "Level comparison", 1, ("within", "scalar", "n")),
    (21, "Dynamic IV", 1, ("dynamic", "scalar", "n")),
    (22, "Ghana", 2, ("naive", "rmse", "1/1")),
    (22, "Ghana", 3, ("ar1", "rmse", "1/1")),
    (22, "Ghana", 4, ("ma1", "rmse", "1/1")),
    (23, "Rook contiguity", 1, ("rook", "scalar", "edges")),
    (23, "Rook contiguity", 2, ("rook", "scalar", "I")),
    (23, "Rook contiguity", 4, ("rook", "scalar", "p")),
    (24, "CR1", 1, ("y1", "se", "cr1")),
    (24, "CR1", 2, ("y1", "scalar", "t_cr1")),
    (25, "Final holdout", 1, ("holdout", "scalar", "events")),
    (25, "Final holdout", 2, ("holdout", "scalar", "auc")),
    (25, "Final holdout", 5, ("holdout", "scalar", "logloss")),
    (26, "Ridge baseline", 1, ("ridge", "scalar", "logloss")),
    (26, "Python forest", 2, ("py_forest", "scalar", "brier")),
    (26, "R forest", 2, ("r_forest", "scalar", "brier")),
    (27, "0.0–0.2", 1, ("audit", "bin_n", "1")),
    (27, "0.0–0.2", 2, ("audit", "bin_mean_p", "1")),
    (28, "1", 2, ("shared", "fold_train_treat", "1")),
    (28, "1", 4, ("shared", "fold_treat", "1")),
    (29, "Lending interest rate", 2, ("country1", "available", "lending")),
    (29, "Lending interest rate", 3, ("country2", "available", "lending")),
    (30, "All observed", 1, ("all", "scalar", "n")),
    (30, "All observed", 2, ("all", "scalar", "denominator")),
    (30, "All observed", 3, ("all", "scalar", "numerator")),
    (30, "All observed", 4, ("all", "scalar", "estimate"), 100),
    (30, "All observed", 5, ("all", "scalar", "lo"), ("all", "scalar", "hi"), 100),
    (31, "Original and revised filings", 1, ("flow", "scalar", "filings")),
    (31, "Same-segment next-quarter outcomes", 1, ("flow", "scalar", "outcome_rows")),
    (32, "GPS planted area", 1, ("gps", "scalar", "n")),
    (32, "GPS planted area", 2, ("gps", "scalar", "kg")),
    (32, "GPS planted area", 4, ("gps", "scalar", "ratio")),
    (33, "Follow-up observed", 1, ("arm0", "scalar", "observed")),
    (33, "Follow-up observed", 2, ("arm1", "scalar", "observed")),
    (34, "Scoped lines", 1, ("revenue", "scalar", "lines")),
    (34, "Eligible invoice balances", 1, ("revenue", "scalar", "invoices")),
    (34, "Eligible invoice balances", 2, ("revenue", "scalar", "net"), "0.01"),
    (36, "Transfer coverage", 1, ("coverage", "scalar", "n")),
    (36, "Transfer coverage", 3, ("coverage", "scalar", "estimate"), 100),
)
NUMERIC = re.compile(r"(?<!\d)[+\-−]?\d+(?:,\d{3})*(?:\.\d+)?")


def assert_cell(out, chapter, label, column, values, evidence_path, key, companion_source):
    manuscript = ROOT / "manuscript/chapters" / f"ch{chapter:02}.qmd"
    candidates = []
    matching = []
    values = [number(str(x)) for x in values]
    for line_num, line in enumerate(manuscript.read_text().splitlines(), 1):
        if not line.startswith("|"):
            continue
        fields = [part.strip() for part in line.strip("|").split("|")]
        if fields[0] != label or len(fields) <= column:
            continue
        formatted = fields[column]
        # Range cells use “to” or an en dash. The glyph minus is part of a value.
        tokens = NUMERIC.findall(formatted)
        parsed = [number(x.replace(",", "").replace("−", "-")) for x in tokens]
        candidates.append((line_num, formatted))
        if len(parsed) == len(values) and all(v.quantize(x) == x for v,x in zip(values,parsed,strict=True)):
            matching.append((line_num, formatted))
    if len(matching) != 1:
        raise ValueError(f"Chapter {chapter}, {label}, column {column}: "
                         f"expected exactly one match for {values}, saw {matching} among {candidates}")
    line_num, printed = matching[0]
    out.append(dict(chapter=chapter, manuscript=manuscript.relative_to(ROOT).as_posix(), source_line=line_num,
                    row_label=label, table_column=column+1, displayed=printed,
                    underlying_value=" / ".join(map(str,values)), source=evidence_path, metric_key=key,
                    source_sha256=digest(companion_source / evidence_path), status="Passed"))


def verify_displays(evidence):
    out = []
    parts = list(EXPECTED_COMPARISONS)
    base = {}
    for part in parts:
        folder = evidence/f"Part_{part}"
        base[part] = metrics(part,folder,"python")
    def check(ch, label, col, values, path, key):
        assert_cell(out,ch,label,col,values,path,key,evidence)

    for ch,label,index,k,*others in METRIC_CELLS:
        part = parts[(ch-1)//4]
        filename = "python.csv" if part in {"I","II"} else "python/metrics.csv"
        keys = [k, *(x for x in others if isinstance(x,tuple))]
        multiplier = next((Decimal(x) for x in others if not isinstance(x,tuple)),Decimal(1))
        values = [base[part][(f"CH{ch:02}",*id)]*multiplier for id in keys]
        check(ch,label,index,values,f"Part_{part}/{filename}",
              " / ".join("|".join(t) for t in keys))
    pilot = "pilot_licensed/python"
    pilots = pilot_tables(evidence/pilot)
    for col, table_name, row, field in (
        (1,"fit","","nobs"),(2,"fit","","df_resid"),
        (3,"coefficients","classical/sessions","estimate"),
        (4,"coefficients","classical/sessions","std_error"),
        (5,"coefficients","HC1/sessions","std_error"),
    ):
        filename = "fit.json" if table_name == "fit" else "coefficients.csv"
        check(13,"Simple pilot",col,[pilots[table_name][row][field]],f"{pilot}/{filename}",f"{row}:{field}")

    path40 = "capstone_report/panel_results.csv"
    _, rows = table(evidence/path40)
    for row in rows:
        label, model = row["label"], row["model"]
        fields = ("n","countries","estimate","se","lo","hi")
        data = {k:number(row[k]) for k in fields}
        for k in fields:
            assert data[k] == base["IX"]["CH35",model,"scalar",k], (model,k)
        for chapter in (35,40):
            source = "Part_IX/python/metrics.csv" if chapter == 35 else path40
            offset = 1 if chapter == 35 else 0
            check(chapter,label,1,[data["n"]],source,f"{model}:n")
            if chapter == 35:
                check(chapter,label,2,[data["countries"]],source,f"{model}:countries")
            check(chapter,label,2+offset,[data["estimate"]],source,f"{model}:estimate")
            check(chapter,label,3+offset,[data["lo"],data["hi"]],source,f"{model}:lo/hi")

    for path, label in (("pilot_first/validation.json","Public checkouts"),("pilot_licensed/validation.json","Licensed replay")):
        payload = json.loads((evidence/path).read_text())
        for col,attribute in ((1,"reference_check_count"),(2,"pairwise_check_count")):
            check(37,label,col,[payload[attribute]],path,attribute)
    path38 = "reporting/report_values.json"
    reports = json.loads((evidence/path38).read_text())
    for scenario, label in (("baseline","Baseline"),("corrected","Corrected harvest")):
        numbers = reports[scenario]
        for index, fields in enumerate((("n",),("estimate",),("std_error",),("ci_low","ci_high")),1):
            check(38,label,index,[numbers[f] for f in fields],path38,f"{scenario}:"+"/".join(fields))
    path39 = "disclosure/public_domains.csv"
    _, release = table(evidence/path39)
    text39 = (ROOT/"manuscript/chapters/ch39.qmd").read_text().splitlines()
    for row in release:
        label, status, est = row["domain"], row["status"], row["estimate"]
        line_num, = [i for i,line in enumerate(text39,1) if line.startswith(f"| {label} |")]
        published = text39[line_num-1].split("|")[2].strip()
        assert published == status
        if est:
            check(39,label,2,[100*number(est)],path39,f"{label}:estimate")
        else:
            assert not any(row[f] for f in ("estimate","lower_95","upper_95"))
            assert text39[line_num-1].split("|")[3].strip() == "—"
        out.append(dict(chapter=39,manuscript="manuscript/chapters/ch39.qmd",source_line=line_num,
                        row_label=label, table_column=2,displayed=published,underlying_value=status,
                        source=path39,metric_key=f"{label}:status",source_sha256=digest(evidence/path39),status="Passed"))
    if {r["chapter"] for r in out} != set(range(1,41)):
        raise ValueError("At least one chapter has no checked manuscript result")
    return sorted(out,key=lambda r:(r["chapter"],r["source_line"],r["table_column"]))
