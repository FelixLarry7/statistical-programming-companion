from contextlib import redirect_stdout
import csv
from decimal import Decimal
import importlib.util
from io import StringIO
from pathlib import Path
import shutil
import sys
import tempfile
import unittest


VERIFICATION = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(VERIFICATION))
from contracts import ROOT, compare_keys, keyed, number, table


class LedgerContracts(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="textbook-contract-")
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "metrics.csv"

    def write(self, text):
        self.path.write_text(text, encoding="utf-8")
        return self.path

    def read(self):
        return keyed(self.path, ("id","value"), ("id",), ("value",))

    def test_keeps_leading_zero_identifier(self):
        self.write("id,value\n001,1.25\n1,2.0\n")
        self.assertEqual(set(self.read()), {("001",), ("1",)})

    def test_rejects_duplicate_key(self):
        self.write("id,value\na,1\na,2\n")
        with self.assertRaisesRegex(ValueError, "Duplicate key"):
            self.read()

    def test_rejects_empty_key(self):
        self.write("id,value\n,5\n")
        with self.assertRaisesRegex(ValueError, "Missing key"):
            self.read()

    def test_rejects_extra_fields(self):
        with self.assertRaisesRegex(ValueError, "Incorrect field count"):
            table(self.write("id,value\na,1,2\n"))

    def test_rejects_reordered_columns(self):
        self.write("value,id\n1,a\n")
        with self.assertRaisesRegex(ValueError, "Unexpected CSV header"):
            self.read()

    def test_rejects_nan_and_infinity(self):
        for candidate in ("NaN","Inf","-Inf"):
            with self.subTest(candidate=candidate), self.assertRaisesRegex(ValueError, "Non-finite"):
                number(candidate)

    def test_rejects_unmatched_keys(self):
        with self.assertRaisesRegex(ValueError, "key set changed"):
            compare_keys({}, {("a",):(Decimal(1),)}, {}, "fixture")

    def test_checks_exact_fields_and_continuous_thresholds(self):
        key = ("a",)
        base = {key:(Decimal("5"),)}
        observed = {key:(Decimal("5.0001"),)}
        self.assertEqual(compare_keys(observed, base, {key:(Decimal("0.0001"),)}, "fixture"), "0.0001")
        with self.assertRaisesRegex(ValueError, "changed beyond"):
            compare_keys(observed, base, {key:(Decimal(0),)}, "fixture")


class SQLiteWindowChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.companion = ROOT/"chapter_companions/Part_II/companion"
        module = importlib.util.spec_from_file_location("sqlite_ch07", cls.companion/"sqlite_ch07.py")
        cls.sqlite = importlib.util.module_from_spec(module)
        module.loader.exec_module(cls.sqlite)

    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix="textbook-sqlite-")
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.inputs = self.root/"inputs"
        self.inputs.mkdir()
        for file in (self.companion/"data/raw").glob("ch07_*.csv"):
            shutil.copy2(file, self.inputs)
        self.reference = self.companion/"evidence/sample_ledger"

    def test_preserves_row_and_peer_frames(self):
        with redirect_stdout(StringIO()):
            self.sqlite.run(self.inputs, self.reference, self.root/"output")
        _, rows = table(self.root/"output/analytical_invoices.csv")
        first = next(r for r in rows if r["invoice_id"] == "T01")
        self.assertEqual((first["rows_running"], first["peer_running"]), ("130", "200"))

    def test_rejects_header_line_disagreement(self):
        path = self.inputs/"ch07_lines.csv"
        columns, rows = table(path)
        rows[0]["amount_minor"] = str(int(rows[0]["amount_minor"]) + 1)
        with path.open("w", newline="") as stream:
            writer = csv.DictWriter(stream, columns)
            writer.writeheader()
            writer.writerows(rows)
        with self.assertRaisesRegex(ValueError, "header reconciliation"):
            self.sqlite.run(self.inputs, self.reference, self.root/"output")


if __name__ == "__main__":
    unittest.main()
