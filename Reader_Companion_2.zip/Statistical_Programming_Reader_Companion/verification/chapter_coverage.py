"""Map the manuscript's chapters, listings and result contracts to their runs."""

from collections import Counter
import csv
import json
from pathlib import Path
import re
import shutil

from contracts import PARTS, ROOT, table


CAPTION = re.compile(r"^\*\*Listing (\d+\.\d+)\. ([^\n]+?)\*\*\s*\n+(```|~~~)([^\n]*)\n(.*?)\n\3", re.M | re.S)
FULL_COMMANDS = {"1.1", "2.4", "5.1", "37.1"}
FULL_SCRIPTS = {"2.2", "10.2", "38.1"}
FRESH = "Executed on the frozen inputs"
ARCHIVED = "Original licensed Stata result checked against matched input and driver"
OUTPUT_COLUMNS = ("chapter", "case", "part", "primary_job", "additional_job", "source",
                  "python", "r", "duckdb", "stata", "primary_comparisons", "review_output")
SQL_SCOPE = {
    1:"Sample and supported simple-regression quantities",
    2:"Invoice-grain net amounts and refund-ledger controls",
    3:"Typed representation, loss and fixed-draw statistics",
    4:"Coverage sample and distributional summaries",
    5:"Landing data, typing and CSV/Parquet exchange",
    6:"Effective exchange rate, signed minor units and split transforms",
    7:"Join cardinality, window frames and exact SQLite reconciliation",
    8:"Data-quality flags and sample dispositions",
    9:"Eligible groups, summaries and covariance",
    10:"Shared bin counts and interval data",
    11:"Fixed-draw moments and coverage arithmetic",
    12:"Survey keys, design weights, domain contrasts and covariance",
    13:"Design moments and simple OLS audit",
    14:"Means and likelihood at declared coefficients",
    15:"Censored scores and Cox risk-set likelihood",
    16:"Gaussian likelihood and conditional predictions at shared parameters",
    17:"Eligible rows, cluster totals and legal allocations",
    18:"Admissible changes, cohort-time effects and aggregation",
    19:"IV contrasts, GMM moments and weighted local jumps",
    20:"Common scores, balance and donor paths at shared weights",
    21:"Consecutive panel rows, within fit and design matrices",
    22:"Forecast windows, AR fits and MA recursions",
    23:"Regional joins, weights and spatial statistics at declared parameters",
    24:"Cluster scores, resampling and common-p-value adjustments",
    25:"Split manifest, training transforms, scoring and paired bootstrap",
    26:"Score evaluation on frozen holdout predictions",
    27:"Frozen calibration and subgroup diagnostics",
    28:"Shared AIPW scores and balance",
    29:"Macroeconomic transformations, vintage timing and AR forecasts",
    30:"Survey domain, weights and PSU calculations",
    31:"Filing timing, shared scoring, reconciliation and portfolio arithmetic",
    32:"Yield conventions, paired adoption and survey totals",
    33:"Trial flow, assignment statistic and exact permutation components",
    34:"Financial reconciliation, forecast scoring and customer cohorts",
    35:"Country coverage and balanced unweighted slopes",
    36:"Survey design ratios and re-ranked delete-PSU estimates",
    37:"Pilot sample, OLS and covariance checks",
    38:"Corrected extract and result reconstruction",
    39:"Uses verified synthetic domain output",
    40:"Balanced model audit and verified source ledger",
}


def write_table(path, columns, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        csv.writer(handle, lineterminator="\n").writerows([columns, *rows])


def chapter_title(path):
    title = re.search(r"(?m)^# (.*?) \{#sec-ch\d+\}$", path.read_text())
    if title is None:
        raise ValueError(f"Missing chapter title in {path.name}.")
    return title[1]


def chapter_rows(output, parts):
    jobs = {record["job"] for record in json.loads((output/"execution_log.json").read_text())}
    for part in PARTS:
        for offset in range(4):
            i = PARTS.index(part) * 4 + 1 + offset
            title = chapter_title(ROOT/"manuscript/chapters"/f"ch{i:02}.qmd")
            if part != "X":
                source = parts[part]["runner"]
                run = f"part_{part}"
                counts = parts[part]["comparisons_by_chapter"][f"CH{i:02}"]
                evidence = f"Part_{part}/comparisons.csv"
                extras_for_chapter = {1:"listing_1_1",2:"listing_2_4",5:"listing_5_1",7:"ch07_sqlite",
                                      10:"listing_10_2",26:"part_VII, part_VII_diagnostics",
                                      27:"part_VII_diagnostics",36:"part_IX_reports"}
                additional = extras_for_chapter.get(i, "")
                if i == 28:
                    additional = "part_VII_diagnostics" + (", ch28_forest" if "ch28_forest" in jobs else "")
            else:
                runs = {37:("pilot_licensed","pilot_compare","companion/pilot/ci/check.py",874,
                            "pilot_licensed/validation.json"),
                        38:("ch38_reports","ch38_notebook_cells, ch38_r_markdown_chunks, ch38_quarto_listing",
                            "companion/reporting/build_reports.py",10,"reporting/audit.json"),
                        39:("ch39_disclosure","","companion/governance/build_release.py",2,
                            "disclosure/disclosure_audit.json"),
                        40:("ch40_tagged_replay","ch40_corrected_report","companion/capstone/review_study.py",24,
                            "capstone_report/review_record.json")}
                run, additional, source, counts, evidence = runs[i]
            if run not in jobs or any(j not in jobs for j in additional.split(", ") if j):
                raise ValueError(f"Missing execution for Chapter {i}.")
            statuses = (FRESH, FRESH, SQL_SCOPE[i], ARCHIVED)
            if i == 38:
                statuses = (FRESH,FRESH,SQL_SCOPE[i],"Original licensed baseline referenced")
            elif i == 39:
                statuses = (FRESH,"Verified statistical inputs reused",SQL_SCOPE[i],"Prior verified inputs referenced")
            yield i, title, part, run, additional, source, *statuses, counts, evidence


def collect_listings():
    _, index = table(ROOT/"part10/book_listing_index.csv")
    by_id = {}
    for chapter in sorted((ROOT/"manuscript/chapters").glob("ch*.qmd")):
        for hit in CAPTION.finditer(chapter.read_text()):
            listing,title,_,language,code = hit.groups()
            if listing in by_id:
                raise ValueError(f"Duplicate listing {listing}.")
            by_id[listing] = (title,language,code)
    if len(index) != 79 or set(by_id) != {entry["listing"] for entry in index}:
        raise ValueError("Manuscript code listing register differs from its rendered source.")
    for entry in index:
        label = entry["listing"]
        title,lang,code = by_id[label]
        if (title,lang) != (entry["title"],entry["language"]):
            raise ValueError(f"The title or language differs for Listing {label}.")
        yield entry, code


def listing_checks(job):
    for entry, code in collect_listings():
        identifier, language = entry["listing"], entry["language"]
        if language == "python":
            compile(code, f"Listing {identifier}", "exec")
        if identifier == "1.1":
            from shlex import split
            script = split(code.replace("\\\n", ""))
            if script != ["python", "companion/pilot/ci/check.py", "--output", "build/ch01",
                          "--licensed-evidence", "companion/pilot/stata/evidence"]:
                raise ValueError("Listing 1.1 has changed from the exercised pilot route.")
            # Execute its exact documented command in a working copy of the companion root.
            example = job.scratch/"ch01_example"
            shutil.copytree(ROOT/"companion/pilot", example/"companion/pilot")
            job.run("listing_1_1", [job.python, "companion/pilot/ci/check.py", "--output",
                                   job.output/"listing_1_1", "--licensed-evidence", "companion/pilot/stata/evidence",
                                   "--rscript", job.rscript], cwd=example)
        elif identifier == "2.4":
            source = ROOT/"chapter_companions/Part_I/companion"
            job.run("listing_2_4", [job.python, source/"benchmark.py", job.output/"Part_I/canonical/ch02.csv",
                                   job.output/"ch02_benchmark.json"])
        elif identifier == "5.1":
            source = ROOT/"chapter_companions/Part_II/companion"
            job.run("listing_5_1", [job.python, source/"acquire.py", "replay", job.output/"ch05_acquired"])
        elif identifier in FULL_SCRIPTS:
            workspace = job.scratch/f"listing_{identifier.replace('.','_')}"
            workspace.mkdir()
            if identifier == "2.2":
                shutil.copy2(job.output/"Part_I/canonical/ch02.csv", workspace)
                code += "\nassert summary['sum'].sum() == 545000 and summary['size'].sum() == 7"
            elif identifier == "10.2":
                path = workspace/"data/raw"
                path.mkdir(parents=True)
                shutil.copy2(ROOT/"chapter_companions/Part_III/companion/data/raw/figure_bins.csv", path)
                code += "\nassert sum(int(r['frequency']) for r in bins) == 6"
            else:
                shutil.copy2(job.output/"reporting/report_values.json", workspace)
            script = workspace/"listing.py"
            script.write_text(code + "\n")
            name = f"listing_{identifier.replace('.','_')}"
            job.run(name, [job.python, script], cwd=workspace)
            if identifier == "10.2":
                shutil.copy2(workspace/"irrigated_counts.png", job.output/"ch10_irrigated_counts.png")


def build_coverage(output, parts):
    chapters = list(chapter_rows(output, parts))
    write_table(output/"chapter_coverage.csv", OUTPUT_COLUMNS, chapters)
    runs = {str(row[0]):row[3] for row in chapters}
    checks = {"1.1":"listing_1_1","2.2":"listing_2_2","2.4":"listing_2_4","5.1":"listing_5_1 and part_II",
              "10.2":"listing_10_2","37.1":"pilot_first and pilot_licensed","38.1":"listing_38_1"}
    entries = []
    for entry, _ in collect_listings():
        n = entry["listing"]
        form = "Standalone command" if n in FULL_COMMANDS else "Complete script with declared input" if n in FULL_SCRIPTS else "Contextual excerpt"
        route = checks.get(n, runs[entry["chapter"]])
        entries.append((entry["chapter"],n,entry["title"],entry["language"],form,route,entry["anchor"]))
    write_table(output/"listing_coverage.csv", ("chapter","listing","title","language","form","tested_route","anchor"), entries)
    counts = Counter(row[4] for row in entries)
    return {"chapters":len(chapters), "listings":len(entries), "listing_forms":dict(counts)}
