# Stage 8 computational review

19 November 2026

The complete ten-part runner executed Python, R and DuckDB afresh.
Stata outputs were replayed from the matching original licensed local
runs. No new native Stata process was started during this assessment.
Read fresh_execution/run_summary.json for scope, counts and software.
The primary comparisons total 81,910 for Parts I to IX. Part X records
the pilot, reporting, disclosure and tagged capstone separately.

The registers directory checks the edited manuscript against the frozen
results and includes 123 published cells, 90 algebraic anchors and
24 stream checks. The optional causal forest retains its earlier
archived execution evidence and was not freshly rerun in Stage 8.
