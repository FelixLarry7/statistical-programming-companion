# Applied research report template

## Executive summary

Give the decision, analytical unit, headline result, uncertainty and the
most consequential identification, data or deployment limit.

## Design and analytical sample

State the research question, target estimand, measures, inclusion rules,
comparison framework, source version and period. Reconcile the source,
analytical and reporting grains. Include a disposition count and relevant
weight, time, assignment, spatial and measurement definitions.

## Methods and comparisons

Define the model or aggregation, uncertainty procedure, selection,
weights and diagnostics. Identify which engines fit independently and
which evaluate shared inputs or replay licensed evidence. Give the exact
rules for structural checks and the declared tolerance for finite values.

## Results and controlled variation

Present a table or figure with labelled units, denominators and
uncertainty. Explain how the prespecified change affects the result
or its interpretation and retain the original output and source key.

## Decision and limitations

State what the evidence supports, relevant alternative explanations
and the conditions for extending the result. Label synthetic, contextual
and empirical findings as appropriate.

## Code and data availability

Give the versioned companion path, input and driver fingerprints, entry
point, dependency metadata and permitted access route. Cite each source
and provide a clean rerun command and a discrepancy decision record.
