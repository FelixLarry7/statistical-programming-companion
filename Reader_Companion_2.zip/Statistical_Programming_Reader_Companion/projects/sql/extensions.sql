CREATE TEMP VIEW teaching_poverty AS
WITH rules AS (SELECT line, basis FROM (VALUES (2200),(2600),(3000)) l(line)
       CROSS JOIN (VALUES ('household'),('person')) b(basis)),
     weighted AS (
       SELECT line,basis,CASE WHEN basis='person' THEN weight*size ELSE weight END AS w,
              welfare
       FROM welfare CROSS JOIN rules
     )
SELECT line,basis,COUNT(*) AS n,SUM(w) AS denominator,
       SUM(CASE WHEN welfare<line THEN w ELSE 0 END)/SUM(w) AS headcount,
       SUM(w*GREATEST(1-welfare/line,0))/SUM(w) AS gap
FROM weighted GROUP BY line,basis;

CREATE TEMP VIEW delivery_age_insurance_standardisation AS
WITH eligible AS (
  SELECT rural,insured,CASE WHEN age<30 THEN 0 ELSE 1 END AS age_group,weight,facility
  FROM births WHERE live=1 AND months<24 AND facility IN (0,1)
), cells AS (
  SELECT rural,insured,age_group,COUNT(*) AS n,SUM(weight) AS weight_total,
         SUM(weight*facility)/SUM(weight) AS risk
  FROM eligible GROUP BY rural,insured,age_group
), target AS (
  SELECT insured,age_group,SUM(weight_total) AS target_weight
  FROM cells GROUP BY insured,age_group
)
SELECT rural,COUNT(*) AS matched_cells,MIN(n) AS minimum_cell_n,
       SUM(target_weight*risk)/SUM(target_weight) AS risk
FROM cells JOIN target USING (insured,age_group)
GROUP BY rural;

CREATE TEMP VIEW spending_and_coverage AS
WITH coverage AS (
  SELECT 'coverage' AS measure,CAST(rural AS VARCHAR) AS group_id,COUNT(*) AS n,
         SUM(weight*insurance)/SUM(weight) AS value
  FROM welfare GROUP BY rural
), expenditure AS (
  SELECT CASE WHEN spend>0 THEN 'positive mean' ELSE 'observed zero count' END AS measure,
         'all' AS group_id,COUNT(*) AS n,AVG(spend) AS value
  FROM spending GROUP BY spend>0
)
SELECT * FROM coverage UNION ALL SELECT * FROM expenditure;

CREATE TEMP VIEW food_thresholds AS
WITH eligible AS (
  SELECT CASE WHEN rural=1 THEN 'Rural' ELSE 'Urban' END AS domain,
         food_spend/size AS per_person,weight
  FROM food WHERE meal_shortfall IN (0,1)
), domain_rows AS (
  SELECT * FROM eligible
  UNION ALL SELECT 'All',per_person,weight FROM eligible
)
SELECT line,domain,COUNT(*) AS n,SUM(weight) AS denominator,
       SUM(CASE WHEN per_person<line THEN weight ELSE 0 END)/SUM(weight) AS prevalence
FROM domain_rows CROSS JOIN (VALUES (200),(300)) t(line)
GROUP BY line,domain;
