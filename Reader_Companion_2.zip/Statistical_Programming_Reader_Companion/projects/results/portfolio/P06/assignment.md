# Bank credit risk and financial performance

P06 · Dashboard specification and validation report

## P06  Bank credit risk and financial performance {#sec-project-p06}

**Research question.** Can the bank-quarter filing available at the forecast date predict the declared next-quarter asset-quality event, and how much apparent accuracy comes from late restatements?

**Design and data.** Use the original synthetic filing and identity histories. Freeze the next-quarter outcome and the Chapter 31 training and test windows. Compare training prevalence and the time-valid model on the same holdout. Score the late-value model separately as a leakage control.

**Prepare the extract.** Reconcile source, reported quarter, release date and legal segment. Select the latest filing released by the declared cutoff. Require a comparable next-quarter outcome in the same segment. Check that labels were available at the start of the forecasting window.

**Assignment**

1. Reconstruct the filing flow from revisions to bank-quarter snapshots, same-segment outcomes, training and held-out rows. Report the features’ maximum availability date.
2. Reproduce discrimination, calibration and log loss on the matched holdout. Show the event count and score denominators for the baseline and time-valid models.
3. Specify a dashboard with a vintage selector, probability calibration and override log. Identify monetary field units using the BankFind field guide and report threshold costs separately from AUC.

**Change one assumption.** Replace the time-valid file by the later restatement, keeping target keys fixed. Count future-feature rows and explain how the availability error changes the apparent score.

**Submit.** Submit the data-definition ledger, holdout validation report, calibration exhibit and a dashboard specification with thresholds and escalation ownership.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
