# P06 replication worksheet

Decision question. Can the bank-quarter filing available at the forecast date predict the declared next-quarter asset-quality event, and how much apparent accuracy comes from late restatements?

Controlled variation. Replace the time-valid file by the later restatement, keeping target keys fixed. Count future-feature rows and explain how the availability error changes the apparent score.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
