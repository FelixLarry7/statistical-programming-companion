# Regional inequality and spatial development

P11 · Spatial diagnostic and map

## Decision and research design

Are regional access values spatially clustered under the 2021 geography, and how much does the result depend on the neighbour graph?

Use 16 published regional percentages from the 2021 census and the pinned Ghana ADM1 geometry. Compare row-standardised rook contiguity with a symmetrised three-nearest-neighbour graph. Reconcile keys and exact permutations before comparing global Moran’s I.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Rook directed edge count | 64 | edges |
| Rook Moran’s I | 0.4945 | index |
| Three-nearest directed edge count | 56 | edges |
| Three-nearest Moran’s I | 0.4657 | index |
| Fixed-permutation probability | 0.0050 | probability |

## Interpretation

Both graphs suggest positive clustering in this 16-region display. The statistic changes with the neighbour definition. The inference is conditional on the chosen fixed permutation design and on region-level measures. Maintain the geoBoundaries and OpenStreetMap notices when reusing the geography.

## Sensitivity and replication

Switch from rook contiguity to symmetrised three-nearest neighbours on the same regions and percentages. Document the change in weights, edge count and statistic.

## Data and verification

Primary files include regions23.csv · weights23.csv · crosswalk23.csv · permutations23.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
