# P11 replication worksheet

Decision question. Are regional access values spatially clustered under the 2021 geography, and how much does the result depend on the neighbour graph?

Controlled variation. Switch from rook contiguity to symmetrised three-nearest neighbours on the same regions and percentages. Document the change in weights, edge count and statistic.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
