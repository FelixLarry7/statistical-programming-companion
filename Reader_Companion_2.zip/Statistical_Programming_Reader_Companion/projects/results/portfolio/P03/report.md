# Social protection impact evaluation

P03 · Evaluation protocol and policy note

## Decision and research design

What does a paired village experiment establish about an offer, and how far does incomplete follow-up limit the decision?

Use the 24-pair, 48-village synthetic eligibility roster in Chapter 33. The observed-case analysis averages matched village contrasts. Define the original eligible-cohort ITT before seeing the outcome, recognising that follow-up is missing for some households. Chapter 17 offers an independently enumerated blocked-lottery check.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Comparison households observed | 417 | households |
| Offered households observed | 414 | households |
| Observed-case matched contrast | 4.25 | points |
| Paired interval lower bound | 2.78 | points |
| Paired interval upper bound | 5.72 | points |
| Eligible-cohort completion lower limit | −9.55 | points |
| Eligible-cohort completion upper limit | 17.33 | points |

## Interpretation

The observed-case contrast is positive. Its reference interval and the full cohort bounds cross the three-point decision threshold from the chapter protocol, and the latter include zero. Additional follow-up or a credible missingness assumption matters more for expansion than the nominal randomisation probability. LEAP 1000 provides programme context and has its own data access and design.

## Sensitivity and replication

Replace the observed-case interpretation with an eligible-cohort claim using the documented completion bounds. Trace what changes when assumptions about missing outcomes are relaxed.

## Data and verification

Primary files include assignment33.csv · roster33.csv · draws33.csv · households17.csv · villages17.csv · allocations17.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
