# P03 replication worksheet

Decision question. What does a paired village experiment establish about an offer, and how far does incomplete follow-up limit the decision?

Controlled variation. Replace the observed-case interpretation with an eligible-cohort claim using the documented completion bounds. Trace what changes when assumptions about missing outcomes are relaxed.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
