# P12 replication worksheet

Decision question. How does life expectancy covary with log real GDP per resident within selected economies after allowing for economy and year effects?

Controlled variation. Insert the weighted slope under the equal-weight key as a controlled error. Restore the original result and explain why its estimand and interval differ from the weighted fit.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
