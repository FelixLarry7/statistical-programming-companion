# Health insurance and health economics

P05 · Health-financing note

## P05  Health insurance and health economics {#sec-project-p05}

**Research question.** How do weighted insurance coverage and expected healthcare spending vary across the declared populations, and what interpretation survives voluntary insurance selection?

**Design and data.** Use Chapter 36 for a design-weighted insurance coverage contrast by residence. Use the separate Chapter 30 household file for expenditure. Keep observed zero expenditure and fit participation and conditional positive expenditure under matched predictors. Standardise the expected total to a common covariate grid.

**Prepare the extract.** Separate the survey household from the synthetic spending household. Preserve the surveys’ strata, PSUs and weights, and keep legitimate zeros in the expenditure file. Record the currency, scope and case-specific denominator.

**Assignment**

1. Reproduce the Chapter 36 total and estimate the rural and urban coverage contrast with a design-linearised standard error. Record denominator weight and design degrees of freedom.
2. Reconcile positive counts and positive spending means. Reproduce the two-part adjusted spending terms and show why the mean of products can differ from the product of means.
3. Compare the unweighted observed insurance-group differences with the standardised costs. State the source and approvals needed to adapt the exercise to Ghana DHS and the additional conditions for causal interpretation.

**Change one assumption.** Exclude zero costs solely as a deliberate diagnostic. Compare the positive-only mean with the full mean and quantify the effect of switching the stated estimand.

**Submit.** Submit a coverage-and-spending note, design and flow tables, two-part ledger and a page documenting selection, common support and limitations.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
