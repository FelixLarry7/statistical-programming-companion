# Public health risk and healthcare utilisation

P04 · Health-access report

## P04  Public health risk and healthcare utilisation {#sec-project-p04}

**Research question.** What is facility-delivery coverage for recent live births, how does it differ by residence, and how sensitive is it to missing recorded delivery location?

**Design and data.** The Chapter 30 synthetic estimate is a weighted ratio for live births aged 0–23 months with known delivery location. Use the complete stratum and PSU frame for linearisation and a Student reference with 16 design degrees of freedom. Keep a common covariate distribution for the additional adjusted residence contrast.

**Prepare the extract.** Check the birth key and survey design identifiers. Preserve ineligible observations as zero contributions to domain totals. Reconcile the live-birth window, missing facilities and the all, rural and urban denominator weights.

**Assignment**

1. Reproduce all three domain ratios and the rural-minus-urban difference with a covariance-aware interval. Show how the numerator and denominator produce the overall result.
2. Implement the separate residence standardisation query. Estimate observed risks within the declared insurance-by-age cells and apply pooled cell weights. Check support and label its target as associational.
3. Bound the overall coverage by assigning all missing locations first to nonfacility and then to facility deliveries. Explain why the Ghana DHS comparator must match the published eligibility and geography.

**Change one assumption.** Expand the reference window to 0–35 months as a sensitivity. Compare this result and the missing-location bounds while retaining the primary denominator.

**Submit.** Submit the birth-flow ledger, design-weighted access table, adjusted contrast, sensitivity plot and a technical note that defines the population and uncertainty.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
