# Agricultural productivity and technology adoption

P08 · Farm productivity study

## P08  Agricultural productivity and technology adoption {#sec-project-p08}

**Research question.** How much does the choice of plot area change measured maize productivity, and what does a paired offer design establish about adoption?

**Design and data.** Use D13 plot-season data for area and yield, then analyse the separate paired adoption trial. The D00 Chapter 13 regression supplies an associational benchmark. Freeze the primary total-output-to-total-planted-area estimand and report a plot-average companion statistic.

**Prepare the extract.** Validate plot-season identifiers and the plot-to-household join. Harmonise harvested mass, moisture and local measurement units. Retain planted plots with zero verified harvest and apply the declared treatment of missing harvest. Keep trial offer and uptake codes distinct.

**Assignment**

1. Calculate the ratio of totals with GPS and reported area on the same sample. Show the corresponding plot-average yield and investigate why it is different.
2. Reproduce the maize offer ITT, first stage and paired Wald ratio. Write a short defence of exclusion and monotonicity in a hypothetical design, then label the descriptive comparison.
3. Describe a Ghana Socioeconomic Panel Survey extension using the documented farm, plot and crop keys. Check season alignment and confirm each allowed variable with the data dictionary.

**Change one assumption.** Substitute reported for GPS area while holding harvest and plot membership fixed. Next apply the positive-harvest restriction and label the sample change separately.

**Submit.** Submit a farm productivity report, area and yield reconciliations, treatment and uptake ledger, and measurement-versus-design sensitivity table.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
