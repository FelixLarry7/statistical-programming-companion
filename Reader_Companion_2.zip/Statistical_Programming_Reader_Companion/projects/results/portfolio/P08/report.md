# Agricultural productivity and technology adoption

P08 · Farm productivity study

## Decision and research design

How much does the choice of plot area change measured maize productivity, and what does a paired offer design establish about adoption?

Use D13 plot-season data for area and yield, then analyse the separate paired adoption trial. The D00 Chapter 13 regression supplies an associational benchmark. Freeze the primary total-output-to-total-planted-area estimand and report a plot-average companion statistic.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Common maize plots | 267 | plots |
| GPS-based yield | 1,635.80 | kg/ha |
| Reported-area yield | 1,543.78 | kg/ha |
| Paired offer ITT | 117.51 | kg/ha |
| Offer effect on uptake | 46.67 | pp |
| Paired Wald ratio | 251.81 | kg/ha |

## Interpretation

Reported area gives a smaller yield ratio on the identical plots. That difference is a measurement effect. The synthetic adoption estimate has a separate paired encouragement design and additional assumptions. A Ghana productivity claim needs a specific survey frame, crop and seasonal measure.

## Sensitivity and replication

Substitute reported for GPS area while holding harvest and plot membership fixed. Next apply the positive-harvest restriction and label the sample change separately.

## Data and verification

Primary files include plots32.csv · trial32.csv · maize_pilot.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
