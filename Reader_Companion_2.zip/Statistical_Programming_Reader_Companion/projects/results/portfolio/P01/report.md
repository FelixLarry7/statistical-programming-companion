# Economic growth and macroeconomic forecasting

P01 · Forecast evaluation

## Decision and research design

Can an autoregression improve forecasts of annual real GDP growth in Ghana, Kenya and Senegal, and does the answer change when the target is the level of an output index?

Use the Chapter 29 rolling origins from 2015 through 2022, with one- and two-year horizons. Compare an autoregression with the trailing five-year mean in percentage points. Chapter 22 forms a separate output-index comparison with a naïve benchmark, AR(1) and conditional MA. Retain a distinct origin, target year, horizon and data-vintage field in each ledger.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Ghana mean RMSE, one year | 2.65 | pp |
| Ghana AR(1) RMSE, one year | 2.65 | pp |
| Ghana mean RMSE, two years | 1.93 | pp |
| Ghana AR(1) RMSE, two years | 2.54 | pp |
| Ghana conditional MA index RMSE | 3.32 | log points |
| Ghana policy-rate daily mean, 2024 | 28.55 | % |

## Interpretation

The small one-year gain in Ghana does not carry over to two years. Choosing a model by target and horizon is more defensible than naming one winner. The conditional MA check is in index log points and uses a different training window. Historical-vintage lab scores do not establish real-time forecast performance.

## Sensitivity and replication

Change from the one-year to the two-year growth horizon. Then compare the 2024 calendar-day mean policy rate with the rate on 31 December. Treat the rate as contextual evidence with its own time basis.

## Data and verification

Primary files include gdp22.csv · macro29.csv · revision29.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
