# P01 replication worksheet

Decision question. Can an autoregression improve forecasts of annual real GDP growth in Ghana, Kenya and Senegal, and does the answer change when the target is the level of an output index?

Controlled variation. Change from the one-year to the two-year growth horizon. Then compare the 2024 calendar-day mean policy rate with the rate on 31 December. Treat the rate as contextual evidence with its own time basis.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
