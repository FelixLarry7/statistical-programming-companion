# Household poverty and welfare measurement

P02 · Survey poverty profile

## P02  Household poverty and welfare measurement {#sec-project-p02}

**Research question.** How sensitive are poverty estimates to the poverty line, the weighting unit and the rural–urban comparison?

**Design and data.** Use the D13 synthetic welfare fixture. Establish the declared welfare unit and time basis before contrasting a household-weighted headcount with a person-weighted headcount. The national teaching lines are GHS 2,200 and 2,600. Use Chapter 12 survey-domain methods for the rural and urban extension.

**Prepare the extract.** Keep one row per household. Bring strata, primary sampling units and weights to the calculation. Use household weight for a household estimand and multiply by household size for the person estimand. Keep the full design frame when forming domains.

**Assignment**

1. Reproduce national headcounts and normalised gaps at both lines using household and person weights. Verify the survey denominator in each calculation.
2. Construct rural and urban ratios with the common welfare basis. Compute a design-linearised interval and the rural-minus-urban gap on the full survey frame.
3. Run the common sensitivity query for alternative poverty lines. Explain what matched denominator, price base and equivalence scale would be needed for a Ghana poverty estimate.

**Change one assumption.** Raise the line from GHS 2,200 to GHS 2,600 with the household sample fixed. Then change the weights on the same line and document the target population for each statistic.

**Submit.** Submit a poverty profile with national and rural–urban results, denominator ledger, variance procedure and an exhibit showing threshold and weighting sensitivity.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
