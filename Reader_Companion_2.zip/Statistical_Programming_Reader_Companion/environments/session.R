packages <- c("MASS", "Matrix", "nlme", "survival", "survey", "sandwich",
              "zoo", "lattice", "Rcpp", "RcppArmadillo", "DBI", "numDeriv",
              "minqa", "mitools", "grf", "RcppEigen", "DiceKriging", "lmtest")
cat(R.version.string, "\n")
for (package in packages) {
  if (requireNamespace(package, quietly=TRUE)) {
    cat(package, utils::packageDescription(package, fields="Version"), "\n")
  } else {
    cat(package, "not installed\n")
  }
}
print(sessionInfo())
