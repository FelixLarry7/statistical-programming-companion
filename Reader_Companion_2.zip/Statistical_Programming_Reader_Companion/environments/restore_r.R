# Install pinned R dependencies into the library selected by R_LIBS_USER.
args <- commandArgs(trailingOnly=TRUE)
args <- args[args != "--args"]
with_forest <- "--forest" %in% args
native <- grep("^--file=", commandArgs(), value=TRUE)
if (length(native)) {
  script <- sub("^--file=", "", native[1])
} else {
  command <- commandArgs()
  script <- command[match("-f", command) + 1L]
  if (!file.exists(script)) script <- gsub("~+~", " ", script, fixed=TRUE)
}
if (getRversion() != "4.5.0") stop("The reference uses R 4.5.0.")
wanted <- read.csv(file.path(dirname(script), "r_packages.csv"), colClasses="character")
if (!with_forest) wanted <- subset(wanted, scope=="core")
lib <- Sys.getenv("R_LIBS_USER")
if (!nzchar(lib) || length(strsplit(lib, .Platform$path.sep, fixed=TRUE)[[1]]) != 1L) {
  stop("Set R_LIBS_USER to one isolated library path.")
}
dir.create(lib, showWarnings=FALSE, recursive=TRUE)
.libPaths(c(lib, .libPaths()))
cran <- sub("/$", "", Sys.getenv("STAGE5_CRAN", "https://cloud.r-project.org"))
pinned <- function(p, version) {
  actual <- tryCatch(utils::packageDescription(p, fields="Version"), error=function(e) NA_character_)
  if (!is.na(actual) && actual == version) return(invisible(NULL))
  archive <- paste0(p, "_", version, ".tar.gz")
  pairs <- c(paste0(cran, "/src/contrib/", archive),
             paste0(cran, "/src/contrib/Archive/", p, "/", archive))
  path <- tempfile(fileext=".tar.gz")
  on.exit(unlink(path))
  for (url in pairs) {
    result <- tryCatch(suppressWarnings(utils::download.file(url, path, mode="wb", quiet=TRUE)), error=function(e) 1L)
    if (identical(result, 0L)) break
  }
  if (!file.exists(path) || result != 0L) stop("Could not retrieve the pinned distribution for ", p)
  utils::install.packages(path, repos=NULL, type="source", lib=lib)
  if (!identical(utils::packageDescription(p, fields="Version"), version)) stop("R installation differs for ", p)
}
for (i in seq_len(nrow(wanted))) pinned(wanted$package[i], wanted$version[i])
versions <- vapply(wanted$package, function(p) utils::packageDescription(p, fields="Version"), character(1))
if (!identical(unname(versions), wanted$version)) stop("Observed R versions differ from the manifest.")
print(versions)
