# Independent base R calculations and native survey estimation.
suppressPackageStartupMessages(library(survey))
argv <- commandArgs(trailingOnly=TRUE)
stopifnot(length(argv)==2)
input <- argv[1]
output <- argv[2]
dir.create(output, showWarnings=FALSE, recursive=TRUE)
read <- function(name) read.csv(file.path(input, paste0(name, ".csv")),
                                na.strings=c(""), stringsAsFactors=FALSE)
write <- function(data, name) write.table(data, file.path(output, paste0(name, ".csv")),
                                           sep=",", row.names=FALSE, quote=FALSE)
options(digits=17, survey.lonely.psu="fail")
metrics <- list()
add <- function(chapter, metric, key, value) {
    metrics[[length(metrics)+1L]] <<- data.frame(chapter=chapter, metric=metric,
        key=as.character(key), value=as.numeric(value))
}
p <- read("plots")
stopifnot(!anyDuplicated(p$plot_id), setequal(unique(p$regime), c("Irrigated","Rainfed")))
variables <- c("yield_t_ha","fert","labour")
good <- !is.na(p$yield_t_ha)
x <- p$yield_t_ha[good]
add("CH09","count","source",nrow(p))
add("CH09","count","yield",length(x))
add("CH09","missing",variables,colSums(is.na(p[variables])))
add("CH09","yield_id",p$plot_id[good],1)
d <- x-mean(x)
moments <- c(mean=mean(x), sample_variance=var(x), population_variance=mean(d^2),
             third_central=mean(d^3), moment_skewness=mean(d^3)/mean(d^2)^1.5,
             raw_mad=mad(x,constant=1))
add("CH09","moment",names(moments),moments)
for (kind in c(7,1))
    add("CH09",paste0("quantile",kind),c("p25","p50","p75"),
        quantile(x,c(.25,.5,.75),type=kind,names=FALSE))
pairs <- list(yf=c("yield_t_ha","fert"), yl=c("yield_t_ha","labour"),
              fl=c("fert","labour"))
for (pair in names(pairs)) for (scope in c("available","common")) {
    v <- p[pairs[[pair]]]
    keep <- complete.cases(if (scope=="available") v else p[variables])
    key <- paste(scope,pair,sep="/")
    add("CH09","pair_n",key,sum(keep))
    add("CH09","covariance",key,cov(v[keep,1],v[keep,2]))
    add("CH09","correlation",key,cor(v[keep,1],v[keep,2]))
    add("CH09","pair_id",paste(key,p$plot_id[keep],sep="/"),1)
}
for (group in c("Irrigated","Rainfed","pooled")) {
    g <- p[good & (p$regime==group | group=="pooled"),]
    add("CH09","group_n",group,nrow(g))
    add("CH09","group_mean",group,mean(g$yield_t_ha))
    add("CH09","group_slope",group,coef(lm(yield_t_ha~fert,g))["fert"])
    if (group=="pooled") next
    n <- nrow(g)
    df <- n-1
    avg <- mean(g$yield_t_ha)
    se <- sd(g$yield_t_ha)/sqrt(n)
    margin <- qt(.975,df)*se
    a <- c(n=n,df=df,mean=avg,se=se,lower=avg-margin,upper=avg+margin)
    for (nm in names(a)) add("CH10",paste0("interval_",nm),group,a[nm])
    bins <- hist(g$yield_t_ha,breaks=1:6,right=FALSE,include.lowest=TRUE,plot=FALSE)
    add("CH10","bin",paste(group,1:5,sep="/"),bins$counts)
    if (group=="Rainfed") {
        shifted <- hist(g$yield_t_ha,breaks=seq(1.5,6.5,1),right=FALSE,
                        include.lowest=TRUE,plot=FALSE)
        add("CH10","shifted_rainfed",1:5,shifted$counts)
    }
}
bins <- read("figure_bins")
ci <- read("figure_intervals")
figure_path <- file.path(output,"ch10_r.pdf")
if (capabilities("cairo")) {
    cairo_pdf(figure_path,width=5.4,height=7.2,family="sans")
} else {
    pdf(figure_path,width=5.4,height=7.2,useDingbats=FALSE,useKerning=FALSE)
}
par(mfrow=c(3,1),mar=c(3.0,4.2,2.0,1.0),mgp=c(2,.5,0),family="sans")
palette <- c(Irrigated="#29485F",Rainfed="#177A76")
for (name in names(palette)) {
    g <- bins[bins$regime==name,]
    plot(NA,xlim=c(1,6),ylim=c(0,4),xaxs="i",yaxs="i",main=paste(name,"plots"),
         xlab="Yield (t/ha)",ylab="Plots",las=1)
    rect(g$mid-.43,0,g$mid+.43,g$frequency,col=palette[name],border=NA)
}
ci <- ci[match(c("Rainfed","Irrigated"),ci$regime),]
plot(ci$mean,1:2,xlim=c(1,6),ylim=c(.6,2.4),pch=c(15,18),yaxt="n",
     xlab="Yield (t/ha)",ylab="",main="Mean and 95% t interval",xaxs="i")
segments(ci$lower,1:2,ci$upper,1:2,lwd=2,col=palette[ci$regime])
points(ci$mean,1:2,pch=c(15,18),col=palette[ci$regime])
axis(2,at=1:2,labels=ci$regime,las=1,cex.axis=.75)
invisible(dev.off())

intervals <- function(design, n, means, sds) {
    se <- sds/sqrt(n)
    tmargin <- qt(.975,n-1)*se
    zmargin <- qnorm(.975)*se
    lt <- means-tmargin
    ut <- means+tmargin
    lz <- means-zmargin
    uz <- means+zmargin
    data.frame(design=design,n=n,replicate=seq_along(means),mean=means,sd=sds,
               lower_t=lt,upper_t=ut,lower_z=lz,upper_z=uz,
               cover_t=as.integer(lt<=1 & ut>=1),cover_z=as.integer(lz<=1 & uz>=1))
}
f <- read("fixed_draws")
fixed <- independent <- list()
RNGkind("Mersenne-Twister", "Inversion")
scenario <- 0L
for (shape in c("normal","skewed")) for (n in c(8L,32L)) {
    scenario <- scenario+1L
    sample <- f[f$design==shape & f$n==n,]
    sample <- sample[order(sample$replicate,sample$draw),]
    stopifnot(all(sample$draw==rep(seq_len(n),64)),all(sample$replicate==rep(1:64,each=n)))
    x <- matrix(sample$x,nrow=n)
    fixed[[scenario]] <- intervals(shape,n,colMeans(x),apply(x,2,sd))
    seed <- 317000+scenario
    set.seed(seed)
    draws <- if (shape=="normal") rnorm(2000*n,1,1) else rexp(2000*n,1)
    mat <- matrix(draws,nrow=n)
    independent[[scenario]] <- transform(intervals(shape,n,colMeans(mat),apply(mat,2,sd)),seed=seed)
}
write(do.call(rbind,fixed),"fixed")
write(do.call(rbind,independent),"simulation")
boot <- read("bootstrap_draws")
stopifnot(all(boot$x==2^(boot$original_index-1)),all(table(boot$replicate,boot$draw)==1))
means <- tapply(boot$x,boot$replicate,mean)
add("CH11","bootstrap_mean",names(means),means)
for (kind in c(7,1)) add("CH11",paste0("bootstrap_type",kind),c("lower","upper"),
                         quantile(means,c(.025,.975),type=kind,names=FALSE))

s <- read("survey")
stopifnot(!anyDuplicated(s$hh_id),all(s$eligible %in% 0:1),all(s$rural %in% 0:1))
add("CH12","count","source",nrow(s))
s <- s[s$eligible==1,]
stopifnot(all(complete.cases(s)),all(s$weight>0))
s$cluster <- interaction(s$stratum,s$psu,drop=TRUE)
s$urban <- 1-s$rural
s$ry <- s$rural*s$welfare
s$uy <- s$urban*s$welfare
add("CH12","count",c("eligible","psus","strata"),
    c(nrow(s),length(unique(s$cluster)),length(unique(s$stratum))))
add("CH12","universe_id",s$hh_id,1)
for (name in c("rural","urban","all")) {
    domain <- if (name=="all") s else s[s[[name]]==1,]
    add("CH12","denominator",name,sum(domain$weight))
    add("CH12","weighted_total",name,sum(domain$weight*domain$welfare))
    add("CH12","unweighted_mean",name,mean(domain$welfare))
    if (name!="all") add("CH12","domain_n",name,nrow(domain))
}
wr <- svydesign(ids=~cluster,strata=~stratum,weights=~weight,data=s,nest=TRUE)
fpc <- svydesign(ids=~cluster,strata=~stratum,weights=~weight,fpc=~fpc_n,data=s,nest=TRUE)
for (name in c("wr","fpc")) {
    design <- if (name=="wr") wr else fpc
    fit <- svymean(~ry+rural+uy+urban,design)
    b <- coef(fit)
    J <- rbind(c(1/b[2],-b[1]/b[2]^2,0,0),c(0,0,1/b[4],-b[3]/b[4]^2))
    C <- J %*% vcov(fit) %*% t(J)
    overall <- svymean(~welfare,design)
    avg <- c(b[1]/b[2],b[3]/b[4],coef(overall),b[3]/b[4]-b[1]/b[2])
    se <- c(sqrt(diag(C)),SE(overall),sqrt(C[1,1]+C[2,2]-2*C[1,2]))
    add("CH12","design_df",name,degf(design))
    add("CH12","domain_covariance",name,C[1,2])
    keys <- paste(name,c("rural","urban","all","gap"),sep="/")
    add("CH12","mean",keys,avg)
    add("CH12","se",keys,se)
}
for (name in c("rural","urban")) {
    keep <- s[[name]]==1
    domain <- subset(wr,keep)
    est <- svymean(~welfare,domain)
    add("CH12","subpop_mean",name,coef(est))
    add("CH12","subpop_se",name,SE(est))
    options(survey.lonely.psu="certainty")
    trimmed <- svydesign(ids=~cluster,strata=~stratum,weights=~weight,data=s[keep,],nest=TRUE)
    add("CH12","trimmed_psus",name,length(unique(s$cluster[keep])))
    add("CH12","trimmed_se",name,SE(svymean(~welfare,trimmed)))
    options(survey.lonely.psu="fail")
}
m <- do.call(rbind,metrics)
stopifnot(!anyDuplicated(m[1:3]),all(is.finite(m$value)))
write(m[order(m$chapter,m$metric,m$key),],"metrics")
cat(R.version.string,"\nsurvey",as.character(packageVersion("survey")),"\n")
