-- Allocate every observed yield to one declared bin.
-- Explicit join predicates retain zero-count bins.
CREATE TEMP VIEW bins10 AS
SELECT g.regime, b.bin, b.bin AS lo, b.bin+1 AS hi, b.bin+.5 AS mid,
       count(y.plot_id) AS frequency
FROM (SELECT DISTINCT regime FROM plots) g
CROSS JOIN range(1,6) b(bin)
LEFT JOIN yield09 y ON y.regime=g.regime AND y.y>=b.bin
 AND (y.y<b.bin+1 OR (b.bin=5 AND y.y=6))
GROUP BY g.regime, b.bin;

CREATE TEMP VIEW intervals10 AS
WITH moments AS (
  SELECT regime, count(*) AS n, count(*)-1 AS df, avg(y) AS mean,
         stddev_samp(y)/sqrt(count(*)) AS se
  FROM yield09 GROUP BY regime
)
SELECT regime, n::DOUBLE AS n, df::DOUBLE AS df, mean, se, mean-t975*se AS lower, mean+t975*se AS upper
FROM moments JOIN critical_values USING (df);

CREATE TEMP VIEW metrics10 AS
SELECT 'bin' AS metric, regime || '/' || bin AS key, frequency::DOUBLE AS value FROM bins10
UNION ALL
SELECT 'interval_' || item, regime, value
FROM (UNPIVOT intervals10 ON n, df, mean, se, lower, upper
      INTO NAME item VALUE value)
UNION ALL
SELECT 'shifted_rainfed', bin::VARCHAR, count(y.plot_id)
FROM range(1,6) t(bin)
LEFT JOIN yield09 y ON y.regime='Rainfed' AND y.y>=bin+.5
 AND (y.y<bin+1.5 OR (bin=5 AND y.y=6.5))
GROUP BY bin;
