-- Contract: one row per plot. Empty numeric fields are SQL NULL.
CREATE TEMP VIEW yield09 AS
SELECT plot_id, regime, yield_t_ha AS y, fert, labour
FROM plots WHERE yield_t_ha IS NOT NULL;

CREATE TEMP VIEW pair09 AS
WITH pairs AS (
  SELECT plot_id, 'yf' AS pair, yield_t_ha AS a, fert AS b,
         labour IS NOT NULL AS third_observed FROM plots
  UNION ALL
  SELECT plot_id, 'yl', yield_t_ha, labour, fert IS NOT NULL FROM plots
  UNION ALL
  SELECT plot_id, 'fl', fert, labour, yield_t_ha IS NOT NULL FROM plots
)
SELECT 'available/' || pair AS sample, plot_id, a, b
FROM pairs WHERE a IS NOT NULL AND b IS NOT NULL
UNION ALL
SELECT 'common/' || pair, plot_id, a, b
FROM pairs WHERE a IS NOT NULL AND b IS NOT NULL AND third_observed;

CREATE TEMP VIEW metrics09 AS
WITH centre AS (
  SELECT avg(y) AS mu, median(y) AS med FROM yield09
), moments AS (
  SELECT avg(y) AS mean, var_samp(y) AS sample_variance,
         var_pop(y) AS population_variance, avg((y-mu)^3) AS third_central,
         avg((y-mu)^3)/var_pop(y)^1.5 AS moment_skewness,
         median(abs(y-med)) AS raw_mad
  FROM yield09 CROSS JOIN centre
), qs AS (
  SELECT quantile_cont(y,.25) AS q725, quantile_cont(y,.50) AS q750,
         quantile_cont(y,.75) AS q775, quantile_disc(y,.25) AS q125,
         quantile_disc(y,.50) AS q150, quantile_disc(y,.75) AS q175
  FROM yield09
), p AS (
  SELECT sample, count(*) AS n, covar_samp(a,b) AS covariance, corr(a,b) AS correlation
  FROM pair09 GROUP BY sample
), g AS (
  SELECT coalesce(regime,'pooled') AS name, count(*) AS n, avg(y) AS mean,
         regr_slope(y,fert) AS slope
  FROM yield09 GROUP BY GROUPING SETS ((regime),())
)
SELECT 'count' AS metric, 'source' AS key, count(*)::DOUBLE AS value FROM plots
UNION ALL SELECT 'count','yield',count(*) FROM yield09
UNION ALL SELECT 'missing','yield_t_ha',count(*)-count(yield_t_ha) FROM plots
UNION ALL SELECT 'missing','fert',count(*)-count(fert) FROM plots
UNION ALL SELECT 'missing','labour',count(*)-count(labour) FROM plots
UNION ALL SELECT 'yield_id',plot_id,1 FROM yield09
UNION ALL SELECT 'moment',statistic,value FROM (
  UNPIVOT moments ON COLUMNS(*) INTO NAME statistic VALUE value
)
UNION ALL SELECT 'quantile' || substr(statistic,2,1), 'p' || substr(statistic,3), value
  FROM (UNPIVOT qs ON COLUMNS(*) INTO NAME statistic VALUE value)
UNION ALL SELECT 'pair_id',sample || '/' || plot_id,1 FROM pair09
UNION ALL SELECT 'pair_n',sample,n FROM p
UNION ALL SELECT 'covariance',sample,covariance FROM p
UNION ALL SELECT 'correlation',sample,correlation FROM p
UNION ALL SELECT 'group_n',name,n FROM g
UNION ALL SELECT 'group_mean',name,mean FROM g
UNION ALL SELECT 'group_slope',name,slope FROM g;
