# Part III computational companion

The same four cases are implemented independently in DuckDB SQL, Python, R, and Stata. Chapters 9 and 10 use a twelve-plot agricultural fixture. Chapter 11 uses frozen draws and separately seeded simulations. Chapter 12 uses a 24-household survey sample with two additional audit records.

## Run the checks

Use Python 3.12 and the packages listed in `requirements.txt`, R with the `survey` package, and a licensed local Stata installation for native reruns. The release records DuckDB 1.4.4, NumPy 2.3.5, SciPy 1.17.0, R 4.5.0 with survey 4.4-2, and Stata 17 IC. The reference calculations run on a standard Python installation with those dependencies. The scripts accept working paths with spaces.

From this directory, use a new or empty output folder:

```bash
python -m pip install -r requirements.txt
python run.py --output ./my_run \
  --stata-evidence ./evidence/stata/evidence_replay.zip \
  --require-four
```

This runs DuckDB, Python and native R, and validates the retained outputs of the licensed Stata run. If your R executable has a different path, supply it with `--rscript`. To rerun Stata, copy the seven CSVs from `data/raw` to an `inputs` folder beside the two do-files in a clean directory, then follow `stata/LOCAL_RUN.md`. Run the Stata do-file locally and pass the returned evidence ZIP to `--stata-evidence`. The supplied replay keeps the original numerical outputs and a log with local paths removed. Return code zero, the executed driver hash, and each input byte are checked. With the Stata argument omitted, the three available engines are checked and the report records that scope.

## Compare the evidence

| File | Use |
|---|---|
| `verification.json` | Status, versions via the engine logs, input hashes, and separate comparison counts |
| `comparisons.csv` | 645 scalar comparisons, 6,144 fixed-draw field comparisons, and 81 hand-derived anchors |
| `duckdb/figure_bins.csv` and `duckdb/figure_intervals.csv` | Recomputed chart inputs checked against the frozen files used by all three renderers |
| `duckdb/survey_psu_scores.csv` | Six PSU rows with domain counts, first-stage frame counts, and linearised scores |
| `simulation_summary.csv` | 12 stream-by-scenario rows with exact hits, coverage, marginal MCSEs, and paired MCSEs |
| `stream_diagnostics.csv` | 24 independent-stream coverage contrasts and pooled MCSEs |
| `stata/` | Native Stata 17 IC exports, log, executed driver, and replay evidence |
| `r/ch10_r.pdf` and `figures/` | The R yield figure and the narrow Python figure rendition |

The verifier requires one row per (chapter, metric, key) and one row per (design, size, replicate) in the fixed and independent output ledgers. Counts, membership keys, integer control totals, and coverage flags are exact. Floating-point comparisons use absolute tolerance 10⁻⁸ plus 10⁻¹⁰ times the larger absolute value. The deterministic comparisons use DuckDB as the common comparison baseline. `reference.py` checks independently derived quantities including survey covariance. Independent streams are compared through coverage and a four-pooled-MCSE diagnostic, in addition to the row-level checks on keys, seeds, and interval arithmetic. The simulation diagnostics are reported separately from the 6,870 deterministic and hand-anchor comparisons.

## Data and assumptions

`data/dictionary.csv` defines fields, units, and grain. `data/provenance.json` records how each fixture is used. All records and measurements in this part are synthetic. Blank measurements remain missing. The survey weights and PSU frame sizes form a controlled first-stage teaching design. Chapter 12 specifies the with-replacement benchmark, first-stage FPC sensitivity, and deliberate singleton example.
