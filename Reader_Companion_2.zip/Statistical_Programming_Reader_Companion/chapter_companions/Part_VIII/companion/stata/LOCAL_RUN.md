# Run Part VIII in Stata 16 or 17

The standalone kit is ready to extract. For a fresh kit from this companion,
copy `run_part8.do` and `part8_driver.do` to an empty directory. In that
directory make an `inputs` folder and copy every CSV from `companion/data/`
into it.

Set the Stata working directory to the kit folder and enter the following in
the Command window.

~~~stata
do run_part8.do
~~~

Keep the resulting `Stata_Verification_Part_VIII_*.zip` with your replication
evidence. Return code 0 means the wrapper and driver completed. Run
`companion/verify.py` with that archive to verify the numerical results.
The offline run uses built-in Stata and Mata in a temporary frame and
restores the original working directory.
