# Data provenance and permissions record

## Public macroeconomic inputs

The six source ZIP files preserve the World Development Indicators bulk CSV
responses used in Chapter 29. The source update is 11 November 2026 and
retrieval was 13 November 2026. `source/wdi_snapshot_metadata.json` records
the exact source endpoints. The analysis extracts three economies for
2000–2024, retains blanks and rounds imported values to ten decimal places.
The complete indicator metadata are included in each source archive.

| WDI indicator | Attribution in the source metadata |
| :-- | :-- |
| NY.GDP.MKTP.KD.ZG | Country official statistics, OECD national accounts and World Bank staff estimates |
| NY.GDP.DEFL.KD.ZG | National statistical offices, central bank national accounts and World Bank staff estimates |
| FP.CPI.TOTL.ZG | IMF International Financial Statistics |
| SL.UEM.TOTL.ZS | ILO Modelled Estimates, ILOSTAT |
| GC.TAX.TOTL.GD.ZS | IMF Government Finance Statistics Yearbook and data files |
| FR.INR.LEND | IMF International Financial Statistics |

Source attribution is to the World Bank, World Development Indicators,
and the original providers listed above. The World Bank's default data
terms apply CC BY 4.0 with additional terms and indicator-level exceptions.
The public-release rights check follows Stage 4 of the blueprint. Review
each third-party indicator before public redistribution or use the
documented retrieval endpoints as the access route.
[World Bank data terms](https://data.worldbank.org/summary-terms-of-use)

`source/bog_mpc_effective_dates.csv` transcribes the published effective
dates and rates through 2024. The companion uses those factual data points
to produce the daily steps and annual aggregates. Attribute the policy
series to the Bank of Ghana. The chart for this chapter is newly rendered
from the numerical series in the companion.
[Bank of Ghana policy rate trends](https://www.bog.gov.gh/monetary-policy/policy-rate-trends/)

The Ghana release-timing demonstration uses the public growth rate as its
base with synthetic dates and adjustments. Its version labels represent
a teaching schedule.

## Contextual and synthetic sources

- The Ghana Statistical Service and ICF report supplies published national
  aggregates for Chapter 30, including Table 9.7. The runnable files
  contain generated delivery, expenditure and follow-up records.
  [2022 Ghana DHS](https://www.dhsprogram.com/pubs/pdf/FR387/FR387.pdf)
- The IMF Financial Soundness Indicators guide supplies the contextual ratio
  definition in Chapter 31. The bank filings, crosswalk, exchange rates,
  transactions and investment assets are generated teaching data.
  [IMF FSI guide](https://www.imf.org/en/data/statistics/fsi-guide)
- The Ghana Census of Agriculture and FAO food-insecurity material inform
  the measurement discussion in Chapter 32. The household, plot and trial
  rows are generated. The seven-day indicator is a teaching item with
  its own definition.
  [Ghana Census of Agriculture](https://www.statsghana.gov.gh/census-surveys/agricultural-census)
  [FAO FIES methodology](https://www.fao.org/measuring-hunger/access-to-food/about-the-food-insecurity-experience-scale-%28fies%29/en)

The part's charts, tables and case data were created for this textbook.
Citations to methodological or contextual sources do not reproduce their
artwork, questionnaires or restricted records.
