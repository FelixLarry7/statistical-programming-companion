"""DuckDB checks for joins, estimands and evaluation on the aligned inputs."""

import argparse
from pathlib import Path

import duckdb

from ledger import Ledger


def run(data, reference, output):
    db=duckdb.connect(config={"threads": 1})
    for f in sorted(data.glob("*.csv")):
        db.read_csv(str(f)).create_view(f.stem)
    db.read_csv(str(reference)).create_view("fit_ledger")
    db.execute((Path(__file__).parent/"sql/labs.sql").read_text())
    def query(sql):
        return db.execute(sql).fetchall()
    def require_none(sql):
        if query(sql):
            raise ValueError(sql)
    for table, keys in (("macro29","country,year"),("policy29","year,day"),
        ("revision29","year,vintage"),("births30","person"),("bank_filings31","source,quarter,version"),
        ("bank_ids31","source,quarter"),("transactions31","line"),("assets31","month"),("plots32","plot"),
        ("households32","household"),("trial32","plot")):
        require_none(f"SELECT {keys} FROM {table} GROUP BY {keys} HAVING count(*)<>1")
    require_none("SELECT country FROM macro29 GROUP BY country HAVING count(*)<>25 OR count(growth)<>25")
    require_none("SELECT year FROM policy_annual WHERE days <> date_diff('day',make_date(year,1,1),make_date(year+1,1,1))")
    require_none("""SELECT f.source FROM bank_filings31 f LEFT JOIN bank_ids31 i USING(source,quarter)
                    WHERE i.bank IS NULL OR f.gross<=0 OR f.npl<0 OR f.npl>f.gross""")
    require_none("""SELECT bank,quarter FROM bank_initial GROUP BY ALL HAVING count(*)<>1""")
    require_none("""SELECT model FROM bank_predictions GROUP BY model HAVING count(*)<>138 OR count(DISTINCT (bank,quarter))<>138""")
    require_none("""SELECT r.line FROM retail_lines r LEFT JOIN retail_lines p ON r.original=p.line
        WHERE r.units<0 AND (p.line IS NULL OR p.units<=0 OR p.currency<>r.currency OR p.customer<>r.customer
                             OR p.price<>r.price OR p.month>r.month)""")
    require_none("""SELECT p.line FROM retail_lines p JOIN retail_lines r ON r.original=p.line
                    WHERE r.units<0 GROUP BY p.line,p.units HAVING -sum(r.units)>p.units""")
    require_none("""SELECT p.plot FROM plots32 p LEFT JOIN households32 h USING(household)
                    WHERE h.household IS NULL""")
    require_none("SELECT pair FROM trial32 GROUP BY pair HAVING count(*)<>2 OR sum(offer)<>1")
    ledger=Ledger()
    for r in query("SELECT country,year,growth,cpi,deflator,unemployment,tax,lending,nominal,index2019 FROM macro_outputs"):
        country,year,*values=r
        m=ledger.model("CH29",f"country{country}")
        if year>=2023:
            for key,value in zip(("growth","cpi","deflator","unemployment","tax","lending"),values[:6],strict=True):
                if value is not None: m.add("snapshot",f"{year}/{key}",value)
        m.add("nominal",year,values[6])
        if year>=2019: m.add("index2019",year,100 if year==2019 else values[7])
    for country,*counts in query("""SELECT country,count(growth),count(cpi),count(deflator),
                                            count(unemployment),count(tax),count(lending) FROM macro29 GROUP BY country"""):
        ledger.model("CH29",f"country{country}").vector("available",
            ("growth","cpi","deflator","unemployment","tax","lending"),counts)
    for country,v in query("""SELECT country,100*(power(product(1+growth/100),0.1)-1)
                                FROM macro29 WHERE year>=2015 GROUP BY country"""):
        ledger.model("CH29",f"country{country}").scalars(cagr2014=v)
    for c,o,h,a,b,e1,e2 in query("SELECT country,origin,horizon,average,ar,error_average,error_ar FROM macro_forecasts"):
        m=ledger.model("CH29",f"country{c}")
        for k,v in (("forecast_average",a),("forecast_ar",b),("error_average",e1),("error_ar",e2)):
            m.add(k,f"{o}/{h}",v)
    for c,h,*v in query("""SELECT country,horizon,sqrt(avg(error_average^2)),avg(abs(error_average)),
                          sqrt(avg(error_ar^2)),avg(abs(error_ar)) FROM macro_forecasts GROUP BY country,horizon"""):
        for k,z in zip(("rmse_average","mae_average","rmse_ar","mae_ar"),v,strict=True):
            ledger.model("CH29",f"country{c}").add(k,h,z)
    m=ledger.model("CH29","policy")
    for y,*v in query("SELECT year,days,annual_mean,year_end FROM policy_annual"):
        for k,z in zip(("days","annual_mean","year_end"),v,strict=True): m.add(k,y,z)
    n,c=query("SELECT count(*),corr(a.annual_mean,m.growth) FROM macro29 m JOIN policy_annual a ON a.year=m.year-1 WHERE m.country=1")[0]
    r=query("SELECT 100*((1+a.annual_mean/100)/(1+m.cpi/100)-1) FROM macro29 m JOIN policy_annual a USING(year) WHERE country=1 AND year=2024")[0][0]
    m.scalars(n_association=n,correlation=c,real_policy_2024=r)
    m=ledger.model("CH29","vintage")
    for o,y,v in query("SELECT origin,year,vintage FROM vintage_choices"): m.add("selected",f"{o}/{y}",v)
    for o,a,b in query("""SELECT v.origin,avg(v.value),avg(f.value) FROM vintage_choices v JOIN revision29 f
                             ON f.year=v.year AND f.vintage=2 GROUP BY v.origin"""):
        m.add("asof_mean",o,a)
        m.add("final_mean",o,b)
    for ch,m,n,den,num,estimate,se,df in query("""SELECT t.chapter,t.model,t.n,t.denominator,t.numerator,t.estimate,v.se,v.df
                                                  FROM survey_totals t JOIN survey_variance v USING(chapter,model)"""):
        ledger.model(ch,m).scalars(n=n,denominator=den,numerator=num,estimate=estimate,se=se,df=df,
                                   lo=estimate-2.1199052992210112*se,hi=estimate+2.1199052992210112*se)
    n,r,o,miss=query("SELECT count(*),count_if(recent_live),count_if(eligible),count_if(recent_live AND NOT eligible) FROM birth_domain")[0]
    ledger.model("CH30","flow").scalars(records=n,window=r,observed=o,missing=miss)
    rural,urban=query("""SELECT max(estimate) FILTER(WHERE model='rural'),
                          max(estimate) FILTER(WHERE model='urban') FROM survey_totals WHERE chapter='CH30'""")[0]
    se=query("""WITH by_h AS (SELECT r.stratum,count(*) AS n,var_samp(r.score-u.score) AS v FROM survey_psu r
                  JOIN survey_psu u USING(chapter,stratum,psu) WHERE r.chapter='CH30'
                  AND r.model='rural' AND u.model='urban' GROUP BY r.stratum)
                  SELECT sqrt(sum(n*v)) FROM by_h""")[0][0]
    delta=rural-urban
    cv=2.1199052992210112
    ledger.model("CH30","rural_gap").scalars(estimate=delta,se=se,df=16,lo=delta-cv*se,hi=delta+cv*se)
    m=ledger.model("CH30","survival")
    surv=1
    for t,n,d,c in query("""SELECT q.time,count_if(s.time>=q.time),count_if(s.time=q.time AND event=1),
                            count_if(s.time=q.time AND event=0) FROM (SELECT DISTINCT time FROM followup30) q
                            CROSS JOIN followup30 s GROUP BY q.time ORDER BY q.time"""):
        surv*=1-d/n
        for k,v in (("risk",n),("events",d),("censor",c),("survival",surv)): m.add(k,t,v)
    n,o,k,rename,merger=query("""SELECT count(*),(SELECT count(*) FROM bank_outcome),
                (SELECT count(*) FROM bank_filings31),count_if(bank=2 AND source=102),count_if(segment=105) FROM bank_initial""")[0]
    m=ledger.model("CH31","flow")
    m.scalars(quarter_rows=n,outcome_rows=o,filings=k,excluded=n-o,rename_in_scope=rename,merged_in_scope=merger)
    for bank,q,v in query("SELECT bank,quarter,ratio FROM bank_initial"):
        m.add("initial_npl",f"{bank}/{q}",v)
    tn,te=query("SELECT count(*),sum(event) FROM bank_outcome WHERE quarter<=15")[0]
    late=query("SELECT count_if(latest_release>quarter+1) FROM bank_outcome WHERE quarter BETWEEN 18 AND 23")[0][0]
    for model,*v in query("SELECT * FROM bank_metrics"):
        m=ledger.model("CH31",model)
        m.vector("scalar",("n","events","mean_p","event_rate","brier","logloss","tp","fp","tn","fn","auc"),v)
        m.scalars(n_train=tn,train_events=te,late_features=late if model=="latest" else 0)
    for model,j,n,p,y in query("""WITH ids AS (SELECT DISTINCT model FROM bank_predictions)
            SELECT m.model,k.bin,count(p.bank),avg(p.p),avg(p.event) FROM ids m CROSS JOIN range(1,6) k(bin)
            LEFT JOIN bank_predictions p ON p.model=m.model AND k.bin=least(5,1+floor(5*p.p))
            GROUP BY m.model,k.bin"""):
        m=ledger.model("CH31",model)
        m.add("bin_n",j,n)
        if n: m.add("bin_p",j,p); m.add("bin_y",j,y)
    m=ledger.model("CH31","retail")
    for month,*v in query("SELECT * FROM retail_month"):
        for k,z in zip(("sales","returns","net","buyers","repeat","anonymous_sales"),v,strict=True): m.add(k,month,z)
    require_none("SELECT month FROM assets31 WHERE equity<=0 OR bond<=0")
    m=ledger.model("CH31","investment")
    for month,ret,wealth,draw in query(
        "SELECT month,total-1,value,drawdown FROM portfolio_intervals"
    ):
        for k,v in (("return",ret),("wealth",wealth),("drawdown",draw)):
            m.add(k,month,v)
    total,price,draw=query(
        "SELECT arg_max(value,month)-1,arg_max(value_price,month)-1,min(drawdown) FROM portfolio_intervals"
    )[0]
    m.scalars(total_return=total,price_return=price,max_drawdown=min(0,draw))
    m=ledger.model("CH32","flow")
    n,k,p,missing=query("SELECT count(*),count_if(maize=1),(SELECT count(*) FROM households32),count_if(maize=1 AND harvest<0) FROM plots32")[0]
    a,z,i,b=query("SELECT count(*),count_if(kg=0),count_if(share<1),count_if(unit=2) FROM valid_maize")[0]
    m.scalars(households=p,plots=n,maize=k,missing_harvest=missing,usable=a,zero=z,intercropped=i,bag_units=b)
    for i,kg,area in query("SELECT plot,kg,gps_ha FROM valid_maize"):
        m.add("harvest_kg",i,kg)
        m.add("gps_ha",i,area)
    for model,*v in query("SELECT * FROM yield_choices"):
        ledger.model("CH32",model).vector("scalar",("n","kg","hectares","ratio","plot_mean"),v)
    v=query("""SELECT count(*),count_if(meal_shortfall=-1),sum(weight*food_spend)/sum(weight*size),
                 sum(weight*food_spend/size)/sum(weight),sum(weight*food_spend)/sum(weight*(adults+0.5*(size-adults)))
                 FROM households32 WHERE rural=1""")[0]
    ledger.model("CH32","welfare").vector("scalar",("n_rural","missing_rural","per_person","household_pc","per_equivalent"),v)
    m=ledger.model("CH32","trial")
    for pair,y,x in query("SELECT * FROM pair_contrasts"):
        m.add("pair_y",pair,y)
        m.add("pair_a",pair,x)
    v=query("""WITH s AS (SELECT count(*) AS n,avg(dy) AS itt,avg(dx) AS fs,
                   avg(dy)/avg(dx) AS late,stddev_samp(dy)/sqrt(count(*)) AS se FROM pair_contrasts)
               SELECT n,itt,fs,late,se,(SELECT stddev_samp(dy-s.late*dx) FROM pair_contrasts)/(sqrt(n)*fs),
                (SELECT avg(yield_kg_ha) FILTER (WHERE adopt=1)-avg(yield_kg_ha) FILTER (WHERE adopt=0) FROM trial32)
               FROM s""")[0]
    m.vector("scalar",("pairs","itt","first","late","itt_se","late_se","naive"),v)
    output.mkdir(parents=True,exist_ok=True)
    ledger.save(output/"metrics.csv")
    print(f"DuckDB {duckdb.__version__} {len(ledger.rows)} keyed values")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data",type=Path)
    parser.add_argument("reference",type=Path)
    parser.add_argument("output",type=Path)
    a=parser.parse_args()
    run(a.data,a.reference,a.output)
