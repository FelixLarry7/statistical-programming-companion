# Independent R fits and transformations for Part VIII.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2)
get_data <- function(n) read.csv(file.path(args[1],paste0(n,".csv")))
dir.create(args[2],recursive=TRUE,showWarnings=FALSE)
parts <- list()
put <- function(ch,m,q,k,v) {
  stopifnot(length(k)==length(v),all(is.finite(v)))
  parts[[length(parts)+1L]] <<- data.frame(chapter=ch,model=m,quantity=q,key=as.character(k),value=as.numeric(v))
}
sc <- function(ch,m,v) put(ch,m,"scalar",names(v),v)
pred <- function(x,b) plogis(drop(x%*%b))
logistic <- function(x,y,w=rep(1,length(y))) {
  fit <- glm.fit(x,y,weights=w,family=quasibinomial(),control=glm.control(epsilon=1e-13,maxit=60))
  stopifnot(fit$converged,all(is.finite(fit$coefficients)))
  fit$coefficients
}
basis <- function(...) cbind(...)

design_se <- function(u,d) {
  by_psu <- rowsum(u,d$psu)
  s <- floor(as.numeric(rownames(by_psu))/100)
  mh <- table(s)
  stopifnot(length(mh)==4,all(mh==5))
  c(se=sqrt(sum(tapply(drop(by_psu),s,var)*mh)),df=sum(mh-1))
}
interval <- function(ch,m,p,d) {
  cv <- qt(0.975,d[["df"]])
  sc(ch,m,c(estimate=p,d,lo=p-cv*d[["se"]],hi=p+cv*d[["se"]]))
}
domain <- function(ch,m,y,keep,d) {
  w <- d$weight*keep
  den <- sum(w)
  num <- sum(w*y)
  p <- num/den
  u <- w*(y-p)/den
  sc(ch,m,c(n=sum(keep),denominator=den,numerator=num))
  interval(ch,m,p,design_se(u,d))
  list(p=p,u=u)
}

macro <- function() {
  d <- get_data("macro29")
  policy <- get_data("policy29")
  rev <- get_data("revision29")
  fields <- c("growth","cpi","deflator","unemployment","tax","lending")
  stopifnot(!anyDuplicated(d[c("country","year")]),nrow(d)==75)
  for (c in 1:3) {
    g <- d[d$country==c,]
    g <- g[order(g$year),]
    stopifnot(all(g$year==2000:2024))
    model <- paste0("country",c)
    put("CH29",model,"available",fields,colSums(!is.na(g[fields])))
    for (field in fields) {
      k <- g$year>=2023 & !is.na(g[[field]])
      if (any(k)) put("CH29",model,"snapshot",paste(g$year[k],field,sep="/"),g[k,field])
    }
    put("CH29",model,"nominal",g$year,100*((1+g$growth/100)*(1+g$deflator/100)-1))
    put("CH29",model,"index2019",2019:2024,c(100,100*cumprod(1+g$growth[g$year>=2020]/100)))
    sc("CH29",model,c(cagr2014=100*(prod(1+g$growth[g$year>=2015]/100)^0.1-1)))
    er <- array(0,c(8,2,2))
    for (o in 2015:2022) {
      seq <- g$growth[g$year<=o]
      b <- lm.fit(cbind(1,head(seq,-1)),tail(seq,-1))$coefficients
      avg <- mean(tail(seq,5))
      p <- tail(seq,1)
      for (h in 1:2) {
        p <- b[1]+b[2]*p
        y <- g$growth[g$year==o+h]
        k <- paste(o,h,sep="/")
        for (j in 1:2) {
          name <- c("average","ar")[j]
          v <- c(avg,p)[j]
          put("CH29",model,paste0("forecast_",name),k,v)
          put("CH29",model,paste0("error_",name),k,y-v)
          er[o-2014,h,j] <- y-v
        }
      }
    }
    for (h in 1:2) for (j in 1:2) {
      name <- c("average","ar")[j]
      put("CH29",model,paste0("rmse_",name),h,sqrt(mean(er[,h,j]^2)))
      put("CH29",model,paste0("mae_",name),h,mean(abs(er[,h,j])))
    }
  }
  stopifnot(!anyDuplicated(policy[c("year","day")]))
  annual <- tapply(policy$policy,policy$year,mean)
  last <- tapply(policy$policy,policy$year,function(x) tail(x,1))
  put("CH29","policy","days",2003:2024,table(policy$year))
  put("CH29","policy","annual_mean",2003:2024,annual)
  put("CH29","policy","year_end",2003:2024,last)
  g <- d[d$country==1,]
  sc("CH29","policy",c(n_association=21,correlation=cor(annual[1:21],g$growth[g$year>=2004]),
      real_policy_2024=100*((1+unname(annual["2024"])/100)/(1+g$cpi[g$year==2024]/100)-1)))
  for (origin in c(2020,2022)) {
    v <- rev[rev$available<=origin & rev$year %in% (origin-3):(origin-1),]
    v <- v[order(v$year,v$vintage),]
    a <- v[!duplicated(v$year,fromLast=TRUE),]
    stopifnot(nrow(a)==3)
    put("CH29","vintage","selected",paste(origin,a$year,sep="/"),a$vintage)
    put("CH29","vintage","asof_mean",origin,mean(a$value))
    put("CH29","vintage","final_mean",origin,mean(rev$value[rev$vintage==2 & rev$year%in%a$year]))
  }
}

health <- function() {
  d <- get_data("births30")
  s <- get_data("followup30")
  costs <- get_data("expenditure30")
  stopifnot(!anyDuplicated(d$person),!anyDuplicated(costs$household))
  window <- d$live==1 & d$months<24
  used <- window & d$facility%in%0:1
  y <- as.numeric(d$facility==1)
  sc("CH30","flow",c(records=nrow(d),window=sum(window),observed=sum(used),missing=sum(window & !used)))
  domain("CH30","all",y,used,d)
  r <- domain("CH30","rural",y,used & d$rural==1,d)
  u <- domain("CH30","urban",y,used & d$rural==0,d)
  interval("CH30","rural_gap",r$p-u$p,design_se(r$u-u$u,d))
  a <- d[used,]
  w <- a$weight
  y <- a$facility
  x <- cbind(1,a$insured,a$rural,(a$age-27)/10,a$parity,a$wealth)
  b <- logistic(x,y,w)
  z0 <- z1 <- x
  z0[,2] <- 0
  z1[,2] <- 1
  pr <- pred(x,b)
  p0 <- pred(z0,b)
  p1 <- pred(z1,b)
  delta <- weighted.mean(p1-p0,w)
  g <- (crossprod(z1,w*p1*(1-p1))-crossprod(z0,w*p0*(1-p0)))/sum(w)
  B <- crossprod(x,(w*pr*(1-pr))*x)
  lin <- rep(0,nrow(d))
  lin[used] <- w*(p1-p0-delta)/sum(w)+drop((w*(y-pr)*x)%*%solve(B,g))
  put("CH30","insurance","beta",c("intercept","insured","rural","age","parity","wealth"),b)
  sc("CH30","insurance",c(odds_ratio=exp(b[2]),risk0=weighted.mean(p0,w),risk1=weighted.mean(p1,w),
      naive_gap=weighted.mean(y[a$insured==1],w[a$insured==1])-weighted.mean(y[a$insured==0],w[a$insured==0])))
  interval("CH30","insurance",delta,design_se(lin,d))
  sc("CH30","sensitivity",c(unweighted=mean(y),
      extended36=mean(d$facility[d$live==1 & d$facility%in%0:1]),
      lower_bound=sum(d$weight[window & d$facility==1])/sum(d$weight[window]),
      upper_bound=sum(d$weight[window & d$facility!=0])/sum(d$weight[window])))
  x <- cbind(1,costs$rural,costs$chronic,costs$insured)
  positive <- costs$spend>0
  b <- logistic(x,positive*1)
  fit <- lm.fit(x[positive,],log(costs$spend[positive]))
  smear <- mean(exp(fit$residuals))
  sc("CH30","spending",c(n=nrow(costs),positive=sum(positive),unconditional=mean(costs$spend),
       positive_mean=mean(costs$spend[positive]),smear=smear))
  for (j in 0:1) {
    z <- x
    z[,4] <- j
    q <- pred(z,b)
    meanpos <- smear*exp(drop(z%*%fit$coefficients))
    put("CH30","spending","prob_positive",j,mean(q))
    put("CH30","spending","mean_positive",j,mean(meanpos))
    put("CH30","spending","mean_spend",j,mean(q*meanpos))
  }
  survival <- 1
  for (t in sort(unique(s$time))) {
    risk <- sum(s$time>=t)
    event <- sum(s$time==t & s$event==1)
    censor <- sum(s$time==t & s$event==0)
    survival <- survival*(1-event/risk)
    for (k in c("risk","events","censor","survival"))
      put("CH30","survival",k,t,switch(k,risk=risk,events=event,censor=censor,survival=survival))
  }
}

risk_metrics <- function(y,p) {
  diff <- outer(p[y==1],p[y==0],"-")
  z <- pmin(1-1e-12,pmax(1e-12,p))
  flag <- p>=0.35
  c(n=length(y),events=sum(y),mean_p=mean(p),event_rate=mean(y),
    auc=mean((diff>0)+0.5*(diff==0)),brier=mean((p-y)^2),logloss=-mean(y*log(z)+(1-y)*log1p(-z)),
    tp=sum(flag & y==1),fp=sum(flag & y==0),tn=sum(!flag & y==0),fn=sum(!flag & y==1))
}
finance <- function() {
  filings <- get_data("bank_filings31")
  ids <- get_data("bank_ids31")
  tx <- get_data("transactions31")
  assets <- get_data("assets31")
  stopifnot(!anyDuplicated(filings[c("source","quarter","version")]),!anyDuplicated(ids[c("source","quarter")]))
  d <- merge(filings,ids,by=c("source","quarter"))
  stopifnot(nrow(d)==nrow(filings),all(d$npl>=0 & d$npl<=d$gross & d$gross>0))
  d$ratio <- d$npl/d$gross
  i <- d[d$release<=d$quarter+1,]
  latest <- d[order(d$release,decreasing=TRUE),]
  latest <- latest[!duplicated(latest[c("bank","quarter")]),c("bank","quarter","ratio","release")]
  stopifnot(nrow(i)==nrow(latest),nrow(i)==nrow(ids))
  nextq <- i[c("bank","segment","quarter","ratio")]
  nextq$quarter <- nextq$quarter-1
  names(nextq)[4] <- "future_ratio"
  s <- merge(merge(i,nextq,by=c("bank","segment","quarter")),latest,
             by=c("bank","quarter"),suffixes=c("","_latest"))
  s <- s[order(s$bank,s$quarter),]
  s$event <- as.integer(s$future_ratio>=0.08)
  sc("CH31","flow",c(filings=nrow(filings),quarter_rows=nrow(i),outcome_rows=nrow(s),
                      excluded=nrow(i)-nrow(s),rename_in_scope=sum(i$bank==2 & i$source==102),
                      merged_in_scope=sum(i$segment==105)))
  put("CH31","flow","initial_npl",paste(i$bank,i$quarter,sep="/"),i$ratio)
  tr <- s[s$quarter<=15,]
  te <- s[s$quarter%in%18:23,]
  for (model in c("initial","latest","constant")) {
    if (model=="constant") p <- rep(mean(tr$event),nrow(te))
    else {
      field <- if (model=="initial") "ratio" else "ratio_latest"
      x <- function(d) cbind(1,(100*d[[field]]-8)/3,(100*d$capital-14)/3,(100*d$funding-22)/8)
      b <- logistic(x(tr),tr$event)
      p <- pred(x(te),b)
      put("CH31",model,"beta",c("intercept","npl","capital","funding"),b)
    }
    sc("CH31",model,c(n_train=nrow(tr),train_events=sum(tr$event),
        late_features=if (model=="latest") sum(te$release_latest>te$quarter+1) else 0,
        risk_metrics(te$event,p)))
    put("CH31",model,"prediction",paste(te$bank,te$quarter,sep="/"),p)
    bins <- pmin(4,floor(5*p))+1
    for (k in 1:5) {
      z <- bins==k
      put("CH31",model,"bin_n",k,sum(z))
      if (any(z)) {
        put("CH31",model,"bin_p",k,mean(p[z]))
        put("CH31",model,"bin_y",k,mean(te$event[z]))
      }
    }
  }
  a <- tx[tx$posted==1,]
  a$value <- a$units*a$price*a$fx
  sold <- a[a$units>0,]
  neg <- a[a$units<0,]
  links <- merge(neg,sold,by.x="original",by.y="line",suffixes=c("","_sale"))
  stopifnot(nrow(links)==nrow(neg),all(links$customer==links$customer_sale),
      all(links$currency==links$currency_sale),all(links$month>=links$month_sale))
  seen <- integer()
  for (j in 1:3) {
    q <- a[a$month==j,]
    ids <- unique(q$customer[q$customer>0 & q$units>0])
    gross <- sum(q$value[q$units>0])
    ret <- -sum(q$value[q$units<0])
    vals <- c(sales=gross,returns=ret,net=gross-ret,buyers=length(ids),repeat_count=sum(ids%in%seen),
               anonymous_sales=sum(q$value[q$units>0 & q$customer==0]))
    names(vals)[5] <- "repeat"
    for (k in names(vals)) put("CH31","retail",k,j,vals[[k]])
    seen <- union(seen,ids)
  }
  a <- assets
  total <- 0.6*tail(a$equity+a$equity_cash,-1)/head(a$equity,-1)+
           0.4*tail(a$bond+a$bond_cash,-1)/head(a$bond,-1)
  price <- 0.6*tail(a$equity,-1)/head(a$equity,-1)+0.4*tail(a$bond,-1)/head(a$bond,-1)
  wealth <- cumprod(total)
  draw <- wealth/cummax(c(1,wealth))[-1]-1
  put("CH31","investment","return",2:12,total-1)
  put("CH31","investment","wealth",2:12,wealth)
  put("CH31","investment","drawdown",2:12,draw)
  sc("CH31","investment",c(total_return=tail(wealth,1)-1,price_return=prod(price)-1,max_drawdown=min(draw)))
}

agriculture <- function() {
  h <- get_data("households32")
  p <- get_data("plots32")
  t <- get_data("trial32")
  stopifnot(!anyDuplicated(h$household),!anyDuplicated(p$plot),!anyDuplicated(t$plot),
            all(p$household%in%h$household))
  crop <- p$maize==1
  ok <- crop & p$harvest>=0 & p$gps>0 & p$reported>0 & p$unit%in%1:2
  a <- p[ok,]
  kg <- a$harvest*ifelse(a$unit==2,50,1)*(1-a$moisture)/0.85
  gps <- a$gps*a$share/10000
  reported <- a$reported*a$share/10000
  sc("CH32","flow",c(households=nrow(h),plots=nrow(p),maize=sum(crop),usable=nrow(a),
      missing_harvest=sum(crop & p$harvest<0),zero=sum(kg==0),intercropped=sum(a$share<1),bag_units=sum(a$unit==2)))
  put("CH32","flow","harvest_kg",a$plot,kg)
  put("CH32","flow","gps_ha",a$plot,gps)
  for (model in c("gps","reported","harvested","main_season")) {
    use <- rep(TRUE,nrow(a))
    area <- gps
    if (model=="reported") area <- reported
    if (model=="harvested") {
      use <- kg>0
      area <- area*a$harvested
    }
    if (model=="main_season") use <- a$season==1
    k <- kg[use]
    z <- area[use]
    sc("CH32",model,c(n=length(k),kg=sum(k),hectares=sum(z),ratio=sum(k)/sum(z),plot_mean=mean(k/z)))
  }
  y <- as.numeric(h$meal_shortfall==1)
  use <- h$meal_shortfall%in%0:1
  domain("CH32","all_food",y,use,h)
  domain("CH32","rural_food",y,use & h$rural==1,h)
  domain("CH32","urban_food",y,use & h$rural==0,h)
  r <- h[h$rural==1,]
  sc("CH32","welfare",c(n_rural=nrow(r),missing_rural=sum(r$meal_shortfall==-1),
      per_person=sum(r$weight*r$food_spend)/sum(r$weight*r$size),
      household_pc=weighted.mean(r$food_spend/r$size,r$weight),
      per_equivalent=sum(r$weight*r$food_spend)/sum(r$weight*(r$adults+0.5*(r$size-r$adults)))))
  s <- merge(t[t$offer==1,],t[t$offer==0,],by="pair",suffixes=c("1","0"))
  stopifnot(nrow(s)==120,!anyDuplicated(s$pair))
  dy <- s$yield_kg_ha1-s$yield_kg_ha0
  dx <- s$adopt1-s$adopt0
  n <- nrow(s)
  late <- mean(dy)/mean(dx)
  sc("CH32","trial",c(pairs=n,itt=mean(dy),first=mean(dx),late=late,itt_se=sd(dy)/sqrt(n),
      late_se=sd(dy-late*dx)/(mean(dx)*sqrt(n)),
      naive=mean(t$yield_kg_ha[t$adopt==1])-mean(t$yield_kg_ha[t$adopt==0])))
  put("CH32","trial","pair_y",s$pair,dy)
  put("CH32","trial","pair_a",s$pair,dx)
}

macro()
health()
finance()
agriculture()
answer <- do.call(rbind,parts)
stopifnot(!anyDuplicated(answer[1:4]))
write.table(answer,file.path(args[2],"metrics.csv"),sep=",",quote=FALSE,row.names=FALSE)
cat(R.version.string,nrow(answer),"keyed values\n")
