# Part VIII data dictionary

Files are UTF-8 CSV with one header row, comma separators and decimal
points. The source-to-analysis generator records the synthetic parameters
and fixed seeds. All source CSVs and analysis CSVs are covered by the
package checksum manifest. Integer keys have no substantive ordering
except dates, quarters, months, release versions and within-group sequences.

## Chapter 29. Macroeconomic data

| File and key | Fields and conventions |
| :-- | :-- |
| `macro29.csv`, country × year | Country 1 Ghana, 2 Kenya, 3 Senegal. Calendar years 2000–2024. Growth, CPI and GDP deflator are annual percentages. Unemployment is a percent of the labour force, tax is a percent of GDP and lending is an annual percentage rate. Blank fields record missing WDI observations. |
| `policy29.csv`, year × day | Day is the one-based calendar day of year. Policy is the Bank of Ghana annual percentage policy rate in effect that day. The daily calendar runs 2003–2024. |
| `revision29.csv`, year × vintage | Synthetic versions of Ghana growth. Availability is an integer cutoff year. First and second releases become available in reference year plus one and plus two respectively. Value is growth in percentage units. |

## Chapter 30. Health data

| File and key | Fields and conventions |
| :-- | :-- |
| `births30.csv`, person | One synthetic index record per person. Stratum, PSU and positive relative design weight. Rural and insured are binary. Age is in years, parity is a count and wealth is a continuous synthetic score. Months are completed months since the index delivery. Live indicates live birth. Facility is 1 for facility, 0 for other place and −1 for unknown. |
| `expenditure30.csv`, household | Rural, chronic condition and insurance indicators. Spend is synthetic monthly out-of-pocket GHS, with zero observed spending retained. |
| `followup30.csv`, person | Time from a common origin in teaching units. Event 1 is first event and 0 is right censoring. At tied times events use the risk set just before censoring. |

## Chapter 31. Finance data

| File and key | Fields and conventions |
| :-- | :-- |
| `bank_ids31.csv`, source × quarter | Maps the numeric source institution code and reference quarter to an analytical bank and consolidation segment. Bank 2 changes its code at quarter 10. Bank 5 enters segment 105 at quarter 17 and bank 6 no longer files. |
| `bank_filings31.csv`, source × quarter × version | Release is the quarter the version becomes observable. Gross loans and NPL are in the same arbitrary monetary units. Capital and funding are shares. Version 1 is initial and 2 is deliberately outcome-informative and late. |
| `transactions31.csv`, line | Month is the posting month. Currency 1 is GHS, 2 a teaching foreign currency. Units are signed. Price is per unit in original currency, FX is GHS per currency unit, original links a return to the sale line, and posted is a binary status. Customer zero is anonymous and original zero marks a sale. |
| `assets31.csv`, month | Monthly equity and bond prices and per-unit cash distributions during the interval ending in the labelled month. Prices use common teaching currency units. |

## Chapter 32. Agriculture data

| File and key | Fields and conventions |
| :-- | :-- |
| `households32.csv`, household | Stratum, PSU, rural indicator, household size, adult count, market distance in km, meal shortfall and food spending. Shortfall is 1 for a synthetic seven-day household response, 0 for no, −1 for unknown. Spending is synthetic monthly GHS. Weight is a positive relative survey weight. |
| `plots32.csv`, plot | Unique plot-season record with a household key. Season 1 is main, 2 secondary. Maize indicates crop eligibility. GPS and reported are total square metres. Share is the fraction allocated to maize and harvested is the fraction of that planted crop area harvested. Unit 1 is kg, 2 is a 50 kg bag. Harvest is quantity in the stated unit, with zero valid and −1 missing. Moisture is the wet-basis fraction. |
| `trial32.csv`, plot | Independent synthetic offer study, with pair key, binary offer and uptake and realised yield in kg/ha. Each pair has exactly one offered and one unoffered record. The paired trial IDs do not link to the other agriculture files. |
