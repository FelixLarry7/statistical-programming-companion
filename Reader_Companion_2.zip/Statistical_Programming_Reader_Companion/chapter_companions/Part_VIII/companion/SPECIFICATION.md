# Part VIII analytical specification

The frozen implementation aligns statistical definitions before running
Python, R, Stata and DuckDB. The decision, input and output keys below give
the minimum information needed to inspect each result. Numeric estimates
use double precision. The verifier compares continuous values at the
declared absolute and relative tolerance and matches discrete counts and
choices exactly.

## Chapter 29. Briefing and forecasts

Use one row per country and calendar year and retain all 75 rows in the
fixed 2000–2024 grid. The policy-rate chronology is separate, keyed to
effective dates. Summarise a 2003–2024 daily expansion by mean and last
calendar day. The association uses paired observations from 2004 to 2024,
with the prior year's mean policy rate and the current year's real growth.

At each origin from 2015 to 2022, fit OLS with an intercept and one growth
lag on consecutive pairs beginning in 2000. Start at the last observed
growth and apply the fitted rule recursively for horizons one and two.
The comparison forecast is the trailing five-year growth mean, used at
both horizons. Score actual minus prediction using MAE and RMSE by country
and horizon. In the separate synthetic release experiment, keep the latest
admissible release for each reference year within the three-year window.
No standard errors are attached to the forecasting scorecard.

## Chapter 30. Coverage and expenditure

In the delivery file, define recent live birth as live and 0–23 completed
months since delivery. The primary domain also requires a valid binary
place. Preserve all four strata and 20 PSUs when forming domain and
contrast contributions. Variance uses with-replacement Taylor
linearisation, 16 design degrees of freedom and a two-sided 95% Student
interval. Missing-place extremes change the numerator while retaining the
eligible full-window denominator.

Fit the weighted Bernoulli logit on observed eligible records with the
intercept and insurance, rural residence, age in centred decades, parity
and wealth. Compare the insurance settings on the same weighted covariate
rows. Variance combines empirical standard-population and fitted-score
terms before PSU aggregation. For expenditure, use a Bernoulli logit for
any spending and an OLS log-spending regression among positive records.
Both use rural residence, chronic status and insurance with an intercept.
The unconditional mean averages complete original-scale predictions over
the unweighted grid. The follow-up fixture uses one origin and right
censoring. Keep tied censored observations in the risk set at the event
time.

## Chapter 31. Asset-quality monitoring

Join the filings to the identity and perimeter crosswalk by source and
quarter. Select the latest release no later than quarter plus one.
The event is a gross NPL share at least 0.08 in the next quarter's initial
filing within the same consolidation segment. Train on reference quarters
1–15 and test on 18–23. Leave 16–17 out of both roles. Fit an intercept and
the three pre-scaled features using unpenalised Bernoulli logistic
likelihood. Use the same labels and rows for the training-rate comparator
and the deliberately late NPL revision. Compare AUC, Brier, log loss and
the 0.35 threshold, with one-half credit for AUC ties. Calibration uses
five equal-width bins, each left closed and right open except that the last
also includes one. SQL reconstructs samples and scores the independently
exported Python probabilities.

Count booked retail lines by posting month. Convert signed value to GHS
line by line. Retain only posted lines, validate the original sale link and
count buyers among distinct identified customers with a positive purchase.
Define repeat from earlier observed months. For the investment fixture,
rebalance at 60% equity and 40% bond each interval, using cash paid in the
ending interval, initial wealth one and zero costs. Include starting wealth
when computing the peak used for drawdown.

## Chapter 32. Yield, welfare and adoption

Keep one row per household for welfare and one row per plot-season record
for yield. The maize sample uses valid harvests, positive areas and
recognised units. Convert to kg at 15% moisture and divide square metres
by 10,000 after maize allocation. Report total kg per total hectare and
equal-plot mean. The reported-area variant uses the same rows and kg.
The harvested-area and main-season variants have their own eligibility
and denominator rules.

Estimate the household shortfall ratio and interval with the design
conventions used for delivery coverage. For rural spending, use the
ratio of weighted food outlay to weighted population, the household-
weighted mean of per-person outlay and the ratio to weighted adult
equivalents. In the independent paired experiment, take offered minus
unoffered differences by pair for uptake and outcome. Divide the average
yield difference by the average uptake difference. Use standard
errors across paired contrasts and the ratio linearisation for the
Wald estimate. The raw adopter–nonadopter gap is a separate description.
