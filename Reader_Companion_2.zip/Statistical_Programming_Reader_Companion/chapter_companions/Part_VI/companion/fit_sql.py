"""Run DuckDB grain, calendar, weights and common-estimand checks."""

import argparse
from pathlib import Path

import duckdb
import numpy as np

from ledger import Ledger


def require(c, sql, n=0):
    actual = c.execute(sql).fetchone()[0]
    if actual!=n:
        raise ValueError(f'Expected {n}, found {actual}. Query: {sql}')


def scalars(c, lab, sql, args=None):
    cursor = c.execute(sql,args or [])
    keys = [col[0] for col in cursor.description]
    lab.vector('scalar',keys,cursor.fetchone())


def panel(c, ledger):
    require(c,'select count(*)-count(distinct (entity,year)) from panel21')
    require(c,'select count(*) from panel_lags where prev>=year')
    m = ledger.model('CH21','within')
    scalars(c,m,'''with a as (select count(*) n,count(distinct entity) ng,
                     sum(residual^2) rss,avg(alpha) as intercept from within_fit)
                   select n,ng as "groups",n-ng-2 as df,rss,rss/(n-ng-2) as s2,intercept,
                     ng::double/(ng-1)*(n-1)/(n-ng-2) as cr1_factor,
                     (select count(*) from panel_lags where n_i=1) as singletons from a''')
    b1,b2,aa,bb,ab = c.execute('select * from within_coefficients').fetchone()
    m.vector('beta',('x1','x2'),(b1,b2))
    for i,year,y,e in c.execute('select entity,year,y,residual from within_fit').fetchall():
        m.add('fit',f'{i}/{year}',y-e)
        m.add('resid',f'{i}/{year}',e)
    for i,a in c.execute('select entity,avg(alpha)-(select avg(alpha) from within_fit) from within_fit group by entity').fetchall():
        m.add('effect',i,a)
    for i,a,b in c.execute('select * from panel_scores').fetchall():
        m.add('score',f'{i}/x1',a)
        m.add('score',f'{i}/x2',b)
    m11,m22,m12 = c.execute('select sum(x1^2),sum(x2^2),sum(x1*x2) from panel_scores').fetchone()
    bread = np.linalg.inv([[aa,ab],[ab,bb]])
    v = bread@np.array([[m11,m12],[m12,m22]])@bread
    n,g = c.execute('select count(*),count(distinct entity) from within_fit').fetchone()
    m.matrix('cov_cr0',('x1','x2'),v)
    m.matrix('cov_cr1',('x1','x2'),(g/(g-1)*(n-1)/(n-g-2))*v)
    for name,condition in (('fd','year-prev=1'),('dynamic','year-prev=1 and year-prev2=2')):
        m = ledger.model('CH21',name)
        keys = c.execute(f'select entity,year from within_rows where {condition}').fetchall()
        m.scalars(n=len(keys))
        for i,y in keys:
            m.add('used',f'{i}/{y}',1)


def forecasting(c, ledger):
    require(c,'select count(*)-count(distinct (country,year)) from gdp22')
    require(c,'select count(*) from growth_levels where year>1990 and (prev_year is null or prev_year<>year-1)')
    require(c,'select count(*) from gdp22 where growth<=-100 or growth is null')
    m = ledger.model('CH22','ar1')
    for country,origin,b0,b1 in c.execute('select country,origin,intercept,phi from ar_coefficients').fetchall():
        m.add('coef',f'{country}/{origin}/intercept',b0)
        m.add('coef',f'{country}/{origin}/phi',b1)
    m = ledger.model('CH22','ma1')
    for country,origin,sse,e in c.execute('select * from ma_recursion').fetchall():
        m.add('coef',f'{country}/{origin}/sse',sse)
        m.add('coef',f'{country}/{origin}/innovation',e)
    for model in ('naive','ar1','ma1'):
        m = ledger.model('CH22',model)
        for cc,o,h,f,e in c.execute('select country,origin,h,forecast,error from forecasts where model=?',[model]).fetchall():
            key=f'{cc}/{o}/{h}'
            m.add('forecast',key,f)
            m.add('error',key,e)
        for cc,h,n,rmse,mae,bias in c.execute('''
            select country,h,count(*),sqrt(avg(error^2)),avg(abs(error)),avg(error)
            from forecasts where model=? group by country,h''',[model]).fetchall():
            key=f'{cc}/{h}'
            for q,v in zip(('n','rmse','mae','bias'),(n,rmse,mae,bias),strict=True):
                m.add(q,key,v)


def spatial(c, ledger):
    require(c,'select count(*)-count(distinct region) from regions23')
    require(c,'select count(*)-count(distinct name) from crosswalk23')
    require(c,'select count(*) from crosswalk23 where geometry_year<>2021')
    require(c,'select count(*) from regions23 full join crosswalk23 using(region) where name is null or access is null')
    require(c,'select count(*)-count(distinct (graph,origin,target)) from weights23')
    require(c,'select count(*) from weights23 where origin=target or weight<=0')
    require(c,'select count(*) from (select graph,origin from weights23 group by all having abs(sum(weight)-1)>1e-9)')
    require(c,'select count(*) from (select draw from permutation_values group by draw having count(*)<>16 or count(distinct z)<>16)')
    for g,name in ((1,'rook'),(2,'distance')):
        m = ledger.model('CH23',name)
        scalars(c,m,'''
        with a as (select o.i as observed,s.edges,s.s0 from moran_observed o
                   join spatial_scale s using(graph) where graph=?),
             b as (select count(*) draws,count(*) filter(where abs(d.i+1.0/15)>=abs(a.observed+1.0/15)-1e-12) extreme
                   from moran_draws d cross join a where graph=?)
        select 16 as n,edges,s0,-1.0/15 as expected,observed as I,extreme,(1.0+extreme)/(draws+1) as p
        from a cross join b''',[g,g])
        for key,v in c.execute('select draw,i from moran_draws where graph=?',[g]).fetchall():
            m.add('perm',key,v)
        for key,v in c.execute('select origin,wy from spatial_lags where graph=?',[g]).fetchall():
            m.add('lag',key,v)
    for model,rss in c.execute('select * from spatial_model_at_reference').fetchall():
        ledger.model('CH23',model).add('scalar','rss',rss)


def inference(c, ledger):
    require(c,'select count(*)-count(distinct record) from trial24')
    require(c,'''select count(*) from (select cluster from trial24 group by cluster having
                 count(*)<>10 or count(distinct assigned)<>1 or count(distinct block)<>1)''')
    require(c,'''select count(*) from assignments24
        where z1+z2+z3+z4+z5+z6<>3 or z7+z8+z9+z10+z11+z12<>3''')
    require(c,'select count(*) from (select distinct * exclude(draw) from assignments24)',400)
    require(c,'''select count(*) from (unpivot signs24 on columns('^s[0-9]+$') into name s value sign)
                 where abs(sign)<>1''')
    require(c,'select count(*) from block_means where n<>60')
    for model in ('y1','y2','y3'):
        m = ledger.model('CH24',model)
        scalars(c,m,'''with a as (select count(*) as n,count(distinct cluster) as clusters from trial24)
                       select n,clusters,n-4 as df,clusters::double/(clusters-1)*(n-1)/(n-4) as cr1_factor from a''')
        scalars(c,m,'''select n.value as ri_stat,
                       count(*) filter(where abs(r.value)>=abs(n.value)-1e-10) as ri_extreme,
                       avg((abs(r.value)>=abs(n.value)-1e-10)::int) as p_ri
                       from ri_draws r join null_contrast n using(model) where model=? group by n.value''',[model])
        for key,v in c.execute('select draw,value from ri_draws where model=?',[model]).fetchall():
            m.add('permutation',key,v)
        for cluster,*row in c.execute('select * exclude(model) from inference_scores where model=?',[model]).fetchall():
            m.vector('score',(f'{cluster}/{key}' for key in ('intercept','assigned','x','block2')),row)
    m = ledger.model('CH24','family')
    for name,bonf,holm,bh in c.execute('select * from multiplicity').fetchall():
        for q,v in zip(('bonferroni','holm','bh'),(bonf,holm,bh),strict=True):
            m.add(q,name,v)
    m = ledger.model('CH24','block')
    scalars(c,m,'select avg(y) as mean,stddev_samp(y)/sqrt(count(*)) as iid_se,(select stddev_samp(value) from block_means) as block_se from serial24')
    for key,v in c.execute('select draw,value from block_means').fetchall():
        m.add('draw',key,v)


if __name__=='__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs','reference','output'):
        p.add_argument(name,type=Path)
    a = p.parse_args()
    c = duckdb.connect(config={'threads':1})
    for f in sorted(a.inputs.glob('*.csv')):
        c.read_csv(str(f),header=True).create_view(f.stem)
    c.read_csv(str(a.reference),header=True).create_view('reference')
    c.execute((Path(__file__).parent/'sql/models.sql').read_text())
    ledger = Ledger()
    for run in (panel,forecasting,spatial,inference):
        run(c,ledger)
    a.output.mkdir(parents=True,exist_ok=True)
    ledger.save(a.output/'metrics.csv')
    for name,order in (('within_fit','entity,year'),('panel_scores','entity'),('forecasts','country,origin,h,model'),
                       ('spatial_lags','graph,origin'),('inference_scores','model,cluster'),('block_means','draw')):
        c.execute(f'select * from {name} order by {order}').df().to_csv(a.output/f'{name}.csv',index=False)
    print('DuckDB',duckdb.__version__,len(ledger.rows),'values')
