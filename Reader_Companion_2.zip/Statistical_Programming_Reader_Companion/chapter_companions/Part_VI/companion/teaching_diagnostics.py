"""Generate the documented sensitivity and native-likelihood diagnostics."""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA

from fit_python import design, moran, ols
from ledger import read as read_ledger


def panel(raw, out):
    d = pd.read_csv(raw/'panel21.csv').sort_values(['entity','year'])
    g = d.groupby('entity')
    gap = g.year.diff()
    wrong = d.loc[gap.gt(1),['entity','year']].assign(prior=g.year.shift()[gap.gt(1)].astype(int))
    wrong.to_csv(out/'panel_gaps.csv',index=False)
    use = gap.eq(1) & (d.year-g.year.shift(2)).eq(2)
    diff = g[['y','x1','x2']].diff()
    v = diff.loc[use]
    y = diff.y.groupby(d.entity).shift()[use].to_numpy()
    z = design(np.ones(len(v)),v[['x1','x2']],g.y.shift(2)[use])
    b = ols(z,y)
    u = y-z@b
    bread = np.linalg.inv(z.T@z)
    row = z*u[:,None]
    cov = bread@(row.T@row)@bread
    pd.DataFrame([{'rows':len(v),'first_stage':b[-1],'hc0_t2':b[-1]**2/cov[-1,-1]}]).to_csv(
        out/'dynamic_first_stage.csv',index=False)


def macro(raw, evidence, out):
    d = pd.read_csv(raw/'gdp22.csv').sort_values(['country','year'])
    rows = []
    for c,a in d.groupby('country'):
        g = 100*np.log1p(a.growth.to_numpy()/100)
        level = np.r_[0,np.cumsum(g[1:])]
        for h in range(1,4):
            errors = [level[i+h]-(level[i]+h*(level[i]-level[0])/i) for i in range(20,32)]
            rows.append((c,h,np.sqrt(np.mean(np.square(errors))),np.mean(np.abs(errors))))
    pd.DataFrame(rows,columns=['country','h','rmse','mae']).to_csv(out/'drift_baseline.csv',index=False)
    ledger = read_ledger(evidence/'python/metrics.csv')
    interval_rows = []
    for c, a in d.groupby('country'):
        growth = 100*np.log1p(a.growth.to_numpy()/100)
        levels = np.r_[0,np.cumsum(growth[1:])]
        for o in range(2010,2022):
            n = o-1989
            key = f'{c}/{o}/'
            b0,phi = [ledger['CH22','ar1','coef',key+x] for x in ('intercept','phi')]
            theta,sse = [ledger['CH22','ma1','coef',key+x] for x in ('theta','sse')]
            arvar = np.mean((growth[2:n]-b0-phi*growth[1:n-1])**2)
            mavar = sse/(n-1)
            for h in range(1,4):
                av = arvar*np.sum(np.cumsum(phi**np.arange(h))**2)
                mv = mavar*(1+(h-1)*(1+theta)**2)
                for model,var in (('ar1',av),('ma1',mv)):
                    forecast = ledger['CH22',model,'forecast',key+str(h)]
                    half = 1.959963984540054*np.sqrt(var)
                    actual = levels[n-1+h]
                    interval_rows.append((c,o,h,model,actual,forecast-half,forecast+half,
                                          forecast-half<=actual<=forecast+half))
    intervals = pd.DataFrame(interval_rows,columns=['country','origin','h','model','actual','low','high','covered'])
    intervals.to_csv(out/'forecast_intervals.csv',index=False)
    intervals.groupby(['country','h','model']).covered.agg(['sum','count','mean']).to_csv(out/'forecast_coverage.csv')
    a = d[(d.country==1)&d.year.between(1991,2021)]
    x = 100*np.log1p(a.growth.to_numpy()/100)
    fit = ARIMA(x,order=(0,0,1),trend='c').fit()
    assert fit.mle_retvals['converged']
    native = pd.DataFrame([{'engine':'Python statsmodels','theta':fit.params[1],
                            'drift':fit.params[0],'growth_forecast':fit.forecast()[0]}])
    pd.concat([native,pd.read_csv(evidence/'r/exact_ma_ghana.csv')],ignore_index=True).to_csv(
        out/'exact_ma_ghana.csv',index=False)


def spatial(raw, out):
    d = pd.read_csv(raw/'regions23.csv').sort_values('region')
    w0 = pd.read_csv(raw/'weights23.csv').query('graph == 1')
    w = np.zeros((16,16))
    w[w0.origin-1,w0.target-1] = w0.weight
    y = d.access.to_numpy()
    x = design(np.ones(16),d[['lat','lon']]-d[['lat','lon']].mean())
    b = ols(x,y)
    u = y-x@b
    # Deliberately remove North East's connections. Keep the isolated region in the denominator.
    names = pd.read_csv(raw/'crosswalk23.csv')
    i = int(names.loc[names.name=='North East','region'].iloc[0])-1
    a = (w>0).astype(float)
    a[i,:] = a[:,i] = 0
    degree = a.sum(1)
    alt = np.divide(a,degree[:,None],out=np.zeros_like(a),where=degree[:,None]>0)
    pd.DataFrame([{'raw_i':moran(y-y.mean(),w),'trend_residual_i':moran(u,w),
                   'isolate_sensitivity_i':moran(y-y.mean(),alt),'isolate_count':sum(degree==0)}]).to_csv(
        out/'spatial_sensitivity.csv',index=False)
    old = {'Ashanti','Brong Ahafo','Central','Eastern','Greater Accra','Northern','Upper East',
           'Upper West','Volta','Western'}
    names.assign(present_in_legacy_name_list=names.name.isin(old)).to_csv(
        out/'incompatible_vintage_join.csv',index=False)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('inputs',type=Path)
    ap.add_argument('evidence',type=Path)
    a=ap.parse_args()
    out=a.evidence/'diagnostics'
    out.mkdir(exist_ok=True)
    panel(a.inputs,out)
    macro(a.inputs,a.evidence,out)
    spatial(a.inputs,out)
