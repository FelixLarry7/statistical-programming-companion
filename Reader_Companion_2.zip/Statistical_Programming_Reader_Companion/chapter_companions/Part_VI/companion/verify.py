"""Reproduce the Part VI evaluations and verify the optional local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

from ledger import read


ROOT=Path(__file__).resolve().parent
RAW=ROOT/"data/raw"


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def run(args, log):
    with log.open("w") as stream:
        result=subprocess.run([str(arg) for arg in args],stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Engine returned {result.returncode}. See {log}.")


def stata_evidence(path,out):
    out.mkdir()
    with ZipFile(path) as z:
        if len(z.namelist())!=len(set(z.namelist())):
            raise ValueError("Duplicate member name in Stata evidence.")
        info=dict(line.split("=",1) for line in z.read("run_info.txt").decode().splitlines())
        if info["part6_rc"]!="0":
            raise ValueError(f"The local Stata run returned {info['part6_rc']}.")
        if info["stata_version"] not in {"16","17"}:
            raise ValueError("Expected a licensed Stata 16 or 17 run.")
        driver=z.read("part6_driver.do")
        if driver!=(ROOT/"stata/part6_driver.do").read_bytes():
            raise ValueError("The executed Stata driver differs from the shipped driver.")
        for p in sorted(RAW.glob("*.csv")):
            if p.read_bytes()!=z.read("input_"+p.name):
                raise ValueError(f"The Stata input differs: {p.name}.")
        log=z.read("part6_run.log").decode("utf-8",errors="replace")
        if "Part VI generated in Stata" not in log:
            raise ValueError("Stata completion line is missing.")
        lines=[]
        for line in log.splitlines():
            if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)",line):
                lines.append("[Local path removed]")
            elif not (line.startswith("> ") and lines and lines[-1]=="[Local path removed]"):
                lines.append(line)
        (out/"part6_run.log").write_text("\n".join(lines)+"\n")
        for file in ("metrics.csv","run_info.txt","part6_driver.do"):
            (out/file).write_bytes(z.read(file))
    report=dict(info,original_archive_sha256=digest(path.read_bytes()),driver_sha256=digest(driver))
    (out/"environment.json").write_text(json.dumps(report,indent=2)+"\n")
    with ZipFile(out/"evidence_replay.zip","w",ZIP_DEFLATED) as z:
        for name in ("metrics.csv","run_info.txt","part6_driver.do","part6_run.log"):
            z.write(out/name,name)
        for p in sorted(RAW.glob("*.csv")):
            z.write(p,"input_"+p.name)
    return report


def anchors():
    """Check design constants and independent scalar calculations."""
    records = {}
    with (RAW/'gdp22.csv').open() as f:
        for row in csv.DictReader(f):
            records[int(row['country']),int(row['year'])] = float(row['growth'])
    with (RAW/'trial24.csv').open() as f:
        y = list(csv.DictReader(f))
    arm = [[float(r['y1']) for r in y if int(r['assigned'])==z] for z in (0,1)]
    ri = math.fsum(arm[1])/60-math.fsum(arm[0])/60
    with (RAW/'serial24.csv').open() as f:
        serial = {int(r['t']):float(r['y']) for r in csv.DictReader(f)}
    with (RAW/'blocks24.csv').open() as f:
        first = next(csv.DictReader(f))
    draw = math.fsum(serial[1+(int(first[f'b{j}'])-1+k)%60]
                     for j in range(1,13) for k in range(5))/60
    out = {
        ('CH21','within','scalar','n'):153, ('CH21','within','scalar','groups'):11,
        ('CH21','within','scalar','singletons'):1, ('CH21','within','scalar','df'):140,
        ('CH21','within','scalar','cr1_factor'):(11/10)*(152/140),
        ('CH21','fd','scalar','n'):136, ('CH21','dynamic','scalar','n'):120,
        ('CH23','rook','scalar','n'):16, ('CH23','rook','scalar','edges'):64,
        ('CH23','distance','scalar','edges'):56,
        ('CH23','rook','scalar','expected'):-1/15, ('CH23','distance','scalar','expected'):-1/15,
        ('CH23','rook','scalar','s0'):16, ('CH23','distance','scalar','s0'):16,
        ('CH24','y1','scalar','ri_stat'):ri,
        ('CH24','block','draw','1'):draw, ('CH24','block','scalar','mean'):math.fsum(serial.values())/60,
    }
    for c in (1,2,3):
        out['CH22','naive','forecast',f'{c}/2010/1'] = math.fsum(
            100*math.log1p(records[c,t]/100) for t in range(1991,2011))
        out['CH22','naive','error',f'{c}/2021/3'] = math.fsum(
            100*math.log1p(records[c,t]/100) for t in (2022,2023,2024))
        out['CH22','ma1','n',f'{c}/3'] = 12
    for m in ('y1','y2','y3'):
        for k,v in (('n',120),('clusters',12),('df',116),('cr1_factor',(12/11)*(119/116))):
            out['CH24',m,'scalar',k]=v
    return out


def tolerance(key, ref):
    _,_,q,k=key
    exact={'n','groups','singletons','df','edges','clusters','extreme','ri_extreme','wild_extreme'}
    return 0. if q in {'n','used'} or (q=='scalar' and k in exact) else 2e-8+2e-8*abs(ref)


def audit(out, with_stata):
    base=read(out/'python/metrics.csv')
    if len(base)!=5756:
        raise ValueError('Unexpected Python ledger size.')
    checks=[]
    engines=('anchor','r','duckdb','stata') if with_stata else ('anchor','r','duckdb')
    for engine in engines:
        other=anchors() if engine=='anchor' else read(out/engine/'metrics.csv')
        if engine in {'r','stata'} and other.keys()!=base.keys():
            raise ValueError(f'{engine}: unmatched keys, missing {sorted(base.keys()-other.keys())[:5]}, '
                             f'extra {sorted(other.keys()-base.keys())[:5]}')
        if engine=='duckdb' and len(other)!=4137:
            raise ValueError('Unexpected DuckDB ledger size.')
        for key,v in sorted(other.items()):
            ref=base[key]
            gap=abs(v-ref)
            tol=tolerance(key,ref)
            checks.append((engine,*key,v,ref,gap,tol,gap<=tol))
    with (out/'comparisons.csv').open('w',newline='') as f:
        w=csv.writer(f,lineterminator='\n')
        w.writerow(('engine','chapter','model','quantity','key','value','python','abs_error','tolerance','passed'))
        w.writerows(checks)
    failed=[r for r in checks if not r[-1]]
    if failed:
        raise ValueError(f'{len(failed)} failed comparisons: {failed[:8]}')
    return dict(Counter(r[0] for r in checks)),dict(Counter(r[1] for r in checks))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--rscript',default='Rscript')
    ap.add_argument('--stata-evidence',type=Path)
    ap.add_argument('--require-four',action='store_true')
    a=ap.parse_args()
    if a.require_four and not a.stata_evidence:
        ap.error('Provide the evidence from the local Stata run.')
    out=a.output.resolve()
    if out.exists() and any(out.iterdir()):
        ap.error('Choose a new or empty output folder.')
    for e in ('python','r','duckdb'):
        (out/e).mkdir(parents=True,exist_ok=True)
    run([sys.executable,ROOT/'fit_python.py',RAW,out/'python'],out/'python/environment.txt')
    run([a.rscript,'--vanilla',ROOT/'fit_r.R',RAW,out/'r'],out/'r/environment.txt')
    run([sys.executable,ROOT/'fit_sql.py',RAW,out/'python/metrics.csv',out/'duckdb'],out/'duckdb/environment.txt')
    stata=stata_evidence(a.stata_evidence,out/'stata') if a.stata_evidence else None
    counts,chapters=audit(out,bool(stata))
    run([sys.executable,ROOT/'teaching_diagnostics.py',RAW,out],out/'diagnostics.log')
    report={
        'status':'VERIFIED' if stata else 'STATA EVIDENCE PENDING',
        'comparisons':sum(counts.values()),'failures':0,
        'comparisons_by_engine':counts,'comparisons_by_chapter':chapters,
        'duckdb_scope':('Panel keys, within fit and sufficient statistics, consecutive windows, '
                        'AR forecasts and MA recursions at common parameters, spatial statistics, '
                        'profile residuals at common coefficients, cluster scores, assignment draws, '
                        'block resamples, and multiplicity at common raw p-values.'),
        'input_sha256':{f.name:digest(f.read_bytes()) for f in sorted(RAW.glob('*.csv'))},
        'stata':stata,
    }
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],report['comparisons'],counts,chapters)


if __name__=='__main__':
    main()
