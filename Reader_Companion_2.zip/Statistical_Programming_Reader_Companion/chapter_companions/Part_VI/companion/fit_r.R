# Independent Part VI statistical implementation in base R.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L)
input <- args[1]
output <- args[2]
read <- function(name) read.csv(file.path(input,paste0(name,".csv")))
rows <- list()
lab <- function(chapter,model) {
    force(chapter)
    force(model)
    function(quantity,key,value) {
        stopifnot(length(key)==length(value),all(is.finite(value)))
        rows[[length(rows)+1L]] <<- data.frame(chapter=chapter,model=model,quantity=quantity,
                                              key=as.character(key),value=as.numeric(value))
    }
}
scalar <- function(add, ...) {
    v <- unlist(lapply(list(...),unname))
    add("scalar",names(v),v)
}
covrows <- function(add, name, keys, v) {
    for (i in seq_along(keys)) for (j in seq_along(keys))
        add(name,paste(keys[i],keys[j],sep="/"),v[i,j])
}
ols <- function(x,y) qr.coef(qr(x),y)
covariance <- function(bread,score) bread%*%crossprod(score)%*%bread

panel <- function() {
    d <- read("panel21")
    d <- d[order(d$entity,d$year),]
    stopifnot(!anyDuplicated(d[c("entity","year")]))
    sizes <- table(d$entity)
    a <- d[sizes[as.character(d$entity)]>1,]
    g <- a$entity
    n <- nrow(a)
    ng <- length(unique(g))
    y <- a$y
    x <- as.matrix(a[c("x1","x2")])
    nx <- as.numeric(sizes[as.character(g)])
    xb <- (rowsum(x,g)/as.numeric(sizes[sizes>1]))[g,]
    yb <- as.vector(rowsum(y,g)/as.numeric(sizes[sizes>1]))[g]
    xc <- x-xb
    yc <- y-yb
    b <- ols(xc,yc)
    u <- as.vector(yc-xc%*%b)
    alpha <- yb-as.vector(xb%*%b)
    ic <- mean(alpha)
    bread <- solve(crossprod(xc))
    s <- rowsum(xc*u,g)
    cr0 <- covariance(bread,s)
    df <- n-ng-2
    factor <- ng/(ng-1)*(n-1)/df
    add <- lab("CH21","within")
    scalar(add,n=n,groups=ng,singletons=sum(sizes==1),df=df,rss=sum(u^2),s2=sum(u^2)/df,
           cr1_factor=factor,intercept=ic)
    names <- c("x1","x2")
    add("beta",names,b)
    covrows(add,"cov_cr0",names,cr0)
    covrows(add,"cov_cr1",names,factor*cr0)
    for (i in seq_len(ng)) {
        add("effect",i,alpha[match(i,g)]-ic)
        add("score",paste(i,names,sep="/"),s[i,])
    }
    keys <- paste(g,a$year,sep="/")
    add("fit",keys,y-u)
    add("resid",keys,u)
    terms <- c("intercept",names)
    lab("CH21","pooled")("beta",terms,ols(cbind(1,x),y))
    theta <- 1-1/sqrt(1+1.5*nx)
    z <- cbind(1-theta,x-theta*xb)
    yq <- y-theta*yb
    lab("CH21","re")("beta",terms,ols(z,yq))
    b <- ols(cbind(z,(1-theta)*xb),yq)
    cre <- lab("CH21","cre")
    cre("beta",c(terms,"mean_x1","mean_x2"),b)
    cre("between",names,b[2:3]+b[4:5])
    j <- 2:n
    idx <- j[g[j]==g[j-1] & a$year[j]-a$year[j-1]==1]
    values <- cbind(y,x)
    dx <- values[idx,]-values[idx-1,]
    add <- lab("CH21","fd")
    scalar(add,n=nrow(dx))
    add("beta",terms,ols(cbind(1,dx[,2:3]),dx[,1]))
    add("used",keys[idx],rep(1,length(idx)))
    idx <- idx[idx>2]
    idx <- idx[g[idx]==g[idx-2] & a$year[idx]-a$year[idx-2]==2]
    dx <- values[idx,]-values[idx-1,]
    lag <- y[idx-1]-y[idx-2]
    z <- cbind(1,dx[,2:3],y[idx-2])
    x <- cbind(1,lag,dx[,2:3])
    add <- lab("CH21","dynamic")
    scalar(add,n=nrow(dx),first_stage=ols(z,lag)[4])
    add("beta",c("intercept","lag",names),ols(z%*%ols(z,x),dx[,1]))
    add("used",keys[idx],rep(1,length(idx)))
}

ma_profile <- function(x) {
    best <- Inf
    for (q in -45:45) {
        theta <- q/50
        a <- b <- numeric(length(x))
        a[1] <- x[1]
        b[1] <- 1
        for (i in 2:length(x)) {
            a[i] <- x[i]-theta*a[i-1]
            b[i] <- 1-theta*b[i-1]
        }
        drift <- sum(a*b)/sum(b^2)
        u <- a-drift*b
        rss <- sum(u^2)
        if (rss<best-1e-10) {
            best <- rss
            fitted <- c(theta,drift,rss,tail(u,1))
        }
    }
    fitted
}

macro <- function() {
    data <- read("gdp22")
    models <- c("naive","ar1","ma1")
    for (country in 1:3) {
        d <- data[data$country==country,]
        d <- d[order(d$year),]
        stopifnot(all(d$year==1990:2024),all(d$growth > -100))
        x <- 100*log1p(d$growth/100)
        level <- c(0,cumsum(x[-1]))
        error <- array(0,c(12,3,3))
        for (origin in 2010:2021) {
            n <- origin-1989
            prefix <- paste(country,origin,sep="/")
            b <- ols(cbind(1,x[2:(n-1)]),x[3:n])
            lab("CH22","ar1")("coef",paste(prefix,c("intercept","phi"),sep="/"),b)
            m <- ma_profile(x[2:n])
            lab("CH22","ma1")("coef",paste(prefix,c("theta","drift","sse","innovation"),sep="/"),m)
            ar <- ma <- level[n]
            last <- x[n]
            for (h in 1:3) {
                last <- b[1]+b[2]*last
                ar <- ar+last
                ma <- ma+m[2]+(h==1)*m[1]*m[4]
                forecast <- c(level[n],ar,ma)
                e <- level[n+h]-forecast
                key <- paste(prefix,h,sep="/")
                for (j in 1:3) {
                    add <- lab("CH22",models[j])
                    add("forecast",key,forecast[j])
                    add("error",key,e[j])
                }
                error[origin-2009,,h] <- e
            }
        }
        for (j in 1:3) {
            add <- lab("CH22",models[j])
            for (h in 1:3) {
                e <- error[,j,h]
                key <- paste(country,h,sep="/")
                add("n",key,length(e))
                add("rmse",key,sqrt(mean(e^2)))
                add("mae",key,mean(abs(e)))
                add("bias",key,mean(e))
            }
        }
    }
}

spatial <- function() {
    d <- read("regions23")
    d <- d[order(d$region),]
    stopifnot(all(d$region==1:16))
    e <- read("weights23")
    stopifnot(!anyDuplicated(e[c("graph","origin","target")]))
    p <- read("permutations23")
    perm <- as.matrix(p[-1])
    stopifnot(all(apply(perm,1,function(i) identical(as.integer(sort(i)),1:16))))
    y <- d$access
    z <- y-mean(y)
    n <- length(z)
    for (g in 1:2) {
        a <- e[e$graph==g,]
        w <- matrix(0,n,n)
        w[cbind(a$origin,a$target)] <- a$weight
        stopifnot(all(abs(rowSums(w)-1)<1e-9),all(diag(w)==0),all((w>0)==(t(w)>0)))
        if (g==1) rook <- w
        moran <- function(z) n/sum(w)*as.numeric(crossprod(z,w%*%z))/sum(z^2)
        obs <- moran(z)
        e0 <- -1/(n-1)
        v <- apply(perm,1,function(i) moran(z[i]))
        ext <- sum(abs(v-e0)>=abs(obs-e0)-1e-12)
        add <- lab("CH23",c("rook","distance")[g])
        scalar(add,n=n,edges=nrow(a),s0=sum(w),expected=e0,I=obs,extreme=ext,p=(ext+1)/(length(v)+1))
        add("perm",p$draw,v)
        add("lag",d$region,w%*%y)
    }
    x <- cbind(1,scale(as.matrix(d[c("lat","lon")]),scale=FALSE))
    terms <- c("intercept","lat","lon")
    for (model in c("sar","sem")) {
        add <- lab("CH23",model)
        best <- -Inf
        for (q in -34:34) {
            par <- q/40
            f <- diag(n)-par*rook
            xx <- if (model=="sar") x else f%*%x
            yy <- f%*%y
            b <- ols(xx,yy)
            rss <- sum((yy-xx%*%b)^2)
            d0 <- determinant(f,logarithm=TRUE)
            stopifnot(d0$sign==1)
            ld <- as.numeric(d0$modulus)
            ll <- ld-n/2*(log(2*pi)+1+log(rss/n))
            add("profile",q,ll)
            if (ll>best+1e-10) {
                best <- ll
                fit <- list(par=par,rss=rss,ld=ld,b=b,f=f)
            }
        }
        scalar(add,param=fit$par,ll=best,logdet=fit$ld,rss=fit$rss)
        add("beta",terms,fit$b)
        mu <- x%*%fit$b
        if (model=="sar") {
            s <- solve(fit$f)
            mu <- s%*%mu
            for (j in 2:3) {
                direct <- mean(diag(s))*fit$b[j]
                total <- mean(rowSums(s))*fit$b[j]
                add("impact",paste(terms[j],c("direct","indirect","total"),sep="/"),
                    c(direct,total-direct,total))
            }
        }
        add("fit",d$region,mu)
    }
}

inference <- function() {
    d <- read("trial24")
    g <- d$cluster
    x0 <- cbind(1,d$x,d$block-1)
    x <- cbind(1,d$assigned,x0[,2:3])
    n <- nrow(x)
    ng <- length(unique(g))
    df <- n-ncol(x)
    fac <- ng/(ng-1)*(n-1)/df
    bread <- solve(crossprod(x))
    signs <- read("signs24")
    s <- as.matrix(signs[-1])
    alloc <- read("assignments24")
    a <- as.matrix(alloc[-1])
    observed <- as.numeric(tapply(d$assigned,g,mean))
    stopifnot(!anyDuplicated(d$record),all(table(g)==10),nrow(a)==400,
              all(rowSums(a[,1:6])==3),all(rowSums(a[,7:12])==3))
    models <- c("y1","y2","y3")
    terms <- c("intercept","assigned","x","block2")
    pvals <- numeric(3)
    for (j in seq_along(models)) {
        model <- models[j]
        y <- d[[model]]
        b <- ols(x,y)
        u <- as.vector(y-x%*%b)
        f0 <- as.vector(x0%*%ols(x0,y))
        u0 <- y-f0
        score <- rowsum(x*u,g)
        cr0 <- covariance(bread,score)
        cr1 <- fac*cr0
        hc0 <- covariance(bread,x*u)
        se <- sqrt(cr1[2,2])
        stat <- b[2]/se
        pvals[j] <- 2*pt(abs(stat),ng-1,lower.tail=FALSE)
        add <- lab("CH24",model)
        add("beta",terms,b)
        scalar(add,n=n,clusters=ng,df=df,cr1_factor=fac,t_cr1=stat,p_cr1=pvals[j],
               p_regdf=2*pt(abs(stat),df,lower.tail=FALSE),p_normal=2*pnorm(-abs(stat)))
        add("se",c("classical","hc0","hc1","cr0","cr1"),sqrt(c(
            sum(u^2)/df*bread[2,2],hc0[2,2],n/df*hc0[2,2],cr0[2,2],cr1[2,2])))
        covrows(add,"cov_cr0",terms,cr0)
        covrows(add,"cov_cr1",terms,cr1)
        for (i in seq_len(ng)) add("score",paste(i,terms,sep="/"),score[i,])
        wild <- numeric(nrow(s))
        for (i in seq_len(nrow(s))) {
            yy <- f0+u0*s[i,g]
            bb <- ols(x,yy)
            v <- fac*covariance(bread,rowsum(x*as.vector(yy-x%*%bb),g))
            wild[i] <- bb[2]/sqrt(v[2,2])
        }
        add("wild_t",signs$draw,wild)
        ext <- sum(abs(wild)>=abs(stat)-1e-10)
        scalar(add,wild_extreme=ext,p_wild=(ext+1)/(length(wild)+1))
        cy <- as.numeric(tapply(y,g,mean))
        ri <- (2*sum(observed*cy)-sum(cy))/6
        b <- as.vector((2*a%*%cy-sum(cy))/6)
        add("permutation",alloc$draw,b)
        ext <- sum(abs(b)>=abs(ri)-1e-10)
        scalar(add,ri_stat=ri,ri_extreme=ext,p_ri=ext/length(b))
    }
    add <- lab("CH24","family")
    for (method in c("holm","bonferroni","bh"))
        add(method,models,p.adjust(pvals,method=if (method=="bh") "BH" else method))
    serial <- read("serial24")
    draws <- read("blocks24")
    y <- serial$y
    stopifnot(all(serial$t==1:60))
    b <- apply(as.matrix(draws[-1]),1,function(row) mean(y[(outer(row-1,0:4,"+")%%60)+1]))
    add <- lab("CH24","block")
    add("draw",draws$draw,b)
    scalar(add,mean=mean(y),iid_se=sd(y)/sqrt(60),block_se=sd(b))
}

panel()
macro()
spatial()
inference()
result <- do.call(rbind,rows)
stopifnot(!anyDuplicated(result[1:4]))
dir.create(output,recursive=TRUE,showWarnings=FALSE)
write.table(result,file.path(output,"metrics.csv"),sep=",",quote=FALSE,row.names=FALSE)
d <- subset(read("gdp22"),country==1 & year>1990 & year<=2021)
g <- 100*log1p(d$growth/100)
fit <- arima(g,order=c(0,0,1),include.mean=TRUE,method="ML")
write.csv(data.frame(engine="R stats",theta=unname(coef(fit)["ma1"]),
                     drift=unname(coef(fit)["intercept"]),
                     growth_forecast=as.numeric(predict(fit,n.ahead=1)$pred)),
          file.path(output,"exact_ma_ghana.csv"),row.names=FALSE)
cat(R.version.string,"\n",nrow(result),"values\n")
