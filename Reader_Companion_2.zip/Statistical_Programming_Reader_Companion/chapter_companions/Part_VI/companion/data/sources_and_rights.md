# Source and rights register

| Use | Source, date and version | Files and treatment |
|:--|:--|:--|
| Chapter 21 panel | Synthetic authoring fixture, seed 21031 | panel21.csv is generated locally. Entity identifiers are synthetic. |
| Chapter 22 GDP growth | World Bank, World Development Indicators, NY.GDP.MKTP.KD.ZG, archive metadata last updated 11 November 2026 | WDI_GDP_growth_indicator.zip retains the frozen source export. gdp22.csv selects Ghana, Kenya and Senegal for 1990–2024. The World Bank indicates CC BY 4.0 for the series. Attribute the World Bank and the indicator, and describe the selection and log transformation. |
| Chapter 23 water access | Ghana Statistical Service, 2021 Population and Housing Census, Volume 3M, Water and Sanitation, published February 2022, table 5.3 and report portal figure 1 | GSS_2021_basic_water_regional_extract.tsv contains only the 16 regional total access values. The national reference is cited from the report. The figure uses an original map composition and credits the published statistics. No household records are included. |
| Chapter 23 geography | geoBoundaries gbOpen Ghana ADM1, boundary ID GHA-ADM1-69750345, represented year 2021, build 12 December 2023, frozen commit 9469f09 | The GeoJSON and metadata retain the provider’s identifiers and source notice. The metadata names OpenStreetMap and Creative Commons Attribution-ShareAlike 2.0 for this boundary. Credit OpenStreetMap contributors and geoBoundaries. The general geoBoundaries catalogue documents its own terms. The derived map artwork retains the boundary attribution and the boundary share-alike terms identified by the metadata. |
| Chapter 23 permutations | Synthetic shared draw manifest, seed 23059 | Fixed index permutations independently of the rates. |
| Chapter 24 clustered and serial examples | Synthetic authoring fixture, seed 24071 | The outcome values, signs and circular block starts are generated locally. The 400 assignment rows enumerate the blocked design. |

## Source links

- World Bank indicator page and CSV export. [Indicator](https://data.worldbank.org/indicator/NY.GDP.MKTP.KD.ZG) · [CSV endpoint](https://api.worldbank.org/v2/en/indicator/NY.GDP.MKTP.KD.ZG?downloadformat=csv) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
- Ghana Statistical Service Water and Sanitation report. [Official report portal](https://census2021.statsghana.gov.gh/subreport.php?Volume-3M-Water-and-Sanitation=&readreport=NjMzMzk0MDg5LjAzNg%3D%3D) · [Figure data](https://datawrapper.dwcdn.net/Ov8cF/1/dataset.csv).
- geoBoundaries Ghana ADM1. [Frozen boundary download](https://media.githubusercontent.com/media/wmgeolab/geoBoundaries/9469f09/releaseData/gbOpen/GHA/ADM1/geoBoundaries-GHA-ADM1.geojson) · [Release metadata endpoint](https://www.geoboundaries.org/api/current/gbOpen/GHA/ADM1/) · [OpenStreetMap copyright](https://www.openstreetmap.org/copyright) · [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/).

The spatial script retains original coordinate precision and applies a geometry validity check before generating centroid and adjacency inputs. The map carries the same region keys and the analytical output stores the provider shape identifiers. A projected or population-weighted location and a refreshed boundary release are separate sensitivities.
