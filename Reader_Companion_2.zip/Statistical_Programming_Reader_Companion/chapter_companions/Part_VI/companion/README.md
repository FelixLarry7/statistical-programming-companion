# Part VI computational companion

The published reference uses Python 3.12.14, R 4.5.0, DuckDB 1.4.4 and a licensed local Stata 17 IC installation. The R code uses base and recommended libraries bundled with R. The Stata code uses native Stata and Mata, with a Stata 16 language version. The verified runtime for this release was Stata 17 IC on macOS.

## Reproduce the checks

From the package root, create a Python environment with the requirements and make Rscript available. Run into a fresh output directory.

~~~bash
python -m pip install -r companion/requirements.txt
python companion/verify.py --output build/part6-replay \
  --stata-evidence companion/evidence/stata/evidence_replay.zip --require-four
~~~

The runner executes Python, R and DuckDB, checks the Stata archive’s completion record, input bytes and executed driver, then reconciles keyed results. It reuses the stored Stata execution evidence in this command. Use the local Stata steps below to produce a new archive. Supply an alternate executable with the --rscript option when required.

| Evidence | Comparisons | Scope |
|:--|--:|:--|
| Independent anchors | 38 | Sample, design and scalar reference calculations |
| R against Python | 5,756 | All declared numerical keys |
| Stata against Python | 5,756 | All declared numerical keys |
| DuckDB against Python | 4,137 | Relational and numerical checks within the declared SQL scope |
| Total | 15,687 | All passed in the Part VI release |

The verifier writes one row per comparison with the reference value, result, absolute discrepancy, tolerance and disposition. Exact design quantities have zero tolerance. For other keys the tolerance is \(2\times10^{-8}+2\times10^{-8}|\text{reference}|\). The immutable record of the submitted Stata archive is in evidence/stata/environment.json and evidence/verification.json. The replay archive contains the verified input bytes and a log with local path lines removed.

DuckDB constructs panel windows and within cross-products, with a small Python matrix solve for the within estimator. It estimates the AR slopes and evaluates the conditional MA recursion at shared coefficients. It computes the Moran statistics, the full spatial permutation vectors and the model residual sums at the shared spatial estimates. It independently evaluates cluster score sums at the common coefficients, all exact assignment contrasts, circular block draws and adjustments of the common raw probabilities. The shared coefficients and p-values keep those audits aligned with the intended scope.

## Rerun the licensed local Stata workflow

Use the separate Part VI local-run kit if it is already on your computer. The package includes its two do-files in stata and the verified inputs in data/raw. To reconstruct the kit, copy both do-files to a fresh folder and copy all files from data/raw into an inputs subfolder. In your installed Stata, set the working directory to that fresh folder and run the following command.

~~~stata
do run_part6.do
~~~

The run generates a dated Stata_Verification_Part_VI ZIP. Pass that ZIP as the --stata-evidence input to the same verifier. See [local-run instructions](stata/LOCAL_RUN.md) for the archive layout and failure-log guidance. A zero return code and a complete numerical match together establish the verification result.

## Rebuild inputs and inspect changes

The frozen analysis inputs are sufficient for all numerical checks. To regenerate them offline from the retained sources and seeded teaching generators, run the following command.

~~~bash
python companion/prepare_inputs.py --output build/rebuilt_inputs
~~~

Compare this directory with data/raw before substituting any files. The original source snapshots and IDs are recorded in the [source register](data/sources_and_rights.md). Different data releases, graph rules or resampling draws define a new experiment. Retain the baseline and document which inputs or rules changed.

| Chapter | Baseline | Documented changed case |
|:--|:--|:--|
| 21 | Common 153-row panel and within fit | Adjacent-year and dynamic windows, working RE and CRE, and the first-stage diagnostic |
| 22 | Fixed WDI vintage and common forecast origins | Historical drift, native-likelihood MA fits, and forecast interval coverage |
| 23 | Matched 2021 regions and rook weights | Distance neighbours, induced isolate, coordinate-trend residuals, and legacy-name join |
| 24 | Blocked fixture with CR1 and a declared outcome family | Alternative references, wild signs, exact assignments and a separate serial block-mean exercise |

The data dictionary describes every input and identifies the grain. The diagnostics directory includes native likelihood results and forecast coverage. Figure data store the plotted points and the map’s original geometry IDs. The SQL code uses the embedded DuckDB engine. The chapter listings assume their named data tables or supplied inputs have been loaded.
