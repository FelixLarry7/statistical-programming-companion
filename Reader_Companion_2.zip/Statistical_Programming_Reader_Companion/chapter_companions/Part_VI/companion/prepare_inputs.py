"""Rebuild the frozen teaching inputs from the retained data snapshots."""

import argparse
import csv
from itertools import combinations, product
import json
from math import asin, cos, radians, sin, sqrt
from pathlib import Path
from random import Random
from zipfile import ZipFile

DATA = Path(__file__).resolve().parent / 'data'


def write(output, name, fields, rows):
    with (output / f'{name}.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(fields.split())
        writer.writerows([[f'{v:.12f}' if isinstance(v, float) else v for v in row]
                          for row in rows])


def panel(output):
    rng = Random(21031)
    rows = []
    for i in range(1,13):
        a = (i-6.5)*.45+rng.gauss(0,.3)
        u = rng.gauss(0,.55)
        lag = 2+a+rng.gauss(0,.4)
        for t in range(2001,2016):
            k = t-2001
            x1 = .62*a+.19*k+rng.gauss(0,.85)
            x2 = .34*a+.18*sin(.42*k+i*.55)+rng.gauss(0,.8)
            u = .50*u+rng.gauss(0,.65)
            y = 2.1+a+.85*x1-.48*x2+.27*lag+u
            lag = y
            if i == 12 and t != 2011:
                continue
            if i != 12 and ((i+t)%17==0 or (i%4==0 and t<2003)):
                continue
            rows.append((i,t,y,x1,x2))
    write(output,'panel21','entity year y x1 x2',rows)


def macro(source, output):
    countries = ('GHA','KEN','SEN')
    with ZipFile(source / 'WDI_GDP_growth_indicator.zip') as archive:
        name = next(n for n in archive.namelist() if n.startswith('API_NY.'))
        content = archive.read(name).decode('utf-8-sig').splitlines()
    assert '2026-11-11' in content[2]
    records = {row['Country Code']:row for row in csv.DictReader(content[4:])
               if row['Country Code'] in countries}
    write(output,'gdp22','country year growth',
          ((i,t,float(records[iso][str(t)])) for i,iso in enumerate(countries,1)
           for t in range(1990,2025)))


def haversine(a,b):
    a1,a2,b1,b2 = map(radians,(*a,*b))
    s = sin((a2-b2)/2)**2+cos(a2)*cos(b2)*sin((a1-b1)/2)**2
    return 2*6371.0088*asin(sqrt(s))


def geography(source, output):
    from shapely import make_valid
    from shapely.geometry import shape
    from shapely.ops import unary_union

    file = source / 'geoBoundaries_GHA_ADM1_2021.geojson'
    features = json.loads(file.read_text())['features']
    shapes = {}
    for f in features:
        name = f['properties']['shapeName'].removesuffix(' Region')
        g = make_valid(shape(f['geometry']))
        if g.geom_type=='GeometryCollection':
            pieces = [p for p in g.geoms if p.geom_type in ('Polygon','MultiPolygon')]
            g = unary_union(pieces)
        assert g.geom_type in ('Polygon','MultiPolygon') and not g.is_empty
        shapes[name] = g
    with (source/'GSS_2021_basic_water_regional_extract.tsv').open(newline='') as stream:
        counts = {r['REGION']:r for r in csv.DictReader(stream,delimiter='\t')
                  if r['REGION'] not in ('','Ghana')}
    names = sorted(shapes)
    assert len(names)==16 and set(names)==set(counts)
    coords = [(shapes[s].centroid.x,shapes[s].centroid.y) for s in names]
    write(output,'regions23','region access lat lon',
          ((i,float(counts[s]['TOTAL']),lat,lon)
           for i,(s,(lon,lat)) in enumerate(zip(names,coords,strict=True),1)))
    write(output,'crosswalk23','region name source_name geometry_year',
          ((i,s,s+' Region',2021) for i,s in enumerate(names,1)))
    rook = set()
    for i,j in combinations(range(16),2):
        boundary = shapes[names[i]].boundary.intersection(shapes[names[j]].boundary)
        if boundary.length > 1e-7:
            rook.update(((i,j),(j,i)))
    distance = set()
    for i in range(16):
        near = sorted((haversine(coords[i],coords[j]),j) for j in range(16) if i!=j)[:3]
        for _,j in near:
            distance.update(((i,j),(j,i)))
    edges = []
    for model, links in ((1,rook),(2,distance)):
        degree = {i:sum(a==i for a,b in links) for i in range(16)}
        edges.extend((model,i+1,j+1,1/degree[i]) for i,j in sorted(links))
    write(output,'weights23','graph origin target weight',edges)
    rng = Random(23059)
    write(output,'permutations23','draw '+' '.join(f'p{i}' for i in range(1,17)),
          ((b,*rng.sample(range(1,17),16)) for b in range(1,400)))


def inference(output):
    rng = Random(24071)
    assignment = (1,0,1,0,0,1,0,1,0,1,1,0)
    rows = []
    for j,a in enumerate(assignment,1):
        block = 1+(j>6)
        c = [rng.gauss(0,s) for s in (.85,1.0,.80)]
        for i in range(1,11):
            x = rng.gauss(.35*(block-1),1.0)
            yy = [18+1.2*block+.95*x+tau*a+c[k]+rng.gauss(0,.6+.12*abs(x))
                  for k,tau in enumerate((1.15,.60,.10))]
            rows.append((j*100+i,j,block,a,x,*yy))
    write(output,'trial24','record cluster block assigned x y1 y2 y3',rows)
    write(output,'assignments24','draw '+' '.join(f'z{j}' for j in range(1,13)),
          ((b,*(int(j in a or j in c) for j in range(1,13)))
           for b,(a,c) in enumerate(product(combinations(range(1,7),3),
                                           combinations(range(7,13),3)),1)))
    write(output,'signs24','draw '+' '.join(f's{j}' for j in range(1,13)),
          ((b,*(rng.choice((-1,1)) for _ in range(12))) for b in range(1,400)))
    y = 0.
    series = []
    for t in range(1,61):
        y = .78*y+rng.gauss(0,.7)
        series.append((t,10+y))
    write(output,'serial24','t y',series)
    write(output,'blocks24','draw '+' '.join(f'b{j}' for j in range(1,13)),
          ((b,*(rng.randrange(1,61) for _ in range(12))) for b in range(1,400)))


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=DATA/'source')
    parser.add_argument('--output',type=Path,default=DATA/'raw')
    args = parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    panel(args.output)
    macro(args.source,args.output)
    geography(args.source,args.output)
    inference(args.output)
