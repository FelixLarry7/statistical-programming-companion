-- Frozen samples and comparison calculations. All indices are explicit.
create view panel_lags as
select *,count(*) over(partition by entity) as n_i,
       avg(y) over(partition by entity) as ybar,
       avg(x1) over(partition by entity) as x1bar,
       avg(x2) over(partition by entity) as x2bar,
       lag(year) over panel_order as prev,lag(year,2) over panel_order as prev2
from panel21 window panel_order as (partition by entity order by year);

create view within_rows as
select *,y-ybar as yc,x1-x1bar as z1,x2-x2bar as z2
from panel_lags where n_i>1;

create view within_coefficients as
with a as (
    select sum(z1*z1) as aa,sum(z2*z2) as bb,sum(z1*z2) as ab,
           sum(z1*yc) as ay,sum(z2*yc) as bx2y
    from within_rows
)
select (bb*ay-ab*bx2y)/(aa*bb-ab^2) as b1,(aa*bx2y-ab*ay)/(aa*bb-ab^2) as b2,
       aa,bb,ab
from a;

create view within_fit as
select r.*,yc-z1*b1-z2*b2 as residual,ybar-x1bar*b1-x2bar*b2 as alpha
from within_rows r cross join within_coefficients;

create view panel_scores as
select entity,sum(z1*residual) as x1,sum(z2*residual) as x2
from within_fit group by entity;

create view growth_levels as
with transformed as (
    select *,100*ln(1+growth/100) as log_growth from gdp22
)
select *,sum(case when year>1990 then log_growth else 0 end) over growth_order as level,
       lag(log_growth) over growth_order as lag_growth,lag(year) over growth_order as prev_year
from transformed window growth_order as (partition by country order by year rows unbounded preceding);

create view origins as
select c.country,o.origin from (select distinct country from gdp22) c
cross join range(2010,2022) o(origin);

create view ar_coefficients as
select o.country,o.origin,regr_slope(log_growth,lag_growth) as phi,
       regr_intercept(log_growth,lag_growth) as intercept
from origins o join growth_levels g on o.country=g.country
where g.year between 1992 and o.origin and g.prev_year=g.year-1 group by all;

create view ma_coefficients as
select cast(split_part(key,'/',1) as integer) as country,
       cast(split_part(key,'/',2) as integer) as origin,
       max(value) filter(where split_part(key,'/',3)='theta') as theta,
       max(value) filter(where split_part(key,'/',3)='drift') as drift
from reference where chapter='CH22' and model='ma1' and quantity='coef'
group by all;

create view ma_recursion as
with recursive innovations(country,origin,year,resid) as (
    select m.country,m.origin,g.year,g.log_growth-m.drift
    from ma_coefficients m join growth_levels g using(country) where g.year=1991
    union all
    select r.country,r.origin,g.year,g.log_growth-m.drift-m.theta*r.resid
    from innovations r join ma_coefficients m using(country,origin)
    join growth_levels g on g.country=r.country and g.year=r.year+1
    where g.year<=r.origin
)
select country,origin,sum(resid^2) as sse,
       max(resid) filter(where year=origin) as innovation
from innovations group by country,origin;

create view forecasts as
with paths as (
    select a.*,g.level,g.log_growth,m.theta,m.drift,u.innovation,
           a.intercept+a.phi*g.log_growth as h1
    from ar_coefficients a join ma_coefficients m using(country,origin)
    join ma_recursion u using(country,origin)
    join growth_levels g on a.country=g.country and a.origin=g.year
), totals as (
    select *,intercept+phi*h1 as h2 from paths
), forecasts as (
    select p.country,p.origin,h,actual.level,
           p.level as naive,
           p.level+h1+case when h>=2 then h2 else 0 end
            +case when h=3 then intercept+phi*h2 else 0 end as ar1,
           p.level+h*drift+theta*innovation as ma1
    from totals p cross join range(1,4) i(h)
    join growth_levels actual on p.country=actual.country and actual.year=p.origin+h
)
select country,origin,h,model,forecast,level-forecast as error
from (unpivot forecasts on naive,ar1,ma1 into name model value forecast);

create view water as
select *,access-avg(access) over() as z,
       lat-avg(lat) over() as latc,lon-avg(lon) over() as lonc
from regions23;

create view spatial_lags as
select e.graph,e.origin,sum(e.weight*t.access) as wy
from weights23 e join water t on e.target=t.region group by all;

create view spatial_scale as
select graph,count(*) as edges,sum(weight) as s0 from weights23 group by graph;

create view moran_observed as
select graph,16/s0*sum(e.weight*a.z*b.z)/(select sum(z^2) from water) as i
from weights23 e join spatial_scale s using(graph)
join water a on e.origin=a.region join water b on e.target=b.region
group by graph,s0;

create view permutation_values as
with positions as (
    unpivot permutations23 on columns('^p[0-9]+$') into name position value region
)
select draw,cast(substr(position,2) as integer) as slot,w.z
from positions join water w using(region);

create view moran_draws as
select e.graph,a.draw,16/s.s0*sum(e.weight*a.z*b.z)/(select sum(z^2) from water) as i
from weights23 e join spatial_scale s using(graph)
join permutation_values a on e.origin=a.slot
join permutation_values b on e.target=b.slot and a.draw=b.draw
group by e.graph,a.draw,s.s0;

create view spatial_model_at_reference as
with coef as (
    select model,max(value) filter(where key='intercept') as intercept,
           max(value) filter(where key='lat') as bl,
           max(value) filter(where key='lon') as bo,
           max(value) filter(where key='param') as spatial_param
    from reference where chapter='CH23' and model in ('sar','sem')
    and quantity in ('beta','scalar') group by model
), ols_resid as (
    select c.*,w.region,w.access-(c.intercept+c.bl*w.latc+c.bo*w.lonc) as e
    from coef c cross join water w
), lag_resid as (
    select r.model,r.region,r.e,r.spatial_param,sum(w.weight*t.e) as we
    from ols_resid r join weights23 w on w.graph=1 and r.region=w.origin
    join ols_resid t on t.model=r.model and w.target=t.region group by all
)
select model,sum((e-spatial_param*case when model='sar' then wy else we end)^2) as rss
from lag_resid l join spatial_lags w on w.graph=1 and l.region=w.origin group by model;

create view inference_long as
select * from (unpivot trial24 on y1,y2,y3 into name model value y);

create view cluster_means as
select model,cluster,block,assigned,count(*) as n,avg(y) as ybar
from inference_long group by all;

create view ri_draws as
with assignments as (
    select draw,cast(substr(slot,2) as integer) as cluster,z
    from (unpivot assignments24 on columns('^z[0-9]+$') into name slot value z)
)
select a.draw,c.model,sum((2*a.z-1)*c.ybar)/6 as value
from assignments a join cluster_means c using(cluster) group by all;

create view null_contrast as
select model,sum((2*assigned-1)*ybar)/6 as value from cluster_means group by model;

create view inference_scores as
with coefs as (
    select model,max(value) filter(where key='intercept') as b0,
           max(value) filter(where key='assigned') as b1,
           max(value) filter(where key='x') as bx,
           max(value) filter(where key='block2') as bb
    from reference where chapter='CH24' and quantity='beta' group by model
), u as (
    select l.*,y-b0-b1*assigned-bx*x-bb*(block-1) as e
    from inference_long l join coefs using(model)
)
select model,cluster,sum(e) as intercept,sum(e*assigned) as assigned,
       sum(e*x) as x,sum(e*(block-1)) as block2
from u group by all;

create view block_means as
with starts as (
    unpivot blocks24 on columns('^b[0-9]+$') into name block_no value start
)
select draw,avg(s.y) as value,count(*) as n from starts b cross join range(0,5) a(step)
join serial24 s on s.t=1+((b.start-1+a.step)%60) group by draw;

create view multiplicity as
with ranked as (
    select model,value as p,row_number() over(order by value,model) as rank
    from reference where chapter='CH24' and quantity='scalar' and key='p_cr1'
)
select model,least(1,3*p) as bonferroni,
       least(1,max((4-rank)*p) over(order by rank rows unbounded preceding)) as holm,
       least(1,min(3*p/rank) over(order by rank rows between current row and unbounded following)) as bh
from ranked;
