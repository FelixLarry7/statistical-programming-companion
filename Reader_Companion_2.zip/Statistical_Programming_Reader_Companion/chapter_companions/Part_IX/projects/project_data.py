"""Read verified outputs and define the public reporting fields."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "companion"))
from ledger import read

METRICS = ROOT / "companion/evidence/python/metrics.csv"
PRODUCTS = ("85123A", "22423", "85099B")
COUNTRIES = (
    ("GHA", "Ghana"), ("KEN", "Kenya"), ("SEN", "Senegal"),
    ("ZAF", "South Africa"), ("BGD", "Bangladesh"), ("BRA", "Brazil"),
    ("IDN", "Indonesia"), ("VNM", "Viet Nam"), ("IND", "India"),
    ("USA", "United States"), ("SSD", "South Sudan"), ("TLS", "Timor-Leste"),
    ("WLD", "World"),
)
MODELS = {
    "common": "Balanced, equal weights",
    "weighted": "Balanced, population weights",
    "expanded": "Expanded, equal weights",
    "national": "Balanced, WDI income",
}
RATE_LABELS = {
    "coverage": "Transfer coverage",
    "exclusion": "Eligibility exclusion",
    "inclusion": "Ineligible receipt among recipients",
    "insured": "Recorded insurance",
    "unmet": "Unmet care",
    "unmet_rural": "Unmet care, rural",
    "unmet_urban": "Unmet care, urban",
}
STATUS = {0: "Withheld", 1: "Insufficient precision", 2: "Released"}


class Results:
    def __init__(self, path):
        self.rows = read(path)

    def get(self, chapter, model, key, quantity="scalar"):
        return self.rows[(f"CH{chapter}", model, quantity, str(key))]

    def values(self, chapter, model):
        return {key: value for (ch, m, q, key), value in self.rows.items()
                if (ch, m, q) == (f"CH{chapter}", model, "scalar")}

    def series(self, chapter, model, quantity):
        return {key: value for (ch, m, q, key), value in self.rows.items()
                if (ch, m, q) == (f"CH{chapter}", model, quantity)}

    def public_domains(self):
        for number in range(1, 5):
            domain = f"Domain {number}"
            values = self.values(36, f"domain{number}")
            status = STATUS[values["status"]]
            if status == "Released":
                yield domain, status, values["estimate"], values["lo"], values["hi"]
            else:
                yield domain, status, None, None, None


def decimal(value, digits=2):
    return f"{value:,.{digits}f}".replace("-", "−")


def percent(value):
    return f"{100 * value:.2f}%"


def interval(low, high, *, pct=False, digits=2):
    if pct:
        return f"{100 * low:.{digits}f}–{100 * high:.{digits}f}%"
    return f"{decimal(low, digits)} to {decimal(high, digits)}"


def gbp(pence):
    return f"£{pence / 100:,.2f}"


def table(header, rows, numeric=()):
    def line(items):
        return "| " + " | ".join(str(item) for item in items) + " |"
    return "\n".join([
        line(header),
        line(["---:" if i in numeric else ":---" for i in range(len(header))]),
        *(line(row) for row in rows),
    ])
