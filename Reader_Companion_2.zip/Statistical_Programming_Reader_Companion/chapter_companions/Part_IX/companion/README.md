# Part IX computational companion

The released data are in `data/`. Check [the codebook](DATA_DICTIONARY.md) and
[the provider record](source/README.md) before recreating a project. The design
contracts and regenerated decision materials are in [projects](../projects/README.md).

## Replay the four-platform evidence

Install Python 3.12, the listed Python requirements, and R 4.5 or a compatible
base R installation. The recorded Stata run is from the author's licensed
Stata 17 IC on macOS. The replay archive preserves the executed source, input
copies, metrics, runtime fields and the command log with local paths removed.

~~~sh
python -m pip install -r companion/requirements.txt
python companion/verify.py --require-four --output build/verification \
  --stata-evidence companion/evidence/stata/evidence_replay.zip
~~~

The command executes Python, base R and DuckDB. It imports the executed Stata
record, verifies its zero return code and completion marker, and compares the
driver and all nine input files byte for byte. Use a fresh output directory
for each replay. To generate fresh licensed evidence locally, extract
`companion/stata/Statistical_Programming_Part_IX_Stata_Local_Run.zip` and follow
`Part_IX_Stata_Local_Run/LOCAL_RUN.md`. The driver uses built-in Stata and
Mata and declares Stata 16 syntax. The documented verification is for the
actual Stata 17 run.

The comparison keys are chapter, model, quantity and key. Counts, integer
pence and release states are compared exactly where designated in the
verifier. Continuous comparisons use absolute error at most 2e−8 + 2e−8
times the absolute Python reference. The ledger records both values, their
difference and the applicable threshold. R and Stata each compare all 6,739
keys against Python. DuckDB compares 6,717 independent values, including both
balanced unweighted slopes. The 22 unshared country-regression fields cover
design constants, covariances and reference intervals or the weighted and
expanded fits. Twenty additional checks use fixture rules or hand anchors.
See `evidence/verification.json` for the runtime and input fingerprints.

If inputs differ, compare hashes before interpreting an estimate. For trial
discrepancies, reconcile eligible and observed cases within village and pair.
For retail discrepancies, check qualifying lines, invoice grain and common
forecast dates. For country fits, check matched keys and residualised income
before covariance conventions. For survey results, compare denominator,
zero-contribution PSUs, tied ranks and release thresholds in that order.

## Rebuild analytical inputs

~~~sh
python companion/prepare_inputs.py --output build/rebuilt_data
diff -qr companion/data build/rebuilt_data
~~~

The source folder includes the adapted UCI extract used by default. To
reproduce its construction from the provider workbook, make a writable copy
of the source folder, download the exact UCI ZIP recorded there and use
`--source PATH_TO_COPY --uci-archive PATH_TO_ZIP`. The input fingerprints
in the verification record refer to the analytical CSVs used across all
platforms.
