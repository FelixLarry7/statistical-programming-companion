"""Independent DuckDB checks of Part IX cohorts, measures and estimands."""

import argparse
from pathlib import Path

import duckdb
import numpy as np

from ledger import Ledger

ROOT=Path(__file__).resolve().parent


def run(data, output):
    db=duckdb.connect(config={"threads":1})
    for f in sorted(data.glob("*.csv")):
        db.read_csv(str(f)).create_view(f.stem)
    db.execute((ROOT/"sql/labs.sql").read_text())
    def query(sql):
        return db.execute(sql).fetchall()
    def empty(sql):
        if query(sql):
            raise ValueError(f"Data contract violated: {sql}")
    for table,key in (("assignment33","village"),("roster33","household"),("draws33","draw"),
        ("retail34","line"),("returns34","line"),("wdi35","economy,year"),("pwt35","economy,year"),
        ("map35","economy"),("welfare36","household")):
        empty(f"SELECT {key} FROM {table} GROUP BY {key} HAVING count(*)<>1")
    empty("SELECT pair FROM assignment33 GROUP BY pair HAVING count(*)<>2 OR sum(offer)<>1")
    empty("SELECT household FROM roster33 ANTI JOIN assignment33 USING(village)")
    empty("SELECT household FROM roster33 WHERE (followup>=0)<>(observed=1) OR (eligible=0 AND observed=1)")
    empty("SELECT village FROM trial_villages WHERE n<>20 OR obs=0")
    empty("SELECT economy FROM wdi35 GROUP BY economy HAVING count(*)<>24")
    empty("SELECT economy FROM wdi35 ANTI JOIN map35 USING(economy)")
    empty("""SELECT r.line FROM returns34 r LEFT JOIN returns34 s ON r.original=s.line
             WHERE r.status=3 AND (s.line IS NULL OR s.status<>1 OR s.pence<>r.pence OR r.units>=0)""")
    empty("""SELECT s.line FROM returns34 r JOIN returns34 s ON r.original=s.line
             WHERE r.status=3 GROUP BY s.line,s.units HAVING -sum(r.units)>s.units""")
    l=Ledger()
    for arm,n,eligible,obs,*counts in query("""SELECT offer,count(*),sum(eligible),sum(observed),
            count_if(reason=1),count_if(reason=2),count_if(reason=3) FROM trial_rows GROUP BY offer"""):
        m=l.model("CH33",f"arm{arm}")
        m.scalars(screened=n,eligible=eligible,observed=obs,missing=eligible-obs,attrition=1-obs/eligible)
        m.vector("reason",(1,2,3),counts)
    for i,*v in query("SELECT village,n,obs,change,baseline,lo,hi FROM trial_villages"):
        l.model("CH33","village").vector("value",(f"{i}/{k}" for k in ("n","obs","change","baseline","lo","hi")),v)
    m=l.model("CH33","trial")
    for i,value in query("SELECT pair,delta FROM trial_pairs"):
        m.add("pair",i,value)
    perm=query("""WITH long AS (
            UNPIVOT draws33 ON COLUMNS(* EXCLUDE(draw)) INTO NAME pair_key VALUE sign
        ) SELECT draw,sum(sign*p.delta)/24 FROM long JOIN trial_pairs p
             ON p.pair=CAST(substr(pair_key,2) AS INTEGER) GROUP BY draw ORDER BY draw""")
    m.vector("permuted",(r[0] for r in perm),(r[1] for r in perm))
    n,est,se,base,attr,lo,hi,shift=query("""SELECT count(*),avg(delta),stddev_samp(delta)/sqrt(count(*)),
      avg(balance),avg(missing_gap),avg(lo),avg(hi),avg(missing_sum) FROM trial_pairs""")[0]
    q=2.0686576104190406
    m.scalars(pairs=n,villages=2*n,estimate=est,se=se,df=n-1,lo=est-q*se,hi=est+q*se,baseline_gap=base,
              attrition_gap=attr,randomisation_p=(1+sum(abs(x[1])>=abs(est)-1e-12 for x in perm))/(1+len(perm)),
              bound_lo=lo,bound_hi=hi,delta3_lo=est-3*shift,delta3_hi=est+3*shift,
              delta6_lo=est-6*shift,delta6_hi=est+6*shift,
              mde=(1.95996398454+0.841621233573)*8*np.sqrt(2*(1+19*.1)/(24*20)))
    n,s,c,u,unknown,anon,gross,cut=query("""SELECT count(*),count_if(sold),count_if(cancellation),
        count_if(other_negative),count_if(NOT (sold OR cancellation)),count_if(sold AND customer=0),
        sum(amount) FILTER (WHERE sold),-sum(amount) FILTER (WHERE cancellation) FROM retail_typed""")[0]
    a,repeated=query("SELECT count(*),sum(net*lines) FROM retail_invoices")[0]
    m=l.model("CH34","revenue")
    m.scalars(lines=n,sales=s,cancel=c,other=u,omitted=unknown,anonymous=anon,invoices=a,gross=gross,
              cancel_value=cut,net=gross-cut,repeated_total=repeated,overcount=repeated-gross+cut)
    for i,value in query("SELECT invoice,net FROM retail_invoices"):
        m.add("invoice",i,value)
    for p,w,value in query("SELECT product,week,units FROM retail_demand"):
        l.model("CH34",f"product{p}").add("demand",w,value)
    for p,w,j,forecast,error in query("SELECT product,week,method,prediction,error FROM retail_forecasts"):
        m=l.model("CH34",f"p{p}_{j}")
        m.add("forecast",w,forecast)
        m.add("error",w,error)
    for p,j,*v in query("""SELECT product,method,count(*),avg(abs(error)),sqrt(avg(error^2)),
        avg(2*greatest(error,0)+greatest(-error,0)),sum(greatest(error,0)),
        count_if(week<=46),avg(abs(error)) FILTER (WHERE week<=46) FROM retail_forecasts GROUP BY ALL"""):
        l.model("CH34",f"p{p}_{j}").vector("scalar",("n","mae","rmse","cost","shortage","changed_n","changed_mae"),v)
    for o,j,*v in query("SELECT * FROM retail_customer"):
        l.model("CH34","customer").vector("snapshot",(f"{o}/{j}/{k}" for k in ("n","events","rate")),v)
    a,b,v,n,k=query("""SELECT sum(units*pence) FILTER(WHERE status=1),-sum(units*pence) FILTER(WHERE status=3),
        sum(units*pence) FILTER(WHERE status=2),count_if(status=3),
        count(DISTINCT original) FILTER(WHERE status=3) FROM returns34""")[0]
    l.model("CH34","linked").scalars(booked=a,returned=b,net=a-b,void=v,linked=n,valid_originals=k)
    for i,n,p,g,u in query("SELECT economy,count(*),count_if(matched),count_if(good),count_if(NOT matched) FROM international GROUP BY economy"):
        l.model("CH35",f"country{i}").scalars(wdi=n,pwt=p,good=g,unmatched=u)
    for i,t,p,*v in query("""SELECT economy,year,pc,life,u5,gdp2015,rgdpo/nullif(emp,0)
                             FROM international WHERE good"""):
        m=l.model("CH35",f"country{i}")
        m.add("income",t,p)
        if t in (2000,2023):
            for k,x in zip(("life","u5","gdp2015","productivity"),v,strict=True):
                if x is not None:
                    m.add("endpoint",f"{t}/{k}",x)
    for m,field in (("common","pc"),("national","gdp2015")):
        n,g,beta=query(f"""WITH t AS (
          SELECT economy,year,ln({field}) AS x,life AS y FROM international_balanced
        ), residual AS (
          SELECT economy,
          x-avg(x) OVER(PARTITION BY economy)-avg(x) OVER(PARTITION BY year)+avg(x) OVER() AS xx,
          y-avg(y) OVER(PARTITION BY economy)-avg(y) OVER(PARTITION BY year)+avg(y) OVER() AS yy
          FROM t
        ) SELECT count(*),count(DISTINCT economy),sum(xx*yy)/sum(xx*xx) FROM residual""")[0]
        l.model("CH35",m).scalars(n=n,countries=g,estimate=beta,df=g-1,k=g+24)
    for t,*v in query("""SELECT year,count(*),avg(life),sum(life*population)/sum(population),avg(pc),
        sum(pc*population)/sum(population) FROM international_balanced WHERE year IN(2000,2023) GROUP BY year"""):
        l.model("CH35","headline").vector("endpoint",
            (f"{t}/{k}" for k in ("countries","mean_life","weighted_life","mean_pc","weighted_pc")),v)
    n,need,known,eligible,covered=query("""SELECT count(*),sum(need),count_if(known),count_if(eligible),
                                           count_if(covered) FROM social_rows""")[0]
    l.model("CH36","flow").scalars(households=n,need=need,known=known,missing=need-known,eligible=eligible,covered=covered)
    q=2.1199052992210112
    for name,n,yes,psus,den,num,p,se,df in query("""SELECT t.model,n,yes,psus,den,num,estimate,se,df
           FROM social_totals t JOIN social_inference i USING(model)"""):
        m=l.model("CH36",name)
        m.scalars(n=n,yes=yes,psus=psus,den=den,num=num,estimate=p,se=se,df=df,lo=p-q*se,hi=p+q*se)
        if name.startswith("domain"):
            status=0 if n<30 or min(yes,n-yes)<5 else (1 if psus<4 or 2*q*se>.28 else 2)
            m.scalars(status=status)
    m=l.model("CH36","inequality")
    vals=query("SELECT * FROM social_rank_scores ORDER BY drop_psu")
    _,c,mu=vals[0]
    for psu,value,p in vals[1:]:
        m.add("jackknife",psu,value)
        m.add("bounded_jk",psu,4*value*p)
    z=np.array([r[1] for r in vals[1:]]).reshape(4,5)
    se=np.sqrt(.8*np.sum((z-z.mean(axis=1)[:,None])**2))
    m.scalars(estimate=c,mean=mu,corrected=4*mu*c,se=se,df=16,lo=c-q*se,hi=c+q*se)
    for name,line,head,gap,den in query("""SELECT b.name,c.line,sum(b.w*CAST(f.welfare<c.line AS INTEGER))/sum(b.w),
           sum(b.w*greatest(0,1-f.welfare/c.line))/sum(b.w),sum(b.w)
        FROM welfare36 f CROSS JOIN (VALUES (2200),(2600)) c(line)
        CROSS JOIN LATERAL (VALUES ('household',f.weight),('person',f.weight*f.size)) b(name,w)
        GROUP BY ALL"""):
        l.model("CH36",f"{name}{line}").scalars(head=head,gap=gap,den=den)
    output.mkdir(parents=True,exist_ok=True)
    l.save(output/"metrics.csv")
    print("DuckDB",duckdb.__version__,len(l.rows),"keyed values")


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data",type=Path)
    ap.add_argument("output",type=Path)
    a=ap.parse_args()
    run(a.data,a.output)
