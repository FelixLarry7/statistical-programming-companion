# Independent base R calculations. Rscript --vanilla labs.R canonical output.csv
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
folder <- args[[1L]]
metrics <- list()
emit <- function(chapter, metric, grp, value) {
    metrics[[length(metrics) + 1L]] <<- data.frame(chapter, metric, grp, value)
}
input <- function(name, types) {
    read.csv(file.path(folder, name), colClasses = types, check.names = FALSE,
             na.strings = "", fileEncoding = "UTF-8")
}

invoices <- input("ch02.csv", c("character", "character", "numeric"))
stopifnot(!anyNA(invoices$invoice_id), !anyDuplicated(invoices$invoice_id))
counts <- table(invoices$channel)
net <- tapply(invoices$net_minor, invoices$channel, sum)
emit("CH02", "invoices", names(counts), as.numeric(counts))
emit("CH02", "net_minor", names(net), as.numeric(net))
emit("CH02", "net_minor", "all", sum(invoices$net_minor))

r <- input("ch03.csv", c(rep("character", 3L), "integer", rep("character", 3L),
                         "integer", "integer", "numeric"))
valid <- !is.na(r$unit_id)
usable <- valid & is.finite(r$value_double)
stopifnot(all(valid == r$valid_key), all(usable == r$usable))
emit("CH03", "valid_keys", "all", sum(valid))
emit("CH03", "distinct_keys", "all", length(unique(r$unit_id[valid])))
emit("CH03", "usable", "all", sum(usable))
states <- table(r$value_state)
emit("CH03", "value_state", names(states), as.numeric(states))
emit("CH03", "rank_code", r$row_id, match(r$rank_label, c("low", "medium", "high")))
x <- r$value_double[r$row_id == "r02"]
single <- readBin(writeBin(x, raw(), size = 4L), "double", n = 1L, size = 4L)
emit("CH03", "float32_loss", "r02", x - single)
emit("CH03", "mean_usable", "all", mean(r$value_double[usable]))
draws <- input("draws.csv", c("character", "numeric"))
emit("CH03", "draw_lt_half", "all", sum(draws$u < 0.5))

coverage <- input("ch04.csv", c("character", rep("integer", 4L)))
rates <- with(coverage, tapply(reached_30d, offer, mean))
strata <- with(coverage, tapply(reached_30d, list(baseline_high, offer), mean))
frozen <- ifelse(coverage$baseline_high == 1L, 0.3, 0.7)
emit("CH04", "eligible", "all", nrow(coverage))
emit("CH04", "coverage", "all", mean(coverage$reached_30d))
emit("CH04", "coverage", "control", rates[["0"]])
emit("CH04", "coverage", "offered", rates[["1"]])
emit("CH04", "difference", "crude", rates[["1"]] - rates[["0"]])
emit("CH04", "difference", "standardised", mean(strata[, "1"] - strata[, "0"]))
emit("CH04", "brier", "frozen", mean((frozen - coverage$reached_30d)^2))
emit("CH04", "brier", "constant", mean((0.5 - coverage$reached_30d)^2))
arguments <- commandArgs()
file_option <- grep("^--file=", arguments, value = TRUE)
if (length(file_option)) {
    script <- sub("^--file=", "", file_option[[1L]])
} else {
    flag <- which(arguments %in% c("-f", "--file"))[[1L]]
    script <- arguments[[flag + 1L]]
}
source(file.path(dirname(script), "depth_metrics.R"), local = TRUE)
write.csv(do.call(rbind, metrics), args[[2L]], row.names = FALSE)
cat(R.version.string, "\n")
