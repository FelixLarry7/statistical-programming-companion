-- Typed extracts for the four extended worked examples.
CREATE TEMP TABLE ch01_maize AS
SELECT * FROM read_csv('data/maize_pilot.csv', header = true, auto_detect = false,
    columns = {'plot_id':'VARCHAR', 'season':'INTEGER', 'area_ha':'DOUBLE',
               'harvest_kg':'DOUBLE', 'sessions':'INTEGER', 'yield_kg_ha':'DOUBLE'});

SELECT CASE WHEN count(*) <> 12 OR count(*) <> count(DISTINCT (plot_id, season))
    OR count(*) FILTER (WHERE plot_id IS NULL OR season IS DISTINCT FROM 2025
        OR sessions IS NULL OR sessions NOT BETWEEN 0 AND 5
        OR area_ha IS NULL OR NOT isfinite(area_ha) OR area_ha <= 0
        OR harvest_kg IS NULL OR NOT isfinite(harvest_kg) OR harvest_kg < 0
        OR yield_kg_ha IS NULL OR NOT isfinite(yield_kg_ha)
        OR abs(yield_kg_ha - harvest_kg / area_ha) > 1e-8) > 0
    THEN error('The maize audit input violates the Stage 2 data contract') END
FROM ch01_maize;

CREATE TEMP TABLE refund_events AS
SELECT * FROM read_csv('data/refund_events.csv', header = true, auto_detect = false,
    columns = {'refund_id':'VARCHAR', 'invoice_id':'VARCHAR', 'event_day':'DATE',
               'status':'VARCHAR', 'refund_minor':'BIGINT'});

SELECT CASE WHEN count(*) <> count(DISTINCT refund_id)
    OR count(*) FILTER (WHERE invoice_id IS NULL OR event_day IS NULL
        OR status IS NULL OR status NOT IN ('settled','pending')
        OR refund_minor IS NULL OR refund_minor < 0) > 0
    THEN error('Refund event keys or domains are invalid') END
FROM refund_events;

SELECT CASE WHEN count(*) > 0 THEN error('A refund has no parent invoice') END
FROM refund_events ANTI JOIN invoices_raw USING (invoice_id);

CREATE TEMP TABLE ch02_ledger AS
SELECT i.invoice_id, i.channel, i.amount_minor
FROM invoices_raw i JOIN ch02 USING (invoice_id);

CREATE TEMP TABLE ch02_refunds AS
SELECT r.refund_id, r.invoice_id, r.refund_minor
FROM refund_events r JOIN ch02_ledger i USING (invoice_id)
WHERE r.status = 'settled' AND r.event_day < DATE '2025-04-01';

SELECT CASE WHEN count(*) FILTER (WHERE
    coalesce(r.refund_minor, 0) <> i.refund_minor
    OR coalesce(r.refund_minor, 0) > i.amount_minor) > 0
    THEN error('As-of event totals do not reconcile to invoice balances') END
FROM invoices_raw i JOIN ch02 USING (invoice_id)
LEFT JOIN (
    SELECT invoice_id, sum(refund_minor) AS refund_minor
    FROM ch02_refunds GROUP BY invoice_id
) r USING (invoice_id);

CREATE TEMP TABLE ch03_design AS
SELECT * FROM read_csv('data/encoding_design.csv', header = true, auto_detect = false,
    columns = {'unit_id':'VARCHAR', 'level':'VARCHAR', 'outcome':'DOUBLE'});

SELECT CASE WHEN count(*) <> count(DISTINCT unit_id)
    OR count(DISTINCT level) <> 3
    OR count(*) FILTER (WHERE level IS NULL OR level NOT IN ('low','medium','high')
        OR outcome IS NULL OR NOT isfinite(outcome)) > 0
    THEN error('The categorical design lacks a valid key or all three levels') END
FROM ch03_design;

CREATE TEMP TABLE ch04_eligible AS
SELECT episode_id, baseline_high, offer, reached_30d
FROM coverage_raw
WHERE cohort = 2025 AND consent = 1;

SELECT CASE WHEN count(*) <> 4 THEN error('A risk-by-offer cell is absent') END
FROM (SELECT DISTINCT baseline_high, offer FROM ch04_eligible);
