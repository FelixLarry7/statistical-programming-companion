-- DuckDB 1.4.4. Execute from the companion directory.
CREATE TEMP TABLE invoices_raw AS
SELECT * FROM read_csv('data/invoices.csv', header = true, auto_detect = false,
    columns = {'invoice_id':'VARCHAR', 'channel':'VARCHAR', 'quarter':'VARCHAR',
        'currency':'VARCHAR', 'amount_minor':'BIGINT', 'refund_minor':'BIGINT', 'state':'VARCHAR'});

SELECT CASE WHEN count(*) <> count(DISTINCT invoice_id)
    OR count(*) FILTER (WHERE channel IS NULL OR channel NOT IN ('agent', 'branch', 'digital')
        OR quarter IS NULL OR currency IS NULL OR state IS NULL
        OR amount_minor IS NULL OR refund_minor IS NULL
        OR refund_minor < 0 OR refund_minor > amount_minor) > 0
    THEN error('Invoice keys or domains are invalid') END
FROM invoices_raw;

CREATE TEMP TABLE ch02 AS
SELECT invoice_id, channel, amount_minor - refund_minor AS net_minor
FROM invoices_raw
WHERE quarter = '2025Q1' AND currency = 'GHS' AND state = 'posted';

CREATE TEMP TABLE representation_raw AS
SELECT * FROM read_csv('data/representation.csv', header = true, auto_detect = false,
    columns = {'row_id':'VARCHAR', 'unit_id':'VARCHAR', 'rank_label':'VARCHAR',
        'value_token':'VARCHAR', 'missing_reason':'VARCHAR'});

SELECT CASE WHEN count(*) <> count(DISTINCT row_id)
    OR count(unit_id) <> count(DISTINCT unit_id)
    OR count(*) FILTER (WHERE rank_label IS NULL OR rank_label NOT IN ('low', 'medium', 'high')
        OR missing_reason IS NULL
        OR (value_token IS NOT NULL AND value_token NOT IN ('.a', 'Inf', '-Inf', 'NaN')
            AND NOT coalesce(isfinite(try_cast(value_token AS DOUBLE)), false))) > 0
    THEN error('Representation keys or domains are invalid') END
FROM representation_raw;

CREATE TEMP TABLE ch03 AS
WITH classified AS (
    SELECT *,
        CASE rank_label WHEN 'low' THEN 1 WHEN 'medium' THEN 2 WHEN 'high' THEN 3 END AS rank_code,
        CASE WHEN value_token IS NULL THEN 'blank'
             WHEN value_token = '.a' THEN 'extended_missing'
             WHEN value_token IN ('Inf', '-Inf') THEN 'infinite'
             WHEN value_token = 'NaN' THEN 'nan'
             ELSE 'finite' END AS value_state
    FROM representation_raw
)
SELECT row_id, unit_id, rank_label, rank_code, value_token, missing_reason, value_state,
       CAST(unit_id IS NOT NULL AS INTEGER) AS valid_key,
       CAST(unit_id IS NOT NULL AND value_state = 'finite' AS INTEGER) AS usable,
       CASE WHEN value_state = 'finite' THEN CAST(value_token AS DOUBLE) END AS value_double
FROM classified;

CREATE TEMP TABLE draws AS
SELECT * FROM read_csv('data/draws.csv', header = true, auto_detect = false,
    columns = {'draw_id':'VARCHAR', 'u':'DOUBLE'});

SELECT CASE WHEN count(*) <> count(DISTINCT draw_id)
    OR count(*) FILTER (WHERE u IS NULL OR NOT isfinite(u) OR u < 0 OR u >= 1) > 0
    THEN error('Draw identities or values are invalid') END
FROM draws;

CREATE TEMP TABLE coverage_raw AS
SELECT * FROM read_csv('data/coverage.csv', header = true, auto_detect = false,
    columns = {'episode_id':'VARCHAR', 'cohort':'INTEGER', 'consent':'INTEGER',
        'baseline_high':'INTEGER', 'offer':'INTEGER', 'reached_30d':'INTEGER', 'opened':'INTEGER'});

SELECT CASE WHEN count(*) <> count(DISTINCT episode_id)
    OR count(*) FILTER (WHERE cohort IS NULL
        OR consent IS NULL OR consent NOT IN (0,1)
        OR baseline_high IS NULL OR baseline_high NOT IN (0,1)
        OR offer IS NULL OR offer NOT IN (0,1)
        OR reached_30d NOT IN (0,1)
        OR opened IS NULL OR opened NOT IN (0,1) OR opened > offer) > 0
    THEN error('Coverage keys or domains are invalid') END
FROM coverage_raw;

CREATE TEMP TABLE ch04_audit AS
SELECT episode_id,
    CASE WHEN cohort <> 2025 THEN 'outside_cohort'
         WHEN consent = 0 THEN 'no_consent'
         WHEN reached_30d IS NULL THEN 'missing_outcome'
         ELSE 'eligible' END AS disposition
FROM coverage_raw;

CREATE TEMP TABLE ch04 AS
SELECT episode_id, baseline_high, offer, reached_30d, opened
FROM coverage_raw JOIN ch04_audit USING (episode_id)
WHERE disposition = 'eligible';
