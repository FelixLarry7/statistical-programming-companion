"""Independent numerical implementations of the four extended Part I cases."""

import numpy as np
import pandas as pd
import statsmodels.api as sm


def maize_metrics(maize):
    scenarios = (
        ('full', maize, 1),
        ('trim_high', maize.loc[maize.sessions.lt(5)], 1),
        ('scaled_tenth', maize, 0.1),
    )
    for scenario, data, scale in scenarios:
        x = data.sessions.to_numpy(dtype=float)
        y = data.yield_kg_ha.to_numpy(dtype=float) * scale
        fit = sm.OLS(y, sm.add_constant(x), missing='raise').fit()
        robust = fit.get_robustcov_results(cov_type='HC1')
        values = {
            'sample_n': fit.nobs, 'slope': fit.params[1], 'intercept': fit.params[0],
            'sxx': np.sum((x-x.mean())**2), 'sse': fit.ssr, 'classical_se': fit.bse[1],
            'hc1_se': robust.bse[1], 'max_leverage': max(fit.get_influence().hat_matrix_diag),
        }
        yield from (('CH01', key, scenario, value) for key, value in values.items())


def refund_metrics(folder):
    ledger = pd.read_csv(folder / 'ch02_ledger.csv', dtype={
        'invoice_id': 'string', 'channel': 'string', 'amount_minor': 'int64'})
    events = pd.read_csv(folder / 'ch02_refunds.csv', dtype={
        'refund_id': 'string', 'invoice_id': 'string', 'refund_minor': 'int64'})
    if events.refund_id.isna().any() or not events.refund_id.is_unique:
        raise ValueError('Refund event keys must be present and unique.')
    broken = ledger.merge(events, on='invoice_id', how='left', validate='one_to_many')
    by_invoice = events.groupby('invoice_id', as_index=False).refund_minor.sum()
    valid = ledger.merge(by_invoice, on='invoice_id', how='left', validate='one_to_one')
    valid['net_minor'] = valid.amount_minor - valid.refund_minor.fillna(0).astype('int64')
    inflated = int((broken.amount_minor - broken.refund_minor.fillna(0)).sum())
    yield 'CH02', 'settled_events', 'all', len(events)
    yield 'CH02', 'gross_minor', 'all', int(ledger.amount_minor.sum())
    yield 'CH02', 'refund_minor', 'all', int(events.refund_minor.sum())
    yield 'CH02', 'join_rows', 'unaggregated', len(broken)
    yield 'CH02', 'inflated_net_minor', 'unaggregated', inflated
    yield 'CH02', 'excess_minor', 'unaggregated', inflated - int(valid.net_minor.sum())
    yield 'CH02', 'pooled_mean_minor', 'all', valid.net_minor.mean()
    yield 'CH02', 'channel_mean_minor', 'all', valid.groupby('channel').net_minor.mean().mean()


def design_metrics(folder, maize):
    data = pd.read_csv(folder / 'ch03_design.csv', dtype={
        'unit_id': 'string', 'level': 'string', 'outcome': 'float64'})
    outcome = data.outcome.to_numpy()
    fitted = []
    for base, terms in [('low', ['medium', 'high']), ('high', ['low', 'medium'])]:
        design = np.column_stack([np.ones(len(data)), *(data.level.eq(term) for term in terms)])
        design = design.astype(float)
        coefs, _, rank, _ = np.linalg.lstsq(design, outcome, rcond=None)
        if rank != 3:
            raise ValueError(f'Rank failure with {base} as reference.')
        prediction = design @ coefs
        fitted.append(prediction)
        for name, value in zip(['intercept', *terms], coefs, strict=True):
            yield 'CH03', f'coef_{base}_ref', name, value
        yield 'CH03', 'design_sse', f'{base}_ref', np.sum((outcome-prediction)**2)
    yield 'CH03', 'design_rank', 'both', rank
    yield 'CH03', 'fitted_gap', 'both', max(abs(fitted[0]-fitted[1]))
    big = float(10**16)
    yield 'CH03', 'sum_order', 'left_assoc', (big + 1.0) - big
    yield 'CH03', 'sum_order', 'reordered', (big - big) + 1.0
    x = maize.sessions.to_numpy(dtype=float)
    n = len(x)
    sxx = np.sum((x-x.mean())**2)
    det = n*sxx
    trace = n+sxx+n*(x.mean()+10**6)**2
    yield 'CH03', 'condition', 'uncentered', (trace+np.sqrt(trace**2-4*det))/(2*np.sqrt(det))
    yield 'CH03', 'condition', 'centered', np.sqrt(max(n, sxx)/min(n, sxx))


def spec_metrics(folder):
    data = pd.read_csv(folder / 'ch04_eligible.csv')
    actual = data.dropna(subset=['reached_30d'])
    yield 'CH04', 'target_n', 'all', len(data)
    yield 'CH04', 'missing_outcome', 'offered', int(data.loc[data.offer.eq(1), 'reached_30d'].isna().sum())
    for metric, grouped in (
        ('crude_bound', data.groupby('offer')),
        ('standardised_bound', data.groupby(['baseline_high', 'offer'])),
    ):
        cells = grouped.reached_30d.agg(['size', 'count', 'sum'])
        lower = cells['sum']/cells['size']
        upper = (cells['sum']+cells['size']-cells['count'])/cells['size']
        if metric == 'crude_bound':
            difference = (lower[1]-upper[0], upper[1]-lower[0])
        else:
            lo, hi = lower.unstack('offer'), upper.unstack('offer')
            difference = ((lo[1]-hi[0]).mean(), (hi[1]-lo[0]).mean())
        yield 'CH04', metric, 'lower', difference[0]
        yield 'CH04', metric, 'upper', difference[1]
    bins = actual.groupby('baseline_high').reached_30d.agg(['size', 'mean'])
    weights = bins['size']/len(actual)
    overall = actual.reached_30d.mean()
    reliability = np.sum(weights*(np.where(bins.index == 1, .3, .7)-bins['mean'])**2)
    resolution = np.sum(weights*(bins['mean']-overall)**2)
    uncertainty = overall*(1-overall)
    for metric, value in [('reliability', reliability), ('resolution', resolution),
                          ('uncertainty', uncertainty), ('reconstructed', reliability-resolution+uncertainty)]:
        yield 'CH04', 'brier_component', metric, value


def deepening_metrics(folder):
    maize = pd.read_csv(folder / 'ch01_maize.csv', dtype={'plot_id': 'string'})
    if maize.duplicated(['plot_id', 'season']).any():
        raise ValueError('The maize input must be unique by plot and season.')
    yield from maize_metrics(maize)
    yield from refund_metrics(folder)
    yield from design_metrics(folder, maize)
    yield from spec_metrics(folder)
