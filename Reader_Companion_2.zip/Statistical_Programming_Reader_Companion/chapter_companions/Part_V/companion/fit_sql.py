"""Execute the Part V SQL comparisons and retain intermediate samples."""

from pathlib import Path
import sys
import duckdb
from ledger import Ledger


def check(c, statement, expected=0):
    value = c.execute(statement).fetchone()[0]
    if value != expected:
        raise ValueError(f'Expected {expected}, found {value}. {statement}')


def scalars(c, lab, statement, params=None):
    rows = c.execute(statement,params or [])
    keys = [item[0] for item in rows.description]
    lab.vector('scalar',keys,rows.fetchone())


def trial(c, ledger):
    check(c,'select count(*)-count(distinct household) from households17')
    check(c,'select count(*)-count(distinct village) from villages17')
    check(c,'select count(*) from households17 anti join villages17 using(village)')
    check(c,'''select count(*) from trial_rows where admin is null
      or baseline_wave>=outcome_wave or measured<>(survey is not null)::int''')
    check(c,'select count(*) from trial_cluster where n<>8')
    check(c,'select count(*) from randomisation where villages<>12 or b1<>3 or b2<>3')
    check(c,'select count(*) from randomisation where mismatches=0',1)
    check(c,'select count(*) from (select distinct * exclude(draw) from allocations17)',400)
    m = ledger.model('CH17','trial')
    scalars(c,m,'''select (select count(*) from households17) as roster,
           (select count(*) from trial_rows) as n,(select count(*) from trial_cluster) as villages,
           (select sum(offer) from trial_cluster) as treated_villages,
           trial_totals.observed/trial_totals.n as itt,count(*) as permutations,
           sum(extreme::int) as extreme,avg(extreme::int) as ri_p
           from randomisation cross join trial_totals group by trial_totals.observed,trial_totals.n''')
    for key, value in c.execute('select draw,statistic from randomisation').fetchall():
        m.add('permutation',key,value)
    for key, value in c.execute('select village,admin/n from trial_cluster').fetchall():
        m.add('village_mean',key,value)
    for key, *values in c.execute('select offer,n,measured,baseline/n,admin/n,survey/measured from trial_arm').fetchall():
        for q,v in zip(('arm_n','arm_measured','arm_baseline','arm_admin','arm_survey'),values,strict=True):
            m.add(q,key,v)
    for k,v in c.execute('''select block,avg(admin/n) filter(where offer=1)-
                         avg(admin/n) filter(where offer=0) from trial_cluster group by block''').fetchall():
        m.add('block_itt',k,v)
    scalars(c,m,'''with bounds as (select *,survey/n as lo,(survey+100*(n-measured))/n as hi from trial_arm)
             select t.receipt/t.n-z.receipt/z.n as receipt_itt,
                    a.observed/a.n/(t.receipt/t.n-z.receipt/z.n) as wald,
                    t.measured/t.n-z.measured/z.n as response_itt,
                    t.lo-z.hi as bound_low,t.hi-z.lo as bound_high
             from bounds t cross join bounds z cross join trial_totals a where t.offer=1 and z.offer=0''')


def rollout(c,ledger):
    check(c,'select count(*)-count(distinct (unit,period)) from rollout_panel')
    check(c,'''select count(*) from (select unit from rollout_panel group by unit having
            count(*)<>10 or min(period)<>0 or max(period)<>9 or
            count(distinct cohort)<>1 or count(distinct x)<>1)''')
    check(c,'select count(*) from did_stratum where nt=0 or nc=0')
    for rule in ('never','notyet','risky'):
        m = ledger.model('CH18',rule)
        for g,t,nt,nc,raw,att in c.execute('select g,t,nt,nc,raw,att from did_att where model=?',[rule]).fetchall():
            for q,v in zip(('target_n','control_n','raw','att'),(nt,nc,raw,att),strict=True):
                m.add(q,f'{g}/{t}',v)
        for g,t,x,n in c.execute('select g,t,x,nc from did_stratum where model=?',[rule]).fetchall():
            m.add('support',f'{g}/{t}/{x}',n)
        for k,n,t in c.execute('select event,nt,effect from did_event where model=?',[rule]).fetchall():
            m.add('event_n',k,n)
            m.add('event_att',k,t)


def iv_rd(c,ledger):
    check(c,'select count(*)-count(distinct record) from encourage19')
    check(c,'select count(*)-count(distinct record) from threshold19')
    check(c,'select count(*) from threshold19 where eligible<>(running>=0)::int')
    for model,d,y in (('strong','dose','outcome'),('weak','weak','weak_outcome')):
        scalars(c,ledger.model('CH19',model),f'''
        select count(*) as n,sum(rz*{d})/sum(rz*z) as first,
               sum(rz*{y})/sum(rz*z) as reduced,sum(rz*{y})/sum(rz*{d}) as effect from iv_partials''')
    m = ledger.model('CH19','gmm')
    for step in (1,2):
        values = c.execute('''
        with b as (select max(value) filter(where key='intercept') as ic,
                          max(value) filter(where key='x') as bx,max(value) filter(where key='dose') as bd
                   from reference where chapter='CH19' and model='gmm' and quantity=?),
        e as (select outcome-ic-bx*x-bd*dose as u,x,z,z2 from encourage19 cross join b)
        select avg(u),avg(u*x),avg(u*z),avg(u*z2) from e''',[f'beta{step}']).fetchone()
        m.vector(f'moment{step}',('intercept','x','z','z2'),values)
    m = ledger.model('CH19','rd')
    for term,h,jump in c.execute('select * from rd_jumps').fetchall():
        m.add(term,h,jump)
    for h,ratio in c.execute('''select hcode,max(jump) filter(where term='fuzzy')/
                             max(jump) filter(where term='receipt') from rd_jumps group by hcode''').fetchall():
        m.add('ratio',h,ratio)
    for h,z,n in c.execute('select hcode,eligible,count(*) from rd_samples group by all').fetchall():
        m.add('right_n' if z else 'left_n',h,n)
    for k,v in c.execute('select record,kernel from rd_samples where hcode=250').fetchall():
        m.add('kernel',k,v)


def selection(c,ledger):
    check(c,'select count(*)-count(distinct record) from selection20')
    check(c,'select count(*)-(select count(*) from selection20 where eligible=1) from observational')
    check(c,'select count(*) from observational where p<=0 or p>=1')
    check(c,'select count(*)-count(distinct (place,period)) from places20')
    check(c,'''select count(*) from (select place from places20 group by place
             having count(*)<>12 or min(period)<>0 or max(period)<>11)''')
    m = ledger.model('CH20','nuisance')
    for k,p,a,b in c.execute('select record,p,mu0,mu1 from observational').fetchall():
        for q,v in zip(('p','mu0','mu1'),(p,a,b),strict=True):
            m.add(q,k,v)
    for model in ('full','trim'):
        m = ledger.model('CH20',model)
        scalars(c,m,'select * exclude(model) from weighted_summary where model=?',[model])
        for key, value in c.execute('select record,score from weighted_rows where model=?',[model]).fetchall():
            m.add('score',key,value)
        for k,raw,ipw in c.execute('select covariate,raw,ipw from weighted_balance where model=?',[model]).fetchall():
            m.add('balance_raw',k,raw)
            m.add('balance_ipw',k,ipw)
    for model in ('scm','exclude4'):
        m = ledger.model('CH20',model)
        for k,fit,gap in c.execute('select period,fit,gap from donor_fit where model=?',[model]).fetchall():
            m.add('fit',k,fit)
            m.add('gap',k,gap)
        scalars(c,m,'''select avg(gap^2) filter(where period<7) as pre_mse,
                      avg(gap) filter(where period>=7) as post_gap,avg(weight_sum) as weight_sum
                      from donor_fit where model=?''',[model])
    m = ledger.model('CH20','scm')
    for k,first,second in c.execute('''
        with w as (select sum(weight) as s from donor_weights where model='scm' and place in (1,2)),
        p as (select period,max(outcome) filter(where place=1)-max(outcome) filter(where place=2) as d
              from places20 group by period)
        select period,fit+s*d/2,fit-s*d/2 from donor_fit join p using(period) cross join w where model='scm'
        ''').fetchall():
        m.add('all_d1',k,first)
        m.add('all_d2',k,second)


if __name__=='__main__':
    raw, reference, output = map(Path,sys.argv[1:])
    c = duckdb.connect(config={'threads':1})
    for file in sorted(raw.glob('*.csv')):
        c.read_csv(str(file),header=True).create_view(file.stem)
    c.read_csv(str(reference),header=True).create_view('reference')
    c.execute((Path(__file__).parent/'sql/models.sql').read_text())
    ledger = Ledger()
    for run in (trial,rollout,iv_rd,selection):
        run(c,ledger)
    output.mkdir(parents=True,exist_ok=True)
    ledger.save(output/'metrics.csv')
    for name,order in (('trial_cluster','village'),('did_stratum','model,g,t,x'),
                       ('rd_samples','hcode,record'),('observational','record'),('donor_fit','model,period')):
        c.execute(f'select * from {name} order by {order}').df().to_csv(output/f'{name}.csv',index=False)
    print('DuckDB',duckdb.__version__,len(ledger.rows),'values')
