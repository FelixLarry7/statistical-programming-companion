"""Regenerate the frozen synthetic Part V data and assignment manifests."""

import argparse
import csv
from itertools import combinations, product
from math import cos, exp, sin
from pathlib import Path
from random import Random

RAW = Path(__file__).resolve().parent/'data/raw'


def write(output, name, fields, rows):
    with (output/f'{name}.csv').open('w',encoding='utf-8',newline='') as stream:
        writer = csv.writer(stream,lineterminator='\n')
        writer.writerow(fields.split())
        for row in rows:
            writer.writerow([format(v,'.10f') if isinstance(v,float) else v for v in row])


def trial(output):
    rng = Random(17023)
    offer = (1,0,0,1,0,1,0,1,1,0,1,0)
    write(output,'villages17','village block offer',
          ((v,1+(v>6),z) for v,z in enumerate(offer,1)))
    rows = []
    for v,z in enumerate(offer,1):
        village_effect = rng.randrange(-7,8)
        for j in range(1,10):
            eligible = int(j<=8)
            base = 40+village_effect+rng.randrange(-10,11)
            receipt = int(rng.random() < (0.18+0.64*z))
            admin = base+3+rng.randrange(-6,7)+6*receipt
            measured = int(eligible and rng.random()>=(0.10+0.10*z))
            survey = min(100,max(0,admin+rng.randrange(-8,9))) if measured else ''
            rows.append((100*v+j,v,eligible,0,1,base,admin,receipt,measured,survey))
    write(output,'households17','household village eligible baseline_wave outcome_wave baseline admin receipt measured survey',rows)
    a = product(combinations(range(1,7),3),combinations(range(7,13),3))
    write(output,'allocations17','draw '+' '.join(f'z{j}' for j in range(1,13)),
          ((b,*(int(j in x or j in y) for j in range(1,13))) for b,(x,y) in enumerate(a,1)))


def rollout(output):
    rng = Random(18029)
    rows,unit = [],0
    for cohort,size,high in ((3,8,2),(5,10,6),(7,12,9),(0,9,4),(9,1,0)):
        for x,count in ((0,size-high),(1,high)):
            for j in range(count):
                unit += 1
                offset = rng.uniform(-5,5)
                centred = j-(count-1)/2
                for t in range(10):
                    k = t-cohort
                    effect = 0
                    if cohort and k==-1:
                        effect = .5+.2*(cohort-3)
                    if cohort and k>=0:
                        start,slope = {3:(2.2,.95),5:(3.6,.45),7:(1.4,.30),9:(2,1)}[cohort]
                        effect = start+slope*k+.40*x
                    untreated = 25+offset+.45*t+1.1*sin(t*.64)+.72*x*t
                    untreated += centred*(.21*t+.25*sin((t+cohort)*.91))
                    rows.append((unit,t,cohort,x,int(unit<=39),untreated+effect))
    write(output,'rollout18','unit period cohort x in_scope outcome',rows)
    write(output,'multipliers18','draw '+' '.join(f'u{j}' for j in range(1,40)),
          ((b,*(rng.choice((-1,1)) for _ in range(39))) for b in range(1,200)))


def instruments(output):
    rng = Random(19037)
    rows = []
    for i in range(1,241):
        x = rng.uniform(-1.8,1.8)
        z,z2 = rng.randrange(2),rng.randrange(2)
        u,v = rng.gauss(0,1),rng.gauss(0,1)
        error = (1.1+.28*abs(x))*u
        dose = .98*z+.68*z2+.45*x+.72*u+.85*v
        weak = .06*z+.45*x+.72*u+.85*v
        rows.append((i,x,z,z2,dose,weak,40+2.7*dose+1.4*x+error,40+2.7*weak+1.4*x+error))
    write(output,'encourage19','record x z z2 dose weak outcome weak_outcome',rows)
    rows = []
    for j in range(-120,121):
        r = j/24
        eligible = int(j>=0)
        receipt = int(rng.random()<(.22+.53*eligible+.025*r))
        noise = rng.gauss(0,.9)
        base = 37+.6*r+.13*r**2+.45*eligible*r
        rows.append((j+121,r,eligible,receipt,base+3.8*eligible+noise,
                     base+4.1*receipt+noise,10+.20*r+rng.gauss(0,.6)))
    write(output,'threshold19','record running eligible receipt sharp fuzzy baseline',rows)


def selection(output):
    rng = Random(20051)
    rows = []
    for i in range(1,321):
        x = rng.gauss(0,1.4)
        rural = rng.randrange(2)
        p = 1/(1+exp(-(-.25+1.15*x+.65*rural)))
        treated = int(rng.random()<p)
        y = 32+3.1*x+2.1*rural+treated*(3.3+.9*x+.65*rural)+rng.gauss(0,2.5)
        rows.append((i,int(i%19!=0),(i-1)%4,x,rural,treated,y))
    write(output,'selection20','record eligible fold x rural treated outcome',rows)
    rows = []
    for t in range(12):
        base = 40+.92*t
        d1 = base-1.6+1.4*sin(.61*t)
        d2 = d1-.58*max(0,t-6)
        d1 += .58*max(0,t-6)
        d3 = base+3.5+1.2*cos(1.24*t)
        d4 = base+1.1+1.4*sin(1.37*t)
        d5 = base+4+1.5*cos(.73*t)
        d6 = base-3.8+1.7*sin(1.89*t)
        y = .45*(d1+d2)/2+.35*d3+.20*d4+.13*sin(2.5*t)
        y += 1.6+.65*(t-7) if t>=7 else 0
        rows.extend((j,t,y) for j,y in enumerate((y,d1,d2,d3,d4,d5,d6)))
    write(output,'places20','place period outcome',rows)


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=RAW)
    args = parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    for build in (trial,rollout,instruments,selection):
        build(args.output)
