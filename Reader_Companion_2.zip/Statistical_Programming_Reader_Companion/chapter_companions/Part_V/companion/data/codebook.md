# Part V synthetic data codebook

All nine CSVs are original synthetic teaching inputs. Score outcomes are measured in points. Blank survey fields indicate missing measurement. Other analysis fields are complete.

| CSV and grain | Variables and design conventions |
|:--|:--|
| villages17 by village | Village IDs 1–12, block 1 for villages 1–6 and block 2 for 7–12, and binary realised offer. |
| households17 by household | Village joins to the register. Eligible selects eight households per village. Baseline wave 0 precedes outcome wave 1. Baseline and admin are complete scores. Receipt and measured are binary. Survey is a score in [0,100] when measured. |
| allocations17 by draw | Columns z1–z12 are binary offers in village order. Each of the 400 unique vectors has three offers in each block. |
| rollout18 by unit and period | Period is 0–9. Cohort is the first adoption date, with 0 for never. Binary x is baseline capacity. In-scope selects 39 units. Outcome is the service score. |
| multipliers18 by draw | Each row gives one sign per municipality in columns u1–u39. Signs are shared across horizons within a draw. |
| encourage19 by record | Baseline x and binary encouragements z and z2 precede exposure. Dose and weak are continuous exposures paired with outcome and weak_outcome. |
| threshold19 by record | Running is the centred score, eligible is one at or above zero, and receipt is actual take-up. Sharp and fuzzy are separate outcomes. Baseline is predetermined. |
| selection20 by record | Eligible fixes scope. Fold is 0–3. X and rural are baseline covariates, treated is participation, and outcome is complete. |
| places20 by place and period | Place 0 is treated at period 7. Donors 1–6 have complete histories from 0–11. Donors 1 and 2 have identical pre-treatment outcomes. |

The rollout baseline is two periods before adoption with one period of anticipation. The risky comparison changes anticipation to zero. The threshold fits keep absolute scores strictly below bandwidths 1.25, 2.50 and 3.75 and use triangular weights. The trimmed observational sensitivity retains held-out propensities in [0.10,0.90]. The donor sensitivity excludes donor 4 and uses the same fitting periods and tie rule.
