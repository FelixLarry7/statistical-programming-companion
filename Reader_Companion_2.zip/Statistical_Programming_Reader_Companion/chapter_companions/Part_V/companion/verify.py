"""Reproduce the Part V evaluations and verify the optional local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

from ledger import read


ROOT=Path(__file__).resolve().parent
RAW=ROOT/"data/raw"


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def run(args, log):
    with log.open("w") as stream:
        result=subprocess.run([str(arg) for arg in args],stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Engine returned {result.returncode}. See {log}.")


def stata_evidence(path,out):
    out.mkdir()
    with ZipFile(path) as z:
        if len(z.namelist())!=len(set(z.namelist())):
            raise ValueError("Duplicate member name in Stata evidence.")
        info=dict(line.split("=",1) for line in z.read("run_info.txt").decode().splitlines())
        if info["part5_rc"]!="0":
            raise ValueError(f"The local Stata run returned {info['part5_rc']}.")
        if info["stata_version"] not in {"16","17"}:
            raise ValueError("Expected a licensed Stata 16 or 17 run.")
        driver=z.read("part5_driver.do")
        if driver!=(ROOT/"stata/part5_driver.do").read_bytes():
            raise ValueError("The executed Stata driver differs from the shipped driver.")
        for p in sorted(RAW.glob("*.csv")):
            if p.read_bytes()!=z.read("input_"+p.name):
                raise ValueError(f"The Stata input differs: {p.name}.")
        log=z.read("part5_run.log").decode("utf-8",errors="replace")
        if "Part V generated in Stata" not in log:
            raise ValueError("Stata completion line is missing.")
        lines=[]
        for line in log.splitlines():
            if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)",line):
                lines.append("[Local path removed]")
            elif not (line.startswith("> ") and lines and lines[-1]=="[Local path removed]"):
                lines.append(line)
        (out/"part5_run.log").write_text("\n".join(lines)+"\n")
        for file in ("metrics.csv","run_info.txt","part5_driver.do"):
            (out/file).write_bytes(z.read(file))
    report=dict(info,original_archive_sha256=digest(path.read_bytes()),driver_sha256=digest(driver))
    (out/"environment.json").write_text(json.dumps(report,indent=2)+"\n")
    with ZipFile(out/"evidence_replay.zip","w",ZIP_DEFLATED) as z:
        for name in ("metrics.csv","run_info.txt","part5_driver.do","part5_run.log"):
            z.write(out/name,name)
        for p in sorted(RAW.glob("*.csv")):
            z.write(p,"input_"+p.name)
    return report


def anchors():
    counts = {3:(8,2.30,.95),5:(10,3.84,.45),7:(12,1.70,.30)}
    r = {
        ('CH17','trial','scalar','roster'):108,
        ('CH17','trial','scalar','n'):96,
        ('CH17','trial','scalar','villages'):12,
        ('CH17','trial','scalar','treated_villages'):6,
        ('CH17','trial','scalar','permutations'):math.comb(6,3)**2,
        ('CH17','trial','scalar','design_effect'):1+7*.1,
        ('CH17','trial','scalar','response_itt'):(33-45)/48,
        ('CH17','trial','scalar','itt'):(2338-2083)/48,
        ('CH18','notyet','control_n','3/3'):31,
        ('CH18','notyet','control_n','3/4'):21,
        ('CH18','never','control_n','3/4'):9,
        ('CH18','notyet','event_n','0'):30,
        ('CH18','notyet','event_n','3'):18,
        ('CH18','notyet','event_n','6'):8,
        ('CH18','notyet','event_att','-3'):0,
        ('CH18','notyet','event_att','-1'):(8*.5+10*.9+12*1.3)/30,
        ('CH19','strong','scalar','n'):240,
        ('CH19','rd','left_n','250'):59,
        ('CH19','rd','right_n','250'):60,
        ('CH19','rd','kernel','121'):1,
        ('CH20','full','scalar','n'):320-320//19,
        ('CH20','scm','scalar','weight_sum'):1,
        ('CH20','exclude4','weight','4'):0,
    }
    for k in range(3):
        r['CH18','notyet','event_att',str(k)] = sum(n*(a+b*k) for n,a,b in counts.values())/30
    return r


def tolerance(key, ref):
    _,_,q,k = key
    exact = {'target_n','control_n','event_n','support','left_n','right_n','arm_n','arm_measured'}
    count = {'n','roster','villages','treated_villages','permutations','extreme','treated'}
    if q in exact or (q=='scalar' and k in count):
        return 0.
    return 3e-8+3e-8*abs(ref)


def audit(out, with_stata):
    base = read(out/'python/metrics.csv')
    if len(base) != 3376:
        raise ValueError('Unexpected reference key count.')
    engines = ['anchor','r','duckdb']+(['stata'] if with_stata else [])
    comparisons = []
    for e in engines:
        values = anchors() if e=='anchor' else read(out/e/'metrics.csv')
        if e in ('r','stata') and values.keys()!=base.keys():
            raise ValueError(f'{e}: non-matching keys, missing {sorted(base.keys()-values.keys())[:5]}, '
                             f'extra {sorted(values.keys()-base.keys())[:5]}')
        if e=='duckdb' and len(values)!=2736:
            raise ValueError('Unexpected DuckDB key count.')
        for key,v in sorted(values.items()):
            ref = base[key]
            gap = abs(v-ref)
            tol = tolerance(key,ref)
            comparisons.append((e,*key,v,ref,gap,tol,gap<=tol))
    with (out/'comparisons.csv').open('w',newline='') as stream:
        writer = csv.writer(stream,lineterminator='\n')
        writer.writerow(('engine','chapter','model','quantity','key','value','python','abs_error','tolerance','passed'))
        writer.writerows(comparisons)
    failed = [r for r in comparisons if not r[-1]]
    if failed:
        raise ValueError(f'{len(failed)} failed comparisons: {failed[:6]}')
    return dict(Counter(r[0] for r in comparisons)),dict(Counter(r[1] for r in comparisons))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--rscript',default='Rscript')
    p.add_argument('--stata-evidence',type=Path)
    p.add_argument('--require-four',action='store_true')
    a = p.parse_args()
    if a.require_four and a.stata_evidence is None:
        p.error('Provide the local Stata evidence ZIP.')
    out = a.output.resolve()
    if out.exists() and any(out.iterdir()):
        p.error('Choose a new or empty output directory.')
    for engine in ('python','r','duckdb'):
        (out/engine).mkdir(parents=True,exist_ok=True)
    run([sys.executable,ROOT/'fit_python.py',RAW,out/'python'],out/'python/environment.txt')
    run([a.rscript,'--vanilla',ROOT/'fit_r.R',RAW,out/'r'],out/'r/environment.txt')
    run([sys.executable,ROOT/'fit_sql.py',RAW,out/'python/metrics.csv',out/'duckdb'],out/'duckdb/environment.txt')
    stata = stata_evidence(a.stata_evidence,out/'stata') if a.stata_evidence else None
    counts, chapters = audit(out,bool(stata))
    run([sys.executable,ROOT/'teaching_diagnostics.py',RAW,out/'duckdb',out/'diagnostics'],out/'diagnostics.log')
    report = {
        'status':'VERIFIED' if stata else 'STATA EVIDENCE PENDING',
        'comparisons':sum(counts.values()),'failures':0,
        'comparisons_by_engine':counts,'comparisons_by_chapter':chapters,
        'duckdb_scope':('Eligible rows, blocked allocations, cohort-time and event-time effects, '
                        'IV contrasts, GMM moments, RD jumps, held-out predictions, '
                        'weights and scores, and donor paths at shared fitted weights.'),
        'input_sha256':{f.name:digest(f.read_bytes()) for f in sorted(RAW.glob('*.csv'))},
        'stata':stata,
    }
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],report['comparisons'],counts,chapters)


if __name__=='__main__':
    main()
