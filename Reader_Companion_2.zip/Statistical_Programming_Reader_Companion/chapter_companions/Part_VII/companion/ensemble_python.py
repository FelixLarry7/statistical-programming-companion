"""Native scikit-learn tree fits with a fixed validation and tree budget."""

import argparse
from pathlib import Path

import pandas as pd
import sklearn
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier

from fit_python import CREDIT, design, fit_scaler, log_losses, write_frame


TREES = 64
DEPTHS = (1, 2)


def train(model, depth, x, d, split):
    common = dict(n_estimators=TREES, max_depth=depth, min_samples_leaf=16,
                  random_state=26000+split)
    if model == "py_forest":
        fit = RandomForestClassifier(**common, max_features="sqrt", n_jobs=1)
    else:
        fit = GradientBoostingClassifier(**common, loss="log_loss", learning_rate=0.06)
    return fit.fit(x, d.outcome, sample_weight=d.weight)


def run(data, out):
    d = pd.read_csv(data / "credit26.csv")
    dev = d[(d.fold != 0) & (d.outcome != -1)]
    test = d[d.fold == 0]
    predictions = test[["borrower", "outcome"]].copy()
    records = []
    for model in ("py_forest", "py_boost"):
        loss = {depth: 0.0 for depth in DEPTHS}
        for split in (1, 2, 3):
            train_rows, valid = dev[dev.fold != split], dev[dev.fold == split]
            scaler = fit_scaler(train_rows[CREDIT].to_numpy())
            x = design(train_rows[CREDIT].to_numpy(), *scaler)[:, 1:]
            v = design(valid[CREDIT].to_numpy(), *scaler)[:, 1:]
            for depth in DEPTHS:
                fit = train(model, depth, x, train_rows, split)
                p = fit.predict_proba(v)[:, 1]
                total = log_losses(valid.outcome.to_numpy(), p).sum()
                loss[depth] += total
                records.append((model, split, depth, TREES, len(valid), total, 0))
        depth = min(DEPTHS, key=loss.get)
        for candidate in DEPTHS:
            records.append((model, 0, candidate, TREES, len(dev), loss[candidate], int(candidate == depth)))
        scaler = fit_scaler(dev[CREDIT].to_numpy())
        fit = train(model, depth, design(dev[CREDIT].to_numpy(), *scaler)[:, 1:], dev, 4)
        predictions[model] = fit.predict_proba(design(test[CREDIT].to_numpy(), *scaler)[:, 1:])[:, 1]
    out.mkdir(parents=True, exist_ok=True)
    write_frame(predictions, out / "ensemble_predictions.csv")
    write_frame(pd.DataFrame(records, columns=["model", "split", "depth", "trees", "n", "loss_sum", "chosen"]),
                out / "ensemble_tuning.csv")
    print(f"scikit-learn {sklearn.__version__}. Two candidates per family, {TREES} trees per fit.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("data", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    run(args.data, args.output)
