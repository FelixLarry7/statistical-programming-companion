# Part VII computational companion

## Reproduce the verified release

The reference run used Python 3.12, NumPy 2.3.5, pandas 2.2.3, scikit-learn
1.8.0, R 4.5.0, DuckDB 1.4.4 and licensed local Stata 17 IC for macOS.
Install the pinned Python dependencies in requirements.txt and make Rscript
available. The core R scripts use base R. The Stata driver uses built-in Mata
and targets Stata 16 or 17. Run the verifier from the companion directory with
a new output path.

~~~bash
python verify.py --output replay \
  --require-four --stata-evidence evidence/stata/evidence_replay.zip
python teaching_diagnostics.py data replay replay/diagnostics
~~~

The verifier checks the driver and each frozen input byte for byte against the
Stata archive. It checks the completion line, exit code and complete
observation-key set before comparing values. To produce fresh Stata evidence,
follow stata/LOCAL_RUN.md with the supplied local-run kit and pass its
resulting ZIP to the verifier. Without a Stata evidence argument, the Python,
R and DuckDB rerun is available and its report marks licensed execution as
pending. The evidence replay archive reproduces the comparison of the
recorded local execution with the current public runtimes.

## Verification scope

| Engine or anchor | Comparisons | Quantities |
| :-- | --: | :-- |
| R | 5,042 | Independent ridge fits, frozen diagnostics, shared and plain causal scores, and common metrics |
| Stata | 5,042 | Independent Stata/Mata calculation on the matching inputs |
| DuckDB | 2,045 | Split and transformation checks, scoring, paired bootstrap, calibration, group rates, shared causal scores and balance |
| Anchors | 20 | Independent count and scalar design checks |
| Total | 12,149 | All passed |

The numerical tolerance is 2e-8 plus 2e-8 times the absolute reference value.
Exact count and category checks use zero tolerance. The comparison ledger
contains each key, value, difference and disposition. The R and Python
ensemble scripts also rerun their own fits and reconcile their own predictions
to the frozen artifacts. Ensemble trees and stochastic fits can differ across
implementations. The common metrics use the same labelled holdout borrowers,
feature definitions and declared candidate budget.

The auxiliary Python diagnostics include a paired credit-loss bootstrap,
permutation importance, partial dependence, a local log-odds decomposition,
a logistic calibration fit, a distance-shift scenario and a fixed-policy
comparison. The main ledger verifies the specified calibration, threshold and
causal calculations. These auxiliary diagnostics are separately reproducible.

## Frozen data and optional exercises

See data_dictionary.md for schemas and generation commands. Preserve the
distributed input files when verifying. Use a new data directory when
regenerating the synthetic inputs or fitting an alternative scenario.
Generated files use stable IDs and documented ordering.

The optional causal forest interoperability script uses the R grf package.
With grf installed, run the following command to export fold 4 predictions
with effect estimates and standard errors.

~~~bash
Rscript causal_forest.R data forest_output
~~~

The supplementary example was executed with grf 2.6.1 under R 4.5.0.
The evidence/optional_forest directory contains its 300 keyed predictions,
runtime record and prediction-band checks. This is separate from the 12,149
four-environment comparisons. Use forest_audit.py with the programme data,
core Python metric ledger, forest prediction file and an output directory
to regenerate its interoperation summary.
