"""Generate explanation and monitoring exhibits from the frozen fits."""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from fit_python import CREDIT, design, fit_ridge, fit_scaler, log_losses, sigmoid, write_frame
from ledger import read


def explain(data, evidence, out):
    d = pd.read_csv(data / "credit26.csv")
    pred = pd.read_csv(data / "credit_predictions.csv")
    joined = d.merge(pred, on=["borrower","outcome","audit_group"], validate="one_to_one")
    assert len(joined) == 240 and (joined.fold == 0).all()
    metric = read(evidence / "python/metrics.csv")

    def value(quantity, key):
        return metric["CH26", "ridge", quantity, key]

    scaler = tuple(np.array([value(k, c) for c in CREDIT]) for k in ("median","centre","scale"))
    b = np.array([value("beta", name) for name in ["intercept", *CREDIT]])

    def predict(raw):
        return sigmoid(design(raw, *scaler) @ b)

    assert np.allclose(predict(joined[CREDIT].to_numpy()), joined.ridge, atol=2e-12, rtol=2e-12)
    labelled = joined[joined.outcome != -1]
    raw, y = labelled[CREDIT].to_numpy(), labelled.outcome.to_numpy()
    p = predict(raw)
    base = log_losses(y,p).mean()
    rng = np.random.default_rng(27051)
    groups = labelled.audit_group.to_numpy()
    draw_rows = []
    for scheme in ("marginal", "within_group"):
        for j, field in enumerate(CREDIT):
            for draw in range(1, 51):
                altered = raw.copy()
                if scheme == "marginal":
                    altered[:,j] = raw[rng.permutation(len(raw)), j]
                else:
                    for group in np.unique(groups):
                        ix = np.flatnonzero(groups == group)
                        altered[ix,j] = raw[rng.permutation(ix), j]
                loss = log_losses(y, predict(altered)).mean()
                draw_rows.append((scheme,field,draw,loss-base))
    rows = pd.DataFrame(draw_rows, columns=["scheme","feature","draw","delta_logloss"])
    write_frame(rows,out/"importance_draws.csv")
    summary = rows.groupby(["scheme","feature"]).delta_logloss.agg(["mean","std"]).reset_index()
    write_frame(summary,out/"importance.csv")
    pd_rows = []
    for group in (0,1,2):
        ref = raw.copy() if group == 0 else raw[groups == group].copy()
        for u in np.linspace(0.1,0.9,9):
            ref[:,0] = u
            pd_rows.append((group,len(ref),u,predict(ref).mean()))
    write_frame(pd.DataFrame(pd_rows,columns=["group","n","utilisation","mean_p"]),out/"partial_dependence.csv")
    profile = np.array([[0.75,0.8,1,42,0.47,0]])
    contrib = design(profile,*scaler)[0]*b
    write_frame(pd.DataFrame({"term":["intercept",*CREDIT],"contribution":contrib}),
                out/"local_logit.csv")
    logits = np.column_stack((np.ones(len(p)), np.log(p/(1-p))))
    cal = fit_ridge(logits,y,np.ones(len(y)),0)
    write_frame(pd.DataFrame([{"intercept":cal[0],"slope":cal[1],
                               "profile_probability":sigmoid(contrib.sum())}]),out/"calibration_fit.csv")


def monitor(data, out):
    d = pd.read_csv(data/"programme28.csv")
    train, held = d[d.fold != 4], d[d.fold == 4]

    def covariates(frame):
        return np.column_stack((frame[["rural","need","distance","baseline"]].to_numpy(),
                                frame.need**2,frame.need*frame.rural))

    scaler = fit_scaler(covariates(train))
    x = design(covariates(train), *scaler)
    b = fit_ridge(x, train.treated.to_numpy(), np.ones(len(train)), 0.008)
    snapshots = []
    for name, s in (("reference",held),("shifted_distance",held.assign(distance=held.distance+0.60))):
        e = sigmoid(design(covariates(s), *scaler) @ b)
        snapshots.append((name,len(s),s.distance.mean(),e.mean(),np.sum((e<0.1)|(e>0.9))))
    write_frame(pd.DataFrame(snapshots,columns=["snapshot","n","mean_distance","mean_e","outside_band"]),
                out/"monitoring.csv")



def paired_credit(data, out):
    ridge = pd.read_csv(data/"credit_predictions.csv")
    ens = pd.read_csv(data/"ensemble26.csv")
    d = ridge.merge(ens,on=["borrower","outcome"],validate="one_to_one")
    d = d[d.outcome != -1]
    y = d.outcome.to_numpy()
    base = log_losses(y,d.ridge.to_numpy())
    rng = np.random.default_rng(26077)
    index = rng.integers(0,len(d),size=(2000,len(d)))
    values = []
    for col in ("py_forest","py_boost","r_forest","r_boost","class2"):
        delta = log_losses(y,d[col].to_numpy())-base
        lo,hi = np.quantile(delta[index].mean(axis=1),[.025,.975])
        values.append((col,len(delta),delta.mean(),lo,hi))
    write_frame(pd.DataFrame(values,columns=["model","n","logloss_delta","lo","hi"]),out/"paired_credit.csv")


def policy(data, out):
    d = pd.read_csv(data/"programme28.csv").merge(pd.read_csv(data/"nuisance28.csv"),
        on=["person","fold"],validate="one_to_one")
    score = d.m1-d.m0 + d.treated*(d.outcome-d.m1)/d.e - (1-d.treated)*(d.outcome-d.m0)/(1-d.e)
    net = score-1.40
    rows = []
    for name,mask in (("none",np.zeros(len(d))),("all",np.ones(len(d))),("rural",d.rural.to_numpy())):
        gain = mask*net
        rows.append((name,mask.mean(),gain.mean(),gain.std(ddof=1)/np.sqrt(len(gain))))
    comparison=(d.rural.to_numpy()-1)*net
    rows.append(("rural_minus_all",d.rural.mean()-1,comparison.mean(),
                 comparison.std(ddof=1)/np.sqrt(len(comparison))))
    write_frame(pd.DataFrame(rows,columns=["rule","share_treated","net_gain","se"]),out/"policy.csv")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("data",type=Path)
    p.add_argument("evidence",type=Path)
    p.add_argument("output",type=Path)
    args = p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    explain(args.data,args.evidence,args.output)
    monitor(args.data,args.output)
    paired_credit(args.data,args.output)
    policy(args.data,args.output)
