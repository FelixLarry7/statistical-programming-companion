# Data dictionary and provenance

All Part VII datasets are original synthetic teaching fixtures. No external
customer, credit or programme microdata enter the analysis. Seeds, variables
and generation rules are in prepare_inputs.py. The input checksums are in
evidence/verification.json.

| File | Key | Contents |
| :-- | :-- | :-- |
| customers25.csv | row_id; customer and month | Four cohorts with 120 customers each and twelve snapshots per customer |
| splits25.csv | split, row_id | Frozen role 1 for fit and role 2 for evaluation |
| bootstrap25.csv | draw, customer | Nonzero multiplicities in 400 paired resamples of 120 final-holdout customers |
| credit26.csv | borrower | 960 labelled or unlabelled synthetic borrowers, four folds and case weights |
| credit_predictions.csv | borrower | 240 holdout borrowers, audit group, label status and both ridge probabilities |
| ensemble26.csv | borrower | The same 240 IDs and four frozen ensemble probabilities |
| programme28.csv | person | 1,200 people, treatment, pre-treatment features, outcome and simulated individual effect |
| nuisance28.csv | person, fold | Frozen out-of-fold propensity and outcome means |

## Customer prediction

Months and label release times are integer indices. The outcome is a lapse
indicator. The main features are tenure in months, spending in synthetic
currency units, earlier contact count and a unitless decline index. Missing
contact counts are blank. Future is a deliberately inadmissible post-window
status available at future_month. The final holdout uses cohort 0 in months
11–12. Development holds out cohorts 1–3 at origins 7, 8 and 9.

## Credit risk and audit

Outcome values are 0 for no event, 1 for an event and −1 for an unobserved
label. Fold 0 is the holdout and folds 1–3 are development. Audit groups
1, 2 and 3 correspond to A, B and C and do not enter the predictor matrix.
The six predictors are utilisation and obligation proportions, volatility
index, late-payment count, history length in months and thin-file indicator.
Missing history is blank. Case weights affect training. Held-out scoring
weights each observed label equally. The audit keeps unobserved labels in
the coverage record and uses full-precision scores at cutoffs.

## Causal analysis

Fold IDs run from 1 through 4. Rural and treated are binary indicators.
Need, distance and baseline are synthetic pre-treatment indices. Outcome
and true_effect use synthetic index points. True_effect is used only as
a simulation benchmark. The nuisance file contains e, m0 and m1, estimated
for the held-out person using the other folds.

## Regenerate into a separate directory

Run from the companion folder using the pinned Python environment and Rscript.

~~~bash
python prepare_inputs.py --output regenerated
python fit_python.py regenerated generated_metrics --freeze
python ensemble_python.py regenerated generated_ensembles/python
Rscript --vanilla ensemble_r.R regenerated generated_ensembles/r
~~~

The first Python fit creates both shared prediction files. For an exact
ensemble-input reconstruction, join the two ensemble exports on borrower
and outcome, with Python model columns followed by R model columns, and
write ensemble26.csv with the shared write_frame helper. Compare results
within the declared tolerance. Use the distributed CSVs for the licensed
evidence check, which requires byte-identical inputs.
