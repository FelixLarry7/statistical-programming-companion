"""Regenerate the synthetic Part VII inputs with fixed seeds and key order."""

import argparse
from collections import Counter
import csv
import math
from pathlib import Path
from random import Random


def write(path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields.split())
        writer.writerows(rows)


def logistic(x):
    return 1 / (1 + math.exp(-x))


def customers(folder):
    rng = Random(25311)
    rows, memberships = [], []
    for customer in range(1, 481):
        cohort = (customer - 1) % 4
        risk = rng.gauss(0, 0.7)
        base = rng.gauss(0, 1)
        for month in range(1, 13):
            row = 12 * (customer - 1) + month
            tenure = 4 + (customer % 31) + month
            spend = max(5, 46 + 12 * base + 0.7 * month + rng.gauss(0, 9))
            contact = sum(rng.random() < logistic(-0.9 + risk) for _ in range(6))
            decline = rng.gauss(0, 1) + 0.35 * risk + 0.035 * month
            eta = -1.85 + 0.33 * contact + 0.76 * decline + 0.48 * risk
            eta += -0.012 * (spend - 46) - 0.023 * (tenure - 20) + 0.047 * month
            outcome = int(rng.random() < logistic(eta))
            future = int(rng.random() < (0.92 if outcome else 0.06))
            contact = None if rng.random() < 0.07 else contact
            rows.append((row, customer, cohort, month, month + 1, outcome, tenure,
                         round(spend, 8), contact, round(decline, 8), future, month + 1))
            for split in range(1, 5):
                held = split if split < 4 else 0
                start = 6 + split if split < 4 else 11
                if cohort == held and start <= month <= start + 1:
                    memberships.append((split, row, 2))
                elif cohort not in (0, held) and month + 1 <= start:
                    memberships.append((split, row, 1))
    write(folder / "customers25.csv",
          "row_id customer cohort month label_month outcome tenure spend contacts decline future future_month", rows)
    write(folder / "splits25.csv", "split row_id role", sorted(memberships))
    held = list(range(1, 481, 4))
    rng = Random(25918)
    boot = [(draw, customer, times)
            for draw in range(1, 401)
            for customer, times in sorted(Counter(rng.choices(held, k=len(held))).items())]
    write(folder / "bootstrap25.csv", "draw customer multiplicity", boot)


def credit(folder):
    rng = Random(26529)
    rows = []
    for borrower in range(1, 961):
        fold = (borrower - 1) % 4
        u = rng.random()
        group = 3 if u < 0.072 else 2 if u < 0.45 else 1
        thin = int(rng.random() < (0.28, 0.47, 0.55)[group - 1])
        utilisation = logistic(rng.gauss(-0.23 + 0.40 * (group == 2), 1.21))
        volatility = abs(rng.gauss(0.4 + 0.3 * thin, 0.47))
        late = sum(rng.random() < logistic(-2.08 + utilisation * 1.85) for _ in range(4))
        history = max(3, 60 - 24 * thin + rng.gauss(0, 17))
        ratio = max(0.04, rng.gauss(0.35 + 0.13 * utilisation, 0.15))
        eta = (-3.55 + 2.55 * utilisation + 0.58 * volatility + 0.44 * late
               - 0.011 * history + 0.29 * thin + 0.75 * (ratio > 0.55 and utilisation > 0.65))
        outcome = int(rng.random() < logistic(eta))
        if rng.random() < (0.035, 0.11, 0.14)[group - 1]:
            outcome = -1
        if rng.random() < 0.095:
            history = None
        weight = 1 + 0.5 * (borrower % 5 == 0) + 0.25 * thin
        rows.append((borrower, fold, group, outcome, weight, round(utilisation, 8),
                     round(volatility, 8), late, None if history is None else round(history, 8),
                     round(ratio, 8), thin))
    write(folder / "credit26.csv",
          "borrower fold audit_group outcome weight utilisation volatility late history ratio thin", rows)


def programme(folder):
    rng = Random(28273)
    rows = []
    for person in range(1, 1201):
        fold = (person - 1) % 4 + 1
        rural = int(rng.random() < 0.47)
        need = rng.gauss(0.25 * rural, 0.9)
        distance = rng.gauss(0.52 * rural, 0.77)
        baseline = rng.gauss(-0.32 * need - 0.25 * rural, 0.95)
        propensity = logistic(-0.28 + 0.83 * need - 0.66 * distance + 0.48 * rural
                              + 0.18 * baseline - 0.19 * need**2)
        treated = int(rng.random() < propensity)
        mu = 12 + 1.35 * baseline - 1.48 * need - 0.67 * distance - 0.8 * rural + 0.35 * need**2
        effect = 1.35 + 0.55 * need + 0.80 * rural
        outcome = mu + treated * effect + rng.gauss(0, 1.40)
        rows.append((person, fold, rural, round(need, 9), round(distance, 9),
                     round(baseline, 9), treated, round(outcome, 9), round(effect, 9)))
    write(folder / "programme28.csv",
          "person fold rural need distance baseline treated outcome true_effect", rows)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "data")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    customers(args.output)
    credit(args.output)
    programme(args.output)
