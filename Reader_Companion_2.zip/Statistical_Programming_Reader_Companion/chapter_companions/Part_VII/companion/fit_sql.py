"""Run DuckDB checks and export the quantities calculated in SQL."""

import argparse
from pathlib import Path

import duckdb

from ledger import Ledger


def run(data, predictions, output):
    db = duckdb.connect()
    for file in sorted(data.glob("*.csv")):
        db.read_csv(str(file)).create_view(file.stem)
    db.read_csv(str(predictions)).create_view("python_metrics")
    db.execute((Path(__file__).parent / "sql/labs.sql").read_text())

    def fetch(sql):
        return db.execute(sql).fetchall()

    def empty(sql):
        if fetch(sql):
            raise ValueError(f"Failed SQL validation: {sql}")

    empty("SELECT row_id FROM customers25 GROUP BY row_id HAVING count(*)<>1")
    empty("SELECT customer,month FROM customers25 GROUP BY ALL HAVING count(*)<>1")
    empty("SELECT split,row_id FROM splits25 GROUP BY ALL HAVING count(*)<>1")
    empty("""(SELECT split,row_id,role FROM customer_roles EXCEPT SELECT * FROM splits25)
          UNION ALL (SELECT * FROM splits25 EXCEPT SELECT split,row_id,role FROM customer_roles)""")
    empty("""SELECT split,customer FROM customer_roles GROUP BY ALL
             HAVING min(role)<>max(role)""")
    empty("SELECT borrower FROM credit26 GROUP BY borrower HAVING count(*)<>1")
    empty("SELECT borrower FROM credit_predictions GROUP BY borrower HAVING count(*)<>1")
    empty("""SELECT c.borrower FROM credit26 c FULL JOIN credit_predictions p USING (borrower)
             WHERE (c.fold=0 AND p.borrower IS NULL) OR
             (p.borrower IS NOT NULL AND (c.fold IS DISTINCT FROM 0
              OR c.outcome IS DISTINCT FROM p.outcome OR c.audit_group IS DISTINCT FROM p.audit_group))""")
    empty("""(SELECT borrower,outcome FROM ensemble26 EXCEPT SELECT borrower,outcome FROM credit_predictions)
          UNION ALL (SELECT borrower,outcome FROM credit_predictions EXCEPT SELECT borrower,outcome FROM ensemble26)""")
    empty("SELECT id FROM scoring_rows WHERE p IS NULL OR p<0 OR p>1 OR y NOT IN (0,1)")
    empty("SELECT chapter,model,id FROM scoring_rows GROUP BY ALL HAVING count(*)<>1")
    empty("SELECT person FROM programme28 GROUP BY person HAVING count(*)<>1")
    empty("SELECT person FROM nuisance28 GROUP BY person HAVING count(*)<>1")
    empty("""SELECT person FROM programme28 FULL JOIN nuisance28 USING (person,fold)
             WHERE treated IS NULL OR e IS NULL OR m0 IS NULL OR m1 IS NULL OR NOT (e>0 AND e<1)""")
    empty("SELECT draw FROM bootstrap_values WHERE weight<>120")
    if fetch("SELECT count(*) FROM bootstrap_values") != [(400,)]:
        raise ValueError("The frozen bootstrap manifest did not produce 400 draws.")

    ledger = Ledger()
    for row in fetch("SELECT * FROM scores"):
        ch, model, *values = row
        ledger.model(ch, model).vector("scalar",
            ("n","events","prevalence","mean_p","brier","logloss","tp","fp","tn","fn","auc","ap"),values)
    for ch, model, feature, median, centre, scale in fetch("SELECT * FROM feature_statistics"):
        m = ledger.model(ch, model)
        for key, value in (("median",median),("centre",centre),("scale",scale)):
            m.add(key, feature, value)
    for row in fetch("SELECT * FROM customer_fit_counts JOIN customer_validation_counts USING (model)"):
        model, *values = row
        ledger.model("CH25", model).vector("scalar",
            ("n_train","n_train_id","last_label_month","train_rate",
             "n_test_id","first_test_month","future_violations"), values)
    m = ledger.model("CH25","holdout")
    for draw, value, _ in fetch("SELECT * FROM bootstrap_values"):
        m.add("bootstrap", draw, value)
    delta, low, high = fetch("""SELECT (SELECT avg(delta) FROM customer_delta),
                          quantile_cont(value,0.025),quantile_cont(value,0.975) FROM bootstrap_values""")[0]
    m.scalars(paired_delta=delta,paired_lo=low,paired_hi=high)
    for model, n, weight in fetch("SELECT * FROM credit_fit_counts"):
        ledger.model("CH26", model).scalars(n_train=n, weight_sum=weight)
    for k, n in fetch("SELECT fold,count(*) FROM credit26 WHERE fold<>0 AND outcome IN (0,1) GROUP BY fold"):
        ledger.model("CH26","tuning").add("validation_n",k,n)

    m = ledger.model("CH27", "audit")
    n_all, missing = fetch("SELECT count(*),count_if(outcome=-1) FROM credit_predictions")[0]
    ece = fetch("SELECT sum(bin_n*abs(bin_mean_p-bin_event_rate))/sum(bin_n) FROM calibration_bins")[0][0]
    m.scalars(n_all=n_all,missing_labels=missing,ece=ece)
    for bin_id, n, p, y in fetch("SELECT * FROM calibration_bins"):
        m.add("bin_n",bin_id,n)
        if n:
            m.add("bin_mean_p",bin_id,p)
            m.add("bin_event_rate",bin_id,y)
    for group, *values in fetch("SELECT * FROM group_coverage"):
        for key, val in zip(("n_all","n","events","non_events","missing","publish"),values,strict=True):
            m.add(key,group,val)
    for group, threshold, *values in fetch("SELECT * FROM group_thresholds"):
        columns = ("tp","fp","tn","fn","tpr","fpr","selection","tpr_lo","tpr_hi","fpr_lo","fpr_hi")
        for key, val in zip(columns,values,strict=True):
            m.add("group_"+key,f"{group}/{threshold}",val)

    m = ledger.model("CH28", "shared")
    for person, psi in fetch("SELECT person,psi FROM causal_scores"):
        m.add("score",person,psi)
    for sample, *values in fetch("SELECT * FROM causal_summaries"):
        for key,val in zip(("n","ate","se","lo","hi","truth"),values,strict=True):
            m.add(key,sample,val)
    for col, raw, ipw in fetch("SELECT * FROM causal_balance"):
        m.add("smd_raw",col,raw)
        m.add("smd_ipw",col,ipw)
    for fold, *values in fetch("""SELECT fold,count(*),(SELECT count(*) FROM causal_scores)-count(*),
                                  sum(treated),(SELECT sum(treated) FROM causal_scores)-sum(treated),avg(e)
                                  FROM causal_scores GROUP BY fold"""):
        for key,val in zip(("fold_n","fold_train","fold_treat","fold_train_treat","fold_mean_e"),values,strict=True):
            m.add(key,fold,val)
    values = fetch("""SELECT avg(outcome) FILTER (WHERE treated=1)-avg(outcome) FILTER (WHERE treated=0),
                      sum(treated),min(e),max(e),avg(e),
                      sum(w_t)^2/sum(w_t^2),sum(w_c)^2/sum(w_c^2) FROM causal_scores""")[0]
    m.vector("scalar",("naive","treated","e_min","e_max","e_mean","ess_t","ess_c"),values)
    output.mkdir(parents=True,exist_ok=True)
    ledger.save(output / "metrics.csv")
    print(f"DuckDB {duckdb.__version__}. {len(ledger.rows)} keyed values.")


if __name__ == "__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data",type=Path)
    ap.add_argument("predictions",type=Path)
    ap.add_argument("output",type=Path)
    args=ap.parse_args()
    run(args.data,args.predictions,args.output)
