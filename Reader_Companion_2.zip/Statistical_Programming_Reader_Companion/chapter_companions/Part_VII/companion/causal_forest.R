# Optional exploratory interoperability route. The core verification runs without grf.
args <- commandArgs(trailingOnly=TRUE)
if (length(args)!=2L) stop("Usage: Rscript causal_forest.R DATA_DIR OUTPUT_DIR")
if (!requireNamespace("grf",quietly=TRUE)) stop("Install the grf package in your R library.")
d <- read.csv(file.path(args[1],"programme28.csv"))
stopifnot(!anyDuplicated(d$person),all(d$fold %in% 1:4))
train <- d$fold!=4
cols <- c("rural","need","distance","baseline")
x_train <- as.matrix(d[train,cols])
x_held <- as.matrix(d[!train,cols])
y_train <- d$outcome[train]
a_train <- d$treated[train]
forest <- grf::causal_forest(x_train,y_train,a_train,
    num.trees=2000,honesty=TRUE,num.threads=1,seed=28001)
pred <- predict(forest,x_held,estimate.variance=TRUE)
dir.create(args[2],recursive=TRUE,showWarnings=FALSE)
out <- data.frame(person=d$person[!train],fold=d$fold[!train],
                  effect=pred$predictions,se=sqrt(pmax(0,pred$variance.estimates)))
stopifnot(all(is.finite(out$effect)),all(is.finite(out$se)))
write.csv(out,file.path(args[2],"forest_holdout.csv"),row.names=FALSE)
writeLines(c(R.version.string,paste("grf",packageVersion("grf"))),
           file.path(args[2],"forest_environment.txt"))
