# Random-subspace bagged trees and Newton boosting, using base R.
argv <- commandArgs()
file_arg <- grep("^--file=", argv, value=TRUE)
script <- if (length(file_arg)) sub("^--file=", "", file_arg[1]) else argv[match("-f",argv)+1L]
stopifnot(length(script)==1, !is.na(script))
# R -f may encode spaces in its commandArgs() path.
if (!file.exists(script)) script <- gsub("~+~"," ",script,fixed=TRUE)
source(file.path(dirname(script),"fit_r.R"))
trees <- 64L

cutpoints <- function(x) lapply(seq_len(ncol(x)), function(j)
  unique(quantile(x[,j],c(0.2,0.4,0.6,0.8),names=FALSE,type=7)))

grow <- function(x, target, w, hessian, cuts, depth, random, rows) {
  total <- sum(w[rows])
  signal <- sum(w[rows]*target[rows])
  leaf <- list(value=signal/sum(w[rows]*hessian[rows]))
  if (!depth || length(rows)<32L) return(leaf)
  cols <- if (random) sample.int(ncol(x),floor(sqrt(ncol(x)))) else seq_len(ncol(x))
  parent <- signal^2 / total
  best <- 1e-12
  rule <- NULL
  for (j in cols) for (t in cuts[[j]]) {
    left <- x[rows,j] <= t
    if (sum(left)<16L || sum(!left)<16L) next
    wl <- sum(w[rows[left]])
    sy <- sum(w[rows[left]]*target[rows[left]])
    gain <- sy^2/wl + (signal-sy)^2/(total-wl) - parent
    if (gain>best) {
      best <- gain
      rule <- list(j=j,t=t,left=left)
    }
  }
  if (is.null(rule)) return(leaf)
  list(j=rule$j,t=rule$t,
       left=grow(x,target,w,hessian,cuts,depth-1L,random,rows[rule$left]),
       right=grow(x,target,w,hessian,cuts,depth-1L,random,rows[!rule$left]))
}

predict_tree <- function(tree,x) {
  if (!is.null(tree$value)) return(rep(tree$value,nrow(x)))
  left <- x[,tree$j] <= tree$t
  result <- numeric(nrow(x))
  result[left] <- predict_tree(tree$left,x[left,,drop=FALSE])
  result[!left] <- predict_tree(tree$right,x[!left,,drop=FALSE])
  result
}

ensemble <- function(name, depth, x, v, y, w, seed) {
  set.seed(seed)
  cuts <- cutpoints(x)
  rows <- seq_along(y)
  if (name=="r_forest") {
    fitted <- numeric(nrow(v))
    for (j in seq_len(trees)) {
      fit <- grow(x,y,w,rep(1,length(y)),cuts,depth,TRUE,sample(rows,replace=TRUE))
      fitted <- fitted+predict_tree(fit,v)/trees
    }
    return(fitted)
  }
  logit <- qlogis(weighted.mean(y,w))
  fitted <- rep(logit,length(y))
  test <- rep(logit,nrow(v))
  for (j in seq_len(trees)) {
    p <- sigmoid(fitted)
    fit <- grow(x,y-p,w,p*(1-p),cuts,depth,FALSE,rows)
    fitted <- fitted + 0.06*predict_tree(fit,x)
    test <- test + 0.06*predict_tree(fit,v)
  }
  sigmoid(test)
}

args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2)
d <- read.csv(file.path(args[1],"credit26.csv"))
dev <- d[d$fold!=0 & d$outcome!=-1,]
test <- d[d$fold==0,]
p <- test[c("borrower","outcome")]
tuning <- list()
for (name in c("r_forest","r_boost")) {
  loss <- numeric(2)
  for (k in 1:3) {
    train <- dev[dev$fold!=k,]
    val <- dev[dev$fold==k,]
    s <- fit_scaler(as.matrix(train[credit_columns]))
    x <- transform_x(as.matrix(train[credit_columns]),s)[,-1]
    v <- transform_x(as.matrix(val[credit_columns]),s)[,-1]
    for (depth in 1:2) {
      pred <- ensemble(name,depth,x,v,train$outcome,train$weight,26000+k)
      total <- sum(log_losses(val$outcome,pred))
      loss[depth] <- loss[depth]+total
      tuning[[length(tuning)+1L]] <- c(name,k,depth,trees,nrow(val),total,0)
    }
  }
  best <- which.min(loss)
  for (depth in 1:2)
    tuning[[length(tuning)+1L]] <- c(name,0,depth,trees,nrow(dev),loss[depth],as.integer(depth==best))
  s <- fit_scaler(as.matrix(dev[credit_columns]))
  x <- transform_x(as.matrix(dev[credit_columns]),s)[,-1]
  v <- transform_x(as.matrix(test[credit_columns]),s)[,-1]
  p[[name]] <- ensemble(name,best,x,v,dev$outcome,dev$weight,26004)
}
dir.create(args[2],showWarnings=FALSE,recursive=TRUE)
tuning <- as.data.frame(do.call(rbind,tuning))
names(tuning) <- c("model","split","depth","trees","n","loss_sum","chosen")
write.table(tuning,file.path(args[2],"ensemble_tuning.csv"),sep=",",quote=FALSE,row.names=FALSE)
write.table(p,file.path(args[2],"ensemble_predictions.csv"),sep=",",quote=FALSE,row.names=FALSE)
cat(R.version.string,"Two candidates per family,",trees,"trees per fit.\n")
