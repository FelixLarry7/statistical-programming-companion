"""Verify the causal-forest export and compare its prespecified prediction bands."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from fit_python import write_frame


def audit(data, metrics, predictions, output):
    d = pd.read_csv(data / "programme28.csv")
    held = d.loc[d.fold == 4, ["person", "fold", "true_effect"]]
    f = pd.read_csv(predictions)
    assert f[["person", "fold"]].equals(held[["person", "fold"]].reset_index(drop=True))
    assert len(f) == 300 and f.person.is_unique
    assert np.isfinite(f[["effect", "se"]]).all().all() and (f.se >= 0).all()
    m = pd.read_csv(metrics)
    match = (m.chapter == "CH28") & (m.model == "shared") & (m.quantity == "score")
    scores = m.loc[match, ["key", "value"]].rename(columns={"value": "shared_score"})
    scores["person"] = scores.pop("key").astype(int)
    x = held.merge(f, on=["person", "fold"], validate="one_to_one")
    x = x.merge(scores, on="person", validate="one_to_one")
    assert len(x) == len(f)
    x["band"] = np.where(x.effect < 1.75, "Below 1.75", "At least 1.75")
    rows = []
    for band in ("Below 1.75", "At least 1.75"):
        group = x[x.band == band]
        rows.append((band, len(group), group.effect.mean(),
                     group.shared_score.mean(), group.true_effect.mean()))
    result = pd.DataFrame(rows, columns=["prediction_band","n","mean_prediction",
                                         "mean_shared_score","mean_sample_truth"])
    output.mkdir(parents=True, exist_ok=True)
    write_frame(result, output / "forest_bands.csv")
    summary = {"held_out_people":len(f), "training_people":len(d)-len(f),
               "held_out_fold":4, "trees":2000, "seed":28001, "honesty":True,
               "mean_prediction":float(f.effect.mean()), "median_prediction_se":float(f.se.median()),
               "band_threshold":1.75}
    (output/"forest_audit.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(result.to_string(index=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data",type=Path)
    ap.add_argument("metrics",type=Path)
    ap.add_argument("predictions",type=Path)
    ap.add_argument("output",type=Path)
    args = ap.parse_args()
    audit(args.data,args.metrics,args.predictions,args.output)
