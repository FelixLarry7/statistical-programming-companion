# Part IV local Stata verification

Use the licensed Stata 16 or 17 installed on your computer. The kit uses
built-in Stata commands and requires no additional packages or network access.

1. Extract the ZIP into a fresh folder.
2. In Stata, set the working directory to the inner folder
   `Part_IV_Stata_Local_Run`, which contains `run_part4.do` and `inputs`.
3. Run `do run_part4.do`. Successful execution prints Part IV return code 0.
4. Upload the resulting `Stata_Verification_Part_IV_*.zip`. If Stata
   reports an error, upload the evidence ZIP containing the diagnostic log.

The evidence includes the exact input copies, executed driver, model metrics
and execution log. The wrapper performs the work in a separate Stata frame.
