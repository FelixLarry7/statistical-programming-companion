*! Run Part IV offline on a licensed Stata installation.
version 16.0
args folder
local starting `"`c(pwd)'"'
if `"`folder'"'!="" cd `"`folder'"'
local root `"`c(pwd)'"'
capture confirm file "inputs/pilot13.csv"
if _rc {
    display as error "Set the working directory to the extracted kit and run do run_part4.do."
    quietly cd `"`starting'"'
    exit 601
}
local stamp=subinstr(subinstr("`c(current_date)'_`c(current_time)'"," ","",.),":","",.)
local evidence `"`root'/stata_part4_`stamp'"'
mkdir `"`evidence'"'
cd `"`evidence'"'
mkdir "inputs"
local files : dir `"`root'/inputs"' files "*.csv"
foreach name of local files {
    copy `"`root'/inputs/`name'"' `"inputs/`name'"'
    copy `"inputs/`name'"' `"input_`name'"'
}
copy `"`root'/part4_driver.do"' "part4_driver.do"

tempname work record sessionlog
frame create `work'
local dp "`c(dp)'"
local more "`c(more)'"
local rng "`c(rng)'"
local state "`c(rngstate)'"
set dp period
set more off
log using "part4_run.log", text name(`sessionlog')
capture noisily frame `work': do "part4_driver.do" "inputs" "."
local rc=_rc
log close `sessionlog'
frame drop `work'
capture quietly set dp `dp'
capture quietly set rng `rng'
capture quietly set rngstate `state'
capture quietly set more `more'
foreach name in metrics.csv {
    capture confirm file "`name'"
    if _rc & `rc'==0 local rc=601
}

file open `record' using "run_info.txt", write text
file write `record' "stata_version=`c(stata_version)'" _n ///
    "edition=`c(flavor)'" _n "build_date=`c(born_date)'" _n "platform=`c(os)'" _n ///
    "run_date=`c(current_date)'" _n "run_time=`c(current_time)'" _n "part4_rc=`rc'" _n
file close `record'

local files : dir "." files "*"
local result `"`root'/Stata_Verification_Part_IV_`stamp'.zip"'
capture noisily zipfile `files', saving(`"`result'"')
local zipped=(_rc==0)
cd `"`starting'"'
display as result "Part IV return code `rc'."
if `zipped' {
    display as result `"Upload the evidence ZIP: `result'"'
}
else {
    display as result `"Compress and upload this evidence folder: `evidence'"'
}
