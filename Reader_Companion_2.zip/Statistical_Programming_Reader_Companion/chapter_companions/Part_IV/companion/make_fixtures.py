"""Regenerate the deterministic synthetic Part IV data files."""

import argparse
import csv
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
SEED = 16142026


def save(folder, name, header, rows):
    with (folder / f"{name}.csv").open("w", encoding="utf-8", newline="") as out:
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(header.split(","))
        writer.writerows(rows)


def make(folder):
    folder.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    pilot = []
    with (ROOT / "data/pilot_source/plots.csv").open() as f:
        plots = {row["plot_id"]: row for row in csv.DictReader(f)}
    with (ROOT / "data/pilot_source/season_records.csv").open() as f:
        for row in csv.DictReader(f):
            area = float(plots[row["plot_id"]]["area_m2"])/10000
            if int(row["season"]) != 2025 or row["sessions"] == "" or row["harvest_kg"] == "" or area <= 0:
                continue
            kg, sessions = float(row["harvest_kg"]), int(row["sessions"])
            if kg >= 0:
                pilot.append((row["plot_id"],int(row["season"]),area,kg,sessions,kg/area))
    save(folder,"pilot13","plot_id,season,area_ha,harvest_kg,sessions,yield_kg_ha",sorted(pilot))
    plots = []
    for i in range(36):
        x = 13 if i==35 else 5*i%9
        irr = int(i%4>=2)
        y = 1190+62*x+145*irr+rng.normal(0,20+4*x)+(340 if i==35 else 0)
        plots.append((f"M{i+1:03d}",x,irr,round(y,6)))
    save(folder,"regression13","plot_id,sessions,irrigated,yield_kg_ha",plots)

    delivery = []
    for i in range(240):
        contacts = int(rng.integers(0,7))
        rural = int(rng.random()<.47)
        p = 1/(1+np.exp(-(-.65+.34*contacts-.65*rural)))
        delivery.append((f"D{i+1:03d}",contacts,rural,int(rng.random()<p)))
    save(folder,"delivery14","case_id,contacts,rural,event",delivery)
    appointments = []
    for i in range(210):
        capacity = round(rng.normal(),6)
        rural = int(rng.random()<.49)
        days = int(rng.choice([15,21,30,45,60]))
        mu = days/30*np.exp(1+.28*capacity-.42*rural)
        count = int(rng.poisson(mu*rng.gamma(1/.55,.55)))
        appointments.append((f"A{i+1:03d}",capacity,rural,days,count))
    save(folder,"appointments14","count_id,capacity,rural,days,appointments",appointments)
    save(folder,"prediction14","scenario_id,contacts,rural,capacity,days",[
        (f"G{1+3*z+j:02d}",contacts,z,cap,days)
        for z in (0,1) for j,(contacts,cap,days) in enumerate([(0,-1,30),(3,0,30),(6,1,60)])
    ])

    censor = []
    for i in range(72):
        x = round(rng.uniform(-2,2),6)
        latent = .88+.94*x+rng.normal(0,1.25)
        censor.append((f"C{i+1:03d}",x,round(max(0,latent),6),int(latent<=0)))
    save(folder,"censor15","case_id,resources,expenditure,censored",censor)
    durations = []
    for i in range(100):
        risk = round(rng.normal(0,1),6)
        supported = int(rng.random()<.45)
        tf = rng.exponential(8/np.exp(.58*risk-.38*supported))
        tc = rng.uniform(1,12)
        durations.append((f"S{i+1:03d}",risk,supported,int(np.ceil(min(tf,tc))),int(tf<=tc)))
    save(folder,"duration15","person_id,risk,supported,duration,event",durations)

    facilities = []
    deviations = [-4.6,-3.5,-2.4,-1.2,-.6,.7,1.3,2.0,3.3,4.4]
    sizes = [3,4,5,6,7,8,4,5,6,7]
    for j,(deviation,size) in enumerate(zip(deviations,sizes),1):
        for i in range(1,9):
            x = round((i-3.5)/2+.1*(j%4-1.5),6)
            y = 22+1.35*x+deviation+rng.normal(0,.9)
            facilities.append((f"F{j:02d}P{i:02d}",f"F{j:02d}",x,round(y,6),int(i<=6),int(i<=size)))
    save(folder,"facilities16","patient_id,facility_id,baseline,outcome,balanced,unbalanced",facilities)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT/"data/raw")
    make(parser.parse_args().output)
