# Independent native R fits for Part IV. Usage: Rscript fit_r.R data/raw output.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L)
input <- args[1]
output <- args[2]
dir.create(output,recursive=TRUE,showWarnings=FALSE)
options(digits=17)
read <- function(name) read.csv(file.path(input,paste0(name,".csv")),stringsAsFactors=FALSE)
metrics <- list()
add <- function(chapter,model,quantity,key,value) {
    metrics[[length(metrics)+1L]] <<- data.frame(
        chapter=chapter,model=model,quantity=quantity,key=as.character(key),value=as.numeric(value))
}
scalars <- function(chapter,model,...) {
    values <- c(...)
    add(chapter,model,"scalar",names(values),values)
}
for (model in c("pilot","multiple")) {
    d <- read(if (model=="pilot") "pilot13" else "regression13")
    f <- if (model=="pilot") yield_kg_ha~sessions else yield_kg_ha~sessions+irrigated
    fit <- lm(f,data=d,na.action=na.fail,singular.ok=FALSE)
    x <- model.matrix(fit)
    n <- nrow(x)
    rss <- sum(residuals(fit)^2)
    df <- df.residual(fit)
    classical <- vcov(fit)
    bread <- classical/(rss/df)
    hc1 <- (n/df)*bread%*%crossprod(x*residuals(fit))%*%bread
    labels <- sub("(Intercept)","intercept",colnames(x),fixed=TRUE)
    scalars("CH13",model,n=n,rank=fit$rank,df=df,rss=rss,r2=summary(fit)$r.squared)
    add("CH13",model,"beta",labels,coef(fit))
    keys <- outer(labels,labels,paste,sep="/")
    add("CH13",model,"classical",as.vector(keys),as.vector(classical))
    add("CH13",model,"hc1",as.vector(keys),as.vector(hc1))
    add("CH13",model,"fit",d$plot_id,fitted(fit))
    add("CH13",model,"residual",d$plot_id,residuals(fit))
    add("CH13",model,"leverage",d$plot_id,hatvalues(fit))
    add("CH13",model,"cook",d$plot_id,cooks.distance(fit))
}
grid <- read("prediction14")
control <- glm.control(epsilon=1e-12,maxit=100)
for (model in c("logit","probit","poisson","nb2")) {
    binary <- model %in% c("logit","probit")
    if (binary) {
        d <- read("delivery14")
        fit <- glm(event~contacts+rural,data=d,
                   family=binomial(link=model),control=control,na.action=na.fail)
        field <- "contacts"
        ids <- d$case_id
        offset <- rep(0,nrow(d))
        off_grid <- rep(0,nrow(grid))
    } else {
        d <- read("appointments14")
        f <- appointments~capacity+rural+offset(log(days/30))
        fit <- if (model=="nb2") MASS::glm.nb(f,data=d,control=control,na.action=na.fail) else
            glm(f,data=d,family=poisson(),control=control,na.action=na.fail)
        field <- "capacity"
        ids <- d$count_id
        offset <- log(d$days/30)
        off_grid <- log(grid$days/30)
    }
    stopifnot(fit$converged, all(is.finite(coef(fit))))
    b <- unname(coef(fit))
    base <- b[1]+b[2]*d[[field]]+offset
    eta <- base+b[3]*d$rural
    inverse <- switch(model,logit=plogis,probit=pnorm,exp)
    mu <- inverse(eta)
    derivative <- switch(model,logit=mu*(1-mu),probit=dnorm(eta),mu)
    scalars("CH14",model,n=nobs(fit),ll=as.numeric(logLik(fit)))
    if (model=="nb2") scalars("CH14",model,alpha=1/fit$theta)
    add("CH14",model,"beta",c("intercept",field,"rural"),b)
    add("CH14",model,"eta",ids,eta)
    add("CH14",model,"mean",ids,mu)
    add("CH14",model,"ame",c(field,"rural"),c(b[2]*mean(derivative),mean(inverse(base+b[3])-inverse(base))))
    eta <- b[1]+b[2]*grid[[field]]+b[3]*grid$rural+off_grid
    add("CH14",model,"grid_eta",grid$scenario_id,eta)
    add("CH14",model,"grid_mean",grid$scenario_id,inverse(eta))
}

d <- read("censor15")
mean <- .9+.8*d$resources
a <- -mean/1.2
z <- (d$expenditure-mean)/1.2
mills <- exp(dnorm(a,log=TRUE)-pnorm(a,log.p=TRUE))
intercept <- ifelse(d$censored,-mills/1.2,z/1.2)
tobit <- list(ll=ifelse(d$censored,pnorm(a,log.p=TRUE),dnorm(z,log=TRUE)-log(1.2)),
              intercept=intercept,beta=d$resources*intercept,
              logsig=ifelse(d$censored,-a*mills,z*z-1))
for (item in names(tobit)) {
    v <- tobit[[item]]
    add("CH15","tobit_eval",item,c(d$case_id,"total"),c(v,sum(v)))
}

s <- read("duration15")
control <- survival::coxph.control(eps=1e-11,iter.max=60)
for (model in c("breslow","efron")) {
    fit <- survival::coxph(survival::Surv(duration,event)~risk+supported,data=s,
                            ties=model,control=control,na.action=na.fail,singular.ok=FALSE)
    scalars("CH15",model,n=fit$n,ll=as.numeric(logLik(fit)))
    add("CH15",model,"beta",c("risk","supported"),coef(fit))
    add("CH15",model,"eta",s$person_id,as.matrix(s[c("risk","supported")])%*%coef(fit))
}
write.csv(as.data.frame(survival::cox.zph(fit,transform="rank")$table),
          file.path(output,"proportional_hazards.csv"),row.names=TRUE)
point <- .30*s$risk-.25*s$supported
w <- exp(point)
surv <- 1
for (time in sort(unique(s$duration[s$event==1]))) {
    r <- s$duration>=time
    d <- s$duration==time & s$event==1
    events <- sum(d)
    surv <- surv*(1-events/sum(r))
    for (metric in c("risk","events","censored","km")) {
        value <- switch(metric,risk=sum(r),events=events,censored=sum(s$duration==time & s$event==0),km=surv)
        add("CH15","riskset",metric,time,value)
    }
    for (model in c("breslow","efron")) {
        frac <- if (model=="efron") (seq_len(events)-1)/events else 0*seq_len(events)
        add("CH15",model,"fixed_ll",time,sum(point[d])-sum(log(sum(w[r])-frac*sum(w[d]))))
    }
}

d <- read("facilities16")
for (model in c("balanced","unbalanced")) {
    a <- d[d[[model]]==1,]
    fit <- nlme::lme(outcome~baseline,random=~1|facility_id,data=a,method="ML",
                     na.action=na.fail,control=nlme::lmeControl(msMaxIter=200,msTol=1e-10))
    b <- nlme::fixef(fit)
    re <- nlme::ranef(fit)
    variances <- nlme::VarCorr(fit)
    scalars("CH16",model,n=nrow(a),groups=nrow(re),ll=as.numeric(logLik(fit)),
            tau2=as.numeric(variances[1,"Variance"]),sigma2=fit$sigma^2)
    add("CH16",model,"beta",c("intercept","baseline"),b)
    add("CH16",model,"effect",rownames(re),re[[1]])
    add("CH16",model,"fit",a$patient_id,b[1]+b[2]*a$baseline+re[[1]][match(a$facility_id,rownames(re))])
}
m <- do.call(rbind,metrics)
stopifnot(!anyDuplicated(m[1:4]),all(is.finite(m$value)))
write.table(m[order(m$chapter,m$model,m$quantity,m$key),],file.path(output,"metrics.csv"),
            sep=",",row.names=FALSE,quote=FALSE)
cat(R.version.string,"\nMASS",as.character(packageVersion("MASS")),
    "survival",as.character(packageVersion("survival")),"nlme",as.character(packageVersion("nlme")),
    "\n",nrow(m),"keyed values\n")
