"""Fit Part IV models using NumPy, SciPy, and statsmodels."""

import argparse
import csv
import json
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize
from scipy.special import expit, log_ndtr, ndtr
import statsmodels
import statsmodels.api as sm
from statsmodels.discrete.discrete_model import NegativeBinomial
from statsmodels.duration.hazard_regression import PHReg

from ledger import Ledger



def ols(raw, m, diag):
    for model, filename, terms in (
        ("pilot","pilot13",["sessions"]),
        ("multiple","regression13",["sessions","irrigated"]),
    ):
        d = pd.read_csv(raw/f"{filename}.csv")
        x = sm.add_constant(d[terms],has_constant="raise")
        y = d.yield_kg_ha
        fit = sm.OLS(y,x,missing="raise",hasconst=True).fit(method="qr")
        hc = fit.get_robustcov_results(cov_type="HC1")
        inf = fit.get_influence()
        names = ["intercept",*terms]
        put = m.model("CH13",model)
        put.scalars(n=fit.nobs,rank=fit.model.rank,df=fit.df_resid,rss=fit.ssr,r2=fit.rsquared)
        put.vector("beta",names,fit.params)
        for cov,matrix in (("classical",fit.cov_params()),("hc1",hc.cov_params())):
            put.matrix(cov,names,np.asarray(matrix))
        for q,vec in (("fit",fit.fittedvalues),("residual",fit.resid),
                      ("leverage",inf.hat_matrix_diag),("cook",inf.cooks_distance[0])):
            put.vector(q,d.plot_id,vec)
        A = np.asarray(fit.normalized_cov_params)
        qc = stats.t.ppf(.975,fit.df_resid)
        diag[model] = {
            "condition_x":float(np.linalg.cond(x)),
            "normal_equation_max_abs":float(np.max(np.abs(x.T@fit.resid))),
            "hat_trace":float(sum(inf.hat_matrix_diag)),
            "hc0_slope_se":float(fit.get_robustcov_results(cov_type="HC0").bse[1]),
            "hc1_slope_se":float(hc.bse[1]),
            "hc1_slope_95ci":[float(fit.params.iloc[1]-qc*hc.bse[1]),
                             float(fit.params.iloc[1]+qc*hc.bse[1])],
            "no_intercept_session_slope":float(sm.OLS(y,d[terms]).fit().params["sessions"]),
            "bread":A.tolist(),
        }
        if model=="multiple":
            keep=d.plot_id!="M036"
            leave=sm.OLS(y[keep],x[keep]).fit()
            diag[model]["omit_M036_sessions"]=float(leave.params["sessions"])
            diag[model]["max_cook_id"]=str(d.plot_id.iloc[np.argmax(inf.cooks_distance[0])])
            diag[model]["exact_alias_rank"]=int(np.linalg.matrix_rank(np.column_stack((x,2*d.sessions))))
            profile=np.array([1,6,1])
            diag[model]["unadjusted_sessions"]=float(sm.OLS(y,x[["const","sessions"]]).fit().params["sessions"])
            diag[model]["six_session_irrigated"]={
                "fitted":float(profile@fit.params),
                "classical_mean_se":float(np.sqrt(profile@fit.cov_params()@profile)),
                "hc1_mean_se":float(np.sqrt(profile@hc.cov_params()@profile)),
                "classical_new_plot_se":float(np.sqrt(profile@fit.cov_params()@profile+fit.mse_resid)),
            }


def glm(raw, m, diag):
    grid=pd.read_csv(raw/"prediction14.csv")
    for model in ("logit","probit","poisson","nb2"):
        binary=model in {"logit","probit"}
        d=pd.read_csv(raw/("delivery14.csv" if binary else "appointments14.csv"))
        field,idcol,ycol=("contacts","case_id","event") if binary else ("capacity","count_id","appointments")
        x=sm.add_constant(d[[field,"rural"]],has_constant="raise")
        offset=np.zeros(len(d)) if binary else np.log(d.days.to_numpy()/30)
        if model=="nb2":
            fit=NegativeBinomial(d[ycol],x,offset=offset,loglike_method="nb2").fit(
                method="newton",maxiter=200,tol=1e-11,disp=False)
            if not fit.mle_retvals["converged"] or fit.params["alpha"]<=0:
                raise ValueError("NB2 optimisation failed.")
        else:
            family=(sm.families.Binomial(link=sm.families.links.Probit()) if model=="probit"
                    else sm.families.Binomial() if model=="logit" else sm.families.Poisson())
            fit=sm.GLM(d[ycol],x,offset=offset,family=family,missing="raise").fit(maxiter=100,tol=1e-11)
            if not fit.converged:
                raise ValueError(f"{model}: optimisation failed.")
        b=np.asarray(fit.params)[:3]
        eta=x@b+offset
        eta0=b[0]+d[field]*b[1]+offset
        inverse={"logit":expit,"probit":ndtr,"poisson":np.exp,"nb2":np.exp}[model]
        mu=inverse(eta)
        derivative=mu*(1-mu) if model=="logit" else stats.norm.pdf(eta) if model=="probit" else mu
        put=m.model("CH14",model)
        put.scalars(n=fit.nobs,ll=fit.llf)
        if model=="nb2":
            put.scalars(alpha=fit.params["alpha"])
        put.vector("beta",["intercept",field,"rural"],b)
        put.vector("eta",d[idcol],eta)
        put.vector("mean",d[idcol],mu)
        put.vector("ame",[field,"rural"],[b[1]*np.mean(derivative),np.mean(inverse(eta0+b[2])-inverse(eta0))])
        grid_eta=b[0]+b[1]*grid[field]+b[2]*grid.rural
        if not binary:
            grid_eta=grid_eta+np.log(grid.days/30)
        put.vector("grid_eta",grid.scenario_id,grid_eta)
        put.vector("grid_mean",grid.scenario_id,inverse(grid_eta))
        if model=="poisson":
            diag["poisson_pearson_df"]=float(np.sum((d.appointments-mu)**2/mu)/(len(d)-len(b)))
            diag["poisson_double_offset_grid_G03"]=float(inverse(grid_eta.iloc[2])*grid.days.iloc[2]/30)
        if model=="logit":
            diag["logit_one_contact_change"]=float(np.mean(inverse(eta+b[1])-mu))
            diag["delivery_events"]=int(d.event.sum())
            diag["separation_fixture"]="event=1(contacts>=3), boundary contacts 2.5"
            separated=(d.contacts.to_numpy()>=3)
            diag["separation_log_likelihood"]={
                str(k):float(-np.logaddexp(0,-(2*separated-1)*k*(d.contacts-2.5)).sum())
                for k in (1,4,16)
            }
            x0,x1=x.to_numpy().copy(),x.to_numpy().copy()
            x0[:,2],x1[:,2]=0,1
            p0,p1=expit(x0@b),expit(x1@b)
            grad=((p1*(1-p1))[:,None]*x1-(p0*(1-p0))[:,None]*x0).mean(axis=0)
            diag["rural_logit_delta_se"]=float(np.sqrt(grad@fit.cov_params()@grad))


def tobit(theta, x, y, c):
    sigma=np.exp(theta[2])
    mean=theta[0]+theta[1]*x
    a=-mean/sigma
    z=(y-mean)/sigma
    inverse_mills=np.exp(stats.norm.logpdf(a)-log_ndtr(a))
    ll=np.where(c,log_ndtr(a),stats.norm.logpdf(z)-theta[2])
    intercept=np.where(c,-inverse_mills/sigma,z/sigma)
    logsig=np.where(c,-a*inverse_mills,z*z-1)
    return np.column_stack((ll,intercept,x*intercept,logsig))


def limited(raw,m,diag):
    d=pd.read_csv(raw/"censor15.csv")
    x,y,c=d.resources.to_numpy(),d.expenditure.to_numpy(),d.censored.to_numpy(bool)
    theta=np.array([.9,.8,np.log(1.2)])
    values=tobit(theta,x,y,c)
    put=m.model("CH15","tobit_eval")
    for i,name in enumerate(("ll","intercept","beta","logsig")):
        put.vector(name,[*d.case_id,"total"],[*values[:,i],sum(values[:,i])])
    def objective(params):
        aggregate=tobit(params,x,y,c).sum(axis=0)
        return -aggregate[0],-aggregate[1:]
    fit=minimize(objective,theta,jac=True,method="BFGS",options={"gtol":1e-7})
    if np.linalg.norm(fit.jac,np.inf)>1e-5:
        raise ValueError("Tobit score did not converge.")
    diag["tobit_fit_python"]={"beta":fit.x[:2].tolist(),"sigma":float(np.exp(fit.x[2])),
                              "ll":float(-fit.fun),"censored":int(c.sum())}

    s=pd.read_csv(raw/"duration15.csv")
    x=s[["risk","supported"]].to_numpy()
    for model in ("breslow","efron"):
        fit=PHReg(s.duration,x,status=s.event,ties=model).fit(disp=0,tol=1e-11)
        put=m.model("CH15",model)
        put.scalars(n=len(s),ll=fit.llf)
        put.vector("beta",["risk","supported"],fit.params)
        put.vector("eta",s.person_id,x@fit.params)
    point=x@np.array([.30,-.25])
    w=np.exp(point)
    survive=1.
    for time in sorted(set(s.duration[s.event==1])):
        r=s.duration>=time
        d=(s.duration==time)&(s.event==1)
        nfail=int(sum(d))
        survive*=1-nfail/sum(r)
        for name,value in (("risk",sum(r)),("events",nfail),("censored",sum((s.duration==time)&(s.event==0))),
                           ("km",survive)):
            m.model("CH15","riskset").add(name,str(time),value)
        for model in ("breslow","efron"):
            frac=np.arange(nfail)/nfail if model=="efron" else np.zeros(nfail)
            part=point[d].sum()-np.log(w[r].sum()-frac*w[d].sum()).sum()
            m.model("CH15",model).add("fixed_ll",str(time),part)
    # Schoenfeld residual trend for the Efron fit is a teaching diagnostic.
    efron=PHReg(s.duration,x,status=s.event,ties="efron").fit(disp=0)
    resid=efron.schoenfeld_residuals[s.event==1,0]
    diag["risk_schoenfeld_log_time_corr"]=float(np.corrcoef(resid,np.log(s.duration[s.event==1]))[0,1])


def mixed(raw,m,diag):
    d=pd.read_csv(raw/"facilities16.csv")
    for model in ("balanced","unbalanced"):
        a=d[d[model]==1].copy()
        fit=sm.MixedLM.from_formula("outcome~baseline",groups="facility_id",data=a).fit(
            reml=False,method="lbfgs",maxiter=400,pgtol=1e-10,factr=100)
        if not fit.converged:
            raise ValueError(f"{model} Gaussian ML optimisation failed.")
        put=m.model("CH16",model)
        tau2,sigma2=fit.cov_re.iloc[0,0],fit.scale
        put.scalars(n=len(a),groups=a.facility_id.nunique(),ll=fit.llf,tau2=tau2,sigma2=sigma2)
        put.vector("beta",["intercept","baseline"],fit.fe_params)
        u={name:float(e.iloc[0]) for name,e in fit.random_effects.items()}
        put.vector("effect",u.keys(),u.values())
        put.vector("fit",a.patient_id,fit.fittedvalues)
        sizes=a.groupby("facility_id").size()
        a["partial_residual"]=a.outcome-np.asarray(fit.predict(a))
        diag[model]={"icc":float(tau2/(tau2+sigma2)),"sizes":{k:int(v) for k,v in sizes.items()},
                     "mean_partial_residual":a.groupby("facility_id").partial_residual.mean().to_dict()}
        restricted=sm.MixedLM.from_formula("outcome~baseline",groups="facility_id",data=a).fit(
            reml=True,method="lbfgs",maxiter=400,pgtol=1e-10,factr=100)
        if not restricted.converged:
            raise ValueError(f"{model} REML sensitivity failed.")
        diag[model]["reml_sensitivity"]={"tau2":float(restricted.cov_re.iloc[0,0]),
                                          "sigma2":float(restricted.scale)}
    # A random slope on a column of ones duplicates the random intercept exactly.
    bad=np.ones((len(d),2))
    split=np.diag([tau2/2,tau2/2])
    singular=np.diag([tau2,0.])
    diag["duplicated_random_slope"]={
        "columns":2,"rank":int(np.linalg.matrix_rank(bad)),
        "implied_covariance_equal":bool(np.allclose(bad@split@bad.T,bad@singular@bad.T)),
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    m, diag=Ledger(),{}
    ols(args.input,m,diag)
    glm(args.input,m,diag)
    limited(args.input,m,diag)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",message="Argument (pgtol|factr) not used by MixedLM.fit")
        mixed(args.input,m,diag)
    m.save(args.output/"metrics.csv")
    (args.output/"diagnostics.json").write_text(json.dumps(diag,indent=2)+"\n")
    print(f"statsmodels {statsmodels.__version__}, NumPy {np.__version__}; {len(m.rows)} keyed values")


if __name__=="__main__":
    main()
