"""DuckDB preparation and independent evaluations at documented model parameters."""

import argparse
from pathlib import Path

import duckdb
import numpy as np

from ledger import Ledger,read


FILES=("pilot13","regression13","delivery14","appointments14","prediction14",
       "censor15","duration15","facilities16")
KEYS=("plot_id","plot_id","case_id","count_id","scenario_id","case_id","person_id","patient_id")


def load_data(db, raw, output):
    for name,key in zip(FILES,KEYS,strict=True):
        db.execute(f"""CREATE TABLE {name} AS
                       SELECT * FROM read_csv(?,header=true,types={{{repr(key)}:'VARCHAR'}})""",
                   [str(raw/f"{name}.csv")])
        n,unique=db.execute(f"SELECT count(*),count(DISTINCT {key}) FROM {name}").fetchone()
        if n!=unique or n==0:
            raise ValueError(f"{name}: key is missing or duplicated.")
    rules=[
        ("pilot13","season=2025 AND area_ha>0 AND harvest_kg>=0 AND sessions BETWEEN 0 AND 5 AND yield_kg_ha=harvest_kg/area_ha"),
        ("regression13","sessions>=0 AND sessions=floor(sessions) AND irrigated IN (0,1) AND isfinite(yield_kg_ha)"),
        ("delivery14","contacts>=0 AND contacts=floor(contacts) AND rural IN (0,1) AND event IN (0,1)"),
        ("appointments14","isfinite(capacity) AND rural IN (0,1) AND days>0 AND appointments>=0 AND appointments=floor(appointments)"),
        ("prediction14","contacts>=0 AND isfinite(capacity) AND rural IN (0,1) AND days>0"),
        ("censor15","censored IN (0,1) AND expenditure>=0 AND (expenditure=0)=(censored=1) AND isfinite(resources)"),
        ("duration15","duration>0 AND duration=floor(duration) AND isfinite(risk) AND event IN (0,1) AND supported IN (0,1)"),
        ("facilities16","facility_id IS NOT NULL AND balanced IN (0,1) AND unbalanced IN (0,1) AND isfinite(baseline) AND isfinite(outcome)"),
    ]
    audit=[]
    for name,expr in rules:
        n,bad=db.execute(f"SELECT count(*),count(*) FILTER (WHERE ({expr}) IS NOT TRUE) FROM {name}").fetchone()
        if bad:
            raise ValueError(f"{name}: {bad} rows violate the analysis contract.")
        audit.append(f"{name},{n},{bad}\n")
    (output/"input_audit.csv").write_text("table,rows,violations\n"+"".join(audit))
    sources=raw.parent/"pilot_source"
    for name in ("plots","season_records"):
        db.execute(f"CREATE TABLE stage2_{name} AS SELECT * FROM read_csv(?,header=true)",
                   [str(sources/f"{name}.csv")])
    for table,key in (("stage2_plots","plot_id"),("stage2_season_records","(plot_id,season)")):
        a,b=db.execute(f"SELECT count(*),count(DISTINCT {key}) FROM {table}").fetchone()
        if a!=b:
            raise ValueError("Stage 2 source keys are duplicated.")
    db.execute("""
    CREATE TEMP VIEW pilot_audit AS
    SELECT s.plot_id,season,area_m2/10000.0 AS area_ha,harvest_kg,sessions,
           CASE WHEN p.plot_id IS NULL THEN 'missing_plot'
                WHEN season<>2025 THEN 'outside_season'
                WHEN area_m2<=0 OR area_m2 IS NULL THEN 'invalid_area'
                WHEN harvest_kg IS NULL THEN 'missing_harvest'
                WHEN sessions IS NULL THEN 'missing_sessions'
                ELSE 'included' END AS disposition
    FROM stage2_season_records s LEFT JOIN stage2_plots p USING (plot_id);
    """)
    diff=db.execute("""
    WITH regenerated AS (
      SELECT plot_id,season,area_ha,harvest_kg,sessions,harvest_kg/area_ha AS yield_kg_ha
      FROM pilot_audit WHERE disposition='included'
    )
    SELECT count(*) FROM (
      (SELECT * FROM regenerated EXCEPT ALL SELECT * FROM pilot13)
      UNION ALL
      (SELECT * FROM pilot13 EXCEPT ALL SELECT * FROM regenerated)
    );
    """).fetchone()[0]
    if diff:
        raise ValueError("The rebuilt 2025 pilot differs from the canonical extract.")
    db.sql("SELECT * FROM pilot_audit ORDER BY plot_id,season").write_csv(str(output/"pilot_sample_audit.csv"))


def ols(db,m):
    for model,terms in (("pilot",["intercept","sessions"]),("multiple",["intercept","sessions","irrigated"])):
        n,sx,sz,sxx,sxz,szz,sy,sxy,szy,tss=db.execute("""
            SELECT n,sx,sz,sxx,sxz,szz,sy,sxy,szy,tss FROM ols_moments WHERE model=?
            """,[model]).fetchone()
        p=len(terms)
        gram=np.array([[n,sx,sz],[sx,sxx,sxz],[sz,sxz,szz]])[:p,:p]
        if np.linalg.cond(gram)>1e5:
            raise ValueError(f"{model}: moment matrix exceeds the declared teaching condition bound.")
        bread=np.linalg.solve(gram,np.eye(p))
        b=np.linalg.solve(gram,[sy,sxy,szy][:p])
        full=np.pad(b,(0,3-p))
        a=np.pad(bread,((0,3-p),(0,3-p)))
        data=db.execute("""
        WITH calc AS (
          SELECT plot_id,x,z,y, ?+?*x+?*z AS fit,
               ?+2*?*x+2*?*z+?*x*x+2*?*x*z+?*z*z AS hat
          FROM ols_rows WHERE model=?
        )
        SELECT plot_id,x,z,fit,y-fit AS residual,hat FROM calc ORDER BY plot_id
        """,[*full,a[0,0],a[0,1],a[0,2],a[1,1],a[1,2],a[2,2],model]).fetchall()
        db.execute("CREATE OR REPLACE TEMP TABLE residual_terms (x DOUBLE,z DOUBLE,residual DOUBLE)")
        db.executemany("INSERT INTO residual_terms VALUES (?,?,?)",[(x,z,e) for _,x,z,_,e,_ in data])
        rss,sx,sz,sxx,sxz,szz=db.execute("""
            SELECT sum(e2),sum(x*e2),sum(z*e2),sum(x*x*e2),sum(x*z*e2),sum(z*z*e2)
            FROM (SELECT *,residual*residual AS e2 FROM residual_terms)
            """).fetchone()
        meat=np.array([[rss,sx,sz],[sx,sxx,sxz],[sz,sxz,szz]])[:p,:p]
        scale=rss/(n-p)
        put=m.model("CH13",model)
        put.scalars(n=n,rank=p,df=n-p,rss=rss,r2=1-rss/tss)
        put.vector("beta",terms,b)
        put.matrix("classical",terms,scale*bread)
        put.matrix("hc1",terms,n/(n-p)*bread@meat@bread)
        for key,_,_,fit,residual,hat in data:
            for q,val in (("fit",fit),("residual",residual),("leverage",hat),
                          ("cook",residual**2*hat/(p*scale*(1-hat)**2))):
                put.add(q,key,val)


def glm(db,m,reference,out):
    db.execute("CREATE TABLE glm_params (model VARCHAR,b0 DOUBLE,bx DOUBLE,bz DOUBLE,size DOUBLE)")
    for model in ("logit","probit","poisson","nb2"):
        term="contacts" if model in {"logit","probit"} else "capacity"
        b=[reference["CH14",model,"beta",k] for k in ("intercept",term,"rural")]
        size=1/reference["CH14",model,"scalar","alpha"] if model=="nb2" else None
        db.execute("INSERT INTO glm_params VALUES (?,?,?,?,?)",[model,*b,size])
    db.execute("""
    CREATE TEMP VIEW glm_values AS
    WITH linear AS (
      SELECT d.*, bx, bz, size, b0+bx*x+off AS eta0, b0+bx*x+bz*z+off AS eta
      FROM glm_design d JOIN glm_params p USING (model)
    ), fitted AS (
      SELECT *, inverse_link(model,eta) AS mu FROM linear
    )
    SELECT *,
       bx*CASE model WHEN 'logit' THEN mu*(1-mu)
                     WHEN 'probit' THEN normal_pdf(eta) ELSE mu END AS slope,
       inverse_link(model,eta0+bz)-inverse_link(model,eta0) AS delta,
       CASE WHEN model IN ('logit','probit') THEN y*ln(mu)+(1-y)*ln(1-mu)
            WHEN model='poisson' THEN y*ln(mu)-mu-lgamma(y+1)
            ELSE lgamma(y+size)-lgamma(size)-lgamma(y+1)
               +size*(ln(size)-ln(size+mu))+y*(ln(mu)-ln(size+mu)) END AS ll
    FROM fitted;
    """)
    for model,id,eta,mu in db.sql("SELECT model,id,eta,mu FROM glm_values").fetchall():
        put=m.model("CH14",model)
        put.add("eta",id,eta)
        put.add("mean",id,mu)
    for model,n,ll,slope,delta in db.sql("""
         SELECT model,count(*),sum(ll),avg(slope),avg(delta) FROM glm_values GROUP BY model
         """).fetchall():
        put=m.model("CH14",model)
        put.scalars(n=n,ll=ll)
        put.add("ame","contacts" if model in {"logit","probit"} else "capacity",slope)
        put.add("ame","rural",delta)
    for model,id,eta,mu in db.sql("""
        WITH linear AS (
          SELECT model,id,b0+bx*x+bz*z+off AS eta FROM glm_grid JOIN glm_params USING(model)
        )
        SELECT *,inverse_link(model,eta) AS mu FROM linear
        """).fetchall():
        put=m.model("CH14",model)
        put.add("grid_eta",id,eta)
        put.add("grid_mean",id,mu)
    db.sql("SELECT * FROM glm_grid ORDER BY model,id").write_csv(str(out/"glm_prediction_design.csv"))


def limited(db,m,out):
    fit=m.model("CH15","tobit_eval")
    labels=("ll","intercept","beta","logsig")
    for id,*v in db.sql("SELECT * FROM censored_normal").fetchall():
        for label,val in zip(labels,v,strict=True):
            fit.add(label,id,val)
    totals=db.sql("SELECT sum(ll),sum(intercept),sum(beta),sum(logsig) FROM censored_normal").fetchone()
    for label,val in zip(labels,totals,strict=True):
        fit.add(label,"total",val)
    risk=m.model("CH15","riskset")
    km=1.
    for t,n,d,c in db.sql("SELECT t,risk,failures,censored FROM risk_sets ORDER BY t").fetchall():
        km*=1-d/n
        for label,val in (("risk",n),("events",d),("censored",c),("km",km)):
            risk.add(label,t,val)
    for model,t,ll in db.sql("SELECT model,t,ll FROM cox_fixed").fetchall():
        m.model("CH15",model).add("fixed_ll",t,ll)
    db.sql("SELECT * FROM risk_sets ORDER BY t").write_csv(str(out/"survival_risk_sets.csv"))


def mixed(db,m,reference,out):
    db.execute("CREATE TABLE mixed_params (model VARCHAR,b0 DOUBLE,b1 DOUBLE,tau2 DOUBLE,sigma2 DOUBLE)")
    for model in ("balanced","unbalanced"):
        pars=[reference["CH16",model,"beta",k] for k in ("intercept","baseline")]
        pars += [reference["CH16",model,"scalar",k] for k in ("tau2","sigma2")]
        db.execute("INSERT INTO mixed_params VALUES (?,?,?,?,?)",[model,*pars])
    db.execute("""
    CREATE TEMP VIEW mixed_deviations AS
    SELECT r.*,p.b0+p.b1*r.baseline AS fixed,r.outcome-(p.b0+p.b1*r.baseline) AS e,p.tau2,p.sigma2
    FROM mixed_rows r JOIN mixed_params p USING(model);
    CREATE TEMP VIEW mixed_group AS
    WITH aggregates AS (
      SELECT model,facility_id,count(*) AS n,sum(e) AS se,sum(e*e) AS sse,
             any_value(tau2) AS tau2,any_value(sigma2) AS sigma2
      FROM mixed_deviations GROUP BY model,facility_id
    ), corrections AS (
      SELECT *,sigma2+n*tau2 AS common_var,tau2*se/(sigma2+n*tau2) AS effect
      FROM aggregates
    )
    SELECT *, -.5*(n*ln(2*pi())+(n-1)*ln(sigma2)+ln(common_var)
                    +(sse-tau2*se*se/common_var)/sigma2) AS ll
    FROM corrections;
    """)
    for model,n,g,ll in db.sql("SELECT model,sum(n),count(*),sum(ll) FROM mixed_group GROUP BY model").fetchall():
        m.model("CH16",model).scalars(n=n,groups=g,ll=ll)
    for model,id,effect in db.sql("SELECT model,facility_id,effect FROM mixed_group").fetchall():
        m.model("CH16",model).add("effect",id,effect)
    for model,id,fit in db.sql("""
        SELECT d.model,d.patient_id,d.fixed+g.effect FROM mixed_deviations d
        JOIN mixed_group g USING(model,facility_id)
    """).fetchall():
        m.model("CH16",model).add("fit",id,fit)
    db.sql("SELECT * FROM mixed_group ORDER BY model,facility_id").write_csv(str(out/"mixed_group_audit.csv"))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input",type=Path)
    parser.add_argument("parameters",type=Path)
    parser.add_argument("output",type=Path)
    args=parser.parse_args()
    args.output.mkdir(exist_ok=True,parents=True)
    db=duckdb.connect()
    load_data(db,args.input,args.output)
    db.execute(Path(__file__).with_name("sql").joinpath("models.sql").read_text())
    reference=read(args.parameters)
    m=Ledger()
    ols(db,m)
    glm(db,m,reference,args.output)
    limited(db,m,args.output)
    mixed(db,m,reference,args.output)
    m.save(args.output/"metrics.csv")
    print(f"DuckDB {duckdb.__version__}; {len(m.rows)} keyed values")


if __name__=="__main__":
    main()
