"""Recompute the Chapter 7 invoice ledger in SQLite and compare exact results."""

import argparse
import csv
from datetime import date
import json
from pathlib import Path
import sqlite3


ROOT = Path(__file__).resolve().parent
SCHEMA = """
CREATE TABLE customers(
    customer_id TEXT NOT NULL, effective_date TEXT NOT NULL,
    version INTEGER NOT NULL, region TEXT NOT NULL,
    PRIMARY KEY (customer_id,effective_date,version)
);
CREATE TABLE invoices(
    invoice_id TEXT NOT NULL PRIMARY KEY, customer_id TEXT NOT NULL,
    invoice_date TEXT NOT NULL, total_minor INTEGER NOT NULL
);
CREATE TABLE lines(
    invoice_id TEXT NOT NULL, line_id TEXT NOT NULL, amount_minor INTEGER NOT NULL,
    PRIMARY KEY (invoice_id,line_id)
);
"""


def iso_date(text):
    value = date.fromisoformat(text)
    if value.isoformat() != text:
        raise ValueError(f"Expected an ISO date, got {text}.")
    return text


def read(path, names, transforms):
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != list(names):
            raise ValueError(f"Unexpected columns in {path.name}.")
        return [tuple(fn(row[name]) for name, fn in zip(names, transforms, strict=True))
                for row in reader]


def run(source, duckdb_outputs, output):
    output.mkdir(parents=True, exist_ok=False)
    tables = {
        "customers": (("customer_id", "effective_date", "version", "region"),
                      (str, iso_date, int, str)),
        "invoices": (("invoice_id", "customer_id", "invoice_date", "total_minor"),
                     (str, str, iso_date, int)),
        "lines": (("invoice_id", "line_id", "amount_minor"), (str, str, int)),
    }
    with sqlite3.connect(":memory:") as db:
        db.executescript(SCHEMA)
        for table, (names, transforms) in tables.items():
            rows = read(source / f"ch07_{table}.csv", names, transforms)
            db.executemany(f"INSERT INTO {table} VALUES ({','.join('?' for _ in names)})", rows)
        db.executescript((ROOT / "sql/ch07_sqlite.sql").read_text())
        if db.execute("SELECT invoice_id FROM ch07_inconsistent_header").fetchone():
            raise ValueError("Invoice details fail the exact header reconciliation.")
        checks = {
            "analytical_invoices": ("ch07_invoice_report", "invoice_id",
                                    (str, str, str, int, str, str, int, int, str)),
            "selected_customers": ("ch07_selected_customer", "customer_id", (str, int, str)),
            "orphan_invoice_lines": ("ch07_orphan_line", "invoice_id,line_id", (str, str, int)),
        }
        counts = {}
        for artifact, (view, order_by, types) in checks.items():
            cursor = db.execute(f"SELECT * FROM {view} ORDER BY {order_by}")
            columns = [item[0] for item in cursor.description]
            rows = cursor.fetchall()
            target = duckdb_outputs / f"{artifact}.csv"
            if rows != read(target, columns, types):
                raise ValueError(f"SQLite output differs from the DuckDB ledger: {artifact}.")
            with (output / target.name).open("w", newline="", encoding="utf-8") as handle:
                csv.writer(handle, lineterminator="\n").writerows([columns, *rows])
            counts[artifact] = len(rows)
    evidence = {"sqlite": sqlite3.sqlite_version, "exact_match": True, "rows": counts}
    (output / "verification.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(f"SQLite {evidence['sqlite']}: {sum(counts.values())} rows matched across three ledgers.")
    return evidence


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "data/raw")
    parser.add_argument("--duckdb-output", type=Path, required=True,
                        help="The sample_ledger directory from the Part II runner.")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run(args.input, args.duckdb_output, args.output)
