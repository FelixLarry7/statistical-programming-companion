# Verify Part II with your licensed Stata installation

This offline kit executes the examples in Chapters 5–8 of *Statistical Programming and Reproducible Data Science* by Felix Larry Essilfie, PhD. It uses Stata syntax version 16 and the exact Part II inputs.

1. Extract the ZIP to a writable folder.
2. In Stata 17 or 16, use **File → Change Working Directory** to select the extracted folder that contains `run_part2.do`.
3. In Stata's Command window enter `do run_part2.do`.
4. Upload the generated `Stata_Verification_Part_II_*.zip`. It includes the original inputs, executed driver, Stata runtime record, log and observed outputs. If Stata reports an error, upload the evidence ZIP or compressed evidence folder so the log can be reviewed.

The wrapper uses a temporary frame and records the result in a timestamped folder. A return code of zero indicates completed execution. The Part II comparator independently checks the results and input hashes after the ZIP is returned.
