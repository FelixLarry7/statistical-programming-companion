*! Part II chapter labs. Run from a licensed Stata 16 or later installation.
version 16.0
args input output
if `"`input'"' == "" | `"`output'"' == "" {
    display as error "Provide the input folder and output CSV path."
    exit 198
}

tempname p train_mean train_sd full_mean full_sd known_weight child_weight
tempfile results exchange invoices fx rates history dimension headers details households people plots
postfile `p' str4 chapter str28 metric str44 key double value using `"`results'"'

* Chapter 5. Explicit strings, calendar dates and exact index hundredths.
import delimited using `"`input'/ch05_import.csv"', clear varnames(1) stringcols(1 2 3 4)
isid record_id
assert ustrregexm(record_id, "^[0-9]{1,5}$")
assert inlist(category, "A", "B")
gen double parsed_day = daily(observed_on, "YMD")
assert !missing(parsed_day) & string(parsed_day, "%tdCCYY-NN-DD")==observed_on
assert value_token==".." | ustrregexm(value_token, "^([0-9]{1,3}([.][0-9]{3})+|[0-9]+),[0-9]{2}$")
gen double value_minor = real(subinstr(subinstr(value_token, ".", "", .), ",", "", .)) if value_token!=".."
assert (missing(value_minor) == (value_token==".."))
gen byte category_code = cond(category=="A",1,2)
label define service_category 1 "Field" 2 "Office"
label values category_code service_category
format parsed_day %tdCCYY-NN-DD
save `"`exchange'"'
use `"`exchange'"', clear
isid record_id
decode category_code, gen(category_label)
gen double date_code = year(parsed_day)*10000 + month(parsed_day)*100 + day(parsed_day)
gen str11 value_state = cond(missing(value_minor), "unavailable", "observed")
gen double integer_id = real(record_id)
egen byte distinct_integer = tag(integer_id)
quietly count if distinct_integer
post `p' ("CH05") ("count") ("integer_ids") (r(N))
post `p' ("CH05") ("count") ("text_ids") (_N)
quietly count if missing(value_minor)
post `p' ("CH05") ("count") ("missing") (r(N))
quietly summarize value_minor, meanonly
post `p' ("CH05") ("total") ("observed_minor") (r(sum))
forvalues i = 1/`=_N' {
    post `p' ("CH05") ("date") (record_id[`i']) (date_code[`i'])
    post `p' ("CH05") ("state") (record_id[`i'] + "/" + value_state[`i']) (1)
    post `p' ("CH05") ("label") (record_id[`i'] + "/" + category_label[`i']) (1)
    if !missing(value_minor[`i']) {
        post `p' ("CH05") ("value_minor") (record_id[`i']) (value_minor[`i'])
    }
}

* Chapter 6. Evaluate candidate rates, then restore the invoice grain.
import delimited using `"`input'/ch06_fx.csv"', clear varnames(1) stringcols(1 2) asdouble
isid currency effective_date
assert fx_pp100>0 & fx_pp100==floor(fx_pp100) & !missing(fx_pp100)
gen double fx_day = daily(effective_date,"YMD")
assert !missing(fx_day)
save `"`fx'"'

import delimited using `"`input'/ch06_invoices.csv"', clear varnames(1) stringcols(1 2 3 4) asdouble
isid invoice_id
assert inlist(currency,"USD","GHS") & inlist(state,"posted","returned","cancelled")
assert quantity>0 & quantity==floor(quantity) & !missing(quantity)
assert missing(price_minor) | (price_minor>=0 & price_minor==floor(price_minor))
gen double inv_day = daily(invoice_date,"YMD")
assert !missing(inv_day)
save `"`invoices'"'
joinby currency using `"`fx'"', unmatched(master)
post `p' ("CH06") ("count") ("currency_join_rows") (_N)
keep if fx_day<=inv_day & !missing(fx_day)
gsort invoice_id -fx_day
by invoice_id: keep if _n==1
keep invoice_id fx_pp100
isid invoice_id
save `"`rates'"'

use `"`invoices'"', clear
merge 1:1 invoice_id using `"`rates'"', assert(master match) nogen
gen str14 disposition = "retained"
replace disposition="missing_rate" if missing(fx_pp100)
replace disposition="missing_price" if missing(price_minor)
replace disposition="cancelled" if state=="cancelled"
gen double numer = quantity * price_minor * fx_pp100 * cond(state=="returned",-1,1) if disposition=="retained"
assert abs(numer)<9007199254740942 if disposition=="retained"
gen double net_minor = sign(numer)*floor((abs(numer)+50)/100) if disposition=="retained"
gen byte high = abs(net_minor)>100000 if disposition=="retained"
post `p' ("CH06") ("count") ("source") (_N)
quietly count if disposition=="retained"
post `p' ("CH06") ("count") ("retained") (r(N))
quietly summarize net_minor, meanonly
post `p' ("CH06") ("total") ("net_minor") (r(sum))
quietly summarize net_minor if state=="posted", meanonly
post `p' ("CH06") ("total") ("posted_minor") (r(sum))
quietly summarize net_minor if state=="returned", meanonly
post `p' ("CH06") ("total") ("returned_minor") (r(sum))
forvalues i = 1/`=_N' {
    post `p' ("CH06") ("invoice_state") (invoice_id[`i'] + "/" + disposition[`i']) (1)
    if disposition[`i']=="retained" {
        post `p' ("CH06") ("net_minor") (invoice_id[`i']) (net_minor[`i'])
        post `p' ("CH06") ("rate") (invoice_id[`i']) (fx_pp100[`i'])
        post `p' ("CH06") ("high_flag") (invoice_id[`i']) (high[`i'])
    }
}

import delimited using `"`input'/ch06_features.csv"', clear varnames(1) stringcols(1 2 3) asdouble
isid record_id
assert inlist(partition, "train", "holdout") & !missing(input_value)
gen double feat_day=daily(observed_on,"YMD")
assert !missing(feat_day)
quietly summarize feat_day if partition=="train", meanonly
local train_last = r(max)
assert feat_day>`train_last' if partition=="holdout"
quietly summarize input_value if partition=="train"
scalar `train_mean' = r(mean)
scalar `train_sd' = sqrt(r(Var)*(r(N)-1)/r(N))
post `p' ("CH06") ("count") ("train") (r(N))
quietly summarize input_value
scalar `full_mean' = r(mean)
scalar `full_sd' = sqrt(r(Var)*(r(N)-1)/r(N))
post `p' ("CH06") ("scale") ("train_mean") (`train_mean')
post `p' ("CH06") ("scale") ("train_sd") (`train_sd')
post `p' ("CH06") ("scale") ("full_mean") (`full_mean')
post `p' ("CH06") ("scale") ("full_sd") (`full_sd')
assert `train_sd'>0 & `full_sd'>0
forvalues i = 1/`=_N' {
    if partition[`i']=="holdout" {
        post `p' ("CH06") ("z_train") (record_id[`i']) ((input_value[`i']-`train_mean')/`train_sd')
        post `p' ("CH06") ("z_full") (record_id[`i']) ((input_value[`i']-`full_mean')/`full_sd')
    }
}

* Chapter 7. One current dimension row, one detail total, one invoice.
import delimited using `"`input'/ch07_customers.csv"', clear varnames(1) stringcols(1 2 4) asdouble
isid customer_id effective_date version
gen double effective_day=daily(effective_date,"YMD")
assert !missing(effective_day)
save `"`history'"'
keep if effective_day<=daily("2025-03-31","YMD")
gsort customer_id -effective_day -version
by customer_id: keep if _n==1
keep customer_id region version
isid customer_id
forvalues i = 1/`=_N' {
    post `p' ("CH07") ("customer_version") (customer_id[`i']) (version[`i'])
}
save `"`dimension'"'

import delimited using `"`input'/ch07_invoices.csv"', clear varnames(1) stringcols(1 2 3) asdouble
isid invoice_id
gen double inv_day=daily(invoice_date,"YMD")
assert !missing(inv_day)
post `p' ("CH07") ("count") ("headers") (_N)
quietly summarize total_minor, meanonly
post `p' ("CH07") ("total") ("headers_minor") (r(sum))
save `"`headers'"'

import delimited using `"`input'/ch07_lines.csv"', clear varnames(1) stringcols(1 2) asdouble
isid invoice_id line_id
post `p' ("CH07") ("count") ("lines") (_N)
merge m:1 invoice_id using `"`headers'"', keep(master match) keepusing(customer_id)
quietly count if _merge==1
post `p' ("CH07") ("count") ("orphan_lines") (r(N))
keep if _merge==3
drop _merge
save `"`details'"'
joinby customer_id using `"`history'"'
post `p' ("CH07") ("count") ("raw_join_rows") (_N)
quietly summarize amount_minor, meanonly
post `p' ("CH07") ("total") ("raw_join_minor") (r(sum))

use `"`details'"', clear
collapse (sum) detail_total=amount_minor, by(invoice_id)
merge 1:1 invoice_id using `"`headers'"', assert(match) nogen
assert detail_total==total_minor
quietly summarize detail_total, meanonly
post `p' ("CH07") ("total") ("matched_lines_minor") (r(sum))
merge m:1 customer_id using `"`dimension'"', keep(master match)
quietly count if _merge==1
post `p' ("CH07") ("count") ("unmatched_headers") (r(N))
quietly summarize total_minor if _merge==1, meanonly
post `p' ("CH07") ("total") ("unmatched_minor") (r(sum))
keep if _merge==3
drop _merge
isid invoice_id
post `p' ("CH07") ("count") ("retained") (_N)
quietly summarize total_minor, meanonly
post `p' ("CH07") ("total") ("retained_minor") (r(sum))
bysort customer_id (inv_day invoice_id): gen double rows_running=sum(total_minor)
bysort customer_id inv_day (invoice_id): gen double peer_running=rows_running[_N]
gen str7 period=substr(invoice_date,1,7)
forvalues i = 1/`=_N' {
    post `p' ("CH07") ("invoice_minor") (invoice_id[`i']) (total_minor[`i'])
    post `p' ("CH07") ("region") (invoice_id[`i'] + "/" + region[`i']) (1)
    post `p' ("CH07") ("rows_running") (invoice_id[`i']) (rows_running[`i'])
    post `p' ("CH07") ("peer_running") (invoice_id[`i']) (peer_running[`i'])
}

preserve
collapse (sum) period_minor=total_minor (count) period_n=total_minor, by(period region)
forvalues i = 1/`=_N' {
    post `p' ("CH07") ("period_minor") (period[`i'] + "/" + region[`i']) (period_minor[`i'])
    post `p' ("CH07") ("period_n") (period[`i'] + "/" + region[`i']) (period_n[`i'])
}
restore
bysort customer_id (period): gen str7 cohort=period[1]
bysort cohort period customer_id: gen byte active=_n==1
collapse (sum) active, by(cohort period)
forvalues i = 1/`=_N' {
    post `p' ("CH07") ("cohort_active") (cohort[`i'] + "/" + period[`i']) (active[`i'])
}

* Chapter 8. Test a defective input, then recompute the corrected population.
import delimited using `"`input'/ch08_households.csv"', clear varnames(1) stringcols(1 2) asdouble
isid hh_id
assert inlist(stratum,"A","B") & inlist(eligible,0,1)
assert weight10>0 & weight10==floor(weight10) & !missing(weight10)
post `p' ("CH08") ("count") ("households") (_N)
quietly count if eligible==1
post `p' ("CH08") ("count") ("eligible_households") (r(N))
save `"`households'"'

import delimited using `"`input'/ch08_households_defect.csv"', clear varnames(1) stringcols(1 2) asdouble
capture isid hh_id
local invalid_hh = (_rc!=0)
post `p' ("CH08") ("defect") ("duplicate_gate_rejects") (`invalid_hh')
bysort hh_id: gen byte excess=_n>1
quietly count if excess
post `p' ("CH08") ("defect") ("duplicate_excess") (r(N))

import delimited using `"`input'/ch08_members_defect.csv"', clear varnames(1) stringcols(1 2) asdouble
isid hh_id member_id
merge m:1 hh_id using `"`households'"', keep(master match) keepusing(eligible)
capture assert _merge==3
local invalid_person = (_rc!=0)
post `p' ("CH08") ("defect") ("orphan_gate_rejects") (`invalid_person')
quietly count if _merge==1
post `p' ("CH08") ("defect") ("orphan_members") (r(N))

import delimited using `"`input'/ch08_members.csv"', clear varnames(1) stringcols(1 2) asdouble
isid hh_id member_id
post `p' ("CH08") ("count") ("members") (_N)
merge m:1 hh_id using `"`households'"', keep(master match) keepusing(eligible weight10)
assert _merge==3
drop _merge
gen str11 disposition="known"
replace disposition="invalid_age" if !inrange(age,0,110) | age!=floor(age)
replace disposition="unknown_age" if age==-99
replace disposition="out_scope" if eligible==0
forvalues i = 1/`=_N' {
    post `p' ("CH08") ("member_state") (hh_id[`i'] + "/" + member_id[`i'] + "/" + disposition[`i']) (1)
}
keep if inlist(disposition,"known","unknown_age")
post `p' ("CH08") ("count") ("eligible_members") (_N)
quietly count if disposition=="known"
post `p' ("CH08") ("count") ("known_ages") (r(N))
quietly count if disposition=="known" & age<18
post `p' ("CH08") ("count") ("known_children") (r(N))
quietly summarize weight10 if disposition=="known", meanonly
scalar `known_weight' = r(sum)
quietly summarize weight10 if disposition=="known" & age<18, meanonly
scalar `child_weight' = r(sum)
quietly summarize weight10, meanonly
post `p' ("CH08") ("weight10") ("eligible") (r(sum))
post `p' ("CH08") ("share") ("unknown_as_adult") (`child_weight'/r(sum))
post `p' ("CH08") ("weight10") ("known") (`known_weight')
post `p' ("CH08") ("weight10") ("children") (`child_weight')
post `p' ("CH08") ("share") ("known_age") (`child_weight'/`known_weight')
save `"`people'"'

import delimited using `"`input'/ch08_plots.csv"', clear varnames(1) stringcols(1 2 4) asdouble
isid plot_id
assert inlist(crop,"maize","rice")
post `p' ("CH08") ("count") ("plots") (_N)
merge m:1 hh_id using `"`households'"', keep(master match) keepusing(eligible)
assert _merge==3
drop _merge
gen str12 disposition="retained"
replace disposition="invalid_area" if missing(area_m2) | area_m2<=0 | area_m2!=floor(area_m2)
replace disposition="out_scope" if eligible==0
forvalues i = 1/`=_N' {
    post `p' ("CH08") ("plot_state") (plot_id[`i'] + "/" + disposition[`i']) (1)
}
keep if disposition=="retained"
post `p' ("CH08") ("count") ("retained_plots") (_N)
quietly summarize area_m2, meanonly
post `p' ("CH08") ("total") ("plot_area_m2") (r(sum))
keep hh_id plot_id
save `"`plots'"'
use `"`people'"', clear
joinby hh_id using `"`plots'"'
post `p' ("CH08") ("count") ("person_plot_join_rows") (_N)
quietly summarize weight10 if disposition=="known", meanonly
post `p' ("CH08") ("weight10") ("join_known") (r(sum))
quietly summarize weight10 if disposition=="known" & age<18, meanonly
post `p' ("CH08") ("weight10") ("join_children") (r(sum))

postclose `p'
use `"`results'"', clear
isid chapter metric key
assert !missing(value)
sort chapter metric key
tempname file
file open `file' using `"`output'"', write text replace
file write `file' "chapter,metric,key,value" _n
forvalues i = 1/`=_N' {
    file write `file' (chapter[`i']) "," (metric[`i']) "," (key[`i']) "," ///
        %24.17g (value[`i']) _n
}
file close `file'
display as result "Part II metrics generated in Stata `c(stata_version)' `c(flavor)'."
