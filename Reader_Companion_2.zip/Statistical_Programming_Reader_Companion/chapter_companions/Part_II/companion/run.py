"""Reproduce Part II and verify the observed outputs against fixed references."""

import argparse
import csv
from decimal import Decimal, InvalidOperation
from itertools import combinations
import json
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
from zipfile import ZipFile

import duckdb

from acquire import RAW, ROOT, digest, json_file, prepare, replay
from anchors import reference
from benchmark import benchmark


COLUMNS = ('chapter', 'metric', 'key', 'value')
NUMERICAL = {'scale', 'z_train', 'z_full', 'share'}
ABSOLUTE = Decimal('1e-10')
RELATIVE = Decimal('1e-12')


def write_csv(path, fields, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(fields)
        writer.writerows(rows)


def native(command, log):
    with log.open('w', encoding='utf-8') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
    if result.returncode:
        raise RuntimeError(f'Command exited with code {result.returncode}. Read {log.name}.')


def read_metrics(path):
    observed = {}
    with path.open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        if tuple(reader.fieldnames or ()) != COLUMNS:
            raise ValueError(f'Unexpected columns in {path.name}')
        for row in reader:
            identity = tuple(row[name] for name in COLUMNS[:3])
            if identity in observed or any(not v for v in identity):
                raise ValueError(f'Missing or duplicated output identity in {path.name}: {identity}')
            try:
                value = Decimal(row['value'].strip())
            except (InvalidOperation, AttributeError) as err:
                raise ValueError(f'Invalid value for {identity} in {path.name}') from err
            if not value.is_finite():
                raise ValueError(f'Non-finite value for {identity} in {path.name}')
            observed[identity] = value
    return observed


def comparisons(label, expected, actual):
    if set(expected) != set(actual):
        raise ValueError(f'{label} has different identities. Missing {set(expected)-set(actual)}. '
                         f'Unexpected {set(actual)-set(expected)}.')
    for key, left in sorted(expected.items()):
        right = actual[key]
        left = Decimal(str(left))
        limit = ABSOLUTE + RELATIVE * max(abs(left), abs(right)) if key[1] in NUMERICAL else Decimal(0)
        yield (label, *key, left, right, abs(left-right), limit, abs(left-right) <= limit)


def sql_metrics(db, inputs, out):
    db.execute('SET threads=1')
    for path in sorted(inputs.glob('*.csv')):
        db.read_csv(str(path), header=True, all_varchar=True).create_view(path.stem)
    db.execute('CREATE TABLE part2_metrics(chapter VARCHAR, metric VARCHAR, key VARCHAR, value DOUBLE)')
    for n in range(5, 9):
        db.execute((ROOT / 'sql' / f'ch{n:02d}.sql').read_text(encoding='utf-8'))
    db.sql('SELECT * FROM part2_metrics ORDER BY chapter, metric, key').write_csv(str(out / 'duckdb.csv'))


def exchange(db, out):
    directory = out / 'exchange'
    directory.mkdir()
    original = db.sql('SELECT * FROM typed05 ORDER BY record_id')
    original.write_parquet(str(directory / 'indicator.parquet'), compression='zstd')
    original.write_csv(str(directory / 'indicator.csv'))
    shutil.copyfile(ROOT / 'data/schema_ch05.json', directory / 'schema.json')
    types = {'record_id': 'VARCHAR', 'observed_on': 'DATE', 'category': 'VARCHAR',
             'value_minor': 'BIGINT', 'value_state': 'VARCHAR'}
    parquet = db.read_parquet(str(directory / 'indicator.parquet'))
    csv_data = db.read_csv(str(directory / 'indicator.csv'), header=True, columns=types)
    rows = original.fetchall()
    for loaded in (parquet, csv_data):
        assert dict(zip(loaded.columns, map(str, loaded.types))) == types
        assert loaded.order('record_id').fetchall() == rows
    numeric = db.sql('SELECT CAST(record_id AS BIGINT) AS record_id FROM typed05')
    collisions = db.sql("""SELECT CAST(record_id AS BIGINT) AS numeric_id,
        list(record_id ORDER BY record_id) AS original_ids
        FROM typed05 GROUP BY numeric_id HAVING count(*) > 1""").fetchall()
    assert collisions == [(123, ['00123', '123'])]
    json_file(directory / 'schema_diff.json', {
        'check': 'deliberate numeric cast on identifier',
        'field': 'record_id', 'expected': types['record_id'], 'observed': str(numeric.types[0]),
        'collisions': [{'coerced_id': number, 'source_ids': ids} for number, ids in collisions],
        'original_rows': len(rows), 'distinct_numeric_ids': 5,
        'repair': 'Reimport the original token as a text identifier.',
        'parquet_roundtrip': 'passed', 'typed_csv_roundtrip': 'passed',
    })


def diagnostics(db, out):
    asof = db.execute("""SELECT i.invoice_id, f.fx_pp100
        FROM bills06 i ASOF LEFT JOIN rates06 f
          ON i.currency = f.currency AND i.invoice_day >= f.rate_day
        ORDER BY i.invoice_id""").fetchall()
    ranked = db.execute('SELECT invoice_id, fx_pp100 FROM matched06 ORDER BY invoice_id').fetchall()
    assert asof == ranked
    results = {'ranked_and_duckdb_asof_match': True}
    default_frame = db.execute("""SELECT invoice_id, peer_running,
        sum(total_minor) OVER (PARTITION BY customer_id ORDER BY invoice_day) AS implicit_frame
        FROM ledger07 ORDER BY invoice_id""").fetchall()
    results['implicit_ordered_frame_equals_explicit_range'] = all(a == b for _, a, b in default_frame)
    assert results['implicit_ordered_frame_equals_explicit_range']
    (out / 'sample_ledger').mkdir()
    for name, query in {
        'invoice_disposition': 'SELECT * FROM matched06 ORDER BY invoice_id',
        'analytical_invoices': 'SELECT * FROM ledger07 ORDER BY invoice_id',
        'selected_customers': 'SELECT * FROM selected07 ORDER BY customer_id',
        'orphan_invoice_lines': """SELECT l.* FROM lines07 l
            WHERE NOT EXISTS (SELECT 1 FROM headers07 h WHERE h.invoice_id = l.invoice_id)
            ORDER BY invoice_id, line_id""",
        'unmatched_invoice_headers': 'SELECT * FROM joined07 WHERE region IS NULL ORDER BY invoice_id',
        'period_region': """SELECT period, region, count(*) AS invoice_count, sum(total_minor) AS total_minor
            FROM ledger07 GROUP BY period, region ORDER BY period, region""",
        'cohort_activity': """SELECT cohort, period, count(DISTINCT customer_id) AS active_customers
            FROM ledger07 GROUP BY cohort, period ORDER BY cohort, period""",
        'household_members': 'SELECT * FROM people08 ORDER BY hh_id, member_id',
        'plot_register': 'SELECT * FROM plots08 ORDER BY plot_id',
        'duplicate_household_keys': """SELECT hh_id, count(*) AS copies
            FROM ch08_households_defect GROUP BY hh_id HAVING count(*) > 1 ORDER BY hh_id""",
        'orphan_person_keys': """SELECT p.hh_id, p.member_id FROM ch08_members_defect p
            WHERE NOT EXISTS (SELECT 1 FROM ch08_households h WHERE h.hh_id = p.hh_id)
            ORDER BY hh_id, member_id""",
    }.items():
        db.sql(query).write_csv(str(out / 'sample_ledger' / f'{name}.csv'))
    gates = {
        'duplicate_household': 'SELECT count(*) = count(DISTINCT hh_id) FROM ch08_households_defect',
        'orphan_member': """SELECT count(*) = count(h.hh_id)
            FROM ch08_members_defect p LEFT JOIN ch08_households h ON p.hh_id = h.hh_id""",
        'corrected_household': 'SELECT count(*) = count(DISTINCT hh_id) FROM ch08_households',
        'corrected_members': """SELECT count(*) = count(h.hh_id)
            FROM ch08_members p LEFT JOIN ch08_households h ON p.hh_id = h.hh_id""",
    }
    observed = {k: bool(db.execute(q).fetchone()[0]) for k, q in gates.items()}
    assert observed == {'duplicate_household': False, 'orphan_member': False,
                        'corrected_household': True, 'corrected_members': True}
    results['schema_gate_accepts'] = observed
    json_file(out / 'diagnostics.json', results)


def negative_page_checks(out):
    pages = sorted(RAW.glob('ch05_page_*.json'))
    assert len(pages) == 2
    altered = out / 'defective_page.json'
    header, rows = json.loads(pages[1].read_text())
    header['snapshot'] = '2025Q1.2'
    json_file(altered, [header, rows])
    tests = {'missing_page': pages[:1], 'repeated_page': [pages[0], pages[0]],
             'source_revision_drift': [pages[0], altered]}
    observed = {}
    for name, inputs in tests.items():
        try:
            replay(inputs)
        except ValueError as exc:
            observed[name] = {'rejected': True, 'diagnostic': str(exc)}
        else:
            raise ValueError(f'Acquisition accepted the deliberate {name} defect.')
    json_file(out / 'acquisition_defects.json', observed)


def import_stata(archive, inputs, out):
    driver = ROOT / 'stata/part2_driver.do'
    names = {'part2_driver.do': digest(driver), **{
        'input_' + p.name: digest(p) for p in inputs.glob('*.csv')}}
    with ZipFile(archive) as bundle:
        members = {}
        wanted = set(names) | {'part2_metrics.csv', 'part2_run.log', 'run_info.txt'}
        for item in bundle.infolist():
            name = Path(item.filename).name
            if not item.is_dir() and name in wanted:
                if name in members or item.file_size > 2_000_000:
                    raise ValueError(f'Duplicate or oversized evidence member {name}')
                members[name] = bundle.read(item)
    for key in ('run_info.txt', 'part2_run.log'):
        if not members.get(key):
            raise ValueError(f'Missing execution evidence {key}')
    record = dict(line.split('=', 1) for line in members['run_info.txt'].decode('utf-8').splitlines() if '=' in line)
    raw_log = members['part2_run.log'].decode('utf-8', errors='replace')
    clean_log = re.sub(r'(?m)^([ \t]*log:[ \t]*).*$(?:\n>[^\n]*)?', r'\1[local path removed]', raw_log)
    (out / 'stata.log').write_text(clean_log, encoding='utf-8')
    json_file(out / 'stata_runtime.json', record)
    if record.get('part2_rc') != '0' or float(record.get('stata_version', '0')) < 16:
        raise ValueError('The local Stata run did not complete. Read the archived Stata log.')
    if not members.get('part2_metrics.csv'):
        raise ValueError('The completed Stata run lacks metrics.')
    from hashlib import sha256
    for name, expected in names.items():
        if sha256(members.get(name, b'')).hexdigest() != expected:
            raise ValueError(f'Returned Stata input or driver differs from release: {name}')
    (out / 'stata.csv').write_bytes(members['part2_metrics.csv'])
    json_file(out / 'stata_provenance.json', {
        'returned_zip_sha256': digest(archive), 'input_and_driver_sha256': names,
        'original_log_sha256': sha256(members['part2_run.log']).hexdigest(),
        'archived_log_sha256': digest(out / 'stata.log'), 'log_edit': 'Local log paths removed.',
    })
    return record


def main(out, rscript, evidence=None, strict=False):
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    inputs = out / 'input'
    acquisition = prepare(inputs)
    json_file(out / 'acquisition.json', acquisition)
    negative_page_checks(out)
    with duckdb.connect() as db:
        sql_metrics(db, inputs, out)
        exchange(db, out)
        diagnostics(db, out)
        json_file(out / 'benchmark.json', benchmark(db, out))
    engines = {'DuckDB': 'duckdb.csv', 'Python': 'python.csv', 'R': 'r.csv'}
    native([sys.executable, str(ROOT / 'python/part2.py'), str(inputs), str(out / 'python.csv')], out / 'python.log')
    native([rscript, '--vanilla', str(ROOT / 'r/part2.R'), str(inputs), str(out / 'r.csv')], out / 'r.log')
    versions = {'Python': platform.python_version(), 'DuckDB': duckdb.__version__,
                'R': (out / 'r.log').read_text().strip(), 'platform': platform.platform()}
    if evidence:
        versions['Stata'] = import_stata(evidence.resolve(), inputs, out)
        engines['Stata'] = 'stata.csv'
    observed = {name: read_metrics(out / path) for name, path in engines.items()}
    anchors = reference()
    write_csv(out / 'reference.csv', COLUMNS, ((*key, value) for key, value in sorted(anchors.items())))
    checks = [row for name, actual in observed.items() for row in comparisons(name + ' vs reference', anchors, actual)]
    for (name1, left), (name2, right) in combinations(observed.items(), 2):
        checks.extend(comparisons(name1 + ' vs ' + name2, left, right))
    failed = sum(not row[-1] for row in checks)
    write_csv(out / 'comparisons.csv',
              ('comparison', *COLUMNS[:3], 'expected', 'observed', 'difference', 'tolerance', 'passed'), checks)
    sources = [*RAW.glob('*'), *ROOT.glob('*.py'), *ROOT.glob('sql/*.sql'),
               ROOT / 'python/part2.py', ROOT / 'r/part2.R', ROOT / 'stata/part2_driver.do',
               ROOT / 'data/schema_ch05.json', ROOT / 'requirements.txt']
    statuses = {name: 'Verified' if all(row[-1] for row in checks if name in row[0])
                else 'Validation failed' for name in engines}
    statuses.setdefault('Stata', 'Awaiting local execution evidence')
    report = {
        'status': ('Validation failed' if failed else 'Verified in four environments'
                   if evidence else 'Verified in three environments'),
        'engines': statuses, 'versions': versions, 'metrics_per_engine': len(anchors),
        'comparison_count': len(checks), 'failed': failed,
        'count_by_chapter': {f'CH{n:02d}': sum(key[0] == f'CH{n:02d}' for key in anchors) for n in range(5, 9)},
        'numeric_tolerance': {'absolute': str(ABSOLUTE), 'relative': str(RELATIVE)},
        'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sorted(sources)},
        'input_sha256': acquisition['input_sha256'],
        'output_sha256': {str(p.relative_to(out)): digest(p) for p in sorted(out.rglob('*')) if p.is_file()},
    }
    json_file(out / 'verification.json', report)
    print(report['status'], len(checks), 'comparisons', failed, 'failed')
    return 1 if failed else 2 if strict and not evidence else 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--rscript', default=shutil.which('Rscript'))
    parser.add_argument('--stata-evidence', type=Path)
    parser.add_argument('--require-four', action='store_true')
    options = parser.parse_args()
    if not options.rscript:
        parser.error('Provide the Rscript executable with --rscript.')
    sys.exit(main(options.output, options.rscript, options.stata_evidence, options.require_four))
