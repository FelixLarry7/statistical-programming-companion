SELECT CASE WHEN count(*) = count(DISTINCT hh_id)
    AND bool_and(stratum IN ('A','B') AND eligible IN ('0','1'))
    AND bool_and(regexp_full_match(weight10, '[0-9]+') AND CAST(weight10 AS BIGINT) > 0)
    THEN 'ok' ELSE error('Household key or domain violation') END FROM ch08_households;
SELECT CASE WHEN count(*) = count(DISTINCT (m.hh_id, m.member_id)) AND count(*) = count(h.hh_id)
    THEN 'ok' ELSE error('Member key or household link violation') END
FROM ch08_members m LEFT JOIN ch08_households h ON m.hh_id = h.hh_id;
SELECT CASE WHEN count(*) = count(DISTINCT p.plot_id) AND count(*) = count(h.hh_id)
    AND bool_and(p.crop IN ('maize','rice'))
    THEN 'ok' ELSE error('Plot key or domain violation') END
FROM ch08_plots p LEFT JOIN ch08_households h ON p.hh_id = h.hh_id;

CREATE TEMP TABLE people08 AS
SELECT m.hh_id, m.member_id, CAST(m.age AS DOUBLE) AS age,
       CAST(h.weight10 AS BIGINT) AS weight10,
       CASE WHEN h.eligible = '0' THEN 'out_scope'
            WHEN CAST(m.age AS DOUBLE) = -99 THEN 'unknown_age'
            WHEN CAST(m.age AS DOUBLE) BETWEEN 0 AND 110
                 AND CAST(m.age AS DOUBLE) = floor(CAST(m.age AS DOUBLE)) THEN 'known'
            ELSE 'invalid_age' END AS disposition
FROM ch08_members m JOIN ch08_households h ON m.hh_id = h.hh_id;

CREATE TEMP TABLE plots08 AS
SELECT p.plot_id, p.hh_id, CAST(p.area_m2 AS DOUBLE) AS area_m2,
       CASE WHEN h.eligible = '0' THEN 'out_scope'
            WHEN CAST(p.area_m2 AS DOUBLE) > 0 AND isfinite(CAST(p.area_m2 AS DOUBLE))
                 AND CAST(p.area_m2 AS DOUBLE) = floor(CAST(p.area_m2 AS DOUBLE)) THEN 'retained'
            ELSE 'invalid_area' END AS disposition
FROM ch08_plots p JOIN ch08_households h ON p.hh_id = h.hh_id;

CREATE TEMP VIEW joined08 AS
SELECT m.* FROM people08 m JOIN plots08 p ON m.hh_id = p.hh_id
WHERE m.disposition IN ('known', 'unknown_age') AND p.disposition = 'retained';

CREATE TEMP VIEW weights08 AS
SELECT sum(weight10) FILTER (WHERE disposition = 'known') AS known_w,
       sum(weight10) FILTER (WHERE disposition = 'known' AND age < 18) AS child_w,
       sum(weight10) FILTER (WHERE disposition IN ('known','unknown_age')) AS eligible_w
FROM people08;

CREATE TEMP VIEW defect08 AS
SELECT (SELECT count(*) - count(DISTINCT hh_id) FROM ch08_households_defect) AS duplicate_n,
       (SELECT count(*) FROM ch08_members_defect m WHERE NOT EXISTS
        (SELECT 1 FROM ch08_households h WHERE h.hh_id = m.hh_id)) AS orphan_n;

INSERT INTO part2_metrics
SELECT 'CH08', 'defect', 'duplicate_excess', duplicate_n FROM defect08
UNION ALL SELECT 'CH08', 'defect', 'duplicate_gate_rejects', CAST(duplicate_n > 0 AS INTEGER) FROM defect08
UNION ALL SELECT 'CH08', 'defect', 'orphan_members', orphan_n FROM defect08
UNION ALL SELECT 'CH08', 'defect', 'orphan_gate_rejects', CAST(orphan_n > 0 AS INTEGER) FROM defect08
UNION ALL SELECT 'CH08', 'count', 'households', count(*) FROM ch08_households
UNION ALL SELECT 'CH08', 'count', 'eligible_households', count(*) FROM ch08_households WHERE eligible = '1'
UNION ALL SELECT 'CH08', 'count', 'members', count(*) FROM people08
UNION ALL SELECT 'CH08', 'count', 'eligible_members', count(*) FROM people08 WHERE disposition IN ('known','unknown_age')
UNION ALL SELECT 'CH08', 'count', 'known_ages', count(*) FROM people08 WHERE disposition = 'known'
UNION ALL SELECT 'CH08', 'count', 'known_children', count(*) FROM people08 WHERE disposition = 'known' AND age < 18
UNION ALL SELECT 'CH08', 'member_state', hh_id || '/' || member_id || '/' || disposition, 1 FROM people08
UNION ALL SELECT 'CH08', 'weight10', 'known', known_w FROM weights08
UNION ALL SELECT 'CH08', 'weight10', 'children', child_w FROM weights08
UNION ALL SELECT 'CH08', 'weight10', 'eligible', eligible_w FROM weights08
UNION ALL SELECT 'CH08', 'share', 'known_age', child_w/known_w FROM weights08
UNION ALL SELECT 'CH08', 'share', 'unknown_as_adult', child_w/eligible_w FROM weights08
UNION ALL SELECT 'CH08', 'count', 'plots', count(*) FROM plots08
UNION ALL SELECT 'CH08', 'count', 'retained_plots', count(*) FROM plots08 WHERE disposition = 'retained'
UNION ALL SELECT 'CH08', 'total', 'plot_area_m2', sum(area_m2) FROM plots08 WHERE disposition = 'retained'
UNION ALL SELECT 'CH08', 'plot_state', plot_id || '/' || disposition, 1 FROM plots08
UNION ALL SELECT 'CH08', 'count', 'person_plot_join_rows', count(*) FROM joined08
UNION ALL SELECT 'CH08', 'weight10', 'join_known', sum(weight10) FROM joined08 WHERE disposition = 'known'
UNION ALL SELECT 'CH08', 'weight10', 'join_children', sum(weight10) FROM joined08 WHERE disposition = 'known' AND age < 18;
