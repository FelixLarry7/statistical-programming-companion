SELECT CASE WHEN count(*) = count(DISTINCT invoice_id)
    AND bool_and(state IN ('posted', 'returned', 'cancelled') AND currency IN ('USD', 'GHS'))
    AND bool_and(regexp_full_match(quantity, '[0-9]+'))
    AND bool_and(price_minor IS NULL OR regexp_full_match(price_minor, '[0-9]+'))
    THEN 'ok' ELSE error('Invoice key or domain violation') END
FROM ch06_invoices;
SELECT CASE WHEN count(*) = count(DISTINCT (currency, effective_date))
    AND bool_and(regexp_full_match(fx_pp100, '[0-9]+') AND CAST(fx_pp100 AS BIGINT) > 0)
    THEN 'ok' ELSE error('Exchange rate key or domain violation') END
FROM ch06_fx;

CREATE TEMP VIEW bills06 AS
SELECT invoice_id, CAST(invoice_date AS DATE) AS invoice_day, currency, state,
       CAST(quantity AS BIGINT) AS quantity, CAST(price_minor AS BIGINT) AS price_minor
FROM ch06_invoices;
CREATE TEMP VIEW rates06 AS
SELECT currency, CAST(effective_date AS DATE) AS rate_day, CAST(fx_pp100 AS BIGINT) AS fx_pp100
FROM ch06_fx;

SELECT CASE WHEN bool_and(quantity > 0) THEN 'ok' ELSE error('Invoice quantity must be positive') END
FROM bills06;

CREATE TEMP TABLE matched06 AS
WITH candidates AS (
    SELECT i.*, f.fx_pp100,
           row_number() OVER (
               PARTITION BY i.invoice_id ORDER BY f.rate_day DESC NULLS LAST
           ) AS seq
    FROM bills06 i LEFT JOIN rates06 f
      ON i.currency = f.currency AND f.rate_day <= i.invoice_day
)
SELECT * EXCLUDE(seq),
       CASE WHEN state = 'cancelled' THEN 'cancelled'
            WHEN price_minor IS NULL THEN 'missing_price'
            WHEN fx_pp100 IS NULL THEN 'missing_rate'
            ELSE 'retained' END AS disposition
FROM candidates WHERE seq = 1;

CREATE TEMP TABLE net06 AS
WITH numerators AS (
    SELECT *, CAST(quantity AS HUGEINT) * price_minor * fx_pp100 AS numer
    FROM matched06 WHERE disposition = 'retained'
)
SELECT invoice_id, state, fx_pp100,
       CASE WHEN numer >= 9007199254740942 THEN error('Amount exceeds exact range')
            ELSE (CASE WHEN state = 'returned' THEN -1 ELSE 1 END) * ((numer+50)//100)
       END AS net_minor
FROM numerators;

INSERT INTO part2_metrics
SELECT 'CH06', 'invoice_state', invoice_id || '/' || disposition, 1 FROM matched06
UNION ALL SELECT 'CH06', 'count', 'source', count(*) FROM bills06
UNION ALL SELECT 'CH06', 'count', 'retained', count(*) FROM net06
UNION ALL SELECT 'CH06', 'count', 'currency_join_rows', count(*)
    FROM bills06 LEFT JOIN rates06 USING (currency)
UNION ALL SELECT 'CH06', 'net_minor', invoice_id, net_minor FROM net06
UNION ALL SELECT 'CH06', 'rate', invoice_id, fx_pp100 FROM net06
UNION ALL SELECT 'CH06', 'high_flag', invoice_id, CAST(abs(net_minor) > 100000 AS INTEGER) FROM net06
UNION ALL SELECT 'CH06', 'total', 'posted_minor', sum(net_minor) FROM net06 WHERE state = 'posted'
UNION ALL SELECT 'CH06', 'total', 'returned_minor', sum(net_minor) FROM net06 WHERE state = 'returned'
UNION ALL SELECT 'CH06', 'total', 'net_minor', sum(net_minor) FROM net06;

CREATE TEMP VIEW features06 AS
SELECT record_id, partition, CAST(observed_on AS DATE) AS feature_day, CAST(input_value AS DOUBLE) AS x
FROM ch06_features;
SELECT CASE WHEN count(*) = count(DISTINCT record_id)
    AND bool_and(partition IN ('train', 'holdout')) AND bool_and(isfinite(x))
    AND max(feature_day) FILTER (WHERE partition = 'train')
        < min(feature_day) FILTER (WHERE partition = 'holdout')
    THEN 'ok' ELSE error('Feature split or domain violation') END
FROM features06;

CREATE TEMP TABLE scales06 AS
SELECT 'train' AS scope, avg(x) AS mu, stddev_pop(x) AS sigma, count(*) AS n
FROM features06 WHERE partition = 'train'
UNION ALL
SELECT 'full', avg(x), stddev_pop(x), count(*) FROM features06;

SELECT CASE WHEN bool_and(isfinite(sigma) AND sigma > 0)
    THEN 'ok' ELSE error('Feature scale is undefined') END
FROM scales06;

INSERT INTO part2_metrics
SELECT 'CH06', 'scale', scope || '_mean', mu FROM scales06
UNION ALL SELECT 'CH06', 'scale', scope || '_sd', sigma FROM scales06
UNION ALL SELECT 'CH06', 'count', 'train', n FROM scales06 WHERE scope = 'train'
UNION ALL SELECT 'CH06', 'z_' || scope, record_id, (x-mu)/sigma
    FROM scales06 CROSS JOIN features06 WHERE partition = 'holdout';
