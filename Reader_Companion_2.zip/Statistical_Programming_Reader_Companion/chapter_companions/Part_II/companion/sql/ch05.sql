SELECT CASE WHEN count(*) = count(DISTINCT record_id)
    AND bool_and(regexp_full_match(record_id, '[0-9]{1,5}'))
    AND bool_and(category IN ('A', 'B'))
    AND bool_and(regexp_full_match(observed_on, '[0-9]{4}-[0-9]{2}-[0-9]{2}'))
    AND bool_and(value_token = '..' OR regexp_full_match(
        value_token, '([0-9]{1,3}([.][0-9]{3})+|[0-9]+),[0-9]{2}'))
    THEN 'ok' ELSE error('Indicator import violates its schema') END
FROM ch05_import;

CREATE TEMP TABLE typed05 AS
SELECT record_id, CAST(observed_on AS DATE) AS observed_on, category,
       CASE WHEN value_token = '..' THEN NULL
            ELSE CAST(replace(replace(value_token, '.', ''), ',', '') AS BIGINT)
       END AS value_minor,
       CASE WHEN value_token = '..' THEN 'unavailable' ELSE 'observed' END AS value_state
FROM ch05_import;

INSERT INTO part2_metrics
SELECT 'CH05', 'date', record_id, CAST(strftime(observed_on, '%Y%m%d') AS INTEGER) FROM typed05
UNION ALL SELECT 'CH05', 'state', record_id || '/' || value_state, 1 FROM typed05
UNION ALL SELECT 'CH05', 'label', record_id || '/' ||
    CASE category WHEN 'A' THEN 'Field' ELSE 'Office' END, 1 FROM typed05
UNION ALL SELECT 'CH05', 'value_minor', record_id, value_minor FROM typed05 WHERE value_minor IS NOT NULL
UNION ALL SELECT 'CH05', 'count', 'text_ids', count(*) FROM typed05
UNION ALL SELECT 'CH05', 'count', 'integer_ids', count(DISTINCT CAST(record_id AS BIGINT)) FROM typed05
UNION ALL SELECT 'CH05', 'count', 'missing', count(*) - count(value_minor) FROM typed05
UNION ALL SELECT 'CH05', 'total', 'observed_minor', sum(value_minor) FROM typed05;
