# Part II computational companion

**Data Engineering, Management, and Quality Assurance**

Chapters 5–8 of *Statistical Programming and Reproducible Data Science* by Felix Larry Essilfie, PhD. The retained run verifies all four environments. The Stata 17 IC run was executed locally on macOS on 12 November 2026. The checked runner reconciles its exact inputs and driver with DuckDB, Python, base R, and the independently worked answer ledger.

## Reproduce the retained comparison

From this directory, use Python 3.12, the pinned DuckDB version, and an installed R. The R implementation uses base R. Use a fresh output directory for each run.

```sh
python -m pip install -r requirements.txt
python run.py --output results/recheck --require-four \
  --stata-evidence evidence/stata_evidence_replay.zip
```

Use `--rscript /path/to/Rscript` when Rscript is outside the command path. The command executes DuckDB, Python, and R and imports the retained native Stata results. To repeat the native Stata execution, generate a fresh offline kit and follow its local instructions.

```sh
python make_stata_kit.py part2_stata_local_run.zip
```

In a licensed Stata installation, open the extracted folder and run `do run_part2.do`. Supply the resulting ZIP to `--stata-evidence`. The driver declares Stata version 16 syntax. The observed evidence records Stata 17 IC. The retained replay archive has the exact observed numerical results, driver, input files, and a copy of the log with local paths removed.

The strict command returns code 0 after successful four-environment verification. Code 2 indicates a successful three-environment run awaiting Stata evidence. A comparison failure or malformed input returns a nonzero status. Consult the output logs and the corresponding row of the comparison.

## Individual cases and inputs

| Chapter | Native calculation and deliberate change | Key outputs |
|---|---|---|
| 5 | Validate two stored service responses. Compare declared text keys and a coercion to integers. Round-trip a typed CSV and Parquet. | `acquisition.json`, `acquisition_defects.json`, `exchange/`, keyed dates, labels and null states |
| 6 | Select the effective rate, reconcile signed minor units, then compare training-only and full-sample scaling. | Invoice disposition, rate and amount ledger, holdout scores |
| 7 | Reconcile headers and lines, select one customer version, compare row and peer frames, and time equivalent summaries. | Orphan and customer ledgers, invoice and cohort results, analysed plans, `benchmark.json` |
| 8 | Check household keys and links, reject the injected defects, then compare the corrected and shifted denominators. | Person and plot dispositions, defect keys, known-age and shifted weights |

DuckDB executes the four chapter SQL files. Python and base R consume the same frozen landing inputs and calculate their outputs independently. The Stata driver also consumes those inputs. Chapter 5's page retrieval and the Parquet and typed CSV round trips have their own checked acquisition and exchange records. Chapter 7's timings measure DuckDB in the recorded environment.

```sh
python acquire.py replay results/landing
python python/part2.py results/landing python_metrics.csv
Rscript --vanilla r/part2.R results/landing r_metrics.csv
```

The `reference.csv` ledger derives from independent worked answers encoded in `anchors.py`. A successful four-environment run reports 172 metrics per environment and 1,720 comparisons. Each observed result is compared with its reference and with the results from the other engines. The identities, state codes, counts, currency amounts, and integer weights use exact agreement. For the finite scaling values and shares, the allowed difference is 10⁻¹⁰ plus 10⁻¹² times the larger absolute magnitude.

## Evidence and provenance

Read `evidence/verification.json` for runtime versions and all source, landing-input, and output digests. The companion retains the exact per-engine metrics, the full comparison ledger, the native Stata log and runtime record, the schema difference, the SQL plans, and the intermediate disposition files. Benchmark times are environmental observations. A new run can have different timings while preserving the calculation results.

The data dictionary is `data/dictionary.csv`. The acquisition and release dispositions are `data/provenance.json`. `data/schema_ch05.json` is the typed exchange schema. The synthetic files can be regenerated into a new folder with `python fixtures.py results/regenerated` and checked byte for byte against `data/raw`.

For the separate Ghana World Development Indicators example, use a connection with access to the provider.

```sh
python acquire.py fetch-wdi results/ghana_population
```

The optional live example keeps original page bytes and response metadata. Its results are outside the fixed synthetic comparison.

## Chapter 7 SQLite adaptation

Use Python 3.12 and its SQLite module from this directory. Run the Part II
runner first to produce the DuckDB reference in `sample_ledger`.

~~~sh
python sqlite_ch07.py --duckdb-output results/recheck/sample_ledger \
  --output results/ch07-sqlite
~~~

The adaptation uses ISO date text and integer minor units. It preserves the
distinction between the invoice-by-invoice `ROWS` frame and the same-date
`RANGE` frame. The three outputs match the selected customer versions,
orphan line and invoice-level ledger exactly. The fixture tests reject a
line amount that fails header reconciliation.
