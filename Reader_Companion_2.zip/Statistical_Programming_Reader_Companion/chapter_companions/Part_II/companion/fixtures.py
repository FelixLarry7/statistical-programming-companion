"""Write the original deterministic teaching inputs for Part II."""

import argparse
import csv
import json
from pathlib import Path


def csv_file(root, name, header, rows):
    with (root / f'{name}.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(header.split())
        writer.writerows(rows)


def generate(root):
    root.mkdir(parents=True, exist_ok=False)
    indicator = (
        ('00123', '2024-12-31', 'A', '1.234,50'),
        ('123', '2025-01-01', 'B', '4,25'),
        ('00401', '2025-02-28', 'B', '..'),
        ('00402', '2024-02-29', 'A', '0,00'),
        ('00007', '2025-03-01', 'A', '99,95'),
        ('00008', '2025-03-31', 'B', '8,10'),
    )
    fields = ('record_id', 'observed_on', 'category', 'value_token')
    for page in (1, 2):
        body = [{'page': page, 'pages': 2, 'per_page': 3, 'total': 6,
                 'dataset': 'SERVICE-INDEX', 'snapshot': '2025Q1.1',
                 'content_type': 'application/json; charset=utf-8'},
                [dict(zip(fields, row, strict=True)) for row in indicator[3*(page-1):3*page]]]
        (root / f'ch05_page_{page}.json').write_text(json.dumps(body, indent=2) + '\n', encoding='utf-8')

    csv_file(root, 'ch06_invoices', 'invoice_id invoice_date currency state quantity price_minor', (
        ('I01', '2025-01-09', 'USD', 'posted', 2, 1000),
        ('I02', '2025-02-01', 'USD', 'posted', 1, 499),
        ('I03', '2025-02-01', 'USD', 'returned', 1, 499),
        ('I04', '2025-02-02', 'USD', 'cancelled', 1, ''),
        ('I05', '2025-01-31', 'GHS', 'posted', 1, ''),
        ('I06', '2024-12-31', 'USD', 'posted', 1, 500),
        ('I07', '2025-02-05', 'GHS', 'posted', 3, 150000),
        ('I08', '2025-02-06', 'GHS', 'posted', 1, 0),
        ('I09', '2025-01-10', 'USD', 'posted', 1, 99),
        ('I10', '2025-01-10', 'USD', 'returned', 1, 99),
    ))
    csv_file(root, 'ch06_fx', 'currency effective_date fx_pp100', (
        ('USD', '2025-01-01', 1250), ('USD', '2025-02-01', 1300), ('GHS', '2024-01-01', 100),
    ))
    csv_file(root, 'ch06_features', 'record_id partition observed_on input_value', (
        ('F01', 'train', '2025-01-01', 10), ('F02', 'train', '2025-01-02', 20),
        ('F03', 'train', '2025-01-03', 30), ('F04', 'holdout', '2025-02-01', 40),
        ('F05', 'holdout', '2025-02-02', 100),
    ))
    csv_file(root, 'ch07_customers', 'customer_id effective_date version region', (
        ('C01', '2025-01-01', 1, 'Central'), ('C01', '2025-02-01', 2, 'Central'),
        ('C01', '2025-02-01', 3, 'Coastal'), ('C02', '2025-01-01', 1, 'Inland'),
        ('C03', '2025-01-01', 1, 'Coastal'), ('C03', '2025-04-01', 2, 'Inland'),
        ('C04', '2025-01-01', 1, 'Inland'),
    ))
    csv_file(root, 'ch07_invoices', 'invoice_id customer_id invoice_date total_minor', (
        ('T01', 'C01', '2025-01-05', 130), ('T02', 'C01', '2025-01-05', 70),
        ('T03', 'C02', '2025-01-22', 80), ('T04', 'C01', '2025-02-04', 120),
        ('T05', 'C03', '2025-02-20', 60), ('T06', 'C02', '2025-03-05', 90),
        ('T07', 'C03', '2025-03-09', 110), ('T08', 'C09', '2025-03-10', 200),
    ))
    csv_file(root, 'ch07_lines', 'invoice_id line_id amount_minor', (
        ('T01', 'L1', 90), ('T01', 'L2', 40), ('T02', 'L1', 70), ('T03', 'L1', 50),
        ('T03', 'L2', 30), ('T04', 'L1', 120), ('T05', 'L1', 30), ('T05', 'L2', 30),
        ('T06', 'L1', 90), ('T07', 'L1', 100), ('T07', 'L2', 10), ('T08', 'L1', 200),
        ('T99', 'L1', 50),
    ))
    households = (
        ('H01', 'A', 1, 20), ('H02', 'A', 1, 15), ('H03', 'B', 1, 10),
        ('H04', 'B', 0, 25), ('H05', 'A', 1, 30), ('H06', 'B', 1, 20),
    )
    members = (
        ('H01', 'M01', 34), ('H01', 'M02', 12), ('H01', 'M03', 6),
        ('H02', 'M01', 40), ('H02', 'M02', -99), ('H03', 'M01', 17), ('H03', 'M02', 19),
        ('H04', 'M01', 12), ('H05', 'M01', 28), ('H05', 'M02', 14), ('H05', 'M03', 9),
        ('H06', 'M01', 120), ('H06', 'M02', 21),
    )
    csv_file(root, 'ch08_households', 'hh_id stratum eligible weight10', households)
    csv_file(root, 'ch08_members', 'hh_id member_id age', members)
    csv_file(root, 'ch08_plots', 'plot_id hh_id area_m2 crop', (
        ('A01', 'H01', 4000, 'maize'), ('A02', 'H01', 6000, 'rice'),
        ('A03', 'H02', 5000, 'maize'), ('A04', 'H03', 0, 'rice'),
        ('A05', 'H04', 7000, 'maize'), ('A06', 'H06', 2500, 'maize'),
        ('A07', 'H05', 3500, 'maize'),
    ))
    csv_file(root, 'ch08_households_defect', 'hh_id stratum eligible weight10',
             (*households, ('H01', 'A', 1, 23)))
    csv_file(root, 'ch08_members_defect', 'hh_id member_id age', (*members, ('H99', 'M01', 11)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    generate(parser.parse_args().directory)
