"""Package the frozen inputs and native Stata driver for a local licensed run."""

import argparse
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from acquire import ROOT, digest, prepare


def build(out):
    with TemporaryDirectory(prefix='part2-stata-kit-') as temporary:
        folder = Path(temporary)
        prepare(folder / 'inputs')
        files = {f'inputs/{p.name}': p for p in sorted((folder / 'inputs').glob('*.csv'))}
        files.update({name: ROOT / 'stata' / name
                      for name in ('run_part2.do', 'part2_driver.do', 'LOCAL_RUN.md')})
        manifest = ''.join(f'{digest(path)}  {name}\n' for name, path in sorted(files.items()))
        with ZipFile(out, 'w', ZIP_DEFLATED, compresslevel=8) as kit:
            for name, path in sorted(files.items()):
                kit.write(path, 'Part_II_Stata_Local_Run/' + name)
            kit.writestr('Part_II_Stata_Local_Run/SHA256SUMS', manifest)
        with ZipFile(out) as kit:
            if kit.testzip() is not None:
                raise ValueError('The local run kit failed its ZIP check.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    build(parser.parse_args().output)
