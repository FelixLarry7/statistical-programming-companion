"""Native Python implementation of the four Part II cases."""

from collections import Counter, defaultdict
import csv
from datetime import date
import math
from pathlib import Path
import re
import statistics
import sys


def rows(folder, name):
    with (folder / (name + '.csv')).open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def keyed(data, *columns):
    result = {}
    for row in data:
        key = tuple(row[c] for c in columns)
        if any(v == '' for v in key) or key in result:
            raise ValueError(f'Missing or repeated key {key}')
        result[key] = row
    return result


def iso(token):
    result = date.fromisoformat(token)
    if result.isoformat() != token:
        raise ValueError(f'Expected an ISO calendar date, got {token!r}')
    return result


def chapter5(folder, emit):
    data = rows(folder, 'ch05_import')
    keyed(data, 'record_id')
    minor, ids = [], set()
    labels = {'A': 'Field', 'B': 'Office'}
    for row in data:
        key, category, token = row['record_id'], row['category'], row['value_token']
        if not re.fullmatch(r'[0-9]{1,5}', key):
            raise ValueError(f'Invalid text identifier {key!r}')
        ids.add(int(key))
        day = iso(row['observed_on'])
        emit('date', key, day.year*10000 + day.month*100 + day.day)
        emit('label', key + '/' + labels[category], 1)
        if token == '..':
            emit('state', key + '/unavailable', 1)
        else:
            if not re.fullmatch(r'(?:[0-9]{1,3}(?:\.[0-9]{3})+|[0-9]+),[0-9]{2}', token):
                raise ValueError(f'Invalid decimal token at {key}')
            amount = int(token.replace('.', '').replace(',', ''))
            minor.append(amount)
            emit('state', key + '/observed', 1)
            emit('value_minor', key, amount)
    emit('count', 'integer_ids', len(ids))
    emit('count', 'text_ids', len(data))
    emit('count', 'missing', len(data) - len(minor))
    emit('total', 'observed_minor', sum(minor))


def chapter6(folder, emit):
    rates = rows(folder, 'ch06_fx')
    keyed(rates, 'currency', 'effective_date')
    by_currency = defaultdict(list)
    for r in rates:
        value = int(r['fx_pp100'])
        if value <= 0:
            raise ValueError('Expected a strictly positive rate.')
        by_currency[r['currency']].append((iso(r['effective_date']), value))
    bills = rows(folder, 'ch06_invoices')
    keyed(bills, 'invoice_id')
    emit('count', 'source', len(bills))
    emit('count', 'currency_join_rows', sum(max(1, len(by_currency[r['currency']])) for r in bills))
    signed = defaultdict(list)
    for row in bills:
        key, state = row['invoice_id'], row['state']
        day, qty = iso(row['invoice_date']), int(row['quantity'])
        price = int(row['price_minor']) if row['price_minor'] else None
        if qty <= 0 or price is not None and price < 0 or state not in {'posted', 'returned', 'cancelled'}:
            raise ValueError(f'Invalid quantity, price or state at {key}')
        chosen = max((r for r in by_currency[row['currency']] if r[0] <= day), default=None)
        if state == 'cancelled':
            reason = 'cancelled'
        elif price is None:
            reason = 'missing_price'
        elif chosen is None:
            reason = 'missing_rate'
        else:
            reason = 'retained'
            rate = chosen[1]
            num = qty * price * rate
            if num >= 2**53 - 50:
                raise ValueError('Integer numerator exceeds the common exact range.')
            net = ((num + 50) // 100) * (-1 if state == 'returned' else 1)
            signed[state].append(net)
            emit('net_minor', key, net)
            emit('rate', key, rate)
            emit('high_flag', key, int(abs(net) > 100000))
        emit('invoice_state', key + '/' + reason, 1)
    emit('count', 'retained', sum(map(len, signed.values())))
    emit('total', 'posted_minor', sum(signed['posted']))
    emit('total', 'returned_minor', sum(signed['returned']))
    emit('total', 'net_minor', sum(sum(group) for group in signed.values()))

    observations = rows(folder, 'ch06_features')
    keyed(observations, 'record_id')
    if any(r['partition'] not in {'train', 'holdout'} for r in observations):
        raise ValueError('Unexpected partition label.')
    train = [r for r in observations if r['partition'] == 'train']
    holdout = [r for r in observations if r['partition'] == 'holdout']
    if max(iso(r['observed_on']) for r in train) >= min(iso(r['observed_on']) for r in holdout):
        raise ValueError('Training and holdout dates overlap.')
    emit('count', 'train', len(train))
    for label, partition in (('train', train), ('full', observations)):
        values = [int(r['input_value']) for r in partition]
        mean, spread = statistics.mean(values), statistics.pstdev(values)
        if not math.isfinite(spread) or spread <= 0:
            raise ValueError('The scaling rule requires a positive finite standard deviation.')
        emit('scale', label + '_mean', mean)
        emit('scale', label + '_sd', spread)
        for row in holdout:
            emit('z_' + label, row['record_id'], (int(row['input_value']) - mean)/spread)


def chapter7(folder, emit):
    history = rows(folder, 'ch07_customers')
    keyed(history, 'customer_id', 'effective_date', 'version')
    by_customer = defaultdict(list)
    for row in history:
        by_customer[row['customer_id']].append((iso(row['effective_date']), int(row['version']), row['region']))
    cutoff = date(2025, 3, 31)
    selected = {}
    for customer, versions in by_customer.items():
        latest = max((v for v in versions if v[0] <= cutoff), default=None)
        if latest:
            selected[customer] = latest
            emit('customer_version', customer, latest[1])

    bills = keyed(rows(folder, 'ch07_invoices'), 'invoice_id')
    lines = rows(folder, 'ch07_lines')
    keyed(lines, 'invoice_id', 'line_id')
    totals = defaultdict(int)
    orphans = 0
    raw_rows = raw_minor = 0
    for row in lines:
        invoice = row['invoice_id']
        amount = int(row['amount_minor'])
        if (invoice,) not in bills:
            orphans += 1
            continue
        totals[invoice] += amount
        versions = len(by_customer[bills[(invoice,)]['customer_id']])
        raw_rows += versions
        raw_minor += versions * amount
    emit('count', 'headers', len(bills))
    emit('count', 'lines', len(lines))
    emit('count', 'orphan_lines', orphans)
    emit('count', 'raw_join_rows', raw_rows)
    emit('total', 'raw_join_minor', raw_minor)
    emit('total', 'headers_minor', sum(int(r['total_minor']) for r in bills.values()))
    emit('total', 'matched_lines_minor', sum(totals.values()))

    current = defaultdict(list)
    unmatched = []
    for (invoice,), row in bills.items():
        total = int(row['total_minor'])
        if invoice not in totals or totals[invoice] != total:
            raise ValueError(f'Invoice detail does not reconcile at {invoice}')
        customer = row['customer_id']
        if customer not in selected:
            unmatched.append(total)
        else:
            current[customer].append((iso(row['invoice_date']), invoice, total))
    emit('count', 'unmatched_headers', len(unmatched))
    emit('total', 'unmatched_minor', sum(unmatched))
    emit('count', 'retained', sum(map(len, current.values())))
    emit('total', 'retained_minor', sum(amount for bill in current.values() for _, _, amount in bill))

    periods = defaultdict(list)
    activity = defaultdict(set)
    for customer, invoices in sorted(current.items()):
        zone = selected[customer][2]
        ordered = sorted(invoices)
        cohort = ordered[0][0].isoformat()[:7]
        cumulative = 0
        for day, invoice, amount in ordered:
            period = day.isoformat()[:7]
            cumulative += amount
            emit('invoice_minor', invoice, amount)
            emit('region', invoice + '/' + zone, 1)
            emit('rows_running', invoice, cumulative)
            emit('peer_running', invoice, sum(value for d, _, value in invoices if d <= day))
            periods[period + '/' + zone].append(amount)
            activity[cohort + '/' + period].add(customer)
    for key, amounts in periods.items():
        emit('period_n', key, len(amounts))
        emit('period_minor', key, sum(amounts))
    for key, customers in activity.items():
        emit('cohort_active', key, len(customers))


def chapter8(folder, emit):
    households = keyed(rows(folder, 'ch08_households'), 'hh_id')
    for row in households.values():
        if row['eligible'] not in {'0', '1'} or row['stratum'] not in {'A', 'B'} or int(row['weight10']) <= 0:
            raise ValueError('Household domain violation.')
    members = keyed(rows(folder, 'ch08_members'), 'hh_id', 'member_id')
    plots = keyed(rows(folder, 'ch08_plots'), 'plot_id')

    defective_hh = rows(folder, 'ch08_households_defect')
    duplicate_excess = sum(n - 1 for n in Counter(r['hh_id'] for r in defective_hh).values())
    orphan_count = sum((r['hh_id'],) not in households for r in rows(folder, 'ch08_members_defect'))
    emit('defect', 'duplicate_excess', duplicate_excess)
    emit('defect', 'duplicate_gate_rejects', int(duplicate_excess > 0))
    emit('defect', 'orphan_members', orphan_count)
    emit('defect', 'orphan_gate_rejects', int(orphan_count > 0))

    emit('count', 'households', len(households))
    emit('count', 'eligible_households', sum(r['eligible'] == '1' for r in households.values()))
    emit('count', 'members', len(members))
    kept = []
    for (hh, member), row in members.items():
        house = households[(hh,)]
        age = int(row['age']) if row['age'] else None
        if house['eligible'] == '0':
            state = 'out_scope'
        elif age == -99:
            state = 'unknown_age'
        elif age is None or not 0 <= age <= 110:
            state = 'invalid_age'
        else:
            state = 'known'
        emit('member_state', '/'.join((hh, member, state)), 1)
        if state in ('known', 'unknown_age'):
            kept.append((hh, int(house['weight10']), state, age))
    known = [(h, w, age) for h, w, state, age in kept if state == 'known']
    eligible_w = sum(w for _, w, _, _ in kept)
    known_w = sum(w for _, w, _ in known)
    child_w = sum(w for _, w, age in known if age < 18)
    emit('count', 'eligible_members', len(kept))
    emit('count', 'known_ages', len(known))
    emit('count', 'known_children', sum(age < 18 for _, _, age in known))
    emit('weight10', 'eligible', eligible_w)
    emit('weight10', 'known', known_w)
    emit('weight10', 'children', child_w)
    emit('share', 'known_age', child_w / known_w)
    emit('share', 'unknown_as_adult', child_w / eligible_w)

    retain_plots = defaultdict(list)
    emit('count', 'plots', len(plots))
    for (plot,), row in plots.items():
        hh = row['hh_id']
        house = households[(hh,)]
        area = int(row['area_m2']) if row['area_m2'] else 0
        if row['crop'] not in {'maize', 'rice'}:
            raise ValueError(f'Invalid crop at {plot}')
        if house['eligible'] == '0':
            state = 'out_scope'
        elif area <= 0:
            state = 'invalid_area'
        else:
            state = 'retained'
            retain_plots[hh].append(area)
        emit('plot_state', plot + '/' + state, 1)
    emit('count', 'retained_plots', sum(map(len, retain_plots.values())))
    emit('total', 'plot_area_m2', sum(sum(group) for group in retain_plots.values()))
    emit('count', 'person_plot_join_rows', sum(len(retain_plots[h]) for h, _, _, _ in kept))
    emit('weight10', 'join_known', sum(w*len(retain_plots[h]) for h, w, _ in known))
    emit('weight10', 'join_children', sum(w*len(retain_plots[h]) for h, w, age in known if age < 18))


def main(folder, out):
    results = []
    for chapter, solve in enumerate((chapter5, chapter6, chapter7, chapter8), 5):
        def emit(metric, key, value):
            results.append((f'CH{chapter:02d}', metric, key, value))
        solve(folder, emit)
    with out.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(('chapter', 'metric', 'key', 'value'))
        writer.writerows(sorted(results))


if __name__ == '__main__':
    main(*(Path(x) for x in sys.argv[1:]))
