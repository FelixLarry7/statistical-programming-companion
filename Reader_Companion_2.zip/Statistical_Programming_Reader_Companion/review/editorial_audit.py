"""Check the complete editorial source and emit a reproducible Stage 8 record."""
from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / 'manuscript'
chapters = sorted((BOOK / 'chapters').glob('ch*.qmd'))
sources = sorted(BOOK.rglob('*.qmd'))
labels, references, citations = [], [], []
bib = set(re.findall(r'(?m)^@\w+\s*\{\s*([^,]+),', (BOOK / 'references.bib').read_text()))
images = []
for path in sources:
    text = path.read_text()
    labels.extend(re.findall(r'\{#([^}\s]+)', text))
    body = re.sub(r'(?ms)^```.*?^```\s*$', '', text)
    references += re.findall(r'@((?:sec|app|eq|tbl|fig|code)-[A-Za-z0-9_-]+)', body)
    citations += re.findall(r'(?<![\w/])@([A-Za-z][A-Za-z0-9_-]*)', body)
    for link in re.finditer(r'!\[([^\]]*)\]\(([^)]+)\)(\{[^\n]*\})?', text):
        alt, name, attrs = link.groups()
        if name.startswith(('https:', 'http:')):
            continue
        image = (path.parent / name).resolve()
        assert image.is_file(), (path, name)
        assert alt.strip() or (attrs and 'fig-alt=' in attrs), (path, name, 'Missing alternative text')
        images.append(str(image.relative_to(BOOK)))
    assert not any(c in text for c in '¿¡�'), path
    assert not re.search(r'\b(?:TODO|TBD|INSERT HERE|NOT EXECUTED)\b', text), path
duplicates = [x for x, count in Counter(labels).items() if count > 1]
missing_refs = sorted(set(references) - set(labels))
missing_cites = sorted(set(citations) - set(labels) - bib)
assert not duplicates, duplicates
assert not missing_refs, missing_refs
assert not missing_cites, missing_cites
assert len(chapters) == 40
for n, path in enumerate(chapters, 1):
    text = path.read_text()
    headings = re.findall(r'(?m)^## (.*)', text)
    assert headings[0].startswith('Introduction') and headings[1].startswith('Learning objectives'), n
    assert '## Exercises' in text, n
    groups = re.findall(r'(?m)^### ([^\n]+)', text.split('## Exercises', 1)[1])
    assert all(any(x.startswith(expected) for x in groups) for expected in
               ['Conceptual questions', 'Programming exercises', 'Statistical reasoning', 'Cross-platform replication exercises']), (n, groups)
parts = sorted((BOOK / 'parts').glob('part-*.qmd'))
apps = sorted((BOOK / 'back').glob('appendix-*.qmd'))
assert len(parts) == 10 and len(apps) == 21
questions = list(csv.DictReader((ROOT / 'review/exercise_index.csv').open()))
assert len(questions) == 892 and len({q['id'] for q in questions}) == 892
assert len(list((ROOT / 'teaching/solutions').glob('ch*.md'))) == 40
assert (BOOK / 'back/appendix-l.qmd').read_bytes() == (ROOT / 'projects/results/appendix-l.qmd').read_bytes()
project = json.loads((ROOT / 'projects/content.json').read_text())[2]
assert any('three-point' in t for t in project['tasks'])
report = {
    'status': 'PASSED', 'review_date': '2026-11-19',
    'review_type': 'AI-assisted technical and editorial assessment',
    'external_human_sign_off': 'Pending', 'chapters': 40, 'parts': 10, 'appendices': 21,
    'source_files': len(sources), 'unique_source_labels': len(labels),
    'cross_references': len(references), 'bibliography_entries': len(bib),
    'citation_uses': len(citations) - len(references), 'image_uses': len(images),
    'chapter_exercises': len(questions), 'selected_worked_answers': 80,
    'sample_exam_answers': 5, 'project_marking_notes': 12,
    'source_sha256': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in sources}
}
(ROOT / 'review/editorial_audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'source_sha256'}, indent=2))
