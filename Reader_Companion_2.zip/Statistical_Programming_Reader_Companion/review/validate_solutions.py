"""Independently calculate selected solution anchors from inputs or keyed outputs."""
import csv
from decimal import Decimal, ROUND_HALF_UP
import json
import math
from pathlib import Path

import numpy as np
from scipy.special import ndtr
from scipy.stats import norm

ROOT = Path(__file__).resolve().parents[1]
checks = []


def check(chapter, item, calculation, expected, tolerance=1e-9):
    difference = abs(float(calculation) - float(expected))
    assert difference <= tolerance, (chapter, item, calculation, expected)
    checks.append(dict(chapter=chapter, item=item, calculated=float(calculation),
                       expected=float(expected), absolute_error=difference,
                       tolerance=tolerance, status='PASSED'))


def rows(path):
    return list(csv.DictReader((ROOT / path).open()))


def metrics(part):
    return {(r['chapter'], r['model'], r['quantity'], r['key']): float(r['value'])
            for r in rows(f'verification/evidence/Part_{part}/python/metrics.csv')}


pilot = rows('chapter_companions/Part_I/companion/data/maize_pilot.csv')
a, b = pilot[:2]
check(1, 'P001 yield', float(a['harvest_kg']) / float(a['area_ha']), 1190)
check(1, 'P002 yield', float(b['harvest_kg']) / float(b['area_ha']), 1210)
check(1, 'Equal plot mean', (1190 + 1210) / 2, 1200)
check(2, 'Net channel total', 180000 + 190000 + 175000, 545000)
check(3, 'binary32 consecutive integer boundary', np.spacing(np.float32(2**24)), 2)
check(3, 'binary64 consecutive integer boundary', np.spacing(float(2**53)), 2)
check(4, 'Overall completion', 4 / 8, .5)
check(4, 'Observed arm contrast', 3 / 4 - 1 / 4, .5)
check(5, 'Pagination ceiling', math.ceil(109 / 20), 6)
check(6, 'Rounded converted invoice', Decimal('3937.5').quantize(Decimal('1'), rounding=ROUND_HALF_UP), 3938)
check(9, 'Empirical variance', (134 - 36**2 / 11) / 11, 178 / 121)
check(9, 'Sample variance', (134 - 36**2 / 11) / 10, 178 / 110)
check(10, 'Irrigated relative frequencies', sum(x / 6 for x in [0, 0, 2, 2, 2]), 1)
check(10, 'Rainfed relative frequencies', sum(x / 5 for x in [1, 3, 1, 0, 0]), 1)
check(12, 'Combined survey mean', (62260 + 79955) / (1375 + 1185), 55.552734375)
x = np.array([float(r['sessions']) for r in pilot])
y = np.array([float(r['harvest_kg']) / float(r['area_ha']) for r in pilot])
X = np.column_stack([np.ones(len(x)), x])
beta = np.linalg.lstsq(X, y, rcond=None)[0]
check(13, 'Intercept from original plots', beta[0], 1200)
check(13, 'Slope from original plots', beta[1], 80)
check(13, 'RSS from original plots', np.sum((y - X @ beta)**2), 6950)
check(13, 'R squared identity', 1 - np.sum((y - X @ beta)**2) / np.sum((y-y.mean())**2), 224000 / 230950)
check(14, 'Contact odds ratio from display', math.exp(.3339), 1.3964, .00005)
check(14, 'Rural odds ratio from display', math.exp(-.4697), .6252, .00005)
iv = metrics('IV')
c001, = [r for r in rows('chapter_companions/Part_IV/companion/data/raw/censor15.csv') if r['case_id']=='C001']
mu = .9 + .8 * float(c001['resources'])
check(15, 'C001 shared predictor', mu, 1.09214)
check(15, 'C001 censoring probability', ndtr(-mu / 1.2), .18138049291993058)
check(15, 'C001 likelihood contribution', math.log(ndtr(-mu / 1.2)), iv['CH15', 'tobit_eval', 'll', 'C001'])
for model, expected in [('balanced', .9113), ('unbalanced', .9134)]:
    tau, sig = (iv['CH16', model, 'scalar', k] for k in ['tau2', 'sigma2'])
    check(16, model + ' ICC', tau / (tau+sig), expected, .00005)
check(18, 'Size weighted event zero', (2.30*8 + 3.84*10 + 1.70*12) / 30, 2.5733333333333333)
v = metrics('V')
for model in ['strong', 'weak']:
    check(19, model + ' IV ratio', v['CH19', model, 'scalar', 'reduced'] / v['CH19', model, 'scalar', 'first'], v['CH19', model, 'scalar', 'effect'])
for band in ['125', '250', '375']:
    check(19, 'Fuzzy RD ratio bandwidth ' + band, v['CH19', 'rd', 'fuzzy', band] / v['CH19', 'rd', 'receipt', band], v['CH19', 'rd', 'ratio', band])
vii = metrics('VII')
ece = sum(vii['CH27','audit','bin_n',str(b)] * abs(vii['CH27','audit','bin_mean_p',str(b)] - vii['CH27','audit','bin_event_rate',str(b)]) for b in range(1,4)) / 223
check(27, 'ECE with unrounded occupied bins', ece, vii['CH27','audit','scalar','ece'])
viii = metrics('VIII')
for model in ['gps','reported']:
    check(32, model + ' planted area ratio', viii['CH32',model,'scalar','kg'] / viii['CH32',model,'scalar','hectares'], viii['CH32',model,'scalar','ratio'])
check(32, 'Constant harvest numerator', viii['CH32','gps','scalar','kg'], viii['CH32','reported','scalar','kg'])
check(32, 'Area definition yield difference', viii['CH32','gps','scalar','ratio'] - viii['CH32','reported','scalar','ratio'], 92.01782105162301)
mde = (norm.ppf(.975) + norm.ppf(.80)) * 8 * math.sqrt(2 * (1+19*.2)/(24*20))
check(33, 'Planning MDE with rho 0.20', mde, 3.17, .005)
check(35, 'Ten percent log income change', math.log(1.10), .09531017980432493)
check(37, 'Slope from paired pilot', beta[1], 80)
check(38, 'Single outcome slope update', ((x - x.mean()) @ (y + np.eye(1, len(y), 4).ravel() * 10)) / ((x-x.mean()) @ (x-x.mean())) - beta[1], (x[4]-x.mean())*10/35)
check(39, 'Complementary table disclosure', 42-38, 4)
ix = metrics('IX')
check('Exam 1', 'Net revenue overstatement', 690000 - 545000, 145000)
check('Exam 1', 'Overstatement percent', 100*145000/545000, 26.60550458715596)
check('Exam 3', 'Observed cohort response', ix['CH33','arm0','scalar','observed']+ix['CH33','arm1','scalar','observed'], 831)
check('Exam 3', 'Paired effect display', ix['CH33','trial','scalar','estimate'], 4.25, .005)
check('Exam 3', 'Lower completion bound', ix['CH33','trial','scalar','bound_lo'], -9.55, .005)
check('Exam 3', 'Upper completion bound', ix['CH33','trial','scalar','bound_hi'], 17.33, .005)
check('Exam 3', 'Adverse six point departure', ix['CH33','trial','scalar','delta6_lo'], 2.64, .005)
record = {'status':'PASSED', 'numeric_anchors':len(checks), 'selected_worked_answers':80,
          'sample_exam_answers':5, 'derivation_review':'AI-assisted reading of the 80 selected solutions and five examination answers',
          'scope':'These numerical checks supplement the 90 independent formula anchors in the full computational audit. They do not certify worked answers for all 892 exercises.',
          'checks':checks}
(ROOT/'review/solution_verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('Passed',len(checks),'numeric solution anchors')
