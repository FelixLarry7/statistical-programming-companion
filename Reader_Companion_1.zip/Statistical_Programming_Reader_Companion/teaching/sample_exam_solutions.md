# Sample examination solutions and marking guide

The examination in `projects/teaching.md` allows 120 minutes and 100 points.
Credit a correct derivation, calculation or diagnosis together with its
assumptions and interpretation. Use the matching release for numeric values.

## Question 1

20 points for sample and grain

The valid total aggregates event refunds to one row per invoice before
joining the invoice amount. On the Chapter 2 fixture, gross invoice value
is 615,000 pesewas and eligible refunds are 70,000. Net value is therefore
545,000 pesewas over seven invoices. The expanded left join has nine rows
and produces 690,000 pesewas. Its excess is 145,000 pesewas, arising from
repetition of gross values of 120,000 and 25,000. The overstatement relative
to the correct net total is 145,000/545,000, approximately 26.61%. A percentage
relative to the incorrect total has a different denominator.

Award 5 points for the invoice key and correct aggregation order, 5 for
reconciling the refund and invoice totals, 5 for the excess and denominator,
and 5 for preserving the zero-valued fully refunded invoice and identifying
the duplicated keys.

## Question 2

25 points for survey inference

Write the domain mean as N_D/D_D. Its first-order perturbation is
(dN_D - mu_D dD_D)/D_D. An observation's linearised contribution is
q_i = w_i I(i in D)(y_i - mu_D)/D_D. Sum q_i within each sampled PSU.
Within every stratum, estimate variance from the dispersion of those PSU
totals, with its sampled-PSU factor and declared finite population
correction. A PSU outside the domain contributes zero and remains in the
design frame. For a rural–urban contrast, subtract the two contributions
within the same observation before summing by PSU. The operation preserves
the covariance between domain estimators.

Award 7 points for differentiating the ratio, 6 for the observation and PSU
contributions, 5 for retaining the full frame and design degrees of freedom,
4 for the contrast covariance and 3 for a correct statement of the weight
and finite-correction convention. An unknown outcome requires explicit
handling before the zero-contribution operation.

## Question 3

25 points for identification

The Chapter 33 observed-case estimate averages 24 matched village-pair
contrasts. It is 4.25 welfare-score points, with a paired reference interval
from 2.78 to 5.72. The original eligible cohort includes 960 households.
Observed follow-up covers 414 offered and 417 comparison households.
Extending the observed-case contrast to the eligible-cohort ITT needs an
assumption or model for the unobserved outcomes. Completing missing outcomes
within their score support gives limits from about -9.55 to 17.33 points.
Under the adverse six-point missingness departure the estimate falls to
about 2.64 points. Both analyses affect a decision using the chapter's
three-point planning threshold. Record the offer, the follow-up endpoint,
the target cohort and the decision criterion separately.

Award 6 points for the assignment, observation and pair estimation units,
5 for the cohort and response reconciliation, 6 for explaining the missing
outcome assumptions, 5 for the sensitivity or bounds and 3 for the
conditional policy interpretation.

## Question 4

15 points for predictive validation

Choose each filing version using its actual availability date relative to
the scoring date. A quarter-end reference date alone cannot establish that
the data were available. Freeze the next-quarter outcome, feature cutoff,
institution boundary and holdout keys before scoring. The time-valid
Chapter 31 model has holdout AUC 0.835. Later restatements give AUC 0.996
and put a future feature in all 138 holdout rows. The later result measures
a retrospective information set. Report calibration and probability loss
on the same admissible cases when evaluating a deployable model.

Award 5 points for the availability rule, 4 for the outcome and holdout
keys, 4 for diagnosing the 138 future-feature rows and 2 for explaining
what additional probability or threshold evidence the decision needs.

## Question 5

15 points for reproducibility

Start from a fresh extraction. Check the manifest and the country-year
sample, then select the equal-weight model key. Refit or review the
matching verified outputs and compare the estimate, covariance, interval,
weights and row count before rounding. The balanced equal-weight slope is
about -1.33 years per log point and the population-weighted slope is about
2.98. Substituting the latter under the former key should fail the keyed
result check even though that number exists elsewhere in the report.
Preserve both genuine specifications. Save the first divergent key and
the correction in the second-reader log.

Award 4 points for a fresh extraction and sample audit, 5 for complete
model-key and field comparison, 4 for the specific substitution diagnosis,
and 2 for a traceable correction record.
