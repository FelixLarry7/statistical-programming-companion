# Chapter teaching resources

The exercise collection reproduces the tasks from all forty chapters.
The solution guides contain eighty worked answers covering the first
conceptual question and first statistical reasoning item in each chapter.
The five-question sample examination has a separate worked marking guide.
Project-specific design, baseline outputs and scenario instructions are in
`projects/results/portfolio`. Use `review/exercise_index.csv` to locate
an individual question and `projects/teaching.md` for the common rubric.

The selected solutions have the verification scope recorded in the Stage 8
review. A separate external reviewer can use that record and the full
exercise index to extend or certify the instructor material.
