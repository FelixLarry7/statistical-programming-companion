# Statistical Programming and Reproducible Data Science

Felix Larry Essilfie, PhD
Stage 8 reader companion

Use **projects/results/portfolio/** for P01–P12. Each project has a
worksheet, assignment, code and data index, results and written report.
Read **projects/teaching.md** for the syllabus and marking rubric.
Use **data/reader_access.md** to obtain provider-only files and
**data/rights/ATTRIBUTIONS.md** for the original credits.

Start from the extracted package root and verify its files.

    sha256sum -c --quiet MANIFEST.sha256

Restore Python and R as described in **environments/README.md**.
To rebuild the project reports from the included evidence and
independently test the four new Python and DuckDB exercises, run:

    python projects/build.py --output build/project-reports

The per-part READMEs identify the original inputs, executable Python,
R, SQL and local licensed Stata routes. The printed Chapter 37 pilot
and Chapter 40 capstone retain their original tagged bundles. The
archived validation tables and logs accompany the specified baseline.
The full Stage 8 rerun summary, software records and logs are under
**verification/stage8/**. Python, R and DuckDB ran afresh for all ten parts.
Stata used the matched evidence from the original licensed local runs.
For licensed replay, use the case's archived run and the matching
analytical inputs. For a new Stata run, use an installed licensed
copy of Stata and the supplied do-file.

The scoped teaching datasets are included. The Bank of Ghana's full
effective-date values, some bulk source archives and the externally
supplied FAOSTAT values use the provider routes in **data/reader_access.md**.
Controlled microdata use the relevant custodian route. The checked
reference values and checked results remain in the reader archive.

The forty chapter exercise files are in **teaching/exercises/**.
Selected solutions contain eighty worked answers, two per chapter, in
**teaching/solutions/**. The sample examination has five worked answers.
See **review/README.md** for the review scope and outstanding external sign-off.

The forty chapter exercise files are in **teaching/exercises/**.
Selected solutions contain eighty worked answers, two per chapter, in
**teaching/solutions/**. The sample examination has five worked answers.
See **review/README.md** for the review scope and outstanding external sign-off.

The forty chapter exercise files are in **teaching/exercises/**.
Selected solutions contain eighty worked answers, two per chapter, in
**teaching/solutions/**. The sample examination has five worked answers.
See **review/README.md** for the review scope and outstanding external sign-off.
