# Advisory sessions and synthetic maize yield

## Research question and methods

How does measured yield vary with recorded sessions in the teaching sample?
Fit an unweighted regression with intercept, using HC1 covariance and a Student reference.

## Results

| Scenario | Rows | Slope | HC1 SE | Lower | Upper |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline | 12 | 80.00 | 4.66 | 69.62 | 90.38 |
| Corrected harvest | 12 | 81.43 | 3.84 | 72.88 | 89.98 |

The observed slope rises from 80.00 to 81.43
kg/ha per recorded session. Both estimates use the same 12 plot-seasons.

## Interpretation and availability

The fitted relationship describes the synthetic sample. A causal estimate in a real
programme needs independent evidence on attendance, conditions and identification.
The source, figure data and verification record accompany this report.
