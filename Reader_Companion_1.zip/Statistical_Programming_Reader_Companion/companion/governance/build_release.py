"""Create and verify both synthetic disclosure teaching archives."""

import argparse
import csv
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
PART_IX = HERE.parent / "capstone/part_ix"
FIELDS = ("domain", "status", "estimate", "lower_95", "upper_95")
STATES = ("Withheld", "Insufficient precision", "Released")
LOG = b"Synthetic review completed.\nFour domain decisions checked.\n"


def projection(path):
    domains = {}
    with path.open(newline="") as stream:
        for row in csv.DictReader(stream):
            if row["chapter"] == "CH36" and row["model"].startswith("domain") and row["quantity"] == "scalar":
                domains.setdefault(row["model"], {})[row["key"]] = float(row["value"])
    dest = StringIO()
    writer = csv.writer(dest, lineterminator="\n")
    writer.writerow(FIELDS)
    for number in range(1, 5):
        row = domains[f"domain{number}"]
        status = STATES[int(row["status"])]
        values = [f"{row[key]:.6f}" for key in ("estimate", "lo", "hi")] if status == "Released" else [""] * 3
        writer.writerow((f"Domain {number}", status, *values))
    return dest.getvalue().encode()


def notebook():
    return {"nbformat":4, "nbformat_minor":5,
            "metadata":{"kernelspec":{"name":"python3","display_name":"Python 3","language":"python"}},
            "cells":[{"id":"public-review","cell_type":"code","metadata":{},"execution_count":None,"outputs":[],
                      "source":["from pathlib import Path\n","print(Path('public_domains.csv').read_text())"]}]}


def pack(path, files):
    with ZipFile(path, "w") as z:
        for name, data in sorted(files.items()):
            info = ZipInfo(name, (2026, 11, 13, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            z.writestr(info, data)


def review(path, approved):
    issues = []
    with ZipFile(path) as z:
        members = z.namelist()
        if set(members) != approved.keys() or len(members) != len(approved):
            return ["Archive membership or uniqueness failed"]
        if z.testzip():
            return ["Archive integrity failed"]
        for name, expected in approved.items():
            if z.read(name) != expected:
                issues.append(f"{name}: differs from approved content")
        reader = csv.DictReader(StringIO(z.read("public_domains.csv").decode()))
        rows = list(reader)
        if tuple(reader.fieldnames or ()) != FIELDS or [r["status"] for r in rows] != [
                "Released","Released","Insufficient precision","Withheld"]:
            issues.append("Public projection has an unexpected schema or status")
        for r in rows:
            values = [r[k] for k in FIELDS[2:]]
            if r["status"] == "Released":
                est, low, high = map(float,values)
                if not 0 <= low <= est <= high <= 1:
                    issues.append("Invalid interval for a released domain")
            elif any(values):
                issues.append("Unreleased domain exposes numerical fields")
    return issues


def build(output):
    metrics = PART_IX / "evidence/python/metrics.csv"
    households = (PART_IX / "data/welfare36.csv").read_bytes()
    allowed = {
        "data_availability.md": (HERE / "data_availability.md").read_bytes(),
        "permissions.csv": (HERE / "permissions.csv").read_bytes(),
        "release_policy.md": (PART_IX / "design/ch36_release_rules.md").read_bytes(),
        "public_domains.csv": projection(metrics),
        "release.log": LOG,
        "public_review.ipynb": (json.dumps(notebook(),indent=2) + "\n").encode(),
    }
    synthetic = households.splitlines()[1].decode() + "\n"
    bad = notebook()
    bad["cells"][0].update(execution_count=1,outputs=[{"name":"stdout","output_type":"stream","text":[synthetic]}])
    defective = output / "temporary_seeded_defect.zip"
    pack(defective,{**allowed,"release.log":LOG + synthetic.encode(),"public_review.ipynb":json.dumps(bad).encode()})
    try:
        faults = review(defective,allowed)
    finally:
        defective.unlink()
    if sorted(r.split(":")[0] for r in faults) != ["public_review.ipynb","release.log"]:
        raise ValueError(f"Negative control did not detect both seeded fields: {faults}")
    public = output / "CH39_Public_Teaching_Release.zip"
    pack(public, allowed)
    if issues := review(public,allowed):
        raise ValueError(issues)
    controlled = output / "CH39_Mock_Authorised_Tier.zip"
    with metrics.open(newline="") as stream:
        reader = csv.DictReader(stream)
        data = StringIO()
        writer = csv.DictWriter(data,fieldnames=reader.fieldnames,lineterminator="\n")
        writer.writeheader()
        writer.writerows(row for row in reader if row["chapter"] == "CH36")
    pack(controlled, {
        "README.md": b"# Mock authorised tier\n\nSynthetic data and Chapter 36 metrics for a teaching rerun.\n",
        "welfare36.csv": households, "chapter36_metrics.csv": data.getvalue().encode(),
        "release_policy.md": allowed["release_policy.md"], "permissions.csv": allowed["permissions.csv"],
    })
    (output / "public_domains.csv").write_bytes(allowed["public_domains.csv"])
    (output / "disclosure_audit.json").write_text(json.dumps({
        "seeded_faults_detected":faults, "corrected_archive_issues":[], "public_members":sorted(allowed),
        "public_domains":4, "released_numeric_domains":2,
        "archive_sha256":{p.name:sha256(p.read_bytes()).hexdigest() for p in (public,controlled)},
    },indent=2)+"\n")
    print("Both seeded defects detected; corrected public archive passed.")


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,default=HERE/"outputs")
    a=p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    build(a.output)
