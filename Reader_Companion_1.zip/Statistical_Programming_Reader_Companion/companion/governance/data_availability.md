# Data availability

The public teaching archive includes the reviewed domain table, an empty
notebook shell, the release policy and permissions record. The separately
packaged mock authorised tier includes the synthetic household fixture and
complete Chapter 36 metric ledger. No real participant records are used.
Both routes are included for instruction. An empirical study would identify
the actual data owner, application procedure, permitted environment,
retention period and required output review.
