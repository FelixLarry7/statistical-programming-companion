-- Explicit source schema and lossless validation precede eligibility filtering.
CREATE TEMP TABLE source_plots AS
SELECT * FROM read_csv(getvariable('plots_path'), auto_detect = false, header = true,
    delim = ',', nullstr = '', columns = {'plot_id': 'VARCHAR', 'area_m2': 'VARCHAR'});

CREATE TEMP TABLE source_seasons AS
SELECT * FROM read_csv(getvariable('seasons_path'), auto_detect = false, header = true,
    delim = ',', nullstr = '', columns = {'plot_id': 'VARCHAR', 'season': 'VARCHAR',
    'harvest_kg': 'VARCHAR', 'sessions': 'VARCHAR'});

CREATE TEMP TABLE raw_plots AS
SELECT plot_id, TRY_CAST(area_m2 AS DOUBLE) AS area_m2, area_m2 AS area_text
FROM source_plots;

CREATE TEMP TABLE raw_seasons AS
SELECT plot_id, TRY_CAST(season AS INTEGER) AS season,
    TRY_CAST(harvest_kg AS DOUBLE) AS harvest_kg, TRY_CAST(sessions AS INTEGER) AS sessions,
    season AS season_text, harvest_kg AS harvest_text, sessions AS sessions_text
FROM source_seasons;

CREATE TEMP TABLE source_issues AS
SELECT 'empty_input' AS issue,
    CAST((SELECT count(*) FROM raw_plots) = 0 OR (SELECT count(*) FROM raw_seasons) = 0 AS BIGINT) AS affected
UNION ALL SELECT 'invalid_plot_identifier', count(*) FROM (
    SELECT plot_id FROM raw_plots UNION ALL SELECT plot_id FROM raw_seasons
) WHERE plot_id IS NULL OR plot_id = '' OR plot_id <> trim(plot_id)
UNION ALL SELECT 'duplicate_plot_key', count(*) FROM (
    SELECT plot_id FROM raw_plots GROUP BY plot_id HAVING count(*) > 1
)
UNION ALL SELECT 'invalid_season', count(*) FROM raw_seasons
    WHERE season IS NULL OR NOT regexp_full_match(season_text, '[0-9]{4}')
UNION ALL SELECT 'duplicate_plot_season_key', count(*) FROM (
    SELECT plot_id, season FROM raw_seasons GROUP BY plot_id, season HAVING count(*) > 1
)
UNION ALL SELECT 'orphan_plot', count(*) FROM raw_seasons AS s
    ANTI JOIN raw_plots AS p ON s.plot_id = p.plot_id
UNION ALL SELECT 'invalid_area_value', count(*) FROM raw_plots
    WHERE area_text IS NOT NULL AND (area_m2 IS NULL OR NOT isfinite(area_m2) OR area_m2 < 0)
UNION ALL SELECT 'invalid_harvest_value', count(*) FROM raw_seasons
    WHERE harvest_text IS NOT NULL AND (harvest_kg IS NULL OR NOT isfinite(harvest_kg) OR harvest_kg < 0)
UNION ALL SELECT 'invalid_session_value', count(*) FROM raw_seasons
    WHERE sessions_text IS NOT NULL AND (sessions IS NULL OR
        NOT regexp_full_match(sessions_text, '[0-9]+') OR sessions NOT BETWEEN 0 AND 5);

SELECT CASE WHEN count(*) = 0 THEN TRUE ELSE error('Source contract violated: ' ||
    string_agg(issue || '=' || CAST(affected AS VARCHAR), ', ' ORDER BY issue)) END
FROM source_issues WHERE affected > 0;

CREATE TEMP TABLE eligible_rows AS
SELECT s.plot_id, s.season, p.area_m2, s.harvest_kg, s.sessions,
    CASE WHEN s.season <> getvariable('target_season') THEN 'outside_season'
         WHEN p.area_m2 IS NULL OR p.area_m2 = 0 THEN 'invalid_area'
         WHEN s.harvest_kg IS NULL THEN 'missing_harvest'
         WHEN s.sessions IS NULL THEN 'missing_sessions'
         ELSE 'included' END AS reason
FROM raw_seasons AS s INNER JOIN raw_plots AS p USING (plot_id);

SELECT CASE WHEN (SELECT count(*) FROM eligible_rows) = (SELECT count(*) FROM raw_seasons)
    THEN TRUE ELSE error('Join changed season-row cardinality') END;

CREATE TEMP TABLE analytical AS
SELECT plot_id, season, area_m2 / 10000.0 AS area_ha, harvest_kg, sessions,
    harvest_kg / (area_m2 / 10000.0) AS yield_kg_ha
FROM eligible_rows WHERE reason = 'included';

SELECT CASE WHEN count(*) FILTER (WHERE NOT isfinite(yield_kg_ha)) = 0
    THEN TRUE ELSE error('Non-finite yield after unit conversion') END
FROM analytical;
