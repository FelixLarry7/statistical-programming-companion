-- SQL estimates and covariance anchors for a full-rank simple OLS fit.
-- regr_* takes the response first, then the predictor.
CREATE TEMP TABLE ols_summary AS
SELECT count(*) AS nobs, avg(sessions) AS x_mean, avg(yield_kg_ha) AS y_mean,
    regr_intercept(yield_kg_ha, sessions) AS intercept,
    regr_slope(yield_kg_ha, sessions) AS slope,
    regr_r2(yield_kg_ha, sessions) AS r_squared
FROM analytical;

SELECT CASE WHEN nobs > 2 AND slope IS NOT NULL AND isfinite(slope)
    THEN TRUE ELSE error('Simple OLS requires more than two rows and nonconstant sessions') END
FROM ols_summary;

CREATE TEMP TABLE ols_predictions AS
SELECT a.plot_id, a.season, a.sessions, a.yield_kg_ha,
    s.intercept + s.slope * a.sessions AS fitted,
    a.yield_kg_ha - (s.intercept + s.slope * a.sessions) AS residual
FROM analytical AS a CROSS JOIN ols_summary AS s;

CREATE TEMP TABLE ols_fit AS
SELECT s.nobs, 2 AS rank, s.nobs - 2 AS df_resid,
    sum(p.residual * p.residual) AS sse,
    sum(pow(p.yield_kg_ha - s.y_mean, 2)) AS sst,
    s.r_squared, s.x_mean, s.y_mean, sum(pow(p.sessions - s.x_mean, 2)) AS sxx
FROM ols_predictions AS p CROSS JOIN ols_summary AS s
GROUP BY s.nobs, s.r_squared, s.x_mean, s.y_mean;

-- OLS coefficient weights give the full 2 x 2 sandwich in scalar form.
CREATE TEMP TABLE ols_covariance AS
WITH slope_weights AS (
    SELECT (p.sessions - f.x_mean) / f.sxx AS w_slope,
        p.residual, f.nobs, f.x_mean, f.sse, f.df_resid
    FROM ols_predictions AS p CROSS JOIN ols_fit AS f
), weights AS (
    SELECT *, 1.0 / nobs - x_mean * w_slope AS w_intercept FROM slope_weights
), products AS (
    SELECT a.parameter AS parameter_1, b.parameter AS parameter_2,
        a.weight * b.weight AS weight_product, w.residual, w.nobs, w.sse, w.df_resid
    FROM weights AS w
    CROSS JOIN LATERAL (VALUES ('intercept', w.w_intercept), ('sessions', w.w_slope)) AS a(parameter, weight)
    CROSS JOIN LATERAL (VALUES ('intercept', w.w_intercept), ('sessions', w.w_slope)) AS b(parameter, weight)
)
SELECT 'classical' AS covariance, parameter_1, parameter_2,
    sum(weight_product * sse / df_resid) AS value
FROM products GROUP BY parameter_1, parameter_2
UNION ALL
SELECT 'HC1', parameter_1, parameter_2,
    sum(weight_product * residual * residual * nobs / df_resid)
FROM products GROUP BY parameter_1, parameter_2;

CREATE TEMP TABLE ols_coefficients AS
SELECT c.covariance, c.parameter_1 AS parameter,
    CASE WHEN c.parameter_1 = 'intercept' THEN s.intercept ELSE s.slope END AS estimate,
    sqrt(c.value) AS std_error
FROM ols_covariance AS c CROSS JOIN ols_summary AS s
WHERE c.parameter_1 = c.parameter_2;
