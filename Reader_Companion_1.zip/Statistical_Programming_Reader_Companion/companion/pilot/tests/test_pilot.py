"""Focused source and discrepancy tests required by the Stage 2 specification."""

import csv
import math
import json
from pathlib import Path
import shutil
import tempfile
import unittest

import duckdb

from fixtures.generate import generate
from python.pilot.fit_ols import fit
from sql.pilot.run import build, check_model, run
from verification.validate import compare, read_outputs, reference, verify_sample

ROOT = Path(__file__).resolve().parents[1]
SPEC = json.loads((ROOT / 'spec/pilot.json').read_text(encoding='utf-8'))
SEASON = SPEC['target_season']


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='stage2-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.raw = self.root / 'raw'
        shutil.copytree(ROOT / 'data/raw', self.raw)

    def append(self, name, line):
        with (self.raw / name).open('a', encoding='utf-8') as stream:
            stream.write(line + '\n')

    def replace(self, name, old, new):
        path = self.raw / name
        text = path.read_text(encoding='utf-8')
        self.assertEqual(text.count(old), 1)
        path.write_text(text.replace(old, new), encoding='utf-8')

    def rejects(self, pattern):
        with duckdb.connect(':memory:') as con, self.assertRaisesRegex(duckdb.Error, pattern):
            build(con, self.raw, SEASON)

    def test_raw_fixture_is_byte_reproducible(self):
        generated = self.root / 'regenerated'
        generate(generated)
        for name in ('plots.csv', 'season_records.csv'):
            self.assertEqual((generated / name).read_bytes(), (self.raw / name).read_bytes())

    def test_known_sample_and_covariance_invariants(self):
        out = self.root / 'sql'
        run(self.raw, out, SEASON)
        expected = reference(SEASON)
        sample = verify_sample(out, SPEC, expected)
        self.assertEqual((sample['included'], sample['excluded']), (12, 4))
        actual = read_outputs(out, inference=False)
        checks = list(compare(expected, actual, SPEC, 'design reference', 'DuckDB', expected_scope=True))
        self.assertTrue(checks and all(check['passed'] for check in checks))

    def test_duplicate_plot_is_rejected(self):
        self.append('plots.csv', 'P001,5000')
        self.rejects('duplicate_plot_key')

    def test_duplicate_plot_season_is_rejected(self):
        self.append('season_records.csv', 'P001,2025,595.0,0')
        self.rejects('duplicate_plot_season_key')

    def test_orphan_plot_is_rejected(self):
        self.append('season_records.csv', 'P999,2025,500.0,0')
        self.rejects('orphan_plot')

    def test_nonfinite_area_is_rejected(self):
        self.replace('plots.csv', 'P013,0', 'P013,inf')
        self.rejects('invalid_area_value')

    def test_fractional_session_is_rejected(self):
        self.replace('season_records.csv', 'P001,2025,595.0,0', 'P001,2025,595.0,0.5')
        self.rejects('invalid_session_value')

    def test_null_area_excluded_and_valid_zero_harvest_retained(self):
        self.replace('plots.csv', 'P013,0', 'P013,')
        self.replace('season_records.csv', 'P001,2025,595.0,0', 'P001,2025,0.0,0')
        with duckdb.connect(':memory:') as con:
            build(con, self.raw, SEASON)
            self.assertEqual(con.execute("SELECT reason FROM eligible_rows WHERE plot_id = 'P013'").fetchone()[0],
                             'invalid_area')
            self.assertEqual(con.execute("SELECT yield_kg_ha FROM analytical WHERE plot_id = 'P001'").fetchone()[0], 0.0)

    def test_reversed_regression_arguments_are_detected(self):
        with duckdb.connect(':memory:') as con:
            build(con, self.raw, SEASON)
            check_model(con, reverse_args=True)
            slope = con.execute('SELECT slope FROM ols_summary').fetchone()[0]
        self.assertFalse(math.isclose(slope, 80.0, rel_tol=1e-10, abs_tol=1e-8))
        print(f'Injected argument reversal: slope={slope:.12f}, expected 80.0')

    def test_hc0_substitution_is_detected(self):
        sql = self.root / 'sql'
        run(self.raw, sql, SEASON)
        baseline, changed = self.root / 'baseline', self.root / 'changed'
        fit(sql / 'analytical.csv', baseline)
        fit(sql / 'analytical.csv', changed, cov_type='HC0')
        rows = list(compare(reference(SEASON), read_outputs(changed, inference=True), SPEC,
                            'design reference', 'Python', expected_scope=True))
        self.assertTrue(any(not check['passed'] and check['key'] == 'HC1/sessions'
                            and check['field'] == 'std_error' for check in rows))
        def slope_se(folder):
            with (folder / 'coefficients.csv').open(encoding='utf-8') as stream:
                row = next(r for r in csv.DictReader(stream) if r['covariance'] == 'HC1' and r['parameter'] == 'sessions')
                return float(row['std_error'])
        ratio = slope_se(baseline) / slope_se(changed)
        self.assertAlmostEqual(ratio, math.sqrt(12 / 10), places=12)
        print(f'Injected HC0 substitution: HC1/HC0 slope SE ratio={ratio:.12f}')
