"""Check the fixture and outputs against an independent analytical reference."""

import csv
from fractions import Fraction
import itertools
import json
import math
from pathlib import Path

from mpmath import mp

PARAMETERS = ('intercept', 'sessions')
METHODS = ('classical', 'HC1')
FIT_FIELDS = ('nobs', 'rank', 'df_resid', 'sse', 'sst', 'r_squared', 'x_mean', 'y_mean', 'sxx')
INFERENCE = ('t_value', 'df_resid', 'p_value', 'ci_low', 'ci_high')


def csv_index(path, keys, fields):
    with path.open(newline='', encoding='utf-8') as stream:
        table = csv.DictReader(stream)
        if set(table.fieldnames or []) != set(keys + fields) or len(table.fieldnames or []) != len(keys + fields):
            raise ValueError(f'Unexpected columns in {path.name}: {table.fieldnames}')
        indexed = {}
        for row in table:
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'Malformed row in {path.name}')
            key = tuple(row[k].strip() for k in keys)
            if key in indexed:
                raise ValueError(f'Duplicate output key in {path.name}: {key}')
            indexed[key] = {field: row[field] for field in fields}
        return indexed


def write_csv(path, fields, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)


def reference(season):
    """Construct the reference from the design, not from the input or engine files."""
    n, df = 12, 10
    mean_x = Fraction(5, 2)
    sxx = Fraction(35)
    residual_square_sum = Fraction(6950)
    total_square_sum = Fraction(230950)
    covariances = {method: [[Fraction(0) for _ in PARAMETERS] for _ in PARAMETERS] for method in METHODS}
    predictions = {}
    for x in range(6):
        weights = (Fraction(1, n) - mean_x * (x - mean_x) / sxx, (x - mean_x) / sxx)
        for i, sign in enumerate((-1, 1), 1):
            fitted = 1200 + 80 * x
            residual = sign * (10 + 5 * x)
            key = (f'P{2*x+i:03}', str(season))
            predictions[key] = {'sessions': x, 'yield_kg_ha': fitted + residual,
                                'fitted': fitted, 'residual': residual}
            for r, c in itertools.product(range(2), repeat=2):
                weight_product = weights[r] * weights[c]
                covariances['classical'][r][c] += weight_product * residual_square_sum / df
                covariances['HC1'][r][c] += weight_product * residual**2 * Fraction(n, df)
    assert covariances['classical'][1][1] == Fraction(139, 7)
    assert covariances['HC1'][1][1] == Fraction(759, 35)

    with mp.workdps(60):
        def two_tailed(t):
            return mp.betainc(mp.mpf(df) / 2, mp.mpf('0.5'), 0, df / (df + t*t), regularized=True)

        critical = mp.findroot(lambda t: two_tailed(t) - mp.mpf('0.05'), (mp.mpf('2'), mp.mpf('3')))
        coefficients = {}
        covariance_rows = {}
        for method in METHODS:
            for r, (term, estimate) in enumerate(zip(PARAMETERS, (1200, 80))):
                variance = covariances[method][r][r]
                se = mp.sqrt(mp.mpf(variance.numerator) / variance.denominator)
                t = estimate / se
                coefficients[method, term] = dict(estimate=estimate, std_error=float(se), t_value=float(t),
                    df_resid=df, p_value=float(two_tailed(abs(t))), ci_low=float(estimate - critical * se),
                    ci_high=float(estimate + critical * se))
                for c, other in enumerate(PARAMETERS):
                    covariance_rows[method, term, other] = {'value': float(covariances[method][r][c])}
    fit = dict(nobs=n, rank=2, df_resid=df, sse=float(residual_square_sum), sst=float(total_square_sum),
               r_squared=float(1 - residual_square_sum / total_square_sum), x_mean=float(mean_x), y_mean=1400,
               sxx=float(sxx))
    return {'fit': {(): fit}, 'coefficients': coefficients, 'covariance': covariance_rows,
            'predictions': predictions}


def verify_sample(folder, spec, expected):
    season = str(spec['target_season'])
    values = ('area_ha', 'harvest_kg', 'sessions', 'yield_kg_ha')
    observed = csv_index(folder / 'analytical.csv', ('plot_id', 'season'), values)
    prediction = expected['predictions']
    if list(observed) != list(prediction) or len(observed) != spec['expected_analytical_rows']:
        raise ValueError('Ordered sample membership differs from the declared fixture')
    for key, row in observed.items():
        area = 0.5 if int(key[0][1:]) % 2 else 1.0
        yield_value = prediction[key]['yield_kg_ha']
        required = (area, area * yield_value, prediction[key]['sessions'], yield_value)
        if tuple(float(row[f]) for f in values) != required:
            raise ValueError(f'Analytical input, units or coding differs for {key}')

    audit = csv_index(folder / 'sample_audit.csv', ('plot_id', 'season'), ('included', 'reason'))
    expected_audit = {key: ('true', 'included') for key in prediction}
    for plot, reason in spec['expected_exclusions'].items():
        expected_audit[plot, str(int(season) - 1) if reason == 'outside_season' else season] = ('false', reason)
    audit_normalized = {k: (v['included'].lower(), v['reason']) for k, v in audit.items()}
    if audit_normalized != expected_audit:
        raise ValueError('Sample audit differs from the declared exclusions and eligibility')
    issues = csv_index(folder / 'source_issues.csv', ('issue',), ('affected',))
    if any(int(v['affected']) != 0 for v in issues.values()):
        raise ValueError('A source-contract issue reached the estimation sample')
    return {'included': len(observed), 'excluded': len(audit) - len(observed),
            'exclusions': spec['expected_exclusions'], 'session_counts': {str(x): 2 for x in range(6)}}


def read_outputs(path, inference):
    fields = ('estimate', 'std_error') + (INFERENCE if inference else ())
    fit = json.loads((path / 'fit.json').read_text(encoding='utf-8'))
    if set(fit) != set(FIT_FIELDS):
        raise ValueError('Unexpected fit summary fields')
    return {'fit': {(): fit},
        'coefficients': csv_index(path / 'coefficients.csv', ('covariance', 'parameter'), fields),
        'covariance': csv_index(path / 'covariance.csv', ('covariance', 'parameter_1', 'parameter_2'), ('value',)),
        'predictions': csv_index(path / 'predictions.csv', ('plot_id', 'season'),
                                 ('sessions', 'yield_kg_ha', 'fitted', 'residual'))}


def compare_number(expected, observed, field, tolerance):
    x, y = float(expected), float(observed)
    if not math.isfinite(x) or not math.isfinite(y):
        raise ValueError(f'Required {field} is non-finite')
    difference = abs(x-y)
    if field in {'nobs', 'rank', 'df_resid', 'sessions', 'yield_kg_ha'}:
        limit = 0.0
    else:
        rules = tolerance['p_value'] if field == 'p_value' else tolerance['standard']
        limit = rules['absolute'] + rules['relative'] * max(abs(x), abs(y))
    return difference, limit, difference <= limit


def compare(left, right, spec, left_name, right_name, *, expected_scope):
    for table, left_rows in left.items():
        right_rows = right[table]
        if set(left_rows) != set(right_rows):
            raise ValueError(f'{right_name} {table} keys differ from {left_name}')
        for key, row in left_rows.items():
            fields = set(row) & set(right_rows[key])
            if expected_scope:
                required = set(row)
                if right_name == 'DuckDB' and table == 'coefficients':
                    required -= set(INFERENCE)
                if fields != required:
                    raise ValueError(f'{right_name} {table} fields differ from its declared scope')
            for field in sorted(fields):
                x, y = row[field], right_rows[key][field]
                diff, limit, passed = compare_number(x, y, field, spec['tolerance'])
                yield {'left_engine': left_name, 'right_engine': right_name, 'table': table,
                       'key': '/'.join(key), 'field': field, 'left_value': x, 'right_value': y,
                       'absolute_difference': diff, 'limit': limit, 'passed': passed}
                if field == 'p_value':
                    reject_x = float(x) < (1 - spec['confidence_level'])
                    reject_y = float(y) < (1 - spec['confidence_level'])
                    yield {'left_engine': left_name, 'right_engine': right_name, 'table': table,
                           'key': '/'.join(key), 'field': 'reject_at_alpha', 'left_value': reject_x,
                           'right_value': reject_y, 'absolute_difference': int(reject_x != reject_y),
                           'limit': 0, 'passed': reject_x == reject_y}


def validate(run_dir, spec, execution, *, engine_dirs=None):
    expected = reference(spec['target_season'])
    sample = verify_sample(run_dir / 'duckdb', spec, expected)
    reference_checks, pairwise = [], []
    valid_outputs = {}
    results = {}
    default_dirs = {'DuckDB': run_dir / 'duckdb', 'Python': run_dir / 'python',
                    'R': run_dir / 'r', 'Stata': run_dir / 'stata'}
    if engine_dirs is not None:
        default_dirs.update(engine_dirs)
    for engine, event in execution.items():
        if event['status'] != 'EXECUTED':
            results[engine] = {'status': event['status'], 'reason': event.get('reason', ''), 'checks': 0}
            continue
        try:
            data = read_outputs(default_dirs[engine], inference=engine != 'DuckDB')
            rows = list(compare(expected, data, spec, 'design reference', engine, expected_scope=True))
            reference_checks.extend(rows)
            n_failed = sum(not row['passed'] for row in rows)
            results[engine] = {'status': 'FAILED VALIDATION' if n_failed else 'VERIFIED',
                               'checks': len(rows), 'failed_checks': n_failed,
                               'scope': 'sample, OLS and covariance anchors' if engine == 'DuckDB'
                               else 'sample, OLS, covariance and t inference'}
            if not n_failed:
                valid_outputs[engine] = data
        except (ValueError, TypeError, KeyError, OSError) as error:
            results[engine] = {'status': 'FAILED VALIDATION', 'reason': str(error), 'checks': 0}

    for left, right in itertools.combinations(valid_outputs, 2):
        pairwise.extend(compare(valid_outputs[left], valid_outputs[right], spec, left, right, expected_scope=False))
    columns = ['left_engine', 'right_engine', 'table', 'key', 'field', 'left_value', 'right_value',
               'absolute_difference', 'limit', 'passed']
    write_csv(run_dir / 'reference_checks.csv', columns, reference_checks)
    write_csv(run_dir / 'cross_environment.csv', columns, pairwise)
    reference_values = {'fit': expected['fit'][()],
                        'coefficients': {'/'.join(k): v for k, v in expected['coefficients'].items()},
                        'covariance': {'/'.join(k): v for k, v in expected['covariance'].items()}}
    (run_dir / 'analytical_reference.json').write_text(json.dumps(reference_values, indent=2) + '\n', encoding='utf-8')
    failed_pairs = sum(not check['passed'] for check in pairwise)
    any_failed = failed_pairs or any(row['status'] == 'FAILED VALIDATION' for row in results.values())
    n_verified = sum(row['status'] == 'VERIFIED' for row in results.values())
    status = ('FAILED VALIDATION' if any_failed else 'VERIFIED' if n_verified == 4
              else 'PARTIALLY VERIFIED' if n_verified else 'NOT EXECUTED')
    summary = {'status': status, 'engines': results, 'sample': sample, 'reference_check_count': len(reference_checks),
               'pairwise_check_count': len(pairwise), 'failed_pairwise_checks': failed_pairs,
               'maximum_absolute_pairwise_difference': max((r['absolute_difference'] for r in pairwise), default=0.0)}
    (run_dir / 'validation.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    return summary
