"""Generate the two original deterministic Stage 2 source tables."""

import argparse
import csv
from decimal import Decimal
from pathlib import Path


def generate(out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    plots = []
    seasons = []
    for sessions in range(6):
        for member, (area, sign) in enumerate(((5000, -1), (10000, 1)), 1):
            plot = f'P{2 * sessions + member:03d}'
            maize_yield = 1200 + 80 * sessions + sign * (10 + 5 * sessions)
            harvest = Decimal(area * maize_yield) / Decimal(10000)
            plots.append((plot, area))
            seasons.append((plot, 2025, f'{harvest:.1f}', sessions))
    plots.extend([('P013', 0), ('P014', 10000), ('P015', 10000), ('P016', 10000)])
    seasons.extend([
        ('P013', 2025, '100.0', 1), ('P014', 2025, '', 2),
        ('P015', 2025, '1350.0', ''), ('P016', 2024, '1250.0', 0),
    ])
    for name, columns, rows in [
        ('plots.csv', ('plot_id', 'area_m2'), plots),
        ('season_records.csv', ('plot_id', 'season', 'harvest_kg', 'sessions'), seasons),
    ]:
        with (out / name).open('w', newline='', encoding='utf-8') as stream:
            writer = csv.writer(stream, lineterminator='\n')
            writer.writerow(columns)
            writer.writerows(rows)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('out', type=Path)
    generate(parser.parse_args().out)
