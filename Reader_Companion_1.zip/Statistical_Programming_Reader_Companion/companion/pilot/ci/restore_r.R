# Check the recorded R environment before execution.
expected <- c(sandwich="3.1-1", zoo="1.8-14", lattice="0.22-7")
actual <- vapply(names(expected), function(x) {
  paste(utils::packageDescription(x, fields="Version"))
}, character(1))
stopifnot(getRversion()=="4.5.0", identical(unname(actual),unname(expected)))
cat(R.version.string,"\n")
write.table(data.frame(package=names(actual),version=unname(actual)),
            row.names=FALSE,quote=FALSE,sep=",")
