# Third-party materials

`manuscript/apa.csl` is the APA Style 7th edition Citation Style Language file from the [Citation Style Language styles repository](https://github.com/citation-style-language/styles/blob/master/apa.csl). It is distributed under the Creative Commons Attribution-ShareAlike 3.0 licence stated in its metadata. The CSL file retains its authorship and licence information.

The analytical scripts use separately installed software. This package contains no Stata executable, licence, private credentials, Python wheels, R binaries or Quarto binaries. Each software dependency retains its own applicable terms. The package includes original deterministic teaching data and original figures.
