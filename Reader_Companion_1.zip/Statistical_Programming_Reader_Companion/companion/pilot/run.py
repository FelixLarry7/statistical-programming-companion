"""Build, execute and verify the four-environment Chapter 13 pilot."""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time

from verification.validate import validate

ROOT = Path(__file__).resolve().parent


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def execute(command, log, *, cwd=ROOT, timeout=180):
    start = time.perf_counter()
    env = {**os.environ, 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'OPENBLAS_NUM_THREADS': '1',
           'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'PYTHONUTF8': '1'}
    try:
        with log.open('w', encoding='utf-8') as stream:
            result = subprocess.run(command, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                    check=False, timeout=timeout)
        outcome = {'status': 'EXECUTED' if result.returncode == 0 else 'FAILED VALIDATION',
                   'exit_code': result.returncode}
        if result.returncode:
            outcome['reason'] = 'Execution returned a non-zero exit status. Inspect the captured log.'
    except (OSError, subprocess.TimeoutExpired) as error:
        with log.open('a', encoding='utf-8') as stream:
            stream.write(f'{type(error).__name__}: {error}\n')
        outcome = {'status': 'FAILED VALIDATION', 'reason': type(error).__name__}
    outcome.update(log=log.name, elapsed_seconds=round(time.perf_counter() - start, 4))
    return outcome


def find_stata():
    for command in ('stata-mp', 'stata-se', 'stata'):
        executable = shutil.which(command)
        if executable:
            return executable
    return None


def build_run(work, spec_file, *, rscript=None, stata=None, stata_results=None):
    spec = json.loads(spec_file.read_text(encoding='utf-8'))
    inputs = ROOT / 'data' / 'raw'
    sql = work / 'duckdb'
    extract = sql / 'analytical.csv'
    python = work / 'python'
    r = work / 'r'
    s = work / 'stata'
    execution = {}
    execution['DuckDB'] = execute([sys.executable, str(ROOT / 'sql/pilot/run.py'), str(inputs), str(sql),
                                   '--spec', str(spec_file)], work / 'duckdb.log')
    if execution['DuckDB']['status'] != 'EXECUTED':
        result = {'status': 'FAILED VALIDATION', 'engines': execution, 'reason': 'Canonical SQL stage failed.'}
        (work / 'validation.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        return result

    execution['Python'] = execute([sys.executable, str(ROOT / 'python/pilot/fit_ols.py'), str(extract), str(python)],
                                  work / 'python.log')
    rscript = rscript or shutil.which('Rscript')
    if rscript:
        execution['R'] = execute([rscript, '--vanilla', str(ROOT / 'r/pilot/fit_ols.R'), str(extract), str(r)],
                                 work / 'r.log')
    else:
        execution['R'] = {'status': 'NOT EXECUTED', 'reason': 'Rscript was unavailable on PATH.'}

    stata = stata or (find_stata() if not stata_results else None)
    if stata_results:
        try:
            expected_hash = (stata_results / 'input_sha256.txt').read_text(encoding='ascii').strip()
            if expected_hash != digest(extract):
                raise ValueError('Imported Stata input hash differs from the canonical extract.')
            s.mkdir()
            for name in ('coefficients.csv', 'covariance.csv', 'predictions.csv', 'fit.json',
                         'environment.txt', 'completed.txt', 'input_sha256.txt'):
                shutil.copyfile(stata_results / name, s / name)
            execution['Stata'] = {'status': 'EXECUTED', 'mode': 'provided licensed run artifacts'}
        except (OSError, ValueError) as error:
            execution['Stata'] = {'status': 'FAILED VALIDATION',
                                  'reason': f'Incomplete or inconsistent licensed outputs: {error}'}
    elif stata:
        s.mkdir()
        shutil.copyfile(ROOT / 'stata/pilot/fit_ols.do', s / 'fit_ols.do')
        shutil.copyfile(extract, s / 'analytical.csv')
        execution['Stata'] = execute([stata, '-b', 'do', 'fit_ols.do', 'analytical.csv', '.'],
                                     work / 'stata-driver.log', cwd=s)
        if execution['Stata']['status'] == 'EXECUTED' and not (s / 'completed.txt').is_file():
            execution['Stata'].update(status='FAILED VALIDATION',
                                      reason='Stata did not write the completion marker. Inspect its batch log.')
    else:
        execution['Stata'] = {'status': 'NOT EXECUTED', 'reason': 'No licensed Stata executable was available.'}

    validation = validate(work, spec, execution)
    sources = ['spec/pilot.json', 'data/raw/plots.csv', 'data/raw/season_records.csv', 'sql/pilot/build.sql',
               'sql/pilot/check_ols.sql', 'sql/pilot/run.py', 'python/pilot/fit_ols.py', 'r/pilot/fit_ols.R',
               'stata/pilot/fit_ols.do', 'verification/validate.py', 'run.py', 'requirements.txt']
    manifest = {'release': (ROOT / 'VERSION').read_text().strip(), 'example_id': spec['example_id'],
                'timestamp_utc': datetime.now(timezone.utc).isoformat(),
                'platform': {'system': platform.system(), 'release': platform.release(),
                             'machine': platform.machine(), 'python': platform.python_version()},
                'packages': {p: metadata.version(p) for p in ('duckdb', 'statsmodels', 'numpy', 'scipy', 'mpmath')},
                'locale': 'C.UTF-8', 'timezone': 'UTC', 'threads_requested': 1,
                'inputs_and_code_sha256': {name: digest(ROOT / name) for name in sources},
                'canonical_extract_sha256': digest(extract), 'execution': execution, 'status': validation['status'],
                'artifacts_sha256': {str(p.relative_to(work)): digest(p) for p in sorted(work.rglob('*')) if p.is_file()}}
    (work / 'run_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    return validation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path, help='New output directory')
    parser.add_argument('--rscript', help='Path to a native Rscript executable')
    stata = parser.add_mutually_exclusive_group()
    stata.add_argument('--stata', help='Path to a licensed Unix-style Stata command')
    stata.add_argument('--stata-results', type=Path, help='Licensed Stata outputs from the same hashed extract')
    parser.add_argument('--require-all', action='store_true', help='Exit 2 unless all four environments verify')
    args = parser.parse_args()
    out = args.output.resolve()
    if out.exists():
        parser.error(f'Output directory already exists: {out}')
    out.parent.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='.stage2-run-', dir=out.parent))
    try:
        validation = build_run(work, ROOT / 'spec/pilot.json', rscript=args.rscript,
                               stata=args.stata, stata_results=args.stata_results)
        work.rename(out)
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise
    print(f'{validation["status"]} | {out / "validation.json"}')
    if validation['status'] == 'FAILED VALIDATION':
        return 1
    if args.require_all and validation['status'] != 'VERIFIED':
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
