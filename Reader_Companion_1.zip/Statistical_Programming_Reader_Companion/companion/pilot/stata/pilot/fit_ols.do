*! Chapter 13 pilot. Execute with a licensed Stata installation.
version 16.0
set more off
args input output
if `"`input'"' == "" | `"`output'"' == "" {
    display as error "Provide analytical.csv and an existing output directory"
    exit 198
}

import delimited using `"`input'"', clear varnames(1) stringcols(1) asdouble encoding("UTF-8")
isid plot_id season, sort
assert !missing(season, area_ha, harvest_kg, sessions, yield_kg_ha)
assert area_ha > 0 & harvest_kg >= 0
assert sessions == floor(sessions) & inrange(sessions, 0, 5)
quietly regress yield_kg_ha sessions
assert e(rank) == 2 & e(N) == _N
assert e(sample)

tempname classical hc1 beta n df rss sst r2 xm ym sxx
matrix `beta' = e(b)
matrix `classical' = e(V)
scalar `n' = e(N)
scalar `df' = e(df_r)
scalar `rss' = e(rss)
scalar `sst' = e(rss) + e(mss)
scalar `r2' = e(r2)
quietly predict double fitted if e(sample), xb
quietly predict double residual if e(sample), residuals
quietly summarize sessions if e(sample)
scalar `xm' = r(mean)
scalar `sxx' = (r(N) - 1) * r(Var)
quietly summarize yield_kg_ha if e(sample), meanonly
scalar `ym' = r(mean)

quietly regress yield_kg_ha sessions, vce(robust)
assert e(sample)
assert e(N) == `n' & e(df_r) == `df' & e(rank) == 2
matrix `hc1' = e(V)

tempname coef cov pred fit env estimate se tvalue pvalue critical done
file open `coef' using `"`output'/coefficients.csv"', write text replace
file write `coef' "covariance,parameter,estimate,std_error,t_value,df_resid,p_value,ci_low,ci_high" _n
file open `cov' using `"`output'/covariance.csv"', write text replace
file write `cov' "covariance,parameter_1,parameter_2,value" _n
scalar `critical' = invttail(`df', .025)
foreach method in classical HC1 {
    local matrix `classical'
    if "`method'" == "HC1" {
        local matrix `hc1'
    }
    foreach term in intercept sessions {
        local i = cond("`term'" == "intercept", 2, 1)
        scalar `estimate' = el(`beta', 1, `i')
        scalar `se' = sqrt(el(`matrix', `i', `i'))
        scalar `tvalue' = `estimate' / `se'
        scalar `pvalue' = 2 * ttail(`df', abs(`tvalue'))
        file write `coef' "`method',`term'," %24.17g (`estimate') "," %24.17g (`se') "," ///
            %24.17g (`tvalue') "," %12.0f (`df') "," %24.17g (`pvalue') "," ///
            %24.17g (`estimate' - `critical' * `se') "," %24.17g (`estimate' + `critical' * `se') _n
        foreach other in intercept sessions {
            local j = cond("`other'" == "intercept", 2, 1)
            file write `cov' "`method',`term',`other'," %24.17g (el(`matrix', `i', `j')) _n
        }
    }
}
file close `coef'
file close `cov'

file open `pred' using `"`output'/predictions.csv"', write text replace
file write `pred' "plot_id,season,sessions,yield_kg_ha,fitted,residual" _n
forvalues row = 1/`=_N' {
    file write `pred' (plot_id[`row']) "," %12.0f (season[`row']) "," ///
        %12.0f (sessions[`row']) "," %24.17g (yield_kg_ha[`row']) "," ///
        %24.17g (fitted[`row']) "," %24.17g (residual[`row']) _n
}
file close `pred'

file open `fit' using `"`output'/fit.json"', write text replace
file write `fit' "{" _n `"  "rank": 2,"' _n
local fields nobs df_resid sse sst r_squared x_mean y_mean sxx
local scalars `n' `df' `rss' `sst' `r2' `xm' `ym' `sxx'
forvalues i = 1/8 {
    local field : word `i' of `fields'
    local value_name : word `i' of `scalars'
    local value = strtrim(string(`value_name', "%24.17g"))
    if substr("`value'", 1, 1) == "." {
        local value "0`value'"
    }
    if substr("`value'", 1, 2) == "-." {
        local value = "-0" + substr("`value'", 2, .)
    }
    local comma = cond(`i' < 8, ",", "")
    file write `fit' `"  "`field'": "' "`value'`comma'" _n
}
file write `fit' "}" _n
file close `fit'

file open `env' using `"`output'/environment.txt"', write text replace
file write `env' "Stata release: `c(stata_version)'" _n "Edition: `c(flavor)'" _n "OS: `c(os)'" _n ///
    "Platform: `c(machine_type)'" _n "Stata build date: `c(born_date)'" _n
file close `env'
file open `done' using `"`output'/completed.txt"', write text replace
file write `done' "Completed both declared OLS covariance fits." _n
file close `done'
