# Run from any directory as Rscript --vanilla fit_ols.R analytical.csv outdir.
fit_ols <- function(input, out) {
  if (!requireNamespace("sandwich", quietly = TRUE)) {
    stop("Install the declared sandwich package before running the R analysis")
  }
  options(digits = 17)
  expected <- c("plot_id", "season", "area_ha", "harvest_kg", "sessions", "yield_kg_ha")
  d <- read.csv(input, colClasses = c("character", "integer", "numeric", "numeric", "integer", "numeric"),
                check.names = FALSE, fileEncoding = "UTF-8")
  stopifnot(identical(names(d), expected), !anyNA(d), nrow(d) > 2L,
            !anyDuplicated(d[c("plot_id", "season")]), all(is.finite(d$yield_kg_ha)))
  model <- lm(yield_kg_ha ~ sessions, data = d, na.action = na.fail, singular.ok = FALSE)
  stopifnot(model$rank == 2L)
  covariance_matrices <- list(classical = vcov(model), HC1 = sandwich::vcovHC(model, type = "HC1"))
  terms <- c("intercept", "sessions")
  estimates <- unname(coef(model))
  df <- df.residual(model)
  critical <- qt(0.975, df)
  coefficient_tables <- list()
  covariance_tables <- list()
  for (method in names(covariance_matrices)) {
    cov <- covariance_matrices[[method]]
    se <- sqrt(diag(cov))
    t_value <- estimates / se
    coefficient_tables[[method]] <- data.frame(
      covariance = method, parameter = terms, estimate = estimates, std_error = unname(se),
      t_value = unname(t_value), df_resid = df, p_value = unname(2 * pt(-abs(t_value), df)),
      ci_low = unname(estimates - critical * se), ci_high = unname(estimates + critical * se)
    )
    grid <- expand.grid(parameter_1 = terms, parameter_2 = terms, stringsAsFactors = FALSE)
    grid$covariance <- method
    grid$value <- as.vector(cov)
    covariance_tables[[method]] <- grid[c("covariance", "parameter_1", "parameter_2", "value")]
  }
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  write_result <- function(data, file) {
    write.csv(data, file.path(out, file), row.names = FALSE, fileEncoding = "UTF-8")
  }
  write_result(do.call(rbind, coefficient_tables), "coefficients.csv")
  write_result(do.call(rbind, covariance_tables), "covariance.csv")
  prediction <- d[c("plot_id", "season", "sessions", "yield_kg_ha")]
  prediction$fitted <- unname(fitted(model))
  prediction$residual <- unname(residuals(model))
  write_result(prediction, "predictions.csv")

  fit <- c(nobs = nobs(model), rank = model$rank, df_resid = df, sse = sum(residuals(model)^2),
           sst = sum((d$yield_kg_ha - mean(d$yield_kg_ha))^2), r_squared = summary(model)$r.squared,
           x_mean = mean(d$sessions), y_mean = mean(d$yield_kg_ha),
           sxx = sum((d$sessions - mean(d$sessions))^2))
  lines <- sprintf('  "%s": %.17g', names(fit), unname(fit))
  writeLines(c("{", paste(lines, collapse = ",\n"), "}"), file.path(out, "fit.json"))
  info <- c(R.version.string, paste("sandwich", packageVersion("sandwich")),
            paste("zoo", packageVersion("zoo")), capture.output(sessionInfo()))
  writeLines(info, file.path(out, "environment.txt"), useBytes = TRUE)
  cat(sprintf("%s | sandwich %s | n=%d, df=%d\n", R.version.string,
              packageVersion("sandwich"), nobs(model), df))
}

if (sys.nframe() == 0L) {
  args <- commandArgs(trailingOnly = TRUE)
  if (length(args) != 2L) stop("Expected analytical.csv and an output directory")
  fit_ols(args[[1L]], args[[2L]])
}
