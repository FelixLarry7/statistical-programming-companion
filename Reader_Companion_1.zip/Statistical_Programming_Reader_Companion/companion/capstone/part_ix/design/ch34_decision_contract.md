# Chapter 34 timing and decision contract

Select the United Kingdom, products 85123A, 22423 and 85099B, and the 52
complete weeks from 6 December 2010. Convert unit prices to whole pence before
multiplication. Keep eligible cancellation deductions distinct from
physical-return evidence. The separate synthetic ledger supports original-sale
linkage and identifies a void as its own event.

For repeat purchasing, origins 27, 33 and 39 are development and origins 45
and 48 are held-out snapshots. Include identified buyers with a qualifying
purchase in the last 12 weeks. Classify recency within four weeks through the
origin. Count a future repeat if a qualifying purchase is made in the next
four weeks. Retain anonymous rows in financial and unit totals. The two test
label periods share week 49.

For the order comparison, issue one-step forecasts at origins 40–51 and
score both benchmarks on weeks 41–52. Loss is two per unit of shortage and
one per unit of surplus. Display the shortened weeks 41–46 calculation as an
intentional comparison failure. Evaluate a new model or ordering rule on
held-out origins with matching information and costs.
