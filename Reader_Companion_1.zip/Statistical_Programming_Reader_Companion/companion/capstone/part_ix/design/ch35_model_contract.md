# Chapter 35 country-year contract

Freeze 2000–2023 before joining. Require unique WDI and PWT economy-year keys
and a unique economy in the crosswalk. Preserve WDI keys in a left join.
Record match presence separately from positive PWT GDP and population,
positive WDI population and observed life expectancy. World is an aggregate.
The balanced set uses the ten economies with 24 usable rows. The expanded
set additionally uses South Sudan's 16 complete rows.

| Model | Rows | Income | Weights |
| --- | ---: | --- | --- |
| Balanced | 240 | PWT real expenditure-side GDP per resident | Equal |
| Population | 240 | Same PWT income | WDI current-year population |
| Expanded | 256 | Same PWT income | Equal |
| WDI income | 240 | WDI real GDP per person in constant 2015 US dollars | Equal |

Fit log income, economy effects and year effects. Group scores by economy.
The covariance multiplier is G/(G−1) × (N−1)/(N−K), with G−1 reference degrees
of freedom. The balanced fit has 34 coefficient columns and the expanded fit
has 35. Compare the unweighted balanced slopes with their two-way-centred
values. Use fixed included countries for the named equal-weight and
population-weighted endpoint summaries. Interpret the estimates as associations
under the specified models.
