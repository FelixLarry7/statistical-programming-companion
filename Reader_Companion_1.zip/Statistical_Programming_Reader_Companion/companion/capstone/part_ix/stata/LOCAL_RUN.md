# Run Part IX in Stata 16 or 17

Extract the complete kit and set Stata's working directory to
`Part_IX_Stata_Local_Run`. From the Command window enter

    do run_part9.do

Upload the resulting `Stata_Verification_Part_IX_*.zip`. If the return code
is nonzero, the same archive preserves the command log for diagnosis.

The kit runs offline using built-in Stata and Mata. It reproduces the
paired trial, dated retail scorecard, country-year panel and synthetic
survey calculations. It stores the exact input copies and driver with the
metrics, version and run status. It uses a temporary frame and restores
the original working directory.
