"""Rebuild the comparative development study and its checked correction."""

import argparse
import csv
from hashlib import sha256
import json
from math import isclose
from pathlib import Path

HERE = Path(__file__).resolve().parent
PART_IX = HERE / "part_ix"
MODELS = {
    "common": ("Balanced, equal weights", "Equal", "PWT"),
    "weighted": ("Balanced, population weights", "WDI population", "PWT"),
    "expanded": ("Expanded, equal weights", "Equal", "PWT"),
    "national": ("Balanced, WDI income", "Equal", "WDI"),
}
FIELDS = ("n", "countries", "estimate", "se", "lo", "hi")
RELEASE = "stage3-part-x-capstone-v1"


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def ledger(path):
    result = {}
    with path.open(newline="") as stream:
        for row in csv.DictReader(stream):
            key = tuple(row[k] for k in ("chapter", "model", "quantity", "key"))
            if key in result:
                raise ValueError(f"Duplicate metric: {key}")
            result[key] = float(row["value"])
    return result


def differences(candidate, original):
    if candidate.keys() != original.keys():
        raise ValueError("The model keys differ.")
    diff = []
    for model, row in original.items():
        if candidate[model].keys() != row.keys():
            raise ValueError(f"The fields differ for {model}.")
        for field, expected in row.items():
            supplied = candidate[model][field]
            passed = (expected == supplied if field in {"n","countries"} else
                      abs(expected-supplied) <= 2e-8 + 2e-8 * abs(expected))
            if not passed:
                diff.append({"model":model, "field":field, "supplied":supplied, "expected":expected})
    return diff


def build(evidence, output):
    status = json.loads((evidence / "verification.json").read_text())
    if status["status"] != "VERIFIED" or status["failures"]:
        raise ValueError("Use the verified Part IX evidence.")
    path = evidence / "python/metrics.csv"
    metrics = ledger(path)
    true = {model:{field:metrics[("CH35",model,"scalar",field)] for field in FIELDS}
            for model in MODELS}
    if [int(v["n"]) for v in true.values()] != [240,240,256,240]:
        raise ValueError("Unexpected analytical populations.")
    seeded = {key:dict(row) for key,row in true.items()}
    seeded["common"]["estimate"] = true["weighted"]["estimate"]
    fault, = differences(seeded,true)
    assert (fault["model"],fault["field"]) == ("common","estimate")
    csv_path = output / "panel_results.csv"
    with csv_path.open("w",newline="") as stream:
        writer = csv.writer(stream,lineterminator="\n")
        writer.writerow(("model","label","weight","income",*FIELDS))
        for model,row in true.items():
            writer.writerow((model,*MODELS[model],*[row[k] for k in FIELDS]))
    with csv_path.open(newline="") as stream:
        verified = {}
        for row in csv.DictReader(stream):
            key = row["model"]
            if key in verified or (row["label"],row["weight"],row["income"]) != MODELS[key]:
                raise ValueError(f"Unexpected or mislabelled model {key}")
            verified[key] = {k:float(row[k]) for k in FIELDS}
    if differences(verified,true):
        raise ValueError("The corrected result table differs from the verified ledger.")
    (output / "review_record.json").write_text(json.dumps({
        "fault":fault, "cause":"A population-weighted estimate was placed under the equal-weight key.",
        "disposition":"Restore the equal-weight value and preserve the valid weighted result.",
        "corrected_comparisons":len(MODELS)*len(FIELDS), "correction_failures":0,
        "part_ix_replay_comparisons":status["comparisons"],
        "chapter_35_comparisons":status["comparisons_by_chapter"]["CH35"],
    },indent=2)+"\n")
    table = ["| Specification | Rows | Slope | 95% reference interval |",
             "| --- | ---: | ---: | ---: |"]
    for key,row in verified.items():
        text = f"| {MODELS[key][0]} | {row['n']:.0f} | {row['estimate']:.2f} | {row['lo']:.2f} to {row['hi']:.2f} |"
        table.append(text.replace("-","−"))
    def endpoint(year, measure):
        return metrics[("CH35","country1","endpoint",f"{year}/{measure}")]
    article = f"""# Life expectancy and income in a selected economy panel

## Research question and data

How does life expectancy vary with log real GDP per resident within selected
economies after removing economy and year effects? World Development Indicators
and Penn World Table 11.0 supply the frozen 2000–2023 country-year data. The
balanced and expanded analysis samples contain 240 and 256 rows.

## Methods

Fit economy and year effects, and cluster the covariance by economy under the
specified finite-sample adjustment and Student reference. Compare the primary
estimate with population weighting, expanded coverage and the WDI income measure.

## Results

Ghana's life expectancy rises from {endpoint(2000,'life'):.2f} to {endpoint(2023,'life'):.2f}
years. Under-five mortality falls from {endpoint(2000,'u5'):.1f} to {endpoint(2023,'u5'):.1f}
per 1,000 live births.

{chr(10).join(table)}

## Interpretation and limitations

The fitted sign changes with the weights and the sample. Each reference interval
contains zero. The selected countries are purposive and potential time-varying
confounding remains. The results support a scoped comparison of trends and
associations. A policy effect requires a separate design.

## Availability and review

The source register, code, inputs and archived licensed evidence accompany the
teaching example. The clean replay uses Python, R and DuckDB and imports verified
Stata 17 IC output from the original licensed execution. The review record
documents a seeded reporting error and its verified correction.

Teaching release {RELEASE}.
"""
    (output / "journal_study.md").write_text(article,encoding="utf-8")
    inputs = ("data/map35.csv","data/pwt35.csv","data/wdi35.csv","design/ch35_crosswalk.csv",
              "design/ch35_model_contract.md","source/source_manifest.json","source/README.md",
              "fit_python.py","fit_r.R","fit_sql.py","sql/labs.sql","stata/part9_driver.do","verify.py")
    files = ("journal_study.md","panel_results.csv","review_record.json")
    (output / "release_manifest.json").write_text(json.dumps({
        "release_tag":RELEASE,"sources":{n:sha(PART_IX/n) for n in inputs},
        "output_sha256":{n:sha(output/n) for n in files},"source_ledger_sha256":sha(path),
        "exact_fields":["n","countries"],"continuous_tolerance":"2e-8 + 2e-8 times absolute reference",
    },indent=2)+"\n")
    print("Seeded model-key fault identified; 24 corrected fields matched.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--evidence",type=Path,default=PART_IX/"evidence")
    p.add_argument("--output",type=Path,default=HERE/"outputs")
    a = p.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    build(a.evidence,a.output)
