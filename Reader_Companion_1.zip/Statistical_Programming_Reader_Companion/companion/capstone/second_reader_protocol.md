# Second-reader reproduction protocol

1. Verify the release manifest and resolve the annotated teaching tag.
2. Restore the public environment and use the frozen source inputs.
3. Run the Part IX verifier in a clean destination. Reconcile the licensed
   evidence by driver, input and completion record.
4. Check the 240 balanced and 256 expanded rows and the inference scope.
5. Generate the capstone study and diagnose the misplaced weighted estimate.
6. Review confounding, reference uncertainty, measurement and generalisation.
7. Return the executed commands, manifest, deviations and review decisions.
   Record which checks were performed and which remain for an independent reviewer.
