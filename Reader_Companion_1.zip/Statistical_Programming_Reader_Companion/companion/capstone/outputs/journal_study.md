# Life expectancy and income in a selected economy panel

## Research question and data

How does life expectancy vary with log real GDP per resident within selected
economies after removing economy and year effects? World Development Indicators
and Penn World Table 11.0 supply the frozen 2000–2023 country-year data. The
balanced and expanded analysis samples contain 240 and 256 rows.

## Methods

Fit economy and year effects, and cluster the covariance by economy under the
specified finite-sample adjustment and Student reference. Compare the primary
estimate with population weighting, expanded coverage and the WDI income measure.

## Results

Ghana's life expectancy rises from 58.14 to 65.50
years. Under-five mortality falls from 99.9 to 37.2
per 1,000 live births.

| Specification | Rows | Slope | 95% reference interval |
| --- | ---: | ---: | ---: |
| Balanced, equal weights | 240 | −1.33 | −7.65 to 4.99 |
| Balanced, population weights | 240 | 2.98 | −1.89 to 7.85 |
| Expanded, equal weights | 256 | 2.41 | −5.20 to 10.02 |
| Balanced, WDI income | 240 | −1.23 | −10.32 to 7.85 |

## Interpretation and limitations

The fitted sign changes with the weights and the sample. Each reference interval
contains zero. The selected countries are purposive and potential time-varying
confounding remains. The results support a scoped comparison of trends and
associations. A policy effect requires a separate design.

## Availability and review

The source register, code, inputs and archived licensed evidence accompany the
teaching example. The clean replay uses Python, R and DuckDB and imports verified
Stata 17 IC output from the original licensed execution. The review record
documents a seeded reporting error and its verified correction.

Teaching release stage3-part-x-capstone-v1.
