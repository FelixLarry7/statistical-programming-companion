# Household survey technical appendix

The teaching population contains 600 households and four strata with five primary sampling units each. The transfer rule uses score at most 55 and a priority flag. An outcome is known for 269 of 277 households with recorded care need. The eight unresolved records remain in the flow ledger. The ratio denominator for unmet care uses households with known outcomes and reported need.

| Measure | Records | Weight | Rate | 95% interval |
| :--- | ---: | ---: | ---: | ---: |
| Transfer coverage | 175 | 230.86 | 75.05% | 69.38–80.71% |
| Eligibility exclusion | 175 | 230.86 | 24.95% | 19.29–30.62% |
| Ineligible receipt among recipients | 269 | 344.10 | 49.65% | 42.01–57.29% |
| Recorded insurance | 600 | 782.56 | 46.74% | 43.16–50.31% |
| Unmet care | 269 | 349.94 | 41.16% | 34.29–48.03% |
| Unmet care, rural | 146 | 203.48 | 50.16% | 42.04–58.27% |
| Unmet care, urban | 123 | 146.46 | 28.66% | 20.91–36.40% |

Each linearised household score contributes to its PSU total. Keep zero-contribution sampled PSUs in the design. Use the with-replacement stratified variance approximation and 16 degrees of freedom. The welfare rank uses weighted tied midranks in the known-need domain. Each of 20 delete-PSU replicates scales the four remaining PSUs in the affected stratum by 5/4 and recomputes the ranks. Conventional concentration is −0.1963 (95% reference interval −0.2522 to −0.1405). The Erreygers correction is −0.3232.

| Threshold | Weighting | Headcount | Gap |
| :--- | :--- | ---: | ---: |
| GHS 2,200 | household | 51.35% | 14.72% |
| GHS 2,200 | person | 50.97% | 14.39% |
| GHS 2,600 | household | 63.22% | 21.33% |
| GHS 2,600 | person | 63.45% | 21.06% |

The fictional thresholds apply per person per month. The gap averages proportional shortfalls over the full selected population. Person weighting multiplies the household weight by household size.

Apply the [public projection rules](../design/ch36_release_rules.md) before export. A real rerun requires authorised access, definitions, linkage rules if applicable, and output review. Every household in this companion is synthetic.
