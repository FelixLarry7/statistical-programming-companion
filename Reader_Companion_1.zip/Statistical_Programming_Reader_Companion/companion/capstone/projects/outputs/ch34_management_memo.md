# Management decision memo

**Decision.** Use the four-week mean as the first ordering benchmark under the specified shortage and surplus costs. It has a lower common-window mean loss for each selected product. Review lead times, stockouts, pack sizes and realised costs before adopting an ordering policy.

The scoped extract has 5,904 lines and 4,893 eligible invoices. Gross booked sales of £311,775.27 less cancellation deductions of £16,283.42 give £295,491.85 net. Repeating each invoice's balance on every eligible line produces £370,648.78, an overstatement of £75,156.93. Reconcile the invoice balance and the line sum before publishing the dashboard. A separate synthetic ledger links booked sales of £81.50 to physical returns of £24.50, yielding £57.00 net under its own contract.

| Product | Rule | MAE | RMSE | Mean loss | Short MAE |
| :--- | :--- | ---: | ---: | ---: | ---: |
| 85123A | Previous week | 475.83 | 615.57 | 724.08 | 274.17 |
| 85123A | Four-week mean | 335.44 | 476.46 | 529.83 | 205.75 |
| 22423 | Previous week | 73.33 | 90.34 | 113.83 | 99.33 |
| 22423 | Four-week mean | 49.17 | 65.28 | 80.67 | 69.92 |
| 85099B | Previous week | 702.25 | 911.38 | 1,073.08 | 834.50 |
| 85099B | Four-week mean | 634.33 | 788.07 | 987.27 | 630.71 |

Primary scores use weeks 41–52. Short MAE uses weeks 41–46. Ranking a shortened-window score against a full-window score changes the observations being scored.

| Test origin | Recent | Other eligible |
| ---: | ---: | ---: |
| 45 | 23.55% | 21.10% |
| 48 | 26.62% | 23.54% |

The cohort comparison covers identified buyers of the three products. A label matures four weeks after its origin. The two test outcome windows share week 49. A contact decision would require a defined incremental benefit and cost, and evidence on response to contact.

**Evidence.** See the [metric dictionary](../design/ch34_metric_dictionary.csv), [timing and decision contract](../design/ch34_decision_contract.md), and the Chapter 34 ledgers. Retail data are adapted from [UCI Online Retail](https://doi.org/10.24432/C5BW33).
