# Evaluation note

**Decision for the fictional programme.** Continue measured implementation and improve follow-up before using a three-point gain as the basis for expansion. The matched-pair point estimate exceeds three, while its reference interval and the adverse six-point scenario include values below that threshold.

| Assignment | Screened | Eligible | Observed | Missing |
| :--- | ---: | ---: | ---: | ---: |
| Comparison | 576 | 480 | 417 | 63 |
| Offer | 576 | 480 | 414 | 66 |

Across 24 matched pairs the observed-case offer contrast is 4.25 points (SE 0.71, 95% paired interval 2.78 to 5.72). The fixed-observation sign diagnostic gives p = 0.002 with 499 archived draws. Its interpretation depends on exchangeability of the observed pattern under the null.

| Sensitivity | Range in score points |
| :--- | ---: |
| Three-point departures | 3.44 to 5.06 |
| Six-point departures | 2.64 to 5.86 |
| Zero-to-100 completion | −9.55 to 17.33 |

The first two ranges change the missing groups' mean changes in opposite directions across arms. The third completes the realised cohort under the 0–100 outcome support. These ranges express assumptions about follow-up. They carry no separate sampling interval. Use the prespecified estimand, 12-month score and original village assignment when rerunning the analysis.

**Evidence.** See [pre-analysis plan](../design/ch33_pre_analysis_plan.md), [deviation ledger](../design/ch33_deviations.csv), and the companion comparisons. All household and assignment records are synthetic.
