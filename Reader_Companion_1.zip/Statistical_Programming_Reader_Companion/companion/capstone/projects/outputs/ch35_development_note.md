# Ghana-centred comparative development note

Ghana's life expectancy rose from 58.14 to 65.50 years from 2000 to 2023. Under-five mortality fell from 99.9 to 37.2 per 1,000 live births. Expenditure-side chained PPP GDP per resident increased from 3,485 to 6,671 in 2021 US dollars. The WDI constant-2015-US-dollar income concept is retained separately.

| Code | Economy | WDI | PWT matches | Unmatched | Usable |
| :--- | :--- | ---: | ---: | ---: | ---: |
| GHA | Ghana | 24 | 24 | 0 | 24 |
| KEN | Kenya | 24 | 24 | 0 | 24 |
| SEN | Senegal | 24 | 24 | 0 | 24 |
| ZAF | South Africa | 24 | 24 | 0 | 24 |
| BGD | Bangladesh | 24 | 24 | 0 | 24 |
| BRA | Brazil | 24 | 24 | 0 | 24 |
| IDN | Indonesia | 24 | 24 | 0 | 24 |
| VNM | Viet Nam | 24 | 24 | 0 | 24 |
| IND | India | 24 | 24 | 0 | 24 |
| USA | United States | 24 | 24 | 0 | 24 |
| SSD | South Sudan | 24 | 24 | 0 | 16 |
| TLS | Timor-Leste | 24 | 0 | 24 | 0 |
| WLD | World | 24 | 0 | 24 | 0 |

The World aggregate is outside the economy estimand. South Sudan contributes 16 usable years and is outside the ten-economy balanced set. Timor-Leste remains visible in the unmatched ledger.

| Specification | Rows | Slope | 95% interval |
| :--- | ---: | ---: | ---: |
| Balanced, equal weights | 240 | −1.33 | −7.65 to 4.99 |
| Balanced, population weights | 240 | 2.98 | −1.89 to 7.85 |
| Expanded, equal weights | 256 | 2.41 | −5.20 to 10.02 |
| Balanced, WDI income | 240 | −1.23 | −10.32 to 7.85 |

Each estimate includes economy and year effects and uses economy-clustered reference inference. Slopes measure years per log income point. The estimated sign depends on weighting and coverage. All four intervals include zero. Use the Ghana endpoints as dated descriptions and the panel estimates as specification-sensitive associations.

**Evidence.** See the [country crosswalk](../design/ch35_crosswalk.csv), source fingerprints and independent fits. Sources are [World Development Indicators](https://databank.worldbank.org/source/world-development-indicators) and [Penn World Table 11.0](https://doi.org/10.34894/FABVLR).
