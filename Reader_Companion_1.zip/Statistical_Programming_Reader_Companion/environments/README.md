# Restore the computational environment

The observed executable set was CPython 3.12.14 on Linux x86-64,
R 4.5.0, DuckDB 1.4.4 and SQLite 3.53.1. The original Stata evidence
identifies the licensed Stata 17 IC builds and dates. Each per-part
runner retains its clear output contract and log.

## Python and DuckDB

From the extracted package root on Linux x86-64 with Python 3.12, run:

~~~sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install --require-hashes \
  -r environments/requirements-linux-x86_64-py312.lock
python -m pip check
~~~

The lock contains all runtime wheels, including transitive dependencies.
It was restored into a new virtual environment and checked before
execution. The SQL examples use the DuckDB Python binding at the pinned
version. The Chapter 7 adaptation uses the SQLite library bundled with
the interpreter. Use the declared inputs in **python.in** when establishing
a new platform lock and rerun the tests on that platform.

## R

Install R 4.5.0 and the relevant recommended packages. The manifest
**r_packages.csv** records exact installed versions. In an isolated R
library, install missing packages and recorded versions from CRAN or
your institutional package mirror. The **restore_r.R** script locates
the pinned CRAN versions and checks them after restoration. The approved
source can be set with the **STAGE5_CRAN** environment variable.

~~~sh
mkdir -p .r-library
export R_LIBS_USER="$PWD/.r-library"
Rscript --vanilla environments/restore_r.R
Rscript --vanilla environments/session.R
~~~

For the optional Chapter 28 forest, pass **--forest** to the restoration
script and to the full runner. A source restore can require R headers,
C and C++ compilers, Fortran and BLAS/LAPACK development libraries.
The optional code and reference prediction export also support an
explicit replay without changing the core Part VII dependencies.
The observed Debian package and CRAN source fingerprints are in
**r_distributions.json**.

## Local Stata and execution scope

The work uses the author’s original licensed Stata 17 IC output from
macOS. The current run validates the original input hashes, driver hashes
and outputs. To run Stata again, use a locally installed licensed Stata
16 or 17 and the applicable part’s native do-files and handoff guide.
Many drivers declare **version 16** syntax. The evidence records the
version that executed. The recorded R and Python dependencies do not
include or require a Stata installation for archive replay.

## Publisher proof toolchain

The integrated manuscript is a Quarto book. Its print proof uses LuaLaTeX,
P052, Noto Sans, DejaVu Sans Mono and Latin Modern Math.
Run the proof corrections and EPUB part assembly as documented in
the root README. The publishing and computational environments are
separate, so rendering the proof does not restart the statistical jobs.
