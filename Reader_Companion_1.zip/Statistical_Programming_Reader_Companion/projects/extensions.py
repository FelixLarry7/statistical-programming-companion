"""Independently evaluate the Stage 7 survey assignments in Python and DuckDB."""
import csv
from decimal import Decimal
from itertools import product
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "projects"
CHAPTERS = ROOT / "chapter_companions"
SOURCES = {
    "welfare": "Part_IX/companion/data/welfare36.csv",
    "births": "Part_VIII/companion/data/births30.csv",
    "spending": "Part_VIII/companion/data/expenditure30.csv",
    "food": "Part_VIII/companion/data/households32.csv",
}
QUERIES = {
    "P02": ("teaching_poverty", "line,basis"),
    "P04": ("delivery_age_insurance_standardisation", "rural"),
    "P05": ("spending_and_coverage", "measure,group_id"),
    "P09": ("food_thresholds", "line,domain"),
}


def records(name):
    with (CHAPTERS / SOURCES[name]).open(newline="") as file:
        return list(csv.DictReader(file))


def poverty():
    data = records("welfare")
    for line,basis in product((2200,2600,3000),("household","person")):
        denom, poor, gap = Decimal(0),Decimal(0),Decimal(0)
        for row in data:
            weight = Decimal(row["weight"]) * (int(row["size"]) if basis == "person" else 1)
            welfare = Decimal(row["welfare"])
            denom += weight
            poor += weight * (welfare < line)
            gap += weight * max(Decimal(1)-welfare/line, Decimal(0))
        yield line,basis,len(data),denom,poor/denom,gap/denom


def delivery():
    data = [row for row in records("births") if row["live"]=="1" and int(row["months"])<24
            and row["facility"] in {"0","1"}]
    pooled = {(a,b):Decimal(0) for a,b in product((0,1),repeat=2)}
    cells = {(r,a,b):[] for r,a,b in product((0,1),repeat=3)}
    for row in data:
        r,a,b = int(row["rural"]),int(row["insured"]),int(int(row["age"])>=30)
        weight = Decimal(row["weight"])
        pooled[a,b] += weight
        cells[r,a,b].append((weight,int(row["facility"])))
    for rural in (0,1):
        counts, risks = [], []
        for (insured, age), target in pooled.items():
            cell = cells[rural,insured,age]
            counts.append(len(cell))
            risks.append(target * sum(w*y for w,y in cell) / sum(w for w,_ in cell))
        yield rural,len(counts),min(counts),sum(risks)/sum(pooled.values())


def coverage_and_spending():
    data = records("welfare")
    for group in ("0","1"):
        rows = [r for r in data if r["rural"]==group]
        yield "coverage",group,len(rows),sum(Decimal(r["weight"])*int(r["insurance"]) for r in rows) / sum(Decimal(r["weight"]) for r in rows)
    spend = [Decimal(row["spend"]) for row in records("spending")]
    positive = [x for x in spend if x>0]
    yield "observed zero count","all",len(spend)-len(positive),Decimal(0)
    yield "positive mean","all",len(positive),sum(positive)/len(positive)


def food_cutoffs():
    data = [row for row in records("food") if row["meal_shortfall"] in {"0","1"}]
    for line,domain in product((200,300),("All","Rural","Urban")):
        rows = [r for r in data if domain=="All" or (r["rural"]=="1")== (domain=="Rural")]
        denominator = sum(Decimal(r["weight"]) for r in rows)
        numerator = sum(Decimal(r["weight"]) for r in rows if Decimal(r["food_spend"])/int(r["size"])<line)
        yield line,domain,len(rows),denominator,numerator/denominator


def run():
    expected = {"P02":poverty,"P04":delivery,"P05":coverage_and_spending,"P09":food_cutoffs}
    checked = []
    output = {}
    with duckdb.connect() as connection:
        connection.execute("SET threads=1")
        for view, path in SOURCES.items():
            connection.read_csv(str(CHAPTERS/path),header=True).create_view(view)
        connection.execute((HERE/"sql/extensions.sql").read_text())
        for project,(view, order) in QUERIES.items():
            relation = connection.sql(f"SELECT * FROM {view} ORDER BY {order}")
            actual = relation.fetchall()
            wanted = list(expected[project]())
            output[project] = [dict(zip(relation.columns,row,strict=True)) for row in actual]
            if len(wanted)!=len(actual):
                raise ValueError(f"{project}: sensitivity row counts differ")
            for index,(ref, obs) in enumerate(zip(wanted,actual,strict=True),1):
                for name,x,y in zip(relation.columns,ref,obs,strict=True):
                    if isinstance(x,str):
                        if x!=y:
                            raise ValueError(f"{project}: unmatched label {x!r}")
                        gap = Decimal(0)
                        limit = Decimal(0)
                    else:
                        ref_value, obs_value = Decimal(str(x)),Decimal(str(y))
                        gap = abs(ref_value-obs_value)
                        limit = Decimal("1e-10") + Decimal("1e-12") * max(abs(ref_value),abs(obs_value)) if isinstance(x,Decimal) else Decimal(0)
                        if not gap.is_finite() or gap>limit:
                            raise ValueError(f"{project}: sensitivity {index}/{name} differs by {gap}")
                    checked.append(dict(project=project,row=index,field=name,python=x,duckdb=y,
                                        abs_error=gap,tolerance=limit,status="Passed"))
    return output, checked
