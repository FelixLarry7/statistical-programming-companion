"""Build the project assignments, reports and evidence from the frozen textbook release."""
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "projects"
sys.path.insert(0, str(ROOT / "verification/cross_platform"))
from comparisons import ENGINES, metrics, result, rule_for
from extensions import run as extension_run


def csv_rows(path):
    with path.open(newline="",encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def csv_write(path, rows):
    with path.open("w",newline="",encoding="utf-8") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]),lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle,"sha256").hexdigest()


def fmt(value,places):
    return f"{value:,.{places}f}".replace("-","−")


def table(headers, rows, numerical=()):
    return ["| "+" | ".join(headers)+" |",
            "| "+" | ".join("---:" if i in numerical else "---" for i in range(len(headers)))+" |",
            *["| "+" | ".join(map(str,row))+" |" for row in rows]]


def artifact_routes(parts):
    for part in parts:
        if part=="X":
            yield dict(part=part,python="companion/capstone/part_ix/fit_python.py",
                       r="companion/capstone/part_ix/fit_r.R",
                       sql="companion/capstone/part_ix/fit_sql.py",
                       stata="companion/capstone/part_ix/stata/part9_driver.do",
                       run="companion/capstone/review_study.py", evidence="verification/evidence/capstone_report")
            continue
        base = f"chapter_companions/Part_{part}/companion"
        if part=="I":
            python,r,sql,stata,driver = "labs.py","labs.R","sql/prepare.sql","stata/labs.do","run.py"
        elif part in {"II","III"}:
            n=2 if part=="II" else 3
            python,r,sql,stata,driver = f"python/part{n}.py",f"r/part{n}.R","sql",f"stata/part{n}_driver.do","run.py"
        else:
            n=["IV","V","VI","VII","VIII","IX"].index(part)+4
            python,r,sql,stata,driver = "fit_python.py","fit_r.R","fit_sql.py",f"stata/part{n}_driver.do","verify.py"
        yield {"part":part,"python":f"{base}/{python}","r":f"{base}/{r}","sql":f"{base}/{sql}",
               "stata":f"{base}/{stata}","run":f"{base}/{driver}","evidence":f"verification/evidence/Part_{part}"}


def spec_and_artifacts(project, policy, inputs):
    data = []
    for filename in project["files"]:
        row, = [r for r in inputs if Path(r["path"]).name==filename]
        assert sha(ROOT/row["path"])==row["sha256"],row["path"]
        data.append({k:row[k] for k in ("path","source_ids","grain","primary_key","rows","sha256","codebook")})
    artifacts = list(artifact_routes(project["parts"]))
    for record in artifacts:
        for name in ("python","r","sql","stata","run","evidence"):
            assert (ROOT/record[name]).exists(),record[name]
    project_spec={"edition":"Stage 8","project":project["id"],"title":project["title"],"question":project["question"],
                  "reader_edition":"All editions","chapters":project["chapters"],"source_ids":policy["source_ids"],
                  "access":policy["analytical_route"],"inputs":data,"reproduce":artifacts,
                  "model_and_inference":project["design"],"declared_variation":project["change"],
                  "codebook_index":"data/codebooks/field_index.csv"}
    if project.get("provider_context"):
        project_spec["provider_context"] = project["provider_context"]
    if project.get("extension"):
        project_spec["extension"]={"engines":["Python","DuckDB"],"rerun":"projects/build.py --one "+project["id"],
                                   "licensed_scope":"Stata archived comparisons apply to the chapter baseline."}
    return project_spec


def extract_results(project, cache, out_checks):
    output = []
    for part,chapter,model,quantity,key,label,unit,places,*factor in project["metrics"]:
        identity=f"CH{chapter:02}",model,quantity,key
        data=cache[part]
        primary=data["python"][identity]
        scale=Decimal(str(factor[0])) if factor else Decimal(1)
        row=dict(project=project["id"],part=part,chapter=chapter,model=model,quantity=quantity,key=key,
                 label=label,unit=unit,reference=str(primary),display=fmt(primary*scale,places),
                 digits=places,multiplier=str(scale),scope="Frozen chapter baseline",
                 checked_engines="Python · R · licensed Stata; DuckDB where supported")
        for engine in ENGINES:
            if engine=="python" or identity not in data[engine]:
                continue
            compared=result(project["id"],identity,"python",engine,primary,data[engine][identity],
                            rule_for(part,identity,engine),f"verification/evidence/Part_{part}/comparisons.csv")
            out_checks.append(compared)
        row["checked_engines"] = ", ".join(e for e in ENGINES if identity in data[e])
        output.append(row)
    return output


def exercise_section(project, book=False):
    ident = project["id"]
    result = [f"## {ident}  {project['title']} {{#sec-project-{ident.lower()}}}","",
              f"**Research question.** {project['question']}","",
              f"**Design and data.** {project['design']}","",
              f"**Prepare the extract.** {project['preparation']}",""]
    if book:
        chapters = ", ".join(f"@sec-ch{n:02}" for n in project["chapters"])
        result += [f"Read {chapters}. [Appendix Q](#app-data-retrieval) lists the commands.",""]
    result += ["**Assignment**","",*[f"{i}. {task}" for i,task in enumerate(project["tasks"],1)],"",
               f"**Change one assumption.** {project['change']}","",
               f"**Submit.** {project['deliverable']}",""]
    return result


def each_project(project, routes, data, extension, report_directory, render_directory):
    ident = project["id"]
    target = report_directory / ident
    target.mkdir()
    snapshot = [r for r in routes if r["project"]==ident][0]
    spec = spec_and_artifacts(project,snapshot,data)
    (target/"specification.json").write_text(json.dumps(spec,indent=2,ensure_ascii=False)+"\n")
    csv_write(target/"inputs.csv",spec["inputs"])
    csv_write(target/"engine_routes.csv",spec["reproduce"])
    (target/"assignment.md").write_text("\n".join(
        [f"# {project['title']}","",f"{ident} · {project['format']}","",*exercise_section(project),
         "**Evidence to retain**","",
         "- Observed sample keys and exclusions", "- Selected estimate, interval or scoring denominator",
         "- Engine result, version and original execution or replay status", "- Change in result or interpretation under the declared variation",
         "", "Use the project specification for the input paths and the teaching rubric for submission criteria.", ""]))
    (target/"worksheet.md").write_text("\n".join([
        f"# {ident} replication worksheet","",f"Decision question. {project['question']}","",
        f"Controlled variation. {project['change']}","", "Record each entry before writing the report.","",
        *table(("Evidence","Your record"),[
            ("Frozen data IDs, version and checksum",""),("Unit, analytical key and inclusion rule",""),
            ("Training or design frame and sample counts",""),("Estimand, units and reference distribution",""),
            ("Python, R, DuckDB and Stata scope",""),("Comparison key, discrepancy and original bound",""),
            ("Baseline and changed scenario",""),("Decision and limits of inference",""),
        ]),"", "A second reader should be able to rerun your reported result from the submitted files.",""]))
    rows = project["result_rows"]
    csv_write(target/"baseline_results.csv",rows)
    ext = extension.get(ident)
    if ext:
        csv_write(target/"sensitivity_results.csv",ext)
    paths = " · ".join(project["files"])
    report = [f"# {project['title']}","",f"{ident} · {project['format']}","",
              "## Decision and research design","",project["question"],"",project["design"],"",
              "## Observed results","",*table(("Quantity","Result","Unit"),[(r["label"],r["display"],r["unit"]) for r in rows],(1,)),
              "", "## Interpretation","",project["discussion"],"",
              "## Sensitivity and replication","",project["change"],""]
    if ext:
        columns=tuple(ext[0])
        report += [
            "The additional sensitivity check was rerun in Python and DuckDB on the frozen inputs.","",
            *table(tuple(k.replace("_"," ").title() for k in columns),[
                tuple(fmt(row[k],4) if isinstance(row[k],float) else str(row[k]) for k in columns)
                for row in ext]),""]
    report += ["## Data and verification","",f"Primary files include {paths}. The specification records the exact files, "
               "observational units, fingerprints, output paths and engine scope. "
               "The archived Stata outputs accompany the original chapter specification.",""]
    (target/"report.md").write_text("\n".join(report))
    summary = render_directory/f"{ident}.json"
    summary.write_text(json.dumps({"id":ident,"title":project["title"],"format":project["format"],"chapters":project["chapters"],
                                   "question":project["question"],"discussion":project["discussion"],
                                   "rows":rows,"figure":project.get("figure"),"figure_alt":project.get("figure_alt")},indent=2,ensure_ascii=False)+"\n")


def build(output, selection):
    all_projects = json.loads((HERE/"content.json").read_text())
    assert [p["id"] for p in all_projects] == [f"P{i:02}" for i in range(1,13)]
    if output.exists():
        raise FileExistsError("Choose a new project output directory.")
    projects = [p for p in all_projects if not selection or p["id"]==selection]
    if not projects:
        raise ValueError(f"Unknown project {selection}")
    necessary = {m[0] for p in projects for m in p["metrics"]}
    evidence = ROOT/"verification/evidence"
    cache = {part:{e:metrics(part,evidence/f"Part_{part}",e) for e in ENGINES} for part in necessary}
    inputs = csv_rows(ROOT/"data/catalog/dataset_catalogue.csv")
    routes = csv_rows(ROOT/"data/catalog/project_routes.csv")
    variations, variation_checks = extension_run()
    out_checks = []
    report_directory = output/"portfolio"
    render_directory = output/"summaries"
    report_directory.mkdir(parents=True)
    render_directory.mkdir()
    for project in projects:
        project["result_rows"]=extract_results(project,cache,out_checks)
        each_project(project,routes,inputs,variations,report_directory,render_directory)
    csv_write(output/"project_comparisons.csv",out_checks)
    if not selection or selection in variations:
        csv_write(output/"sensitivity_checks.csv",[r for r in variation_checks if r["project"] in {p["id"] for p in projects}])
    combined = [f"# Applied project guides {{#app-project-guides}}","",
                "The twelve projects move from a research decision to an auditable result. Each assignment has a ready-to-run teaching baseline, a change in specification and a decision-facing deliverable. Use the common marking rubric in [Appendix O](#app-teaching). The [reader companion](#app-reader-companion) identifies the complete files and worked reports.","",
                *table(("Project","Study","Deliverable"),[(f"[{p['id']}](#sec-project-{p['id'].lower()})",p["title"],p["format"]) for p in projects]),""]
    for p in projects:
        ident = p["id"]
        combined += ["```{=latex}",r"\clearpage","```","",*exercise_section(p,book=True)]
        key_results = p["result_rows"]
        key_results = key_results[:3] if ident not in {"P01","P03","P04","P06","P10","P12"} else key_results[:5]
        combined += ["**Checked reference values**","",
                     *table(("Quantity","Value","Unit"),
                            [(r["label"],r["display"],r["unit"]) for r in key_results],(1,)),""]
    (output/"appendix-l.qmd").write_text("\n".join(combined))
    stratum = Counter(r["scope"] for r in out_checks)
    files = {p.relative_to(output).as_posix():sha(p) for p in sorted(output.rglob("*")) if p.is_file()}
    summary = {
        "status":"Passed","projects":len(projects),"project_ids":[p["id"] for p in projects],
        "baseline_metrics":sum(len(p["result_rows"]) for p in projects),"archived_comparisons":len(out_checks),
        "checks_by_project":dict(sorted(stratum.items())),
        "new_python_duckdb_checks":sum(r["project"] in {p["id"] for p in projects} for r in variation_checks),
        "source":"Frozen Stage 6 execution and Stage 7 survey sensitivity calculations",
        "sha256":files,
    }
    (output/"summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False)+"\n")
    print(f"Passed {len(projects)} projects, {summary['baseline_metrics']} report metrics, "
          f"{len(out_checks)} archived comparisons and {summary['new_python_duckdb_checks']} fresh sensitivity checks.")


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--one",help="Project ID, for example P03.")
    args=parser.parse_args()
    build(args.output,args.one)
