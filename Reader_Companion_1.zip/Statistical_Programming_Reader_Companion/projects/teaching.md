# Teaching the applied research portfolio

## Fourteen-week advanced course

| Week | Reading and lab | Observable assessment |
| --- | --- | --- |
| 1 | Chapters 1–4 and the maize pilot | Identify the unit, input and verified result. |
| 2 | Chapters 5–8 | Produce a typed import, primary key and join audit. |
| 3 | Chapters 9–12 and P02 | Explain a weighted poverty ratio and design variance. |
| 4 | Chapters 13–16 and P08 | Match coefficient and covariance, then trace area units. |
| 5 | Chapter 17 and P03 protocol | Define ITT, assignment unit and missingness rule. |
| 6 | Chapters 18–20 and P10 design | Compare support, weighting and anticipation rules. |
| 7 | Chapters 21–24 and P01 | Score fixed forecast keys and defend the horizon. |
| 8 | Chapters 25–28 and P06 | Diagnose future-feature leakage from dated filings. |
| 9 | Chapters 29–30 and P04/P05 | Reconcile delivery and spending denominators. |
| 10 | Chapters 31–32 and P09 | Document threshold and measurement sensitivity. |
| 11 | Chapter 33 and P03 report | Review the trial flow and missing-outcome bounds. |
| 12 | Chapters 34–36 and P07/P11 | Produce a revenue or spatial decision memo. |
| 13 | Chapters 37–39 and P12 | Exchange the build record and verify permitted outputs. |
| 14 | Chapter 40 and P12 | Defend the article, correction and reproduction record. |

## Twenty-four-week sequence

Run a twelve-week methods semester and a twelve-week applications semester.
The first semester covers Parts I–VII and concludes with verification of the
maize pilot and a time- or group-based holdout. Use a technical examination
and one independently reproduced case. In the second semester, use Weeks
1–2 for P01/P02, 3–4 for P03/P04, 5–6 for P05/P06, 7–8 for P07–P09,
9–10 for P10/P11 and 11–12 for P12. Select a primary assignment in each
pair to limit duplication. Use the companion's report and evidence ledger
for review. Assign a second reader to the capstone with a clean extraction.

## Assessment and feedback

| Dimension | Points | Full-credit evidence |
| --- | --- | --- |
| Research question and design | 25 | Correct estimand, population, assumptions and decision. |
| Data lineage and sample | 20 | Fingerprints, named grain, eligibility and exact key ledger. |
| Computational and statistical method | 20 | Executable transformations, valid model, uncertainty and checked comparator. |
| Reproduction and discrepancy review | 20 | Clear entry point, version and logs. A verified rerun or resolved discrepancy. |
| Interpretation and decision communication | 15 | Numerically accurate units, substantive limitations and appropriate decision scope. |

For each dimension, award full points when the evidence meets the described
standard, approximately three quarters for a small traceable defect, half for
a materially incomplete but interpretable submission, and zero for a missing
or unrecoverable requirement. Grade a changed estimand separately from a
numerical mismatch. Offer the original scope and the first failed gate as
feedback before reviewing the final report.

## Sample examination

Use 120 minutes and 100 points.

1. **Sample and grain, 20 points.** Diagnose a revenue overstatement from
   repeated invoice balances. Identify the denominator of the error and write the
   aggregation order for a corrected merge.
2. **Survey inference, 25 points.** Derive the linearised contribution to a
   weighted domain ratio. Explain how retaining zero contributions outside
   the domain changes the treatment of the survey design frame.
3. **Identification, 25 points.** Compare inference for the matched
   observed-case offer contrast with inference for the eligible cohort.
   Explain the role of the assignment unit and one completion sensitivity.
4. **Predictive validation, 15 points.** Given two versions of each filing,
   identify admissible predictors for a future label. Interpret an increase
   in AUC caused by a later restatement.
5. **Reproducibility, 15 points.** Outline a second-reader audit that would
   detect a weighted model estimate reported under an unweighted key.

Use the submitted estimand, a valid calculation or diagnosis, and a
decision-facing interpretation as the three components of each answer.
The Stage 8 selected solution guide supplies worked quantitative and conceptual answers, the five examination answers and project-specific marking notes. Each guide states the exercise and the source result used for checking.
