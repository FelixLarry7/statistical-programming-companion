# Household poverty and welfare measurement

P02 · Survey poverty profile

## Decision and research design

How sensitive are poverty estimates to the poverty line, the weighting unit and the rural–urban comparison?

Use the D13 synthetic welfare fixture. Establish the declared welfare unit and time basis before contrasting a household-weighted headcount with a person-weighted headcount. The national teaching lines are GHS 2,200 and 2,600. Use Chapter 12 survey-domain methods for the rural and urban extension.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| GHS 2,200 household headcount | 51.35 | % |
| GHS 2,200 person headcount | 50.97 | % |
| GHS 2,600 household headcount | 63.22 | % |
| GHS 2,600 household gap | 21.33 | % |

## Interpretation

The higher teaching line increases the weighted headcount and raises the average normalised gap. National household and person headcounts differ because the person target gives larger households more representation. These are synthetic teaching rates. The empirical GLSS VII route requires the official welfare and survey files under GSS terms. A higher GHS 3,000 teaching line is included in the sensitivity output.

## Sensitivity and replication

Raise the line from GHS 2,200 to GHS 2,600 with the household sample fixed. Then change the weights on the same line and document the target population for each statistic.

The additional sensitivity check was rerun in Python and DuckDB on the frozen inputs.

| Line | Basis | N | Denominator | Headcount | Gap |
| --- | --- | --- | --- | --- | --- |
| 2200 | household | 600 | 782.5600 | 0.5135 | 0.1472 |
| 2200 | person | 600 | 3,897.3900 | 0.5097 | 0.1439 |
| 2600 | household | 600 | 782.5600 | 0.6322 | 0.2133 |
| 2600 | person | 600 | 3,897.3900 | 0.6345 | 0.2106 |
| 3000 | household | 600 | 782.5600 | 0.7301 | 0.2767 |
| 3000 | person | 600 | 3,897.3900 | 0.7268 | 0.2741 |

## Data and verification

Primary files include welfare36.csv · survey.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
