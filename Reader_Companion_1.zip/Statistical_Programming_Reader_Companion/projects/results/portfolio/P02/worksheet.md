# P02 replication worksheet

Decision question. How sensitive are poverty estimates to the poverty line, the weighting unit and the rural–urban comparison?

Controlled variation. Raise the line from GHS 2,200 to GHS 2,600 with the household sample fixed. Then change the weights on the same line and document the target population for each statistic.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
