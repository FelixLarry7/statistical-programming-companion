# P04 replication worksheet

Decision question. What is facility-delivery coverage for recent live births, how does it differ by residence, and how sensitive is it to missing recorded delivery location?

Controlled variation. Expand the reference window to 0–35 months as a sensitivity. Compare this result and the missing-location bounds while retaining the primary denominator.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
