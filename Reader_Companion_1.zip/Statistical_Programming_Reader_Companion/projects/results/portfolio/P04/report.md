# Public health risk and healthcare utilisation

P04 · Health-access report

## Decision and research design

What is facility-delivery coverage for recent live births, how does it differ by residence, and how sensitive is it to missing recorded delivery location?

The Chapter 30 synthetic estimate is a weighted ratio for live births aged 0–23 months with known delivery location. Use the complete stratum and PSU frame for linearisation and a Student reference with 16 design degrees of freedom. Keep a common covariate distribution for the additional adjusted residence contrast.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Eligible births with known location | 374 | births |
| Facility delivery coverage | 69.41 | % |
| Rural minus urban coverage | −25.10 | pp |
| Residence contrast, lower limit | −34.12 | pp |
| Residence contrast, upper limit | −16.08 | pp |

## Interpretation

The synthetic residence gap is substantial under the common observed-case definition. Changing the time window changes the sampled target, while the bounds keep the original window and vary the missing responses. Local service planning would require design-matched real data and contextual evidence about barriers and capacity.

## Sensitivity and replication

Expand the reference window to 0–35 months as a sensitivity. Compare this result and the missing-location bounds while retaining the primary denominator.

The additional sensitivity check was rerun in Python and DuckDB on the frozen inputs.

| Rural | Matched Cells | Minimum Cell N | Risk |
| --- | --- | --- | --- |
| 0 | 4 | 35 | 0.8535 |
| 1 | 4 | 35 | 0.6230 |

## Data and verification

Primary files include births30.csv · delivery14.csv · prediction14.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
