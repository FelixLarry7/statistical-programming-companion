# P08 replication worksheet

Decision question. How much does the choice of plot area change measured maize productivity, and what does a paired offer design establish about adoption?

Controlled variation. Substitute reported for GPS area while holding harvest and plot membership fixed. Next apply the positive-harvest restriction and label the sample change separately.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
