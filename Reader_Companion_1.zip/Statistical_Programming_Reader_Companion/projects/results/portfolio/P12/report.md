# Integrated multi-software research publication

P12 · Journal-style article and replication package

## Decision and research design

How does life expectancy covary with log real GDP per resident within selected economies after allowing for economy and year effects?

Freeze the World Development Indicators and Penn World Table 11.0 inputs for 2000–2023. Use ten balanced economies with equal weights for the principal regression, with economy-clustered covariance and the declared small-sample Student reference. State the distinction between within-economy association and a policy effect.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Balanced observations | 240 | economy-years |
| Balanced equal-weight slope | −1.33 | years/log point |
| Balanced-model lower interval bound | −7.65 | years/log point |
| Balanced-model upper interval bound | 4.99 | years/log point |
| Population-weighted slope | 2.98 | years/log point |
| Expanded-sample slope | 2.41 | years/log point |

## Interpretation

The weighted estimate reverses the sign of the equal-weight estimate. The intervals under the four specifications include zero. Ten balanced economies, selected coverage and time-varying confounding limit interpretation. The replication handoff preserves original licensed Stata results and specifies who can rerun each engine.

## Sensitivity and replication

Insert the weighted slope under the equal-weight key as a controlled error. Restore the original result and explain why its estimand and interval differ from the weighted fit.

## Data and verification

Primary files include map35.csv · pwt35.csv · wdi35.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
