# Integrated multi-software research publication

P12 · Journal-style article and replication package

## P12  Integrated multi-software research publication {#sec-project-p12}

**Research question.** How does life expectancy covary with log real GDP per resident within selected economies after allowing for economy and year effects?

**Design and data.** Freeze the World Development Indicators and Penn World Table 11.0 inputs for 2000–2023. Use ten balanced economies with equal weights for the principal regression, with economy-clustered covariance and the declared small-sample Student reference. State the distinction between within-economy association and a policy effect.

**Prepare the extract.** Reconcile provider codes, the economy crosswalk, price concept and missing-year dispositions before joining. Preserve the 312-key audit and the 240-row balanced set. Use a stable model key in every output.

**Assignment**

1. Prepare a protocol, reconstruct balanced and expanded ledgers and compute scope summaries for Ghana and the comparison economies.
2. Fit the four specified models and tabulate estimates, intervals, number of economies and weights. Distinguish income measurement, weighting and sample membership in the sensitivity analysis.
3. Write a journal-style article, produce figure data, package the manifest and assign a second reader to rebuild the primary table. Seed a weighted-value substitution and record how the verification rejects it.

**Change one assumption.** Insert the weighted slope under the equal-weight key as a controlled error. Restore the original result and explain why its estimand and interval differ from the weighted fit.

**Submit.** Submit the article with data-availability statement, tables and figures, both estimation samples, dependency and source manifests, discrepancy register and a second-reader rerun record.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
