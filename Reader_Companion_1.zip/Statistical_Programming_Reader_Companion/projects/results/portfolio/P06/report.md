# Bank credit risk and financial performance

P06 · Dashboard specification and validation report

## Decision and research design

Can the bank-quarter filing available at the forecast date predict the declared next-quarter asset-quality event, and how much apparent accuracy comes from late restatements?

Use the original synthetic filing and identity histories. Freeze the next-quarter outcome and the Chapter 31 training and test windows. Compare training prevalence and the time-valid model on the same holdout. Score the late-value model separately as a leakage control.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Comparable next-quarter outcomes | 543 | bank-quarters |
| Time-valid test observations | 138 | bank-quarters |
| Time-valid AUC | 0.835 | score |
| Late-restatement AUC | 0.996 | score |
| Late feature rows | 138 | bank-quarters |

## Interpretation

The change from AUC 0.835 to 0.996 accompanies 138 future-feature rows. The stronger score is unusable for an ex-ante decision. The federal data are contextual and retrospective here. A live asset-quality deployment needs a time-stamped validation, prevalence monitoring and an independently justified operational threshold.

## Sensitivity and replication

Replace the time-valid file by the later restatement, keeping target keys fixed. Count future-feature rows and explain how the availability error changes the apparent score.

## Data and verification

Primary files include assets31.csv · bank_filings31.csv · bank_ids31.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
