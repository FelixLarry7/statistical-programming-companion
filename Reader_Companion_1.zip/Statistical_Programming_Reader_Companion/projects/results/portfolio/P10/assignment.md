# Policy reform and difference-in-differences

P10 · Event-study design report

## P10  Policy reform and difference-in-differences {#sec-project-p10}

**Research question.** How sensitive is the event-study estimate to the comparator, the anticipation window and the support requirement?

**Design and data.** Use Chapter 18's synthetic staggered adoption panel, with explicit municipal cohorts and clean baselines. Compute group-time treatment effects with never-treated or eligible not-yet-treated comparisons and aggregate at event time using support-aware weights. Use shared multiplier draws and report the stated band.

**Prepare the extract.** Check uniqueness at municipality-period grain. Freeze cohort and treatment timing, eligibility, anticipation horizon and calendar support. Record target and control counts by cell, and preserve the stable shared replicate keys.

**Assignment**

1. Write the design and identification assumptions in a pre-analysis protocol, including the target, never-treated alternatives and admissible pre-reform periods.
2. Rebuild comparator membership, selected cohort-time estimates and event-time aggregates. Reproduce the published band with frozen draws and report supported periods.
3. Compare the conventional diagnostic with the adjusted cell path and the deliberately risky comparator. Use supported pre-policy contrasts as plausibility checks and state what they can and cannot establish about parallel counterfactual paths.

**Change one assumption.** Admit municipal controls during their anticipation window as a controlled failure, then inspect the shock response and event-time estimates under the original eligibility definition.

**Submit.** Submit a preregistration-style design note, cohort-time sample ledger, event-study figure, band and replication handoff. Include assumptions, code and an audit of unsupported cells.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
