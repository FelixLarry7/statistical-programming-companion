# Policy reform and difference-in-differences

P10 · Event-study design report

## Decision and research design

How sensitive is the event-study estimate to the comparator, the anticipation window and the support requirement?

Use Chapter 18's synthetic staggered adoption panel, with explicit municipal cohorts and clean baselines. Compute group-time treatment effects with never-treated or eligible not-yet-treated comparisons and aggregate at event time using support-aware weights. Use shared multiplier draws and report the stated band.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Never-treated comparator, event time zero | 2.573 | points |
| Eligible comparator, event time zero | 2.573 | points |
| Risky comparator, event time zero | 1.620 | points |
| Published band lower bound | 2.128 | points |
| Published band upper bound | 3.019 | points |

## Interpretation

The two admissible comparator routes agree at event time zero. The deliberately risky comparator gives a smaller estimate. Comparator choice changes the counterfactual and therefore should be resolved before fitting. A convincing policy design needs substantive evidence about anticipation, comparability and exposure.

## Sensitivity and replication

Admit municipal controls during their anticipation window as a controlled failure, then inspect the shock response and event-time estimates under the original eligibility definition.

## Data and verification

Primary files include rollout18.csv · multipliers18.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
