# P10 replication worksheet

Decision question. How sensitive is the event-study estimate to the comparator, the anticipation window and the support requirement?

Controlled variation. Admit municipal controls during their anticipation window as a controlled failure, then inspect the shock response and event-time estimates under the original eligibility definition.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
