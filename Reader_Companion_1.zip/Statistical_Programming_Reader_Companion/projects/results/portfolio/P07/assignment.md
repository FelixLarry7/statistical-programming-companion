# Business intelligence and customer analytics

P07 · Management brief

## P07  Business intelligence and customer analytics {#sec-project-p07}

**Research question.** What net bookings and forecast losses follow from a defined transaction contract, and which procurement rule is defensible for the three-product fixture?

**Design and data.** Use the attributed UCI Online Retail adaptation. Organise the revenue reconciliation by eligible invoice before repeating customer or product measures. Freeze the forecasting window and compare naïve and trailing-four-week rules against a shared demand proxy and shortage cost.

**Prepare the extract.** Classify positive sales, eligible cancellations, exceptions and anonymous customer rows before joining. Keep the original sign and integer pence. Establish aggregate grain for booked revenue, product-week forecasts and customer cohorts.

**Assignment**

1. Rebuild the net bookings and the wrong repeated-invoice join in SQL. Show how preaggregation fixes the amount and keep cancellation and return credits separate.
2. Reproduce the held-out MAE and cost table for each product, with an explicit forecasting cutoff. Check keys and loss denominators before comparing forecasts.
3. Draft a decision memo that explains how lead time, stockouts and returns affect a demand proxy. Design an alert for a plausible sensitivity in one replenishment cost.

**Change one assumption.** Score the last six holdout weeks separately, maintaining their observation keys, and compare with the original twelve-week loss. Trace the effect of counting repeated invoice balances as separate revenue.

**Submit.** Submit a management brief, metric dictionary, revenue groups, matched forecasts and loss table. Include the source attribution and recoding note.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
