# Business intelligence and customer analytics

P07 · Management brief

## Decision and research design

What net bookings and forecast losses follow from a defined transaction contract, and which procurement rule is defensible for the three-product fixture?

Use the attributed UCI Online Retail adaptation. Organise the revenue reconciliation by eligible invoice before repeating customer or product measures. Freeze the forecasting window and compare naïve and trailing-four-week rules against a shared demand proxy and shortage cost.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Net booked value | 295,491.85 | GBP |
| Repeated-invoice overstatement | 75,156.93 | GBP |
| Product 85123A naïve MAE | 475.83 | units |
| Product 85123A mean-of-four MAE | 335.44 | units |

## Interpretation

Corrected booked revenue is £295,491.85 in the scoped extract. Repeating balances overstates it by £75,156.93. The trailing mean has lower held-out MAE for the reported product, but transactional quantity may reflect lost sales and stock availability. A commercial rollout calls for fresh calibration.

## Sensitivity and replication

Score the last six holdout weeks separately, maintaining their observation keys, and compare with the original twelve-week loss. Trace the effect of counting repeated invoice balances as separate revenue.

## Data and verification

Primary files include retail34.csv · returns34.csv · ch07_invoices.csv · ch07_lines.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
