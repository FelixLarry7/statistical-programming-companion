# P07 replication worksheet

Decision question. What net bookings and forecast losses follow from a defined transaction contract, and which procurement rule is defensible for the three-product fixture?

Controlled variation. Score the last six holdout weeks separately, maintaining their observation keys, and compare with the original twelve-week loss. Trace the effect of counting repeated invoice balances as separate revenue.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
