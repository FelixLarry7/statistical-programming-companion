# Economic growth and macroeconomic forecasting

P01 · Forecast evaluation

## P01  Economic growth and macroeconomic forecasting {#sec-project-p01}

**Research question.** Can an autoregression improve forecasts of annual real GDP growth in Ghana, Kenya and Senegal, and does the answer change when the target is the level of an output index?

**Design and data.** Use the Chapter 29 rolling origins from 2015 through 2022, with one- and two-year horizons. Compare an autoregression with the trailing five-year mean in percentage points. Chapter 22 forms a separate output-index comparison with a naïve benchmark, AR(1) and conditional MA. Retain a distinct origin, target year, horizon and data-vintage field in each ledger.

**Prepare the extract.** Key by country and year. Check contiguous training periods and verify that an origin-horizon target follows its training window. Match the model and comparator to the same scored keys. For monetary context, expand the published effective dates before taking the day-weighted annual policy rate.

**Assignment**

1. Reproduce the Ghana growth errors in the two horizons. Recalculate RMSE and MAE from the keyed errors and provide the full three-country scorecard.
2. Compare the three Chapter 22 index forecasts at matched origins and one-, two- and three-year horizons. Label the growth and index units separately.
3. Build 95% predictive intervals for Ghana’s growth autoregression and five-year mean. Use rolling one-step residuals available by each origin, or a documented model-based variance. Report interval coverage and average width by horizon. Check whether revised inputs limit the real-time interpretation.

**Change one assumption.** Change from the one-year to the two-year growth horizon. Then compare the 2024 calendar-day mean policy rate with the rate on 31 December. Treat the rate as contextual evidence with its own time basis.

**Submit.** Submit a 750-word forecast brief, source-vintage register, origin–horizon ledger, score table and one plot with a text alternative. Record your interval construction in an appendix.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
