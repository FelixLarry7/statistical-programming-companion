# Regional inequality and spatial development

P11 · Spatial diagnostic and map

## P11  Regional inequality and spatial development {#sec-project-p11}

**Research question.** Are regional access values spatially clustered under the 2021 geography, and how much does the result depend on the neighbour graph?

**Design and data.** Use 16 published regional percentages from the 2021 census and the pinned Ghana ADM1 geometry. Compare row-standardised rook contiguity with a symmetrised three-nearest-neighbour graph. Reconcile keys and exact permutations before comparing global Moran’s I.

**Prepare the extract.** Join the regional table to the geometry identifiers through the 2021 crosswalk. Confirm all 16 matched regions and log graph weights, diagonal and row sums. Store geometry release, geographic reference system and original-source attribution.

**Assignment**

1. Produce directed edge and neighbour counts and verify that each row has a valid weight sum. Cross-check the weights against the frozen files.
2. Reproduce global Moran’s I and the fixed-permutation probabilities under both graphs. Describe the null, precision of the fixed draw count and the unit of inference.
3. Deliver an accessible map and describe two scale sensitivities. Discuss why a region-level cluster cannot establish household-level mechanisms.

**Change one assumption.** Switch from rook contiguity to symmetrised three-nearest neighbours on the same regions and percentages. Document the change in weights, edge count and statistic.

**Submit.** Submit an accessible map, spatial diagnostic note, crosswalk and weighted-edge audit with original credits and source citations.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
