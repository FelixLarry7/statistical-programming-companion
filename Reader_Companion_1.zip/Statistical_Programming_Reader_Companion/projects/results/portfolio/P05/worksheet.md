# P05 replication worksheet

Decision question. How do weighted insurance coverage and expected healthcare spending vary across the declared populations, and what interpretation survives voluntary insurance selection?

Controlled variation. Exclude zero costs solely as a deliberate diagnostic. Compare the positive-only mean with the full mean and quantify the effect of switching the stated estimand.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
