# Food security and rural household vulnerability

P09 · Vulnerability profile

## Decision and research design

How does an eligible seven-day meal-shortfall indicator vary by residence, and how sensitive is a separate expenditure-based screening measure to the chosen cutoff?

Use the synthetic Chapter 32 household survey. Estimate a domain ratio and design-based interval for the meal-shortfall indicator. Construct a separate low food-spending indicator on the same observed-outcome universe. Use two explicitly labelled thresholds in fixture units.

## Observed results

| Quantity | Result | Unit |
| --- | ---: | --- |
| Households with observed shortfall | 231 | households |
| Overall meal shortfall | 36.14 | % |
| Rural meal shortfall | 46.57 | % |
| Urban meal shortfall | 17.41 | % |

## Interpretation

The frozen weighted shortfall is higher in the synthetic rural domain. The alternative threshold changes the screening rate by design. The exercise indicators do not stand in for a verified CFSVA measurement protocol. Conclusions about actual populations require approved source records and scope alignment.

## Sensitivity and replication

Raise the per-person expenditure threshold from 200 to 300 and then compare the change by domain. Retain the recorded shortfall outcome and its definition.

The additional sensitivity check was rerun in Python and DuckDB on the frozen inputs.

| Line | Domain | N | Denominator | Prevalence |
| --- | --- | --- | --- | --- |
| 200 | All | 231 | 431.6600 | 0.0000 |
| 200 | Rural | 136 | 277.2800 | 0.0000 |
| 200 | Urban | 95 | 154.3800 | 0.0000 |
| 300 | All | 231 | 431.6600 | 0.3759 |
| 300 | Rural | 136 | 277.2800 | 0.3738 |
| 300 | Urban | 95 | 154.3800 | 0.3796 |

## Data and verification

Primary files include households32.csv · survey.csv · welfare36.csv. The specification records the exact files, observational units, fingerprints, output paths and engine scope. The archived Stata outputs accompany the original chapter specification.
