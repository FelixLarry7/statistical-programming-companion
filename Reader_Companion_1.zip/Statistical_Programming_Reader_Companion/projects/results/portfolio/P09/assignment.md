# Food security and rural household vulnerability

P09 · Vulnerability profile

## P09  Food security and rural household vulnerability {#sec-project-p09}

**Research question.** How does an eligible seven-day meal-shortfall indicator vary by residence, and how sensitive is a separate expenditure-based screening measure to the chosen cutoff?

**Design and data.** Use the synthetic Chapter 32 household survey. Estimate a domain ratio and design-based interval for the meal-shortfall indicator. Construct a separate low food-spending indicator on the same observed-outcome universe. Use two explicitly labelled thresholds in fixture units.

**Prepare the extract.** Freeze household grain, survey weights, missing codes and recall definition. Create the complete domain frame before summing PSU-level contributions. Keep weighted numerator, denominator and observed count for both measures.

**Assignment**

1. Reproduce the all, rural and urban shortfall estimates and intervals, retaining the original survey design and outcome window.
2. Run the supplied threshold extension at 200 and 300 synthetic expenditure units per person. Report each threshold, number of households and weighted headcount. Explain why it is a distinct indicator from meal shortfall.
3. Describe how an approved CFSVA analysis would check instrument wording, recall windows, spatial coverage and the interpretation of the resulting rates.

**Change one assumption.** Raise the per-person expenditure threshold from 200 to 300 and then compare the change by domain. Retain the recorded shortfall outcome and its definition.

**Submit.** Submit a two-page food security brief, design-based table, sensitivity chart and a short statement on suitability for prioritising further survey work.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
