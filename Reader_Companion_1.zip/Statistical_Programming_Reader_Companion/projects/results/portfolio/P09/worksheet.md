# P09 replication worksheet

Decision question. How does an eligible seven-day meal-shortfall indicator vary by residence, and how sensitive is a separate expenditure-based screening measure to the chosen cutoff?

Controlled variation. Raise the per-person expenditure threshold from 200 to 300 and then compare the change by domain. Retain the recorded shortfall outcome and its definition.

Record each entry before writing the report.

| Evidence | Your record |
| --- | --- |
| Frozen data IDs, version and checksum |  |
| Unit, analytical key and inclusion rule |  |
| Training or design frame and sample counts |  |
| Estimand, units and reference distribution |  |
| Python, R, DuckDB and Stata scope |  |
| Comparison key, discrepancy and original bound |  |
| Baseline and changed scenario |  |
| Decision and limits of inference |  |

A second reader should be able to rerun your reported result from the submitted files.
