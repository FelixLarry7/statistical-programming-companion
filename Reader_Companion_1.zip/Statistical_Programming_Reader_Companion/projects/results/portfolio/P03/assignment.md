# Social protection impact evaluation

P03 · Evaluation protocol and policy note

## P03  Social protection impact evaluation {#sec-project-p03}

**Research question.** What does a paired village experiment establish about an offer, and how far does incomplete follow-up limit the decision?

**Design and data.** Use the 24-pair, 48-village synthetic eligibility roster in Chapter 33. The observed-case analysis averages matched village contrasts. Define the original eligible-cohort ITT before seeing the outcome, recognising that follow-up is missing for some households. Chapter 17 offers an independently enumerated blocked-lottery check.

**Prepare the extract.** Validate one assignment per village, one offered village in each pair and eligibility before assigning observation status. Join the assignment to the screened roster using the village key. Align sample, pairing and sign draws before inference.

**Assignment**

1. Register target population, assignment unit, primary outcome, pairing, covariance and missing-outcome plan before preparing the results table.
2. Reconcile screening to follow-up by arm. Reproduce the observed-case estimate, paired interval and randomisation calculation with frozen sign vectors. Describe the sharp-null claim.
3. Compare the three- and six-point missingness departures with the full outcome-range bounds. Write a conditional recommendation against the prespecified three-point planning threshold in Chapter 33 and defend it in a replication exchange.

**Change one assumption.** Replace the observed-case interpretation with an eligible-cohort claim using the documented completion bounds. Trace what changes when assumptions about missing outcomes are relaxed.

**Submit.** Submit the pre-analysis plan, one-page trial flow, effect table, verified sensitivity ledger, policy note and a reviewer rerun instruction.

**Evidence to retain**

- Observed sample keys and exclusions
- Selected estimate, interval or scoring denominator
- Engine result, version and original execution or replay status
- Change in result or interpretation under the declared variation

Use the project specification for the input paths and the teaching rubric for submission criteria.
