# Applied research portfolio

Use the twelve assignments in **results/portfolio/** with the book's
chapter explanations. Each project directory includes an assignment,
replication worksheet, design specification, file and checksum list,
engine routes, checked reference values and a decision-facing report.
The reported baseline metrics use the released Stage 6 evidence.
The added poverty, delivery, insurance and food-threshold exercises
compare independent Python and DuckDB implementations.

From the companion root, verify the archive and rebuild the project reports.

~~~sh
sha256sum -c --quiet MANIFEST.sha256
python projects/build.py --output build/projects
python projects/build.py --one P03 --output build/project-P03
~~~

The chapter runner and environment records are in **verification/**
and **environments/**. Use the project specification to select a part
and the model keys before reproducing the full chapter. Original Stata
execution is documented separately from licensed replay. To run Stata,
use the institution's local licensed installation and the supplied
do-file and handoff notes.

The teaching files reproduce the book's specified exercises. The
source register distinguishes frozen inputs, provider-retrieval routes
and custodian approvals. Work through the public teaching baseline
before substituting institutional data or refreshed releases.
