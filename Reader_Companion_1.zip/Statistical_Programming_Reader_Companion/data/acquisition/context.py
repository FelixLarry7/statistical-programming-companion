"""Rebuild optional Stage 4 context extracts from downloaded provider bytes."""
import argparse
from collections import Counter
import csv
from datetime import datetime
from decimal import Decimal
from hashlib import sha256
from io import TextIOWrapper
import json
from pathlib import Path
import re
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
FDIC = 'CERT REPDTE ASSET LNLSGR LNLSNET NCLNLS NCLNLSR'.split()
FAO = 'area_code area item_code item element_code element year unit value flag note'.split()


def write(path, names, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='') as file:
        writer = csv.writer(file, lineterminator='\n')
        writer.writerow(names)
        writer.writerows(rows)


def bog(path):
    content = path.read_text()
    rates = re.search(r'"name":"BOG Policy Rate".*?"data":(\[[^]]+\])', content)
    dates = re.search(r'"categories":(\["[^]]+\])', content[rates.start():])
    pairs = [(datetime.strptime(dt.strip(), '%d %b %Y').strftime('%Y-%m-%d'), Decimal(str(rate)))
             for dt, rate in zip(json.loads(dates[1]), json.loads(rates[1]), strict=True)]
    rows = [(dt, rate) for dt, rate in pairs if dt <= '2024-12-31']
    assert len(rows) == 122 and len(set(dt for dt, _ in rows)) == 122
    return sorted(rows)


def fao(path):
    with ZipFile(path) as archive:
        name, = [name for name in archive.namelist() if name.endswith('_All_Data_(Normalized).csv')]
        with TextIOWrapper(archive.open(name), encoding='latin-1', newline='') as handle:
            fields = 'Area Code|Area|Item Code|Item|Element Code|Element|Year|Unit|Value|Flag|Note'.split('|')
            rows = [tuple(record[k] for k in fields) for record in csv.DictReader(handle)
                    if record['Area Code'] == '81' and record['Item Code'] == '56'
                    and record['Element Code'] in {'5312','5412','5510'}
                    and 2010 <= int(record['Year']) <= 2024]
    counts = Counter(row[9] for row in rows)
    assert len(rows) == 45 and counts == {'A':34,'X':8,'E':2,'I':1}, counts
    return sorted(rows, key=lambda r: (r[6], r[4]))


def fdic(path):
    obj = json.loads(path.read_text(), parse_float=Decimal)
    rows = [entry['data'] for entry in obj['data']]
    keys = [(r['CERT'], r['REPDTE']) for r in rows]
    assert len(keys) == len(set(keys)) == 64
    assert sorted(Counter(key[0] for key in keys).values()) == [16] * 4
    errors = [abs(Decimal(r['NCLNLSR']) - Decimal(100*r['NCLNLS'])/r['LNLSGR']) for r in rows]
    assert max(errors) < Decimal('1E-14')
    rows.sort(key=lambda r: (r['CERT'],r['REPDTE']))
    return [tuple(row[f] for f in FDIC) for row in rows], str(max(errors)), obj['meta']['index']


def water(path):
    with path.open(newline='') as handle:
        source = [(r['REGION'], Decimal(r['TOTAL'])) for r in csv.DictReader(handle,delimiter='\t')
                  if r['REGION'] and r['TOTAL']]
    assert source[0] == ('Ghana',Decimal('87.7')) and len(source) == 17
    return [(r,p) for r,p in source[1:]]


def rebuild(identifier, source, target):
    recipes = json.loads((ROOT/'catalog/provider_files.json').read_text())
    receipt, = [r for r in recipes if r['id'] == identifier]
    if sha256(source.read_bytes()).hexdigest() != receipt['retrieved_sha256']:
        raise ValueError('Source bytes differ from the verified retrieval. Review the revision before rebuilding.')
    if target.exists():
        raise ValueError('Supply a fresh output path.')
    choices = {'D02-01':(('effective_date','policy_rate'),bog),
               'D07-01':(FAO,fao),'D10-01':(FDIC,lambda p:fdic(p)[0]),
               'D11-01':(('region','basic_water_pct'),water)}
    fields, transform = choices[identifier]
    rows = transform(source)
    write(target,fields,rows)
    print(f'{identifier}: rebuilt {len(rows)} rows at {target}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_id', choices=('D02-01','D07-01','D10-01','D11-01'))
    parser.add_argument('source_file',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    rebuild(args.source_id,args.source_file,args.output)
