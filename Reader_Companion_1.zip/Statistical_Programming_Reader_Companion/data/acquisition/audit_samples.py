"""Record exact analytical keys and mutually exclusive sample dispositions."""
from collections import Counter
from decimal import Decimal
import json
from pathlib import Path

from catalogue import load
from context import write

DATA=Path(__file__).resolve().parents[1]
ROOT=DATA.parent
LEDGERS=DATA/'ledgers'


def rows(part, filename):
    base=ROOT/'chapter_companions'/f'Part_{part}'/'companion'/'data'
    path, = list(base.rglob(f'{filename}.csv'))
    return load(path)[1]


def register(case, keys, source, disposition, **metadata):
    records=sorted([(*(str(r[k]) for k in keys),disposition(r)) for r in source])
    assert len(records)==len(set(r[:-1] for r in records)), case
    write(LEDGERS/f'{case}.csv',(*keys,'disposition'),records)
    write(LEDGERS/f'{case}_included.csv', keys,[r[:-1] for r in records if r[-1]=='included'])
    return {'case':case,'source_records':len(records),'dispositions':dict(sorted(Counter(r[-1] for r in records).items())),**metadata}


def binary(row, field, outside='out_of_scope'):
    return 'included' if row[field]=='1' else outside


def facility(row):
    if row['live']!='1':
        return 'not_live_birth'
    if int(row['months'])>=24:
        return 'outside_24_months'
    return 'included' if row['facility'] in {'0','1'} else 'unknown_place'


def bank():
    filings=rows('VIII','bank_filings31')
    ids={(r['source'],r['quarter']):r for r in rows('VIII','bank_ids31')}
    initial={}
    for r in filings:
        if int(r['release'])<=int(r['quarter'])+1:
            key=(r['source'],r['quarter'])
            if key not in initial or int(r['release'])>int(initial[key]['release']):
                initial[key]={**r,**ids[key]}
    bank_rows={(r['bank'],int(r['quarter'])):r for r in initial.values()}
    assert len(bank_rows)==len(ids)==568
    def disposition(r):
        following=bank_rows.get((r['bank'],int(r['quarter'])+1))
        if following is None:
            return 'no_next_quarter'
        return 'included' if following['segment']==r['segment'] else 'segment_break'
    return register('ch31_comparable_filings',('bank','quarter'),bank_rows.values(),disposition,
                    source_filings=len(filings))


def maize(row):
    if row['maize']!='1':
        return 'other_crop'
    if Decimal(row['harvest'])<0:
        return 'missing_harvest'
    if Decimal(row['gps'])<=0 or Decimal(row['reported'])<=0 or row['unit'] not in {'1','2'}:
        return 'invalid_area_or_unit'
    return 'included'


def trial():
    roster=rows('IX','roster33')
    assignment={r['village']:r['offer'] for r in rows('IX','assignment33')}
    counts={}
    for assignment_value in ('0','1'):
        arm=[r for r in roster if assignment[r['village']]==assignment_value]
        counts[assignment_value]={'screened':len(arm),'eligible':sum(r['eligible']=='1' for r in arm),
                                  'observed':sum(r['eligible']=='1' and r['observed']=='1' for r in arm)}
    def disposition(r):
        if r['eligible']=='0':
            return 'out_of_scope'
        return binary(r,'observed','followup_missing')
    return register('ch33_followup',('household',),roster,disposition,counts_by_offer=counts)


def panel():
    source=rows('IX','wdi35')
    mapping={r['economy']:r['include'] for r in rows('IX','map35')}
    pwt={(r['economy'],r['year']):r for r in rows('IX','pwt35')}

    def positive(value):
        return bool(value) and Decimal(value)>0

    def disposition(r):
        if mapping[r['economy']]!='1':
            return 'aggregate_out_of_scope'
        other=pwt.get((r['economy'],r['year']))
        if other is None:
            return 'no_pwt_match'
        if not r['life'] or not positive(r['population']) or not positive(other['rgdpe']) or not positive(other['pop']):
            return 'missing_or_nonpositive_input'
        return 'included'

    key=('economy','year')
    expanded=register('ch35_expanded_panel',key,source,disposition)
    retained=[r for r in source if disposition(r)=='included']
    counts=Counter(r['economy'] for r in retained)
    balanced=register('ch35_balanced_panel',key,retained,
                      lambda r:'included' if counts[r['economy']]==24 else 'incomplete_economy_window')
    return [expanded,balanced]


def care(r):
    if r['need']!='1':
        return 'outside_care_need_domain'
    return 'included' if r['unmet'] in {'0','1'} else 'unknown_care_outcome'


def build():
    pilot=load(ROOT/'companion/pilot/evidence/licensed/duckdb/sample_audit.csv')[1]
    records=[
        register('ch13_pilot',('plot_id','season'),pilot,lambda r:r['reason']),
        register('ch12_survey_universe',('hh_id',),rows('III','survey'),lambda r:binary(r,'eligible')),
        register('ch17_trial_universe',('household',),rows('V','households17'),lambda r:binary(r,'eligible')),
        register('ch18_rollout',('unit','period'),rows('V','rollout18'),lambda r:binary(r,'in_scope')),
        register('ch30_facility_delivery',('person',),rows('VIII','births30'),facility),
        bank(),
        register('ch32_meal_shortfall',('household',),rows('VIII','households32'),
                 lambda r:'included' if r['meal_shortfall'] in {'0','1'} else 'unknown_response'),
        register('ch32_maize_yield',('plot','season'),rows('VIII','plots32'),maize),
        trial(), *panel(),
        register('ch36_care_domain',('household',),rows('IX','welfare36'),care),
    ]
    for rec, expected in zip(records,(12,24,96,390,374,543,231,267,831,256,240,269),strict=True):
        assert rec['dispositions']['included']==expected,rec
    old=load(ROOT/'companion/pilot/evidence/licensed/duckdb/analytical.csv')[1]
    new=load(ROOT/'companion/reporting/outputs/scenario_analytical.csv')[1]
    assert [(r['plot_id'],r['season']) for r in old]==[(r['plot_id'],r['season']) for r in new]
    assert [a['plot_id'] for a,b in zip(old,new,strict=True) if Decimal(a['harvest_kg'])!=Decimal(b['harvest_kg'])]==['P011']
    result={'case_ledgers':records,'changed_plot':'P011','same_corrected_sample_keys':len(old)}
    (DATA/'quality/sample_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f'{len(records)} sample ledgers and matching included-key files.')


if __name__=='__main__':
    build()
