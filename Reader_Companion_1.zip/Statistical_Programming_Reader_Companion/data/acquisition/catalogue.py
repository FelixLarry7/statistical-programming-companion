"""Build the dataset catalogue and observed field index from the frozen inputs."""
from collections import Counter
from csv import DictReader
from decimal import Decimal, InvalidOperation
from hashlib import sha256
import json
from pathlib import Path

from context import write

DATA = Path(__file__).resolve().parents[1]
ROOT = DATA.parent
CODEBOOK = {'I':'data/codebook.md','II':'data/dictionary.csv','III':'data/dictionary.csv',
            'IV':'data/codebook.csv','V':'data/codebook.md','VI':'data/codebook.md',
            'VII':'data_dictionary.md','VIII':'DATA_DICTIONARY.md','IX':'DATA_DICTIONARY.md'}
DEFINITIONS = {
    'rgdpe': ('Expenditure-side real GDP at chained PPPs','million 2021 USD'),
    'rgdpo': ('Output-side real GDP at chained PPPs','million 2021 USD'),
    'rgdpna': ('Real GDP at constant national prices','million 2021 USD'),
    'pop': ('Penn World Table resident population','million people'),
    'emp': ('Penn World Table persons engaged','million people'),
    'life': ('Life expectancy at birth','years'),
    'gdp2015': ('WDI real GDP per resident','constant 2015 USD'),
    'u5': ('Under-five mortality rate','per 1,000 live births'),
    'population': ('WDI midyear population','people'),
    'harvest_kg': ('Recorded harvest weight','kg'),
    'yield_kg_ha': ('Harvest divided by eligible area','kg/ha'),
    'yield_t_ha': ('Yield per hectare','tonnes/ha'),
    'area_m2': ('Recorded plot area','m²'),
    'area_ha': ('Cultivated area','ha'),
    'weight': ('Relative analytical weight','chapter-specific'),
    'weight10': ('Relative weight stored in tenths','tenths of a weight unit'),
    'lat': ('Centroid latitude','degrees'),
    'lon': ('Centroid longitude','degrees'),
    'policy': ('Policy rate in force on date','percent'),
    'growth': ('Annual real GDP growth','percent'),
    'cpi': ('Annual consumer-price inflation','percent'),
    'deflator': ('Annual GDP deflator inflation','percent'),
    'unemployment': ('Modelled unemployment','percent of labour force'),
    'tax': ('Tax revenue','percent of GDP'),
    'lending': ('Annual lending rate','percent'),
    'pence': ('Unit price','GBP pence'),
    'CERT': ('FDIC certificate identifier','institution code'),
    'REPDTE': ('Financial report date','YYYYMMDD'),
    'ASSET': ('Total assets','thousand USD'),
    'LNLSGR': ('Gross loans and leases','thousand USD'),
    'LNLSNET': ('Net loans and leases','thousand USD'),
    'NCLNLS': ('Total noncurrent loans and leases','thousand USD'),
    'NCLNLSR': ('Noncurrent loans and leases relative to gross loans and leases','percent'),
    'meal_shortfall': ('Shortfall response on the teaching food-access item','0 no, 1 yes, −1 unknown'),
    'facility': ('Place of delivery','0 other, 1 facility, −1 unknown'),
    'unmet': ('Unmet care conditional on need','0 no, 1 yes, −1 unknown or out of domain'),
}
NULLS = {None, '', 'NA', 'NaN', 'NULL', '.'}
EXPECTED_DEFECTS = {'ch08_members_defect.csv','ch08_households_defect.csv'}


def source_path(row):
    part, name = row['part'], row['file']
    if part not in CODEBOOK:
        return ROOT/name, ROOT/'data/codebooks/data_notes.md'
    prefix = ROOT/'chapter_companions'/f'Part_{part}'/'companion'
    options = [item for item in (prefix/'data').rglob(name) if item.is_file()]
    path, = options
    return path, prefix/CODEBOOK[part]


def load(path):
    if path.suffix == '.json':
        objects = json.loads(path.read_text())
        if isinstance(objects[1], list):
            objects = objects[1]
        names = list(dict.fromkeys(k for r in objects for k in r))
        return names, objects
    with path.open(encoding='utf-8-sig',newline='') as handle:
        reader=DictReader(handle)
        return reader.fieldnames, list(reader)


def null(value):
    return not isinstance(value,(list,dict)) and value in NULLS


def storage(values):
    if not values:
        return 'all missing'
    if any(isinstance(v, (dict,list)) for v in values):
        return 'structured JSON'
    if any(isinstance(v, bool) for v in values):
        return 'boolean'
    if all(str(v).isdigit() or str(v).startswith('-') and str(v)[1:].isdigit() for v in values):
        if any(str(v).lstrip('-').startswith('0') and len(str(v).lstrip('-')) > 1 for v in values):
            return 'text with leading zero'
        return 'integer'
    try:
        if all(Decimal(str(v)).is_finite() for v in values):
            return 'decimal'
    except InvalidOperation:
        pass
    return 'text'


def build():
    with (DATA/'catalog/tables.tsv').open(newline='') as handle:
        declared=list(DictReader(handle,delimiter='\t'))
    catalogue, fields, sizes = [], [], []
    for item in declared:
        part, chapter, grain = (item[k] for k in ('part','chapter','grain'))
        path, codebook = source_path(item)
        assert codebook.is_file(), codebook
        names, records = load(path)
        key = item['primary_key'].split()
        if path.suffix == '.json' and key == ['record_id'] and 'record_id' not in names:
            key = ['countryiso3code','date','indicator']
        assert set(key).issubset(names), (path,key,names)
        if path.suffix == '.json':
            keys = [tuple(json.dumps(r.get(k),sort_keys=True) for k in key) for r in records]
        else:
            keys = [tuple(r.get(k) for k in key) for r in records]
        duplicates, incomplete = len(keys)-len(set(keys)), sum(any(null(value) for value in k) for k in keys)
        rel = path.relative_to(ROOT).as_posix()
        guide = codebook.relative_to(ROOT).as_posix()
        if duplicates and path.name not in EXPECTED_DEFECTS:
            raise ValueError(f'Unexpected duplicate key in {rel}: {duplicates}')
        status='seeded defect' if path.name in EXPECTED_DEFECTS else 'checked'
        catalogue.append((part,chapter,rel,item['sources'],grain,' '.join(key),len(records),len(names),
                          sha256(path.read_bytes()).hexdigest(),guide))
        sizes.append((rel,len(records),len(set(keys)),duplicates,incomplete,status))
        for name in names:
            values=[r.get(name) for r in records if not null(r.get(name))]
            role='primary key' if name in key else ''
            meaning, unit=DEFINITIONS.get(name, ('See chapter codebook', ''))
            fields.append((rel, name, storage(values),role,meaning,unit,len(records)-len(values),guide))
    write(DATA/'catalog/dataset_catalogue.csv',
          ('part','chapter','path','source_ids','grain','primary_key','rows','fields','sha256','codebook'),catalogue)
    write(DATA/'codebooks/field_index.csv',
          ('path','field','observed_type','key_role','definition','unit_or_domain','missing_rows','codebook'),fields)
    write(DATA/'quality/table_key_checks.csv',
          ('path','rows','distinct_keys','duplicate_key_rows','incomplete_key_rows','status'),sizes)
    print(f'{len(catalogue)} tables and {len(fields)} fields.')


if __name__ == '__main__':
    build()
