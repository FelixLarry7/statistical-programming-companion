# Stage 4 data companion

Start with the dataset catalogue. It links each frozen table to its chapter,
source family, grain, key, checksum and codebook. The field index records
schema and missingness. The sample ledgers record a disposition for each
source key and a separate file of included keys. Keep the survey design
frame for variance estimation when using the domain ledgers.

## Retrieve provider files

The provider register supplies downloadable file IDs, original URLs, observed
SHA-256 fingerprints and any different frozen archive hash. Use a new output
directory to avoid confusing an updated response with the pinned edition.
A changed response creates a separate mismatch record. Keep source changes
only after reviewing schema, coverage, reporting dates and values.

~~~sh
python data/acquisition/fetch_sources.py --list
python data/acquisition/fetch_sources.py D09-01 D12-01 --output build/provider
python data/acquisition/fetch_sources.py D10-01 --output build/provider
python data/acquisition/context.py D10-01 \
  build/provider/bankfind_four_banks_raw.json build/fdic_rebuilt.csv
~~~

For the complete retail reconstruction, copy
**chapter_companions/Part_IX/companion/source/** to a disposable directory.
Run the companion's **prepare_inputs.py** with **--source** pointing to
that copy, **--uci-archive** to the downloaded workbook archive and
**--output** to a new location. The acquisition receipts, source checks
and reconstruction evidence identify the exact files and scope.

## Use the rights register

The review archive preserves evidence for the author and contains the
teaching path. The asset decisions specify the narrower public release
routes. The custodian guide identifies approved or application-based
empirical routes. Use a documented research purpose and the conditions
for the exact files and intended publications. Controlled microdata are
excluded. Public provider profiles in the companion include aggregate
counts and descriptions of fields.
