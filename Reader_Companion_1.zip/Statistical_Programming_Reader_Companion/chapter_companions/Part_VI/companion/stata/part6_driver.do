*! Part VI comparative labs. Stata 16 or 17 and built-in Mata.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide the input and output folders."
    exit 198
}
mata:
string scalar vi_id(real scalar x)
{
    return(strtrim(strofreal(x,"%12.0f")))
}

void vi_put(real scalar f, string scalar chapter, string scalar model,
    string scalar quantity, string scalar key, real scalar value)
{
    assert(value<.)
    fput(f,chapter+","+model+","+quantity+","+key+","+strtrim(strofreal(value,"%24.16g")))
}

void vi_beta(real scalar f, string scalar ch, string scalar model,
    string rowvector keys, real colvector value)
{
    real scalar j
    assert(cols(keys)==rows(value))
    for (j=1;j<=rows(value);j++) vi_put(f,ch,model,"beta",keys[j],value[j])
}

real scalar vi_sd(real colvector u)
{
    return(sqrt(sum((u:-mean(u)):^2)/(rows(u)-1)))
}

void vi21(real scalar f, real matrix d, real rowvector native)
{
    real matrix a, x, xb, xc, bread, meat, cov, dx, dyn, z, xp
    real colvector use, i, g, y, yb, yc, b, u, q, theta, alpha, regy, first
    real scalar j,k,l,n,ng,ns,rss,df,fac,base
    string scalar key
    string rowvector terms
    use=J(rows(d),1,0)
    ns=0
    ng=0
    for (j=1;j<=12;j++) {
        i=selectindex(d[,1]:==j)
        assert(rows(i)>0)
        if (rows(i)==1) ns=ns+1
        else {
            ng=ng+1
            use[i]=J(rows(i),1,1)
        }
    }
    a=select(d,use)
    n=rows(a)
    g=a[,1]
    y=a[,3]
    x=a[,4..5]
    yb=J(n,1,0)
    xb=J(n,2,0)
    theta=J(n,1,0)
    for (j=1;j<=11;j++) {
        i=selectindex(g:==j)
        yb[i]=J(rows(i),1,mean(y[i]))
        xb[i,]=J(rows(i),1,1)*mean(x[i,])
        theta[i]=J(rows(i),1,1-1/sqrt(1+1.5*rows(i)))
    }
    xc=x-xb
    yc=y-yb
    b=qrsolve(xc,yc)
    assert(max(abs(b-native'))<1e-8)
    u=yc-xc*b
    alpha=yb-xb*b
    base=mean(alpha)
    rss=quadcross(u,u)
    df=n-ng-2
    fac=(ng/(ng-1))*((n-1)/df)
    bread=invsym(quadcross(xc,xc))
    meat=J(2,2,0)
    terms=("x1","x2")
    for (j=1;j<=11;j++) {
        i=selectindex(g:==j)
        q=quadcross(xc[i,],u[i])
        meat=meat+q*q'
        vi_put(f,"CH21","within","effect",vi_id(j),alpha[i[1]]-base)
        for (k=1;k<=2;k++) vi_put(f,"CH21","within","score",vi_id(j)+"/"+terms[k],q[k])
    }
    cov=bread*meat*bread
    for (k=1;k<=2;k++) {
        for (l=1;l<=2;l++) {
            key=terms[k]+"/"+terms[l]
            vi_put(f,"CH21","within","cov_cr0",key,cov[k,l])
            vi_put(f,"CH21","within","cov_cr1",key,fac*cov[k,l])
        }
    }
    vi_put(f,"CH21","within","scalar","n",n)
    vi_put(f,"CH21","within","scalar","groups",ng)
    vi_put(f,"CH21","within","scalar","singletons",ns)
    vi_put(f,"CH21","within","scalar","df",df)
    vi_put(f,"CH21","within","scalar","rss",rss)
    vi_put(f,"CH21","within","scalar","s2",rss/df)
    vi_put(f,"CH21","within","scalar","cr1_factor",fac)
    vi_put(f,"CH21","within","scalar","intercept",base)
    vi_beta(f,"CH21","within",terms,b)
    for (j=1;j<=n;j++) {
        key=vi_id(a[j,1])+"/"+vi_id(a[j,2])
        vi_put(f,"CH21","within","fit",key,y[j]-u[j])
        vi_put(f,"CH21","within","resid",key,u[j])
    }
    terms=("intercept","x1","x2")
    vi_beta(f,"CH21","pooled",terms,qrsolve((J(n,1,1),x),y))
    z=(1:-theta,x-theta:*xb)
    regy=y-theta:*yb
    vi_beta(f,"CH21","re",terms,qrsolve(z,regy))
    b=qrsolve((z,(1:-theta):*xb),regy)
    vi_beta(f,"CH21","cre",(terms,"mean_x1","mean_x2"),b)
    vi_put(f,"CH21","cre","between","x1",b[2]+b[4])
    vi_put(f,"CH21","cre","between","x2",b[3]+b[5])

    dx=J(0,3,.)
    dyn=J(0,5,.)
    for (j=2;j<=n;j++) {
        if (g[j]==g[j-1] & a[j,2]==a[j-1,2]+1) {
            dx=dx \ (a[j,3..5]-a[j-1,3..5])
            key=vi_id(a[j,1])+"/"+vi_id(a[j,2])
            vi_put(f,"CH21","fd","used",key,1)
            if (j>2) {
                if (g[j]==g[j-2] & a[j,2]==a[j-2,2]+2) {
                    dyn=dyn \ (a[j,3]-a[j-1,3],a[j-1,3]-a[j-2,3],
                        a[j,4..5]-a[j-1,4..5],a[j-2,3])
                    vi_put(f,"CH21","dynamic","used",key,1)
                }
            }
        }
    }
    vi_put(f,"CH21","fd","scalar","n",rows(dx))
    vi_beta(f,"CH21","fd",terms,qrsolve((J(rows(dx),1,1),dx[,2..3]),dx[,1]))
    n=rows(dyn)
    x=(J(n,1,1),dyn[,2..4])
    z=(J(n,1,1),dyn[,3..5])
    xp=z*qrsolve(z,x)
    first=qrsolve(z,dyn[,2])
    vi_put(f,"CH21","dynamic","scalar","n",n)
    vi_put(f,"CH21","dynamic","scalar","first_stage",first[4])
    vi_beta(f,"CH21","dynamic",("intercept","lag","x1","x2"),qrsolve(xp,dyn[,1]))
}

void vi22(real scalar f, real matrix data)
{
    real matrix d, err, e
    real colvector x, levels, u, v, obs, residual, b
    real scalar c,t,j,k,m,n,o,h,q,theta,drift,loss,best,btheta,bdrift,blag,g,ar,ma,prev
    string scalar key
    string rowvector models
    models=("naive","ar1","ma1")
    for (c=1;c<=3;c++) {
        d=select(data,data[,1]:==c)
        assert(rows(d)==35 & sum(d[,2]:!=(1990::2024))==0)
        x=100:*ln(1:+d[,3]:/100)
        levels=J(35,1,0)
        for (t=2;t<=35;t++) levels[t]=levels[t-1]+x[t]
        err=J(12,9,0)
        for (o=2010;o<=2021;o++) {
            n=o-1989
            b=qrsolve((J(n-2,1,1),x[2..(n-1)]),x[3..n])
            key=vi_id(c)+"/"+vi_id(o)+"/"
            vi_put(f,"CH22","ar1","coef",key+"intercept",b[1])
            vi_put(f,"CH22","ar1","coef",key+"phi",b[2])
            best=.
            obs=x[2..n]
            for (q=-45;q<=45;q++) {
                theta=q/50
                u=J(n-1,1,0)
                v=u
                u[1]=obs[1]
                v[1]=1
                for (j=2;j<=rows(obs);j++) {
                    u[j]=obs[j]-theta*u[j-1]
                    v[j]=1-theta*v[j-1]
                }
                drift=quadcross(u,v)/quadcross(v,v)
                residual=u-drift*v
                loss=quadcross(residual,residual)
                if (missing(best) | loss<best-1e-10) {
                    best=loss
                    btheta=theta
                    bdrift=drift
                    blag=residual[rows(residual)]
                }
            }
            vi_put(f,"CH22","ma1","coef",key+"theta",btheta)
            vi_put(f,"CH22","ma1","coef",key+"drift",bdrift)
            vi_put(f,"CH22","ma1","coef",key+"sse",best)
            vi_put(f,"CH22","ma1","coef",key+"innovation",blag)
            ar=levels[n]
            ma=ar
            prev=x[n]
            for (h=1;h<=3;h++) {
                prev=b[1]+b[2]*prev
                ar=ar+prev
                ma=ma+bdrift+(h==1)*btheta*blag
                e=(levels[n],ar,ma)
                for (m=1;m<=3;m++) {
                    vi_put(f,"CH22",models[m],"forecast",key+vi_id(h),e[m])
                    g=levels[n+h]-e[m]
                    err[o-2009,(m-1)*3+h]=g
                    vi_put(f,"CH22",models[m],"error",key+vi_id(h),g)
                }
            }
        }
        for (m=1;m<=3;m++) {
            for (h=1;h<=3;h++) {
                u=err[,(m-1)*3+h]
                key=vi_id(c)+"/"+vi_id(h)
                vi_put(f,"CH22",models[m],"n",key,rows(u))
                vi_put(f,"CH22",models[m],"rmse",key,sqrt(mean(u:^2)))
                vi_put(f,"CH22",models[m],"mae",key,mean(abs(u)))
                vi_put(f,"CH22",models[m],"bias",key,mean(u))
            }
        }
    }
}

void vi23(real scalar f, real matrix d, real matrix edges, real matrix permutations)
{
    real matrix w,w0,edges0,x,fw,design,sp
    real colvector y,z,q,b,bestb,e,pred
    real scalar n,m,j,k,r,t,obs,s0,e0,ext,value,par,ld,rss,ll,best,br,bld,brss,df
    string scalar model,key
    string rowvector names
    n=rows(d)
    assert(n==16 & sum(d[,1]:!=(1::n))==0)
    y=d[,2]
    z=y:-mean(y)
    for (m=1;m<=2;m++) {
        model=(m==1 ? "rook" : "distance")
        w=J(n,n,0)
        edges0=select(edges,edges[,1]:==m)
        for (j=1;j<=rows(edges0);j++) w[edges0[j,2],edges0[j,3]]=edges0[j,4]
        assert(max(abs(rowsum(w):-1))<1e-9)
        if (m==1) w0=w
        s0=sum(w)
        e0=-1/(n-1)
        obs=(n/s0)*quadcross(z,w*z)/quadcross(z,z)
        ext=0
        for (j=1;j<=rows(permutations);j++) {
            q=z[permutations[j,2..17]]
            value=(n/s0)*quadcross(q,w*q)/quadcross(q,q)
            vi_put(f,"CH23",model,"perm",vi_id(permutations[j,1]),value)
            ext=ext+(abs(value-e0)>=abs(obs-e0)-1e-12)
        }
        for (j=1;j<=n;j++) vi_put(f,"CH23",model,"lag",vi_id(j),w[j,]*y)
        vi_put(f,"CH23",model,"scalar","n",n)
        vi_put(f,"CH23",model,"scalar","edges",rows(edges0))
        vi_put(f,"CH23",model,"scalar","s0",s0)
        vi_put(f,"CH23",model,"scalar","expected",e0)
        vi_put(f,"CH23",model,"scalar","I",obs)
        vi_put(f,"CH23",model,"scalar","extreme",ext)
        vi_put(f,"CH23",model,"scalar","p",(1+ext)/(rows(permutations)+1))
    }

    x=(J(n,1,1),d[,3..4]:-mean(d[,3..4]))
    for (m=1;m<=2;m++) {
        model=(m==1 ? "sar" : "sem")
        best=.
        for (r=-34;r<=34;r++) {
            par=r/40
            fw=I(n)-par*w0
            design=x
            if (m==2) design=fw*x
            b=qrsolve(design,fw*y)
            e=fw*y-design*b
            rss=quadcross(e,e)
            ld=ln(det(fw))
            ll=ld-n/2*(ln(2*3.141592653589793)+1+ln(rss/n))
            vi_put(f,"CH23",model,"profile",vi_id(r),ll)
            if (missing(best) | ll>best+1e-10) {
                best=ll
                br=par
                bld=ld
                brss=rss
                bestb=b
            }
        }
        vi_put(f,"CH23",model,"scalar","param",br)
        vi_put(f,"CH23",model,"scalar","ll",best)
        vi_put(f,"CH23",model,"scalar","rss",brss)
        vi_put(f,"CH23",model,"scalar","logdet",bld)
        names=("intercept","lat","lon")
        vi_beta(f,"CH23",model,names,bestb)
        if (m==1) {
            sp=lusolve(I(n)-br*w0,I(n))
            pred=sp*x*bestb
            for (k=2;k<=3;k++) {
                value=mean(diagonal(sp))*bestb[k]
                t=mean(rowsum(sp))*bestb[k]
                vi_put(f,"CH23",model,"impact",names[k]+"/direct",value)
                vi_put(f,"CH23",model,"impact",names[k]+"/indirect",t-value)
                vi_put(f,"CH23",model,"impact",names[k]+"/total",t)
            }
        }
        else pred=x*bestb
        for (j=1;j<=n;j++) vi_put(f,"CH23",model,"fit",vi_id(j),pred[j])
    }
}

real matrix vi_scores(real matrix x, real colvector u, real colvector g)
{
    real matrix s
    real colvector i
    real scalar j
    s=J(12,cols(x),0)
    for (j=1;j<=12;j++) {
        i=selectindex(g:==j)
        s[j,]=quadcross(u[i],x[i,])
    }
    return(s)
}

void vi24(real scalar f, real matrix d, real matrix signs, real matrix alloc,
    real matrix serial, real matrix starts, real rowvector native)
{
    real matrix x,x0,bread,cr0,cr1,hc0,score,cc
    real colvector y,b,u,g,yy,f0,u0,sv,bb,groupy,observed,pvec,idx,adjust,blocks,series
    real scalar j,k,l,m,h,n,ng,df,fac,rss,stat,se,sw,ri,v,ext,exri,sum0,tot,p0,r,at,bmax,bmin
    string scalar model,key
    string rowvector names
    n=rows(d)
    g=d[,2]
    assert(n==120 & rows(signs)==399 & rows(alloc)==400)
    x0=(J(n,1,1),d[,5],d[,3]:-1)
    x=(J(n,1,1),d[,4],x0[,2..3])
    bread=invsym(quadcross(x,x))
    ng=12
    df=n-cols(x)
    fac=(ng/(ng-1))*(n-1)/df
    pvec=J(3,1,0)
    names=("intercept","assigned","x","block2")
    observed=J(12,1,0)
    for (j=1;j<=12;j++) observed[j]=mean(select(d[,4],g:==j))
    assert(sum(rowsum(abs(alloc[,2..13]:-observed')):==0)==1)
    for (m=1;m<=3;m++) {
        model="y"+vi_id(m)
        y=d[,m+5]
        b=qrsolve(x,y)
        u=y-x*b
        f0=x0*qrsolve(x0,y)
        u0=y-f0
        score=vi_scores(x,u,g)
        cr0=bread*quadcross(score,score)*bread
        cr1=fac*cr0
        cc=x:*u
        hc0=bread*quadcross(cc,cc)*bread
        rss=quadcross(u,u)
        se=sqrt(cr1[2,2])
        if (m==1) assert(max(abs((b[2],se)-native))<1e-8)
        stat=b[2]/se
        p0=2*ttail(ng-1,abs(stat))
        pvec[m]=p0
        vi_beta(f,"CH24",model,names,b)
        vi_put(f,"CH24",model,"scalar","n",n)
        vi_put(f,"CH24",model,"scalar","clusters",ng)
        vi_put(f,"CH24",model,"scalar","df",df)
        vi_put(f,"CH24",model,"scalar","cr1_factor",fac)
        vi_put(f,"CH24",model,"scalar","t_cr1",stat)
        vi_put(f,"CH24",model,"scalar","p_cr1",p0)
        vi_put(f,"CH24",model,"scalar","p_regdf",2*ttail(df,abs(stat)))
        vi_put(f,"CH24",model,"scalar","p_normal",2*normal(-abs(stat)))
        vi_put(f,"CH24",model,"se","classical",sqrt((rss/df)*bread[2,2]))
        vi_put(f,"CH24",model,"se","hc0",sqrt(hc0[2,2]))
        vi_put(f,"CH24",model,"se","hc1",sqrt((n/df)*hc0[2,2]))
        vi_put(f,"CH24",model,"se","cr0",sqrt(cr0[2,2]))
        vi_put(f,"CH24",model,"se","cr1",se)
        for (j=1;j<=4;j++) {
            for (k=1;k<=4;k++) {
                key=names[j]+"/"+names[k]
                vi_put(f,"CH24",model,"cov_cr0",key,cr0[j,k])
                vi_put(f,"CH24",model,"cov_cr1",key,cr1[j,k])
            }
            for (k=1;k<=12;k++) vi_put(f,"CH24",model,"score",vi_id(k)+"/"+names[j],score[k,j])
        }

        ext=0
        for (j=1;j<=rows(signs);j++) {
            sv=signs[j,2..13]'
            yy=f0+u0:*sv[g]
            bb=qrsolve(x,yy)
            score=vi_scores(x,yy-x*bb,g)
            cc=bread*quadcross(score,score)*bread
            sw=bb[2]/sqrt(fac*cc[2,2])
            ext=ext+(abs(sw)>=abs(stat)-1e-10)
            vi_put(f,"CH24",model,"wild_t",vi_id(signs[j,1]),sw)
        }
        vi_put(f,"CH24",model,"scalar","wild_extreme",ext)
        vi_put(f,"CH24",model,"scalar","p_wild",(1+ext)/(rows(signs)+1))

        groupy=J(12,1,0)
        for (j=1;j<=12;j++) groupy[j]=mean(select(y,g:==j))
        tot=sum(groupy)
        ri=(2*quadcross(observed,groupy)-tot)/6
        exri=0
        for (j=1;j<=rows(alloc);j++) {
            v=(2*(alloc[j,2..13]*groupy)-tot)/6
            exri=exri+(abs(v)>=abs(ri)-1e-10)
            vi_put(f,"CH24",model,"permutation",vi_id(alloc[j,1]),v)
        }
        vi_put(f,"CH24",model,"scalar","ri_stat",ri)
        vi_put(f,"CH24",model,"scalar","ri_extreme",exri)
        vi_put(f,"CH24",model,"scalar","p_ri",exri/rows(alloc))
    }

    idx=order(pvec,1)
    bmax=0
    for (j=1;j<=3;j++) {
        k=idx[j]
        key="y"+vi_id(k)
        bmax=max((bmax,(4-j)*pvec[k]))
        vi_put(f,"CH24","family","holm",key,min((1,bmax)))
        vi_put(f,"CH24","family","bonferroni",key,min((1,3*pvec[k])))
    }
    bmin=1
    for (j=3;j>=1;j--) {
        k=idx[j]
        bmin=min((bmin,3*pvec[k]/j))
        vi_put(f,"CH24","family","bh","y"+vi_id(k),bmin)
    }
    series=serial[,2]
    assert(rows(series)==60 & sum(serial[,1]:!=(1::60))==0)
    blocks=J(rows(starts),1,0)
    for (j=1;j<=rows(starts);j++) {
        sum0=0
        for (k=2;k<=13;k++) {
            for (l=0;l<=4;l++) {
                at=1+mod(starts[j,k]-1+l,60)
                sum0=sum0+series[at]
            }
        }
        blocks[j]=sum0/60
        vi_put(f,"CH24","block","draw",vi_id(starts[j,1]),blocks[j])
    }
    vi_put(f,"CH24","block","scalar","mean",mean(series))
    vi_put(f,"CH24","block","scalar","iid_se",vi_sd(series)/sqrt(60))
    vi_put(f,"CH24","block","scalar","block_se",vi_sd(blocks))
}
end

tempname b21 b24
mata: vi_fh=fopen(st_local("output")+"/metrics.csv","w")
mata: fput(vi_fh,"chapter,model,quantity,key,value")

import delimited using `"`input'/panel21.csv"', clear varnames(1) asdouble
isid entity year
sort entity year
by entity: gen int group_n=_N
quietly regress y x1 x2 i.entity if group_n>1
matrix `b21'=(_b[x1],_b[x2])
mata: vi21(vi_fh,st_data(.,("entity","year","y","x1","x2")),st_matrix("`b21'"))
display as text "Chapter 21 completed."

import delimited using `"`input'/gdp22.csv"', clear varnames(1) asdouble
isid country year
sort country year
assert growth>-100 & growth<.
mata: vi22(vi_fh,st_data(.,1..3))
display as text "Chapter 22 completed."

import delimited using `"`input'/regions23.csv"', clear varnames(1) asdouble
isid region
sort region
mata: vi_regions=st_data(.,1..4)
import delimited using `"`input'/weights23.csv"', clear varnames(1) asdouble
isid graph origin target
assert origin!=target & weight>0 & weight<.
mata: vi_edges=st_data(.,1..4)
import delimited using `"`input'/permutations23.csv"', clear varnames(1) asdouble
isid draw
sort draw
mata: vi23(vi_fh,vi_regions,vi_edges,st_data(.,1..17))
display as text "Chapter 23 completed."

import delimited using `"`input'/trial24.csv"', clear varnames(1) asdouble
isid record
sort cluster record
by cluster: assert _N==10 & assigned==assigned[1] & block==block[1]
quietly regress y1 assigned x i.block, vce(cluster cluster)
matrix `b24'=(_b[assigned],_se[assigned])
mata: vi_trial=st_data(.,("record","cluster","block","assigned","x","y1","y2","y3"))
import delimited using `"`input'/signs24.csv"', clear varnames(1) asdouble
isid draw
sort draw
mata: vi_signs=st_data(.,1..13)
import delimited using `"`input'/assignments24.csv"', clear varnames(1) asdouble
isid draw
sort draw
mata: vi_alloc=st_data(.,1..13)
import delimited using `"`input'/serial24.csv"', clear varnames(1) asdouble
isid t
sort t
mata: vi_serial=st_data(.,1..2)
import delimited using `"`input'/blocks24.csv"', clear varnames(1) asdouble
isid draw
sort draw
mata: vi24(vi_fh,vi_trial,vi_signs,vi_alloc,vi_serial,st_data(.,1..13),st_matrix("`b24'"))
mata: fclose(vi_fh)
display as result "Part VI generated in Stata."
