# Verify Part VI on local Stata

Use licensed Stata 17 or 16 on your computer. The do-files use built-in Stata and Mata. All inputs are supplied and the run works offline.

1. Extract the ZIP. In Stata, set your working directory to the inner Part_VI_Stata_Local_Run folder using cd and its quoted absolute path.
2. Run **do run_part6.do** in the Stata command window.
3. Upload the resulting **Stata_Verification_Part_VI_*.zip**. The run should report return code 0.

If automatic compression fails, compress the files directly inside the evidence directory shown by Stata. If the run returns a nonzero code, share that ZIP or the text log so the failing command can be identified. The archive includes the exact driver, input files, result ledger, and runtime record.
