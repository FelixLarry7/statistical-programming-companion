"""Fit the Part VI reference analyses in Python."""

import argparse
from pathlib import Path
import platform

import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm, t

from ledger import Ledger


def design(*columns):
    return np.column_stack(columns)


def ols(x, y):
    return np.linalg.lstsq(x, y, rcond=None)[0]


def scores(x, u, g, count):
    out = np.zeros((count,x.shape[1]))
    np.add.at(out,g-1,x*u[:,None])
    return out


def covariance(bread, score):
    return bread @ (score.T @ score) @ bread


def panel(read, ledger):
    d = read('panel21').sort_values(['entity','year'])
    assert not d.duplicated(['entity','year']).any()
    n0 = d.groupby('entity').size()
    a = d[d.entity.isin(n0[n0>1].index)].copy()
    cols = ['y','x1','x2']
    means = a.groupby('entity')[cols].transform('mean')
    y, x = a.y.to_numpy(), a[cols[1:]].to_numpy()
    ybar, xb = means.y.to_numpy(), means[cols[1:]].to_numpy()
    yc, xc = y-ybar, x-xb
    b = ols(xc,yc)
    u = yc-xc@b
    g = a.entity.to_numpy()
    n, groups = len(a), len(np.unique(g))
    df = n-groups-2
    bread = np.linalg.inv(xc.T@xc)
    s = scores(xc,u,g,groups)
    v = covariance(bread,s)
    factor = groups/(groups-1)*(n-1)/df
    alpha = ybar-xb@b
    mean_alpha = alpha.mean()
    m = ledger.model('CH21','within')
    m.scalars(n=n,groups=groups,singletons=sum(n0==1),df=df,rss=u@u,s2=(u@u)/df,
              cr1_factor=factor,intercept=mean_alpha)
    names = ('x1','x2')
    m.vector('beta',names,b)
    m.matrix('cov_cr0',names,v)
    m.matrix('cov_cr1',names,v*factor)
    for entity in range(1,groups+1):
        m.add('effect',entity,alpha[g==entity][0]-mean_alpha)
        m.vector('score',(f'{entity}/{term}' for term in names),s[entity-1])
    keys = [f'{i}/{t}' for i,t in zip(a.entity,a.year,strict=True)]
    m.vector('fit',keys,y-u)
    m.vector('resid',keys,u)
    terms = ('intercept','x1','x2')
    one = np.ones(n)
    ledger.model('CH21','pooled').vector('beta',terms,ols(design(one,x),y))
    theta = 1-1/np.sqrt(1+1.5*a.entity.map(n0).to_numpy())
    z = design(one-theta,x-theta[:,None]*xb)
    yq = y-theta*ybar
    ledger.model('CH21','re').vector('beta',terms,ols(z,yq))
    m = ledger.model('CH21','cre')
    b = ols(design(z,(1-theta)[:,None]*xb),yq)
    m.vector('beta',(*terms,'mean_x1','mean_x2'),b)
    m.vector('between',names,b[1:3]+b[3:])
    assert np.isclose(np.sum(alpha-mean_alpha),0)
    grouped = a.groupby('entity',sort=False)
    differences = grouped[cols].diff()
    consecutive = grouped.year.diff().eq(1)
    m = ledger.model('CH21','fd')
    d1 = differences[consecutive]
    m.scalars(n=len(d1))
    m.vector('beta',terms,ols(design(np.ones(len(d1)),d1[cols[1:]]),d1.y))
    m.vector('used',(key for key,v in zip(keys,consecutive,strict=True) if v),np.ones(len(d1)))
    twice = consecutive & (a.year-grouped.year.shift(2)).eq(2)
    d2 = differences[twice]
    lag = differences.y.groupby(a.entity).shift()[twice].to_numpy()
    y2 = grouped.y.shift(2)[twice].to_numpy()
    x = design(np.ones(len(d2)),lag,d2[cols[1:]])
    z = design(np.ones(len(d2)),d2[cols[1:]],y2)
    m = ledger.model('CH21','dynamic')
    m.scalars(n=len(d2),first_stage=ols(z,lag)[-1])
    m.vector('beta',('intercept','lag','x1','x2'),ols(z@ols(z,x),d2.y))
    m.vector('used',(key for key,v in zip(keys,twice,strict=True) if v),np.ones(len(d2)))


def ma_profile(x):
    best = None
    for q in range(-45,46):
        theta = q/50
        a,b = np.empty(len(x)),np.empty(len(x))
        a[0],b[0] = x[0],1
        for j in range(1,len(x)):
            a[j] = x[j]-theta*a[j-1]
            b[j] = 1-theta*b[j-1]
        drift = a@b/(b@b)
        u = a-drift*b
        loss = u@u
        if best is None or loss < best[0]-1e-10:
            best = (loss,theta,drift,u[-1])
    return best


def macro(read, ledger):
    d = read('gdp22').sort_values(['country','year'])
    assert not d.duplicated(['country','year']).any() and d.growth.gt(-100).all()
    for c,a in d.groupby('country'):
        assert np.array_equal(a.year,np.arange(1990,2025))
        x = 100*np.log1p(a.growth.to_numpy()/100)
        levels = np.r_[0,np.cumsum(x[1:])]
        errs = np.zeros((12,3,3))
        models = [ledger.model('CH22',name) for name in ('naive','ar1','ma1')]
        for o in range(2010,2022):
            n = o-1989
            key = f'{c}/{o}/'
            b = ols(design(np.ones(n-2),x[1:n-1]),x[2:n])
            models[1].vector('coef',(key+s for s in ('intercept','phi')),b)
            loss,theta,drift,u = ma_profile(x[1:n])
            models[2].vector('coef',(key+s for s in ('theta','drift','sse','innovation')),
                             (theta,drift,loss,u))
            ar = ma = levels[n-1]
            last = x[n-1]
            for h in range(1,4):
                last = b[0]+b[1]*last
                ar += last
                ma += drift+(theta*u if h==1 else 0)
                for j,(m,yhat) in enumerate(zip(models,(levels[n-1],ar,ma),strict=True)):
                    error = levels[n-1+h]-yhat
                    m.add('forecast',key+str(h),yhat)
                    m.add('error',key+str(h),error)
                    errs[o-2010,j,h-1] = error
        for j,m in enumerate(models):
            for h in range(3):
                v = errs[:,j,h]
                key = f'{c}/{h+1}'
                m.add('n',key,len(v))
                m.add('rmse',key,np.sqrt(np.mean(v**2)))
                m.add('mae',key,np.mean(abs(v)))
                m.add('bias',key,np.mean(v))


def moran(z,w):
    return len(z)/w.sum()*(z@w@z)/(z@z)


def spatial(read, ledger):
    d = read('regions23').sort_values('region')
    e = read('weights23')
    crosswalk = read('crosswalk23')
    assert d.region.is_unique and set(d.region)==set(crosswalk.region) and crosswalk.name.is_unique
    assert crosswalk.geometry_year.eq(2021).all() and not e.duplicated(['graph','origin','target']).any()
    perm = read('permutations23').sort_values('draw')
    p = perm.iloc[:,1:].to_numpy()
    assert np.all(np.sort(p,axis=1)==np.arange(1,17))
    y = d.access.to_numpy()
    z = y-y.mean()
    for g, name in ((1,'rook'),(2,'distance')):
        a = e[e.graph==g]
        w = np.zeros((len(d),len(d)))
        w[a.origin-1,a.target-1] = a.weight
        assert np.allclose(w.sum(1),1) and np.all(np.diag(w)==0)
        assert np.array_equal(w>0,w.T>0)
        if g==1:
            rook = w.copy()
        observed = moran(z,w)
        e0 = -1/(len(z)-1)
        permuted = np.array([moran(z[row-1],w) for row in p])
        extreme = np.sum(abs(permuted-e0)>=abs(observed-e0)-1e-12)
        m = ledger.model('CH23',name)
        m.scalars(n=len(z),edges=len(a),s0=w.sum(),expected=e0,I=observed,
                  extreme=extreme,p=(1+extreme)/(1+len(p)))
        m.vector('perm',perm.draw,permuted)
        m.vector('lag',d.region,w@y)
    xy = d[['lat','lon']].to_numpy()
    x = design(np.ones(len(d)),xy-xy.mean(0))
    names = ('intercept','lat','lon')
    eye = np.eye(len(d))
    for model in ('sar','sem'):
        m = ledger.model('CH23',model)
        best = None
        for k in range(-34,35):
            rho = k/40
            filt = eye-rho*rook
            xx = x if model=='sar' else filt@x
            yy = filt@y
            b = ols(xx,yy)
            residual = yy-xx@b
            rss = residual@residual
            sign,ld = np.linalg.slogdet(filt)
            assert sign==1
            ll = ld-len(y)/2*(np.log(2*np.pi)+1+np.log(rss/len(y)))
            m.add('profile',k,ll)
            if best is None or ll > best[0]+1e-10:
                best = (ll,rho,ld,rss,b)
        ll,rho,ld,rss,b = best
        m.scalars(param=rho,ll=ll,logdet=ld,rss=rss)
        m.vector('beta',names,b)
        if model=='sar':
            s = np.linalg.solve(eye-rho*rook,eye)
            fitted = s@x@b
            for j,name in enumerate(names[1:],1):
                direct = np.diag(s).mean()*b[j]
                total = s.sum(1).mean()*b[j]
                m.vector('impact',(f'{name}/{q}' for q in ('direct','indirect','total')),
                         (direct,total-direct,total))
        else:
            fitted = x@b
        m.vector('fit',d.region,fitted)


def inference(read,ledger):
    d = read('trial24').sort_values(['cluster','record'])
    assert d.record.is_unique
    assert d.groupby('cluster').size().eq(10).all()
    assert d.groupby('cluster')[['assigned','block']].nunique().eq(1).all().all()
    g = d.cluster.to_numpy()
    one = np.ones(len(d))
    x0 = design(one,d.x,d.block-1)
    x = design(one,d.assigned,x0[:,1:])
    n,k = x.shape
    groups = len(np.unique(g))
    df = n-k
    factor = groups/(groups-1)*(n-1)/df
    bread = np.linalg.inv(x.T@x)
    draws = read('signs24').sort_values('draw')
    s = draws.iloc[:,1:].to_numpy()
    assert s.shape==(399,12) and np.isin(s,[-1,1]).all()
    allocations = read('assignments24').sort_values('draw')
    a = allocations.iloc[:,1:].to_numpy()
    assert len(np.unique(a,axis=0))==400 and np.isin(a,[0,1]).all()
    assert (a[:,:6].sum(1)==3).all() and (a[:,6:].sum(1)==3).all()
    observed = d.groupby('cluster').assigned.first().to_numpy()
    assert np.sum((a==observed).all(1))==1
    pvals = []
    names = ('intercept','assigned','x','block2')
    for model in ('y1','y2','y3'):
        y = d[model].to_numpy()
        b = ols(x,y)
        u = y-x@b
        fitted0 = x0@ols(x0,y)
        u0 = y-fitted0
        cl = scores(x,u,g,groups)
        cr0 = covariance(bread,cl)
        cr1 = factor*cr0
        hc0 = covariance(bread,x*u[:,None])
        se = np.sqrt(cr1[1,1])
        stat = b[1]/se
        p0 = 2*t.sf(abs(stat),groups-1)
        pvals.append(p0)
        m = ledger.model('CH24',model)
        m.vector('beta',names,b)
        m.scalars(n=n,clusters=groups,df=df,cr1_factor=factor,t_cr1=stat,p_cr1=p0,
                  p_regdf=2*t.sf(abs(stat),df),p_normal=2*norm.sf(abs(stat)))
        m.vector('se',('classical','hc0','hc1','cr0','cr1'),np.sqrt(
            ((u@u/df)*bread[1,1],hc0[1,1],n/df*hc0[1,1],cr0[1,1],cr1[1,1])))
        m.matrix('cov_cr0',names,cr0)
        m.matrix('cov_cr1',names,cr1)
        for j,row in enumerate(cl,1):
            m.vector('score',(f'{j}/{term}' for term in names),row)
        wstats = []
        for z in s:
            yy = fitted0+u0*z[g-1]
            bb = ols(x,yy)
            clb = scores(x,yy-x@bb,g,groups)
            v = factor*covariance(bread,clb)
            wstats.append(bb[1]/np.sqrt(v[1,1]))
        m.vector('wild_t',draws.draw,wstats)
        ext = np.sum(abs(np.asarray(wstats))>=abs(stat)-1e-10)
        m.scalars(wild_extreme=ext,p_wild=(1+ext)/(1+len(s)))
        cy = d.groupby('cluster')[model].mean().to_numpy()
        original = (2*(observed@cy)-cy.sum())/6
        randomized = (2*a@cy-cy.sum())/6
        ext = np.sum(abs(randomized)>=abs(original)-1e-10)
        m.vector('permutation',allocations.draw,randomized)
        m.scalars(ri_stat=original,ri_extreme=ext,p_ri=ext/len(a))
    pvals = np.array(pvals)
    order = np.argsort(pvals,kind='stable')
    m = ledger.model('CH24','family')
    labels = [f'y{i+1}' for i in order]
    p = pvals[order]
    m.vector('bonferroni',labels,np.minimum(1,3*p))
    m.vector('holm',labels,np.minimum(1,np.maximum.accumulate(np.arange(3,0,-1)*p)))
    m.vector('bh',labels,np.minimum(1,np.minimum.accumulate((3*p/np.arange(1,4))[::-1])[::-1]))
    series = read('serial24').sort_values('t')
    starts = read('blocks24').sort_values('draw')
    assert np.array_equal(series.t,np.arange(1,61))
    index = (starts.iloc[:,1:].to_numpy()[:,:,None]-1+np.arange(5))%60
    draws = series.y.to_numpy()[index].mean((1,2))
    m = ledger.model('CH24','block')
    m.vector('draw',starts.draw,draws)
    m.scalars(mean=series.y.mean(),iid_se=series.y.std()/np.sqrt(60),block_se=np.std(draws,ddof=1))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('inputs',type=Path)
    ap.add_argument('output',type=Path)
    a = ap.parse_args()
    def read(name):
        return pd.read_csv(a.inputs/f'{name}.csv')
    m = Ledger()
    for run in (panel,macro,spatial,inference):
        run(read,m)
    a.output.mkdir(parents=True,exist_ok=True)
    m.save(a.output/'metrics.csv')
    print('Python',platform.python_version(),'NumPy',np.__version__,'pandas',pd.__version__,
          'SciPy',scipy.__version__,len(m.rows),'values')


if __name__=='__main__':
    main()
