# Part VI data dictionary

The keyed analytical CSV files in raw contain the exact inputs used in the verification run. Indices are one-based unless the model explicitly defines an offset. The source register identifies the public figures and original geometry.

| File | Grain and key | Fields and interpretation |
|:--|:--|:--|
| panel21.csv | Synthetic country-year, entity and year | entity is 1–12. year is a calendar year from 2001 to 2015. y is the outcome index. x1 and x2 are synthetic investment and service-capacity indices. |
| gdp22.csv | Published country-year, country and year | Country 1 is Ghana (GHA), 2 Kenya (KEN) and 3 Senegal (SEN). year is 1990–2024. growth is annual real GDP growth in percent, as stored from the frozen WDI extract. |
| regions23.csv | Region, region | access is the 2021 census percentage of households with basic drinking-water services. lat and lon are frozen polygon centroid coordinates in degrees. |
| crosswalk23.csv | Region, region | name is the census region name. source_name is the geoBoundaries name. geometry_year is the represented 2021 boundary vintage. The provider’s shapeID and shapeISO are in the plotted-data crosswalk. |
| weights23.csv | Directed graph edge, graph, origin and target | graph 1 is rook contiguity. graph 2 is the symmetrised three-nearest centroid graph. origin and target are region IDs. weight is the row-standardised neighbour weight. Diagonal entries and absent edges are zero. |
| permutations23.csv | Label permutation, draw | p1–p16 give the source region position placed in each ordered slot. There are 399 independently generated permutations. |
| trial24.csv | Synthetic observation, record | cluster is 1–12, with ten records each. block is 1 or 2. assigned is the cluster-level binary offer. x is a baseline covariate. y1–y3 are index-point outcomes. |
| signs24.csv | Wild draw, draw | s1–s12 are fixed Rademacher signs, in cluster order, for 399 draws. |
| assignments24.csv | Permissible allocation, draw | z1–z12 are binary offer indicators. There are three offers in each six-cluster block and 400 distinct allocations. |
| serial24.csv | Synthetic serial observation, t | t is ordered from 1 to 60. y is the serially dependent measurement. |
| blocks24.csv | Circular bootstrap draw, draw | b1–b12 are starts in 1–60. Each start produces five consecutive positions using circular wraparound. There are 399 draws. |

## Ledger fields

Each engine exports chapter, model, quantity, key and value. A slash in key separates ordered index components such as country/origin/horizon, cluster/term or coefficient row/column. A value called p refers to the corresponding model and reference specified in the chapter. The comparison file records the engine, same four-part key, value, Python reference, absolute discrepancy, tolerance and pass flag.

Sample keys and bootstrap or permutation IDs are checked explicitly. The main spatial analyses use row-standardised graphs with no isolates. The changed isolate example keeps its row and sets its lag to zero. The trial keeps the two blocks and ten observations per cluster in all regression fits.
