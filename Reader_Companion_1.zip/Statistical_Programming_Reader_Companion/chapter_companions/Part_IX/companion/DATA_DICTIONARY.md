# Analysis input dictionary

| File | Grain and key | Rows | Interpretation |
| --- | --- | ---: | --- |
| assignment33.csv | Village, village ID | 48 | Pair 1–24, planning region 1–4, assigned offer 0/1. |
| roster33.csv | Household, household ID | 1,152 | Village key, fixed eligibility flag, baseline and follow-up on 0–100 scale, observed flag and reason. |
| draws33.csv | Draw, draw ID | 499 | Independent teaching signs in columns p01–p24 ordered by matched pair. |
| retail34.csv | Workbook row, line | 5,904 | Scoped invoice and customer keys, product ID, week, signed units, price in pence, leading-C flag. |
| returns34.csv | Synthetic return or sale ledger line | 14 | Invoice, status, units, pence and original line identifier when applicable. |
| map35.csv | Economy code, integer key | 13 | WDI/PWT crosswalk key and economy-scope flag. |
| wdi35.csv | Economy-year | 312 | Life expectancy in years, midyear resident population, under-five mortality per 1,000 live births and GDP per resident in 2015 US dollars. |
| pwt35.csv | Economy-year | 264 | Expenditure- and output-side real GDP at chained PPPs, constant national price real GDP, population and persons engaged. |
| welfare36.csv | Household, household ID | 600 | Stratum, PSU, domain, rural flag, assessment score, priority flag, transfer and insurance flags, care need and outcome, welfare, size and survey weight. |

## Codes and units

- Trial `followup=-1` is unavailable. Reason 0 is observed, 1–3 are three
  synthetic nonresponse categories, and 4 marks ineligibility. The reason
  codes carry no measured explanation beyond their fixture categories.
  `offer` is the original assignment and is preserved for missing follow-up.
- The UCI product map is 1 = 85123A, 2 = 22423, 3 = 85099B. `customer=0` is
  unidentified. `cancel=1` is the provider's leading-C invoice flag.
  Positive unit prices are in pence per unit. Week 1 begins Monday
  6 December 2010. `line` is the source workbook row, including the header
  row in the row number. Invoice and customer values were recoded within scope.
- In `returns34.csv`, status 1 is booked sale, 2 is void, and 3 is executed
  return. An `original` value of zero means the row carries no linked
  original sale.
- In `pwt35.csv`, `rgdpe`, `rgdpo`, and `rgdpna` use millions of 2021 US
  dollars on their respective price bases. `pop` and `emp` are in millions
  of people. Source blanks remain empty. See [the country crosswalk](../projects/design/ch35_crosswalk.csv).
- In `welfare36.csv`, `unmet=-1` marks an undefined or unresolved care
  outcome. With `need=1`, the sentinel means the outcome is unknown.
  With `need=0`, the household is outside the care outcome domain. Welfare
  is a synthetic monthly GHS amount per person. `size` is household
  members and `weight` is a relative synthetic household survey weight.
  A household is eligible when `score<=55` and `priority=1`.
