CREATE VIEW trial_rows AS
SELECT r.*,a.pair,a.region,a.offer
FROM roster33 r JOIN assignment33 a USING (village);

CREATE VIEW trial_villages AS
SELECT village,pair,offer,count(*) AS n,sum(observed) AS obs,
       avg(followup-baseline) FILTER (WHERE observed=1) AS change,
       avg(baseline) AS baseline,
       (sum(followup) FILTER (WHERE observed=1)-sum(baseline))/n AS lo,
       lo+100*(n-obs)/n AS hi
FROM trial_rows WHERE eligible=1 GROUP BY ALL;

CREATE VIEW trial_pairs AS
SELECT t.pair,t.change-c.change AS delta,t.baseline-c.baseline AS balance,
       c.obs/c.n-t.obs/t.n AS missing_gap,t.lo-c.hi AS lo,t.hi-c.lo AS hi,
       2-t.obs/t.n-c.obs/c.n AS missing_sum
FROM trial_villages t JOIN trial_villages c USING (pair)
WHERE t.offer=1 AND c.offer=0;

CREATE VIEW retail_typed AS
SELECT *,cancel=0 AND units>0 AND pence>0 AS sold,
         cancel=1 AND units<0 AND pence>0 AS cancellation,
         cancel=0 AND units<0 AND pence>0 AS other_negative,
         units*pence AS amount
FROM retail34;

CREATE VIEW retail_invoices AS
SELECT invoice,sum(amount) AS net,count(*) AS lines
FROM retail_typed WHERE sold OR cancellation GROUP BY invoice;

CREATE VIEW retail_demand AS
WITH observed AS (
    SELECT product,week,sum(units) AS units FROM retail_typed WHERE sold GROUP BY ALL
)
SELECT p.product,w.week,coalesce(o.units,0) AS units
FROM range(1,4) p(product) CROSS JOIN range(1,53) w(week)
LEFT JOIN observed o USING(product,week);

CREATE VIEW retail_forecasts AS
WITH history AS (
    SELECT product,week,units,lag(units) OVER part AS naive,
           avg(units) OVER (PARTITION BY product ORDER BY week
                           ROWS BETWEEN 4 PRECEDING AND 1 PRECEDING) AS mean4
    FROM retail_demand WINDOW part AS (PARTITION BY product ORDER BY week)
)
SELECT product,week,units,f.method,f.value AS prediction,units-f.value AS error
FROM history CROSS JOIN LATERAL (VALUES ('naive',naive),('mean4',mean4)) f(method,value)
WHERE week BETWEEN 41 AND 52;

CREATE VIEW retail_customer AS
WITH history AS (
    SELECT o.origin,d.customer,max(d.week) AS last_week
    FROM (VALUES (27),(33),(39),(45),(48)) o(origin) JOIN retail_typed d
    ON d.sold AND d.customer>0 AND d.week BETWEEN o.origin-11 AND o.origin
    GROUP BY ALL
), labels AS (
    SELECT *,CAST(origin-last_week<=3 AS INTEGER) AS recent,
           EXISTS (SELECT 1 FROM retail_typed f
                   WHERE f.sold AND f.customer=h.customer AND f.week BETWEEN h.origin+1 AND h.origin+4) AS event
    FROM history h
)
SELECT origin,recent,count(*) AS n,count_if(event) AS events,avg(CAST(event AS INTEGER)) AS rate
FROM labels GROUP BY origin,recent;

CREATE VIEW international AS
SELECT w.*,m.include,p.rgdpe,p.rgdpo,p.rgdpna,p.pop,p.emp,p.economy IS NOT NULL AS matched,
       coalesce(m.include=1 AND w.life IS NOT NULL AND w.population>0 AND p.rgdpe>0 AND p.pop>0,FALSE) AS good,
       p.rgdpe/nullif(p.pop,0) AS pc
FROM wdi35 w JOIN map35 m USING(economy) LEFT JOIN pwt35 p USING(economy,year);

CREATE VIEW international_balanced AS
SELECT * FROM international WHERE good
QUALIFY count(*) OVER (PARTITION BY economy)=24;

CREATE VIEW social_rows AS
SELECT *,score<=55 AND priority=1 AS eligible,transfer=1 AS covered,
       need=1 AND unmet IN (0,1) AS known
FROM welfare36;

CREATE VIEW social_stack AS
SELECT d.household,d.stratum,d.psu,d.weight,kv.model,
       CAST(kv.keep AS INTEGER) AS keep,CAST(kv.result AS INTEGER) AS y
FROM social_rows d CROSS JOIN LATERAL (VALUES
  ('coverage',eligible,covered),('exclusion',eligible,NOT covered),
  ('inclusion',covered,NOT eligible),('unmet',known,unmet=1),
  ('unmet_rural',known AND rural=1,unmet=1),('unmet_urban',known AND rural=0,unmet=1),
  ('insured',TRUE,insurance=1),('domain1',known AND domain=1,unmet=1),
  ('domain2',known AND domain=2,unmet=1),('domain3',known AND domain=3,unmet=1),
  ('domain4',known AND domain=4,unmet=1)) kv(model,keep,result);

CREATE VIEW social_totals AS
SELECT model,sum(keep) AS n,sum(keep*y) AS yes,count(DISTINCT psu) FILTER(WHERE keep=1) AS psus,
       sum(keep*weight) AS den,sum(keep*weight*y) AS num,num/den AS estimate
FROM social_stack GROUP BY model;

CREATE VIEW social_inference AS
WITH psus AS (
    SELECT z.model,stratum,psu,sum(z.weight*z.keep*(z.y-a.estimate)/a.den) AS score
    FROM social_stack z JOIN social_totals a USING (model) GROUP BY z.model,stratum,psu
), strata AS (
    SELECT model,stratum,count(*) AS m,var_samp(score) AS v FROM psus GROUP BY ALL
)
SELECT model,sqrt(sum(m*v)) AS se,sum(m-1) AS df FROM strata GROUP BY model;

CREATE VIEW social_rank_scores AS
WITH replicates AS (
    SELECT 0 AS drop_psu,0 AS stratum
    UNION ALL SELECT DISTINCT psu,stratum FROM welfare36
), weighted AS (
    SELECT r.drop_psu,h.welfare,h.unmet,
           CASE WHEN h.psu=r.drop_psu THEN 0 WHEN h.stratum=r.stratum THEN 1.25*h.weight ELSE h.weight END AS w
    FROM social_rows h CROSS JOIN replicates r WHERE h.known
), grouped AS (
    SELECT drop_psu,welfare,sum(w) AS mass,sum(w*unmet) AS burden FROM weighted GROUP BY ALL
), ranks AS (
    SELECT *,sum(mass) OVER (PARTITION BY drop_psu) AS total,
       (sum(mass) OVER (PARTITION BY drop_psu ORDER BY welfare ROWS UNBOUNDED PRECEDING)-mass/2)/total AS r
    FROM grouped
)
SELECT drop_psu,2*sum(burden*(r-0.5))/sum(burden) AS c,sum(burden)/max(total) AS mu
FROM ranks GROUP BY drop_psu;
