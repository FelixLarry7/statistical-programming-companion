"""Reproduce Part IX and compare keyed evidence, including a local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED


from ledger import read

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
EXACT = {"n","obs","lines","sales","cancel","other","omitted","anonymous","invoices","gross",
         "cancel_value","net","repeated_total","overcount","booked","returned","void","linked",
         "valid_originals","changed_n","screened","eligible","observed","missing","reason","demand",
         "invoice","pairs","villages","wdi","pwt","good","unmatched","countries","k","df","yes",
         "psus","households","need","known","covered","status","events"}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def run(argv, log):
    with log.open("w", encoding="utf-8") as f:
        result = subprocess.run([str(x) for x in argv], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
    if result.returncode != 0:
        raise RuntimeError(f"Exit code {result.returncode}. Read {log}.")


def import_stata(path, out):
    out.mkdir()
    driver = "part9_driver.do"
    with ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate evidence member name.")
        info = dict(row.split("=", 1) for row in z.read("run_info.txt").decode().splitlines() if row)
        if info["part9_rc"] != "0":
            raise ValueError(f"Local Stata returned {info['part9_rc']}. Inspect part9_run.log.")
        if info["stata_version"] not in {"16", "16.0", "17", "17.0"}:
            raise ValueError(f"Unexpected local Stata version {info['stata_version']}.")
        source = z.read(driver)
        if source != (ROOT / "stata" / driver).read_bytes():
            raise ValueError("Executed driver differs from the released driver.")
        for file in sorted(DATA.glob("*.csv")):
            if z.read("input_" + file.name) != file.read_bytes():
                raise ValueError(f"Executed input differs: {file.name}.")
        log = z.read("part9_run.log").decode("utf-8", errors="replace")
        if "Part IX generated in Stata" not in log:
            raise ValueError("Stata completion line was not found.")
        for name in ("metrics.csv", "run_info.txt", driver):
            (out / name).write_bytes(z.read(name))
    clean = []
    for line in log.splitlines():
        if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)", line):
            clean.append("[Local path removed]")
        elif not (line.startswith("> ") and clean and clean[-1] == "[Local path removed]"):
            clean.append(line)
    (out / "part9_run.log").write_text("\n".join(clean) + "\n")
    report = dict(info, input_archive_sha256=sha(path.read_bytes()), driver_sha256=sha(source))
    (out / "environment.json").write_text(json.dumps(report, indent=2) + "\n")
    with ZipFile(out / "evidence_replay.zip", "w", ZIP_DEFLATED) as z:
        for name in ("metrics.csv", "run_info.txt", driver, "part9_run.log"):
            z.write(out / name, name)
        for file in sorted(DATA.glob("*.csv")):
            z.write(file, "input_" + file.name)
    return report


def anchors():
    return {
        ("CH33","arm0","scalar","screened"): 24*24,
        ("CH33","arm1","scalar","eligible"): 24*20,
        ("CH33","trial","scalar","pairs"): 24,
        ("CH33","trial","scalar","df"): 23,
        ("CH33","trial","scalar","attrition_gap"): (66-63)/480,
        ("CH34","revenue","scalar","lines"): 5904,
        ("CH34","revenue","scalar","net"): 31177527-1628342,
        ("CH34","linked","scalar","valid_originals"): 3,
        ("CH34","linked","scalar","net"): 8150-2450,
        ("CH34","p1_naive","scalar","n"): 12,
        ("CH35","country12","scalar","unmatched"): 24,
        ("CH35","country13","scalar","good"): 0,
        ("CH35","country11","scalar","good"): 16,
        ("CH35","common","scalar","n"): 10*24,
        ("CH35","expanded","scalar","n"): 10*24+16,
        ("CH36","flow","scalar","households"): 4*5*30,
        ("CH36","flow","scalar","known"): 277-8,
        ("CH36","unmet","scalar","df"): 16,
        ("CH36","domain3","scalar","status"): 1,
        ("CH36","domain4","scalar","status"): 0,
    }


def compare(out, stata):
    reference = read(out / "python/metrics.csv")
    if len(reference) != 6739:
        raise ValueError(f"Incorrect Python coverage: {len(reference)}.")
    engines = ["anchor", "r", "duckdb"] + (["stata"] if stata else [])
    comparisons = []
    for engine in engines:
        other = anchors() if engine == "anchor" else read(out / engine / "metrics.csv")
        if engine in {"r", "stata"} and other.keys() != reference.keys():
            raise ValueError(f"{engine} ledger keys differ. Missing {sorted(reference.keys()-other.keys())[:8]}, "
                             f"extra {sorted(other.keys()-reference.keys())[:8]}.")
        if engine == "duckdb" and len(other) != 6717:
            raise ValueError(f"Incorrect DuckDB coverage: {len(other)}.")
        for key, value in sorted(other.items()):
            ref = reference[key]
            quantity = key[3].split("/")[-1] if key[2] in {"scalar","value","endpoint","snapshot"} else key[2]
            tolerance = 0 if quantity in EXACT else 2e-8 + 2e-8*abs(ref)
            gap = abs(value-ref)
            comparisons.append((engine, *key, value, ref, gap, tolerance, gap <= tolerance))
    with (out / "comparisons.csv").open("w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(("engine","chapter","model","quantity","key","value","python","abs_error","tolerance","passed"))
        w.writerows(comparisons)
    errors = [row for row in comparisons if not row[-1]]
    if errors:
        raise ValueError(f"{len(errors)} failed checks. First results: {errors[:5]}")
    return (dict(Counter(row[0] for row in comparisons)), dict(Counter(row[1] for row in comparisons)))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--rscript", default="Rscript")
    ap.add_argument("--sql-python", default=sys.executable)
    ap.add_argument("--stata-evidence", type=Path)
    ap.add_argument("--require-four", action="store_true")
    args = ap.parse_args()
    if args.require_four and not args.stata_evidence:
        ap.error("--require-four requires a local Stata evidence ZIP")
    out = args.output.resolve()
    if out.exists() and any(out.iterdir()):
        ap.error("Use a new or empty output directory.")
    for engine in ("python", "r", "duckdb"):
        (out / engine).mkdir(parents=True, exist_ok=True)
    run([sys.executable, ROOT/"fit_python.py", DATA, out/"python"], out/"python/environment.txt")
    run([args.rscript, "--vanilla", ROOT/"fit_r.R", DATA, out/"r"], out/"r/environment.txt")
    run([args.sql_python, ROOT/"fit_sql.py", DATA, out/"duckdb"],
        out/"duckdb/environment.txt")
    stata = import_stata(args.stata_evidence.resolve(), out/"stata") if args.stata_evidence else None
    counts, chapters = compare(out, stata)
    report = dict(status="VERIFIED" if stata else "STATA EVIDENCE PENDING", comparisons=sum(counts.values()),
                  failures=0, comparisons_by_engine=counts, comparisons_by_chapter=chapters,
                  duckdb_scope="Independent trial and permutation calculations, financial reconciliation, "
                  "forecast scoring, customer cohorts, country coverage and balanced unweighted slopes, "
                  "survey design ratios and re-ranked delete-PSU inequality estimates.",
                  input_sha256={p.name: sha(p.read_bytes()) for p in sorted(DATA.glob("*.csv"))},
                  stata=stata)
    (out/"verification.json").write_text(json.dumps(report, indent=2)+"\n")
    print(report["status"], report["comparisons"], counts, chapters)


if __name__ == "__main__":
    main()
