# Part IX source and attribution record

| Source | Version and adaptation | Use in Part IX |
| --- | --- | --- |
| Daqing Chen, Online Retail, UCI Machine Learning Repository | 2015. Three products, UK transactions and 52 complete weeks starting 6 December 2010. Scoped identifiers recoded and prices converted to pence. | Reconciled invoice lines, customer cohorts and demand proxies. [Dataset and CC BY 4.0 terms](https://doi.org/10.24432/C5BW33) |
| The World Bank, World Development Indicators | Indicator snapshots marked 11 November 2026. Selected 13 source economy codes, 2000–2023, with original indicators and missing values. | Ghana endpoints, peer comparison, eligibility and sensitivity. [DataBank](https://databank.worldbank.org/source/world-development-indicators) · [Dataset terms](https://www.worldbank.org/ext/en/legal/terms-conditions/datasets) |
| Robert C. Feenstra, Robert Inklaar and Marcel P. Timmer, Penn World Table 11.0 | 7 October 2025 release. The teaching extract selects five fields, 13 source codes and years 2000–2023, with no imputation. | GDP and population concepts and country-year models. [Dataset DOI](https://doi.org/10.34894/FABVLR) · [Attribution and CC BY 4.0 terms](https://www.rug.nl/ggdc/productivity/pwt/?lang=en) |
| Book-generated fixtures | Deterministic trial, sign vectors, linked return ledger and household survey. | Chapters 33 and 36 and the original-sale linkage demonstration in Chapter 34. |

The WDI indicator codes are SP.DYN.LE00.IN (life expectancy at birth in
years), SH.DYN.MORT (under-five mortality per 1,000 live births), SP.POP.TOTL
(midyear population), and NY.GDP.PCAP.KD (GDP per person, constant 2015 US
dollars). World Bank provider attributions appear with the indicator
metadata. The project leaves historical observations and missing values
as reported. The World Bank's terms distinguish third-party rights where
applicable. Retain the attribution and confirm relevant provider terms at
the commercial release gate.

For PWT 11.0 also cite Feenstra, Inklaar and Timmer (2015), The next
generation of the Penn World Table, American Economic Review 105(10),
3150–3182. [Methodology DOI](https://doi.org/10.1257/aer.20130954)

The analysis CSVs generated from these snapshots match the input copies in
the author's verified Stata run byte for byte. Two WDI provider ZIPs were
reacquired during the rebuild and have different whole-archive fingerprints
from the first download. Both retain the 11 November 2026 release marker,
and the selected analytical values match the verified CSVs. The source
manifest records both sets of fingerprints where relevant.

The UCI workbook is available from the provider and its frozen download
fingerprint is in the source manifest. The adapted extract is included. All
synthetic fixtures can be recreated with the package generator. The Ghana
DHS, LEAP and CFSVA publications are cited for context and their household
records are absent from the computational inputs.
