*! Part IX comparative labs. Stata 16/17 and built-in Mata.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide input and output folders."
    exit 198
}
mata:
string scalar p9_id(real scalar x)
{
    return(strtrim(strofreal(x,"%12.0f")))
}

void p9_put(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string scalar key, real scalar value)
{
    assert(value<.)
    fput(f,ch+","+model+","+quantity+","+key+","+strtrim(strofreal(value,"%24.16g")))
}

void p9_vec(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string rowvector keys, real rowvector values)
{
    real scalar j
    assert(cols(keys)==cols(values))
    for (j=1;j<=cols(keys);j++) p9_put(f,ch,model,quantity,keys[j],values[j])
}

real scalar p9_var(real colvector x)
{
    return(sum((x:-mean(x)):^2)/(rows(x)-1))
}


real scalar p9_design_se(real colvector u, real matrix d)
{
    real scalar h,j,ss
    real colvector g
    ss=0
    for (h=1;h<=4;h++) {
        g=J(5,1,0)
        for (j=1;j<=5;j++) {
            assert(sum(d[,2]:==100*h+j)>0)
            g[j]=sum(select(u,d[,2]:==100*h+j))
        }
        ss=ss+5*p9_var(g)
    }
    return(sqrt(ss))
}

void p9_trial(real scalar f, real matrix a, real matrix r, real matrix draws)
{
    real matrix by, x
    real colvector eligible, observed, y, delta, base, miss, perm
    real scalar i, j, n, o, lower, upper, est, se, q, shift, tot, nall, nobs
    string scalar m, k
    by=J(48,8,.)
    assert(rows(a)==48)
    for (i=1;i<=48;i++) {
        x=select(r,r[,2]:==a[i,1])
        eligible=x[,3]:==1
        observed=x[,5]:==1
        n=sum(eligible)
        o=sum(observed)
        assert(n==20 & o>0)
        y=select(x[,6]-x[,4],observed)
        tot=sum(select(x[,4],eligible))
        lower=(sum(select(x[,6],observed))-tot)/n
        upper=lower+100*(n-o)/n
        by[i,]=(a[i,2],a[i,4],n,o,mean(y),tot/n,lower,upper)
        k=p9_id(a[i,1])+"/"
        p9_vec(f,"CH33","village","value",k:+("n","obs","change","baseline","lo","hi"),by[i,3..8])
    }
    for (j=0;j<=1;j++) {
        m="arm"+p9_id(j)
        x=select(by,by[,2]:==j)
        nall=sum(x[,3])
        nobs=sum(x[,4])
        p9_vec(f,"CH33",m,"scalar",("screened","eligible","observed","missing","attrition"),
            (rows(x)*24,nall,nobs,nall-nobs,1-nobs/nall))
        for (i=1;i<=3;i++) {
            tot=0
            for (n=1;n<=48;n++) {
                if (a[n,4]==j) tot=tot+sum((r[,2]:==a[n,1]):&(r[,7]:==i))
            }
            p9_put(f,"CH33",m,"reason",p9_id(i),tot)
        }
    }
    x=sort(by,(1,2))
    delta=J(24,1,0)
    base=delta
    miss=delta
    lower=0
    upper=0
    shift=0
    for (i=1;i<=24;i++) {
        j=2*i
        assert(x[j-1,1]==i & x[j,1]==i & x[j-1,2]==0 & x[j,2]==1)
        delta[i]=x[j,5]-x[j-1,5]
        base[i]=x[j,6]-x[j-1,6]
        miss[i]=x[j-1,4]/x[j-1,3]-x[j,4]/x[j,3]
        lower=lower+(x[j,7]-x[j-1,8])/24
        upper=upper+(x[j,8]-x[j-1,7])/24
        shift=shift+2-x[j-1,4]/x[j-1,3]-x[j,4]/x[j,3]
        p9_put(f,"CH33","trial","pair",p9_id(i),delta[i])
    }
    shift=shift/24
    perm=draws[,2..25]*delta/24
    for (i=1;i<=rows(perm);i++) p9_put(f,"CH33","trial","permuted",p9_id(draws[i,1]),perm[i])
    est=mean(delta)
    se=sqrt(p9_var(delta)/24)
    q=invttail(23,0.025)
    p9_vec(f,"CH33","trial","scalar",("pairs","villages","estimate","se","df","lo","hi","baseline_gap",
        "attrition_gap","randomisation_p","bound_lo","bound_hi","delta3_lo","delta3_hi","delta6_lo","delta6_hi","mde"),
        (24,48,est,se,23,est-q*se,est+q*se,mean(base),mean(miss),
        (1+sum(abs(perm):>=abs(est)-1e-12))/(1+rows(perm)),lower,upper,
        est-3*shift,est+3*shift,est-6*shift,est+6*shift,
        (invnormal(.975)+invnormal(.8))*8*sqrt(2*(1+19*.1)/(24*20))))
}

void p9_business(real scalar f, real matrix x, real matrix r)
{
    real colvector positive, cancelled, other, price, tot, mult, u, err, h, hi, lo, buyers
    real matrix b, v, s
    real scalar i,j,k,c,o, gross, cut, actual, pred, net, er, amount, events, n, a, mval, count
    string scalar m
    string rowvector methods
    real rowvector origins
    methods=("naive","mean4")
    origins=(27,33,39,45,48)
    positive=(x[,8]:==0):&(x[,5]:>0):&(x[,6]:>0)
    cancelled=(x[,8]:==1):&(x[,5]:<0):&(x[,6]:>0)
    other=(x[,8]:==0):&(x[,5]:<0):&(x[,6]:>0)
    price=x[,5]:*x[,6]
    gross=sum(price:*positive)
    cut=-sum(price:*cancelled)
    v=select(x,positive:|cancelled)
    tot=J(max(v[,2]),1,0)
    mult=tot
    for (i=1;i<=rows(v);i++) {
        j=v[i,2]
        tot[j]=tot[j]+v[i,5]*v[i,6]
        mult[j]=mult[j]+1
    }
    for (j=1;j<=rows(tot);j++) {
        if (mult[j]>0) p9_put(f,"CH34","revenue","invoice",p9_id(j),tot[j])
    }
    net=gross-cut
    p9_vec(f,"CH34","revenue","scalar",("lines","sales","cancel","other","omitted","anonymous","invoices",
        "gross","cancel_value","net","repeated_total","overcount"),
        (rows(x),sum(positive),sum(cancelled),sum(other),rows(x)-rows(v),
        sum(positive:*(x[,7]:==0)),sum(mult:>0),gross,cut,net,sum(tot:*mult),sum(tot:*mult)-net))
    b=select(x,positive)
    for (c=1;c<=3;c++) {
        s=select(b,b[,3]:==c)
        u=J(52,1,0)
        for (i=1;i<=rows(s);i++) u[s[i,4]]=u[s[i,4]]+s[i,5]
        m="product"+p9_id(c)
        for (i=1;i<=52;i++) p9_put(f,"CH34",m,"demand",p9_id(i),u[i])
        for (j=1;j<=2;j++) {
            m="p"+p9_id(c)+"_"+methods[j]
            err=J(12,1,0)
            for (o=40;o<=51;o++) {
                pred=u[o]
                if (j==2) pred=mean(u[|o-3\o|])
                actual=u[o+1]
                er=actual-pred
                err[o-39]=er
                p9_put(f,"CH34",m,"forecast",p9_id(o+1),pred)
                p9_put(f,"CH34",m,"error",p9_id(o+1),er)
            }
            hi=rowmax((err,J(12,1,0)))
            lo=rowmax((-err,J(12,1,0)))
            p9_vec(f,"CH34",m,"scalar",("n","mae","rmse","cost","shortage","changed_n","changed_mae"),
                (12,mean(abs(err)),sqrt(mean(err:^2)),mean(2:*hi:+lo),sum(hi),6,mean(abs(err[|1\6|]))))
        }
    }
    b=select(b,b[,7]:>0)
    buyers=J(max(b[,7]),1,0)
    for (i=1;i<=5;i++) {
        o=origins[i]
        u=buyers
        h=buyers
        for (j=1;j<=rows(b);j++) {
            k=b[j,7]
            a=b[j,4]
            if (a<=o & a>=o-11) u[k]=max((u[k],a))
            if (a>o & a<=o+4) h[k]=1
        }
        for (j=0;j<=1;j++) {
            v=select(h,(u:>0):&((o:-u:<=3):==j))
            m=p9_id(o)+"/"+p9_id(j)+"/"
            p9_vec(f,"CH34","customer","snapshot",m:+("n","events","rate"),(rows(v),sum(v),mean(v)))
        }
    }
    s=select(r,r[,3]:==3)
    v=select(r,r[,3]:==1)
    h=J(max(r[,1]),1,0)
    for (i=1;i<=rows(s);i++) {
        j=s[i,6]
        assert(r[j,1]==j & r[j,3]==1 & s[i,5]==r[j,5] & s[i,4]<0)
        h[j]=h[j]-s[i,4]
        assert(h[j]<=r[j,4])
    }
    gross=sum(v[,4]:*v[,5])
    cut=-sum(s[,4]:*s[,5])
    v=select(r,r[,3]:==2)
    p9_vec(f,"CH34","linked","scalar",("booked","returned","net","void","linked","valid_originals"),
        (gross,cut,gross-cut,sum(v[,4]:*v[,5]),rows(s),sum(h:>0)))
}

void p9_reg(real scalar f, string scalar m, real matrix s, real colvector xv, real colvector w)
{
    real matrix x, scores, inv, vc
    real colvector years, countries, b, e, match
    real scalar i,n,k,g,se,q
    years=uniqrows(sort(s[,2],1))
    countries=uniqrows(sort(s[,1],1))
    n=rows(s)
    g=rows(countries)
    x=(J(n,1,1),xv)
    for (i=2;i<=g;i++) x=(x,s[,1]:==countries[i])
    for (i=2;i<=rows(years);i++) x=(x,s[,2]:==years[i])
    b=qrsolve(x:*sqrt(w),s[,3]:*sqrt(w))
    e=s[,3]-x*b
    inv=invsym(quadcross(x,w:*x))
    k=cols(x)
    scores=J(g,k,0)
    for (i=1;i<=g;i++) scores[i,]=quadcross((s[,1]:==countries[i]):*w:*e,x)
    vc=(g/(g-1))*((n-1)/(n-k))*inv*quadcross(scores,scores)*inv
    se=sqrt(vc[2,2])
    q=invttail(g-1,.025)
    p9_vec(f,"CH35",m,"scalar",("estimate","se","n","countries","k","df","lo","hi"),
        (b[2],se,n,g,k,g-1,b[2]-q*se,b[2]+q*se))
}

void p9_development(real scalar f, real matrix d, real matrix p, real matrix map)
{
    real matrix all, a, b, expanded, balanced, x
    real colvector good, match, w
    real scalar i,j,k,year,valid,pc,n
    string scalar m, id
    all=J(312,11,.)
    assert(rows(d)==312)
    for (i=1;i<=13;i++) {
        a=select(d,d[,1]:==i)
        b=select(p,p[,1]:==i)
        n=0
        valid=0
        m="country"+p9_id(i)
        for (j=1;j<=24;j++) {
            year=a[j,2]
            k=(i-1)*24+j
            all[k,1..6]=a[j,]
            if (rows(b)==0) continue
            match=selectindex(b[,2]:==year)
            if (rows(match)==0) continue
            assert(rows(match)==1)
            n++
            x=b[match,3..7]
            if (map[i,2]!=1 | a[j,3]>=. | a[j,4]<=0 | a[j,4]>=. | x[1]>=. | x[1]<=0 | x[4]<=0 | x[4]>=.) continue
            pc=x[1]/x[4]
            all[k,7..11]=(pc,x[2]/x[5],1,n,0)
            valid++
            p9_put(f,"CH35",m,"income",p9_id(year),pc)
            if (year==2000 | year==2023) {
                id=p9_id(year)+"/"
                p9_put(f,"CH35",m,"endpoint",id+"life",a[j,3])
                if (a[j,5]<.) p9_put(f,"CH35",m,"endpoint",id+"u5",a[j,5])
                if (a[j,6]<.) p9_put(f,"CH35",m,"endpoint",id+"gdp2015",a[j,6])
                if (x[5]>0 & x[5]<.) p9_put(f,"CH35",m,"endpoint",id+"productivity",x[2]/x[5])
            }
        }
        if (valid==24) all[|(i-1)*24+1,11\i*24,11|]=J(24,1,1)
        p9_vec(f,"CH35",m,"scalar",("wdi","pwt","good","unmatched"),(24,n,valid,24-n))
    }
    expanded=select(all,all[,9]:==1)
    balanced=select(expanded,expanded[,11]:==1)
    p9_reg(f,"common",balanced,ln(balanced[,7]),J(rows(balanced),1,1))
    p9_reg(f,"weighted",balanced,ln(balanced[,7]),balanced[,4]:/1000000)
    p9_reg(f,"expanded",expanded,ln(expanded[,7]),J(rows(expanded),1,1))
    p9_reg(f,"national",balanced,ln(balanced[,6]),J(rows(balanced),1,1))
    for (j=1;j<=2;j++) {
        year=2000+23*(j-1)
        x=select(balanced,balanced[,2]:==year)
        w=x[,4]
        p9_vec(f,"CH35","headline","endpoint",(p9_id(year)+"/"):+
            ("countries","mean_life","weighted_life","mean_pc","weighted_pc"),
            (rows(x),mean(x[,3]),sum(x[,3]:*w)/sum(w),mean(x[,7]),sum(x[,7]:*w)/sum(w)))
    }
}

real scalar p9_domain(real scalar f, string scalar m, real matrix x, real colvector y, real colvector keep)
{
    real colvector w
    real scalar n,yes,psus,den,num,p,se,q,h,j
    w=x[,14]:*keep
    n=sum(keep)
    yes=sum(y:*keep)
    psus=0
    for (h=1;h<=4;h++) {
        for (j=1;j<=5;j++) psus=psus+(sum(keep:*(x[,3]:==100*h+j))>0)
    }
    den=sum(w)
    num=sum(w:*y)
    p=num/den
    se=p9_design_se(w:*(y:-p):/den,x[,2..3])
    q=invttail(16,.025)
    p9_vec(f,"CH36",m,"scalar",("n","yes","psus","den","num","estimate","se","df","lo","hi"),
        (n,yes,psus,den,num,p,se,16,p-q*se,p+q*se))
    if (n<30 | min((yes,n-yes))<5) return(0)
    if (psus<4 | 2*q*se>.28) return(1)
    return(2)
}

real rowvector p9_ci(real colvector y, real colvector income, real colvector w)
{
    real colvector v,k
    real scalar j,W,num,before,block,cross
    v=uniqrows(sort(income,1))
    W=sum(w)
    num=sum(w:*y)
    before=0
    cross=0
    for (j=1;j<=rows(v);j++) {
        k=(income:==v[j])
        block=sum(k:*w)
        cross=cross+sum(k:*w:*y)*((before+block/2)/W-.5)
        before=before+block
    }
    return((2*cross/num,num/W))
}

void p9_social(real scalar f, real matrix x)
{
    real colvector need,known,y,eligible,covered,keep,w,iq
    real matrix h
    real rowvector ci,repv
    real scalar i,j,psu,ss,se,q,status,line,t
    string scalar m
    need=x[,10]:==1
    known=need:&(x[,11]:>=0)
    y=x[,11]:==1
    eligible=(x[,6]:<=55):&(x[,7]:==1)
    covered=x[,8]:==1
    p9_vec(f,"CH36","flow","scalar",("households","need","known","missing","eligible","covered"),
        (rows(x),sum(need),sum(known),sum(need)-sum(known),sum(eligible),sum(covered)))
    status=p9_domain(f,"coverage",x,covered,eligible)
    status=p9_domain(f,"exclusion",x,1:-covered,eligible)
    status=p9_domain(f,"inclusion",x,1:-eligible,covered)
    status=p9_domain(f,"unmet",x,y,known)
    status=p9_domain(f,"unmet_rural",x,y,known:&(x[,5]:==1))
    status=p9_domain(f,"unmet_urban",x,y,known:&(x[,5]:==0))
    status=p9_domain(f,"insured",x,x[,9]:==1,J(rows(x),1,1))
    for (i=1;i<=4;i++) {
        m="domain"+p9_id(i)
        status=p9_domain(f,m,x,y,known:&(x[,4]:==i))
        p9_put(f,"CH36",m,"scalar","status",status)
    }
    h=select(x,known)
    ci=p9_ci(h[,11],h[,12],h[,14])
    ss=0
    for (i=1;i<=4;i++) {
        iq=J(5,1,0)
        for (j=1;j<=5;j++) {
            psu=100*i+j
            w=h[,14]:*(h[,3]:!=psu):*(1:+.25:*(h[,2]:==i))
            repv=p9_ci(h[,11],h[,12],w)
            iq[j]=repv[1]
            p9_put(f,"CH36","inequality","jackknife",p9_id(psu),repv[1])
            p9_put(f,"CH36","inequality","bounded_jk",p9_id(psu),4*repv[2]*repv[1])
        }
        ss=ss+.8*sum((iq:-mean(iq)):^2)
    }
    se=sqrt(ss)
    q=invttail(16,.025)
    p9_vec(f,"CH36","inequality","scalar",("estimate","se","df","lo","hi","mean","corrected"),
        (ci[1],se,16,ci[1]-q*se,ci[1]+q*se,ci[2],4*ci[1]*ci[2]))
    for (i=1;i<=2;i++) {
        line=2200+400*(i-1)
        for (t=1;t<=2;t++) {
            w=x[,14]
            if (t==2) w=w:*x[,13]
            m="household"+p9_id(line)
            if (t==2) m="person"+p9_id(line)
            keep=x[,12]:<line
            p9_vec(f,"CH36",m,"scalar",("head","gap","den"),
                (sum(w:*keep)/sum(w),sum(w:*keep:*(1:-x[,12]:/line))/sum(w),sum(w)))
        }
    }
}
end

mata: p9_fh=fopen(st_local("output")+"/metrics.csv","w")
mata: fput(p9_fh,"chapter,model,quantity,key,value")

import delimited using `"`input'/assignment33.csv"', clear varnames(1) asdouble
isid village
sort village
mata: p9_a=st_data(.,1..4)

import delimited using `"`input'/roster33.csv"', clear varnames(1) asdouble
isid household
sort household
mata: p9_r=st_data(.,1..7)

import delimited using `"`input'/draws33.csv"', clear varnames(1) asdouble
isid draw
sort draw
mata: p9_d=st_data(.,1..25)

import delimited using `"`input'/retail34.csv"', clear varnames(1) asdouble
isid line
sort line
mata: p9_x=st_data(.,1..8)

import delimited using `"`input'/returns34.csv"', clear varnames(1) asdouble
isid line
sort line
mata: p9_v=st_data(.,1..6)

import delimited using `"`input'/wdi35.csv"', clear varnames(1) asdouble
isid economy year
sort economy year
mata: p9_w=st_data(.,1..6)

import delimited using `"`input'/pwt35.csv"', clear varnames(1) asdouble
isid economy year
sort economy year
mata: p9_p=st_data(.,1..7)

import delimited using `"`input'/map35.csv"', clear varnames(1) asdouble
isid economy
sort economy
mata: p9_m=st_data(.,1..2)

import delimited using `"`input'/welfare36.csv"', clear varnames(1) asdouble
isid household
sort household
mata: p9_h=st_data(.,1..14)

mata: p9_trial(p9_fh,p9_a,p9_r,p9_d)
mata: p9_business(p9_fh,p9_x,p9_v)
mata: p9_development(p9_fh,p9_w,p9_p,p9_m)
mata: p9_social(p9_fh,p9_h)
mata: fclose(p9_fh)
display as result "Part IX generated in Stata."
