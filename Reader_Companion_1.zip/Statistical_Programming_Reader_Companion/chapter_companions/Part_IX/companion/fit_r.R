# Independent base-R implementation of the Part IX calculations.
a <- commandArgs(trailingOnly=TRUE)
stopifnot(length(a)==2)
getdata <- function(name) read.csv(file.path(a[1],paste0(name,".csv")))
rows <- new.env(hash=TRUE,parent=emptyenv())
put <- function(ch,m,q,k,v) {
  stopifnot(length(k)==length(v),all(is.finite(v)))
  key <- paste(ch,m,q,k,sep=",")
  stopifnot(!anyDuplicated(key),!any(vapply(key,exists,logical(1),envir=rows,inherits=FALSE)))
  for(i in seq_along(k)) assign(key[i],v[i],envir=rows)
}
sc <- function(c,m,v) put(c,m,"scalar",names(v),v)

trial <- function() {
  a <- getdata("assignment33")
  r <- getdata("roster33")
  z <- getdata("draws33")
  stopifnot(!anyDuplicated(a$village),!anyDuplicated(r$household))
  x <- merge(r,a,by="village")
  stopifnot(nrow(x)==nrow(r),all((x$followup>=0)==as.logical(x$observed)))
  v <- t(vapply(split(x,x$village),function(s) {
    s <- s[s$eligible==1,]
    u <- s[s$observed==1,]
    c(pair=s$pair[1],offer=s$offer[1],n=nrow(s),obs=nrow(u),change=mean(u$followup-u$baseline),
      baseline=mean(s$baseline),lo=(sum(u$followup)-sum(s$baseline))/nrow(s),
      hi=(sum(u$followup)+100*(nrow(s)-nrow(u))-sum(s$baseline))/nrow(s))
  },numeric(8)))
  for(i in seq_len(nrow(v))) put("CH33","village","value",paste(rownames(v)[i],colnames(v)[3:8],sep="/"),v[i,3:8])
  for(i in 0:1) {
    s <- x[x$offer==i,]
    m <- paste0("arm",i)
    sc("CH33",m,c(screened=nrow(s),eligible=sum(s$eligible),observed=sum(s$observed),
                  missing=sum(s$eligible)-sum(s$observed),attrition=1-sum(s$observed)/sum(s$eligible)))
    put("CH33",m,"reason",1:3,as.vector(table(factor(s$reason,levels=1:3))))
  }
  u <- v[v[,"offer"]==1,]; u <- u[order(u[,"pair"]),]
  w <- v[v[,"offer"]==0,]; w <- w[order(w[,"pair"]),]
  stopifnot(all(u[,"pair"]==w[,"pair"]),nrow(u)==24)
  diff <- u[,"change"]-w[,"change"]
  missing1 <- 1-u[,"obs"]/u[,"n"]
  missing0 <- 1-w[,"obs"]/w[,"n"]
  p <- drop(as.matrix(z[,-1])%*%diff)/24
  est <- mean(diff)
  se <- sd(diff)/sqrt(24)
  cv <- qt(.975,23)
  s <- mean(missing1+missing0)
  put("CH33","trial","pair",u[,"pair"],diff)
  put("CH33","trial","permuted",z$draw,p)
  sc("CH33","trial",c(pairs=24,villages=48,estimate=est,se=se,df=23,lo=est-cv*se,hi=est+cv*se,
      baseline_gap=mean(u[,"baseline"]-w[,"baseline"]),attrition_gap=mean(missing1-missing0),
      randomisation_p=(1+sum(abs(p)>=abs(est)-1e-12))/(1+length(p)),
      bound_lo=mean(u[,"lo"]-w[,"hi"]),bound_hi=mean(u[,"hi"]-w[,"lo"]),
      delta3_lo=est-3*s,delta3_hi=est+3*s,delta6_lo=est-6*s,delta6_hi=est+6*s,
      mde=(qnorm(.975)+qnorm(.8))*8*sqrt(2*(1+19*.1)/(24*20))))
}

retail <- function() {
  x <- getdata("retail34")
  r <- getdata("returns34")
  sale <- x$cancel==0 & x$units>0 & x$pence>0
  cancel <- x$cancel==1 & x$units<0 & x$pence>0
  other <- x$cancel==0 & x$units<0 & x$pence>0
  amount <- x$units*x$pence
  v <- x[sale | cancel,]
  tot <- tapply(v$units*v$pence,v$invoice,sum)
  gross <- sum(amount[sale])
  cut <- -sum(amount[cancel])
  twice <- sum(tot[as.character(v$invoice)])
  put("CH34","revenue","invoice",names(tot),as.vector(tot))
  sc("CH34","revenue",c(lines=nrow(x),sales=sum(sale),cancel=sum(cancel),other=sum(other),
    omitted=sum(!(sale|cancel)),anonymous=sum(sale&x$customer==0),invoices=length(tot),
    gross=gross,cancel_value=cut,net=gross-cut,repeated_total=twice,overcount=twice-(gross-cut)))
  b <- x[sale,]
  for(j in 1:3) {
    s <- b[b$product==j,]
    y <- tapply(s$units,factor(s$week,levels=1:52),sum)
    y[is.na(y)] <- 0
    put("CH34",paste0("product",j),"demand",1:52,y)
    actual <- y[41:52]
    for(method in c("naive","mean4")) {
      p <- if(method=="naive") y[40:51] else vapply(40:51,function(o) mean(y[(o-3):o]),numeric(1))
      err <- actual-p
      m <- paste0("p",j,"_",method)
      put("CH34",m,"forecast",41:52,p)
      put("CH34",m,"error",41:52,err)
      sc("CH34",m,c(n=12,mae=mean(abs(err)),rmse=sqrt(mean(err^2)),
        cost=mean(2*pmax(err,0)+pmax(-err,0)),shortage=sum(pmax(err,0)),
        changed_n=6,changed_mae=mean(abs(err[1:6]))))
    }
  }
  b <- b[b$customer>0,]
  for(o in c(27,33,39,45,48)) {
    s <- b[b$week>=o-11 & b$week<=o,]
    p <- tapply(s$week,s$customer,max)
    y <- unique(b$customer[b$week>o & b$week<=o+4])
    for(k in 0:1) {
      v <- names(p)[(o-p<=3)==as.logical(k)] %in% as.character(y)
      put("CH34","customer","snapshot",paste(o,k,c("n","events","rate"),sep="/"),c(length(v),sum(v),mean(v)))
    }
  }
  b <- r[r$status==1,]
  k <- r[r$status==3,]
  t <- match(k$original,b$line)
  stopifnot(!anyNA(t),all(k$pence==b$pence[t]),all(k$units<0))
  n <- tapply(-k$units,k$original,sum)
  stopifnot(all(n<=b$units[match(names(n),b$line)]))
  booked <- sum(b$units*b$pence)
  returned <- -sum(k$units*k$pence)
  sc("CH34","linked",c(booked=booked,returned=returned,net=booked-returned,
    void=sum(r$units[r$status==2]*r$pence[r$status==2]),linked=nrow(k),valid_originals=length(n)))
}

regression <- function(s,m,field,weighted) {
  x <- model.matrix(~log(s[[field]])+factor(economy)+factor(year),data=s)
  w <- if(weighted) s$population/1e6 else rep(1,nrow(s))
  y <- s$life
  b <- lm.wfit(x,y,w)$coefficients
  e <- drop(y-x%*%b)
  v <- solve(crossprod(x,w*x))
  scores <- rowsum(x*(w*e),s$economy)
  g <- nrow(scores); n <- nrow(s); k <- ncol(x)
  vc <- g/(g-1)*(n-1)/(n-k)*v%*%crossprod(scores)%*%v
  se <- sqrt(vc[2,2])
  q <- qt(.975,g-1)
  sc("CH35",m,c(estimate=unname(b[2]),se=se,n=n,countries=g,k=k,df=g-1,lo=unname(b[2])-q*se,hi=unname(b[2])+q*se))
}

development <- function() {
  d <- getdata("wdi35")
  p <- getdata("pwt35")
  m <- getdata("map35")
  p$found <- 1
  z <- merge(merge(d,m,by="economy"),p,by=c("economy","year"),all.x=TRUE)
  z$pc <- z$rgdpe/z$pop
  z$good <- with(z,include==1 & !is.na(life) & !is.na(population) & population>0 & !is.na(pc) & pc>0)
  for(i in sort(unique(z$economy))) {
    s <- z[z$economy==i,]
    model <- paste0("country",i)
    sc("CH35",model,c(wdi=nrow(s),pwt=sum(!is.na(s$found)),good=sum(s$good),unmatched=sum(is.na(s$found))))
    t <- s[s$good,]
    put("CH35",model,"income",t$year,t$pc)
    for(j in which(t$year %in% c(2000,2023))) {
      v <- with(t[j,],c(life=life,u5=u5,gdp2015=gdp2015,productivity=rgdpo/emp))
      put("CH35",model,"endpoint",paste(t$year[j],names(v)[is.finite(v)],sep="/"),v[is.finite(v)])
    }
  }
  s <- z[z$good,]
  n <- table(s$economy)
  b <- s[s$economy %in% as.integer(names(n)[n==24]),]
  regression(b,"common","pc",FALSE)
  regression(b,"weighted","pc",TRUE)
  regression(s,"expanded","pc",FALSE)
  regression(b,"national","gdp2015",FALSE)
  for(year in c(2000,2023)) {
    s <- b[b$year==year,]
    put("CH35","headline","endpoint",paste(year,c("countries","mean_life","weighted_life","mean_pc","weighted_pc"),sep="/"),
      c(nrow(s),mean(s$life),weighted.mean(s$life,s$population),mean(s$pc),weighted.mean(s$pc,s$population)))
  }
}

domain <- function(f,y,keep,m) {
  w <- f$weight*keep
  den <- sum(w); num <- sum(w*y); p <- num/den
  u <- rowsum(w*(y-p)/den,f$psu)
  se <- sqrt(sum(5*vapply(split(drop(u),as.integer(rownames(u))%/%100),var,numeric(1))))
  q <- qt(.975,16)
  n <- sum(keep); yes <- sum(keep & y==1); psus <- length(unique(f$psu[keep]))
  sc("CH36",m,c(n=n,yes=yes,psus=psus,den=den,num=num,estimate=p,se=se,df=16,lo=p-q*se,hi=p+q*se))
  if(n<30 || min(yes,n-yes)<5) 0 else if(psus<4 || 2*q*se>.28) 1 else 2
}

ci <- function(y,x,w) {
  z <- rowsum(cbind(w,w*y),x,reorder=TRUE)
  q <- sum(z[,2])
  v <- (cumsum(z[,1])-z[,1]/2)/sum(z[,1])
  c(2*sum(z[,2]*(v-.5))/q,q/sum(z[,1]))
}

social <- function() {
  f <- getdata("welfare36")
  need <- f$need==1
  obs <- need & f$unmet %in% 0:1
  eligible <- f$score<=55 & f$priority==1
  covered <- f$transfer==1
  y <- f$unmet==1
  sc("CH36","flow",c(households=nrow(f),need=sum(need),known=sum(obs),missing=sum(need&!obs),
                     eligible=sum(eligible),covered=sum(covered)))
  domain(f,covered,eligible,"coverage")
  domain(f,!covered,eligible,"exclusion")
  domain(f,!eligible,covered,"inclusion")
  domain(f,y,obs,"unmet")
  domain(f,y,obs&f$rural==1,"unmet_rural")
  domain(f,y,obs&f$rural==0,"unmet_urban")
  domain(f,f$insurance==1,rep(TRUE,nrow(f)),"insured")
  for(j in 1:4) {
    m <- paste0("domain",j)
    sc("CH36",m,c(status=domain(f,y,obs&f$domain==j,m)))
  }
  h <- f[obs,]
  z <- ci(h$unmet,h$welfare,h$weight)
  ss <- 0
  for(s in 1:4) {
    k <- 100*s+1:5
    v <- vapply(k,function(j) ci(h$unmet,h$welfare,h$weight*(h$psu!=j)*(1+.25*(h$stratum==s))),numeric(2))
    put("CH36","inequality","jackknife",k,v[1,])
    put("CH36","inequality","bounded_jk",k,4*v[1,]*v[2,])
    ss <- ss+4/5*sum((v[1,]-mean(v[1,]))^2)
  }
  se <- sqrt(ss)
  q <- qt(.975,16)
  sc("CH36","inequality",c(estimate=z[1],se=se,df=16,lo=z[1]-q*se,hi=z[1]+q*se,mean=z[2],corrected=4*z[1]*z[2]))
  for(line in c(2200,2600)) for(basis in c("household","person")) {
    w <- if(basis=="household") f$weight else f$weight*f$size
    sc("CH36",paste0(basis,line),c(head=weighted.mean(f$welfare<line,w),
       gap=weighted.mean(pmax(1-f$welfare/line,0),w),den=sum(w)))
  }
}

trial()
retail()
development()
social()
keys <- sort(ls(rows))
dir.create(a[2],recursive=TRUE,showWarnings=FALSE)
writeLines(c("chapter,model,quantity,key,value",paste(keys,sprintf("%.17g",unlist(mget(keys,rows))),sep=",")),
           file.path(a[2],"metrics.csv"))
cat(R.version.string,length(keys),"keyed values\n")
