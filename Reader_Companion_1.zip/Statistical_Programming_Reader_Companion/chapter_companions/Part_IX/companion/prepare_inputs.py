"""Rebuild Part IX fixtures and the dated UCI, WDI and PWT teaching extracts."""

import argparse
import csv
from datetime import date
import hashlib
import io
from math import exp
from pathlib import Path
from random import Random
from zipfile import ZipFile

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent
COUNTRIES = (
    ("GHA", "Ghana"), ("KEN", "Kenya"), ("SEN", "Senegal"), ("ZAF", "South Africa"),
    ("BGD", "Bangladesh"), ("BRA", "Brazil"), ("IDN", "Indonesia"), ("VNM", "Viet Nam"),
    ("IND", "India"), ("USA", "United States"), ("SSD", "South Sudan"), ("TLS", "Timor-Leste"),
    ("WLD", "World"),
)
WDI = {"life":"SP.DYN.LE00.IN", "population":"SP.POP.TOTL", "u5":"SH.DYN.MORT",
       "gdp2015":"NY.GDP.PCAP.KD"}
PRODUCTS = ("85123A", "22423", "85099B")
FIRST_WEEK = date(2010, 12, 6)
UCI_SHA256 = "f5385cbb54bbebf7196389109c6b0621faab0c304e3702548165e71c84aede8b"


def write(out, filename, columns, rows):
    with (out / (filename+".csv")).open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(columns.split())
        writer.writerows(rows)


def probability(value):
    return 1/(1+exp(-value))


def trial(out):
    rng = Random(33041)
    assign, roster = [], []
    for pair in range(1, 25):
        offered = rng.randint(0, 1)
        shared = rng.gauss(0, 6.5)
        for site in (0, 1):
            village = 2*pair-1+site
            offer = int(site==offered)
            assign.append((village, pair, 1+(pair-1)//6, offer))
            baseline_shift = shared+rng.gauss(0, 3)
            change_shift = rng.gauss(0, 2.2)
            for j in range(1, 25):
                hh=100*village+j
                eligible=int(j<=20)
                baseline=round(min(86,max(18,49+baseline_shift+rng.gauss(0,7))),3)
                outcome=round(min(99,max(1,baseline+1.8+4.4*offer+change_shift+rng.gauss(0,6))),3)
                observed=int(rng.random()<probability(2.2-0.42*offer+0.021*(baseline-48)))
                reason=0 if observed else rng.choice((1,2,2,3))
                if not eligible:
                    observed,reason=0,4
                roster.append((hh,village,eligible,baseline,observed,outcome if observed else -1,reason))
    write(out,"assignment33","village pair region offer",assign)
    write(out,"roster33","household village eligible baseline observed followup reason",roster)
    rng=Random(33042)
    write(out,"draws33","draw "+" ".join(f"p{i:02d}" for i in range(1,25)),
          ((d,*(rng.choice((-1,1)) for _ in range(24))) for d in range(1,500)))


def uci_extract(archive, folder):
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=UCI_SHA256:
        raise ValueError("UCI archive checksum differs from the frozen snapshot.")
    with ZipFile(archive) as z:
        sheet = load_workbook(io.BytesIO(z.read("Online Retail.xlsx")), read_only=True, data_only=True).active
        rows=sheet.values
        header=next(rows)
        assert header[:8]==("InvoiceNo","StockCode","Description","Quantity","InvoiceDate","UnitPrice","CustomerID","Country")
        selected=[]
        for number,(invoice,product,_,units,stamp,price,customer,country) in enumerate(rows,2):
            product=str(product).upper()
            if product not in PRODUCTS or country!="United Kingdom":
                continue
            week=(stamp.date()-FIRST_WEEK).days//7+1
            if 1<=week<=52:
                selected.append((number,str(invoice),product,week,units,round(price*100),customer))
    invoices={k:j for j,k in enumerate(dict.fromkeys(r[1] for r in selected),1)}
    customers={k:j for j,k in enumerate(dict.fromkeys(r[6] for r in selected if r[6] is not None),1)}
    write(folder,"retail34_extract","line invoice product week units pence customer cancel",
          ((line,invoices[inv],PRODUCTS.index(product)+1,week,units,pence,customers.get(customer,0),
            int(inv.upper().startswith("C"))) for line,inv,product,week,units,pence,customer in selected))


def retail(out, source):
    p = source/"retail34_extract.csv"
    (out/"retail34.csv").write_bytes(p.read_bytes())
    rows = [
        (1,101,1,4,350,0),(2,101,1,2,500,0),(3,102,1,8,300,0),
        (4,103,2,3,600,0),(5,104,3,-2,350,1),(6,105,1,1,850,0),
        (7,106,3,-1,350,1),(8,107,3,-1,500,2),(9,108,2,1,650,0),
        (10,109,1,5,200,0),(11,110,3,-2,300,3),(12,111,3,-1,300,3),
        (13,112,1,2,750,0),(14,113,2,2,330,0),
    ]
    write(out,"returns34","line invoice status units pence original",rows)


def wdi_rows(source, code):
    with ZipFile(source/f"{code}.zip") as z:
        member = next(name for name in z.namelist() if name.startswith("API_"))
        rows = list(csv.reader(io.StringIO(z.read(member).decode("utf-8-sig"))))
    version=next(r[1] for r in rows[:4] if r and r[0]=="Last Updated Date")
    if version!="2026-11-11":
        raise ValueError(f"{code} source revision {version} differs from the verified 2026-11-11 extract.")
    pos={year:rows[4].index(str(year)) for year in range(2000,2024)}
    codes={i for i,_ in COUNTRIES}
    return {(r[1],year):r[k] for r in rows[5:] if r[1] in codes for year,k in pos.items()}


def international(out, source):
    # The source snapshot is kept separate from optional provider files.
    fields={key:wdi_rows(source,code) for key,code in WDI.items()}
    lookup={c:i for i,(c,_) in enumerate(COUNTRIES,1)}
    write(out,"map35","economy include",((i,int(code!="WLD")) for i,(code,_) in enumerate(COUNTRIES,1)))
    write(out,"wdi35","economy year "+" ".join(WDI),
          ((i,t,*(f.get((c,t),"") for f in fields.values()))
           for c,i in lookup.items() for t in range(2000,2024)))
    sheet=load_workbook(source/"pwt110.xlsx",read_only=True,data_only=True)["Data"]
    rows=sheet.values
    fields=next(rows)
    keep=[]
    for row in rows:
        x=dict(zip(fields,row))
        code,year=x["countrycode"],x["year"]
        if code in lookup and 2000<=year<=2023:
            keep.append((lookup[code],year,*(x[k] for k in ("rgdpe","rgdpo","rgdpna","pop","emp"))))
    write(out,"pwt35","economy year rgdpe rgdpo rgdpna pop emp",sorted(keep))


def welfare(out):
    rng=Random(36083)
    rows=[]
    for s in range(1,5):
        for cluster in range(1,6):
            psu=100*s+cluster
            shift=rng.gauss(0,0.43)
            for j in range(1,31):
                hh=100*psu+j
                domain=4 if s==1 and cluster==1 and j<=12 else 1+(j+cluster+s)%3
                rural=int(rng.random()<0.28+0.11*domain)
                income=10*round(exp(rng.gauss(7.82-0.22*rural+0.13*shift,0.47))/10)
                score=int(min(97,max(3,57+0.011*(income-2200)+rng.gauss(0,13)-6*rural)))
                priority=int(rng.random()<0.69-0.10*(domain==2))
                enrolled=int(rng.random()<probability(-0.7+1.65*(score<=55 and priority==1)+0.32*shift-0.10*rural))
                insured=int(rng.random()<probability(-0.32+0.65*enrolled+0.00026*(income-1700)-0.50*rural))
                need=int(rng.random()<probability(-0.27+0.33*rural+0.37*shift))
                unmet=int(rng.random()<probability(0.23-0.72*insured-0.00046*(income-1600)+0.44*rural+0.47*shift)) if need else -1
                if need and rng.random()<0.045:
                    unmet=-1
                size=rng.randint(2,8)
                w=round(0.67+0.17*s+0.22*rural+0.04*(j%6),3)
                rows.append((hh,s,psu,domain,rural,score,priority,enrolled,insured,need,unmet,income,size,w))
    write(out,"welfare36","household stratum psu domain rural score priority transfer insurance need unmet welfare size weight",rows)


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--source",type=Path,default=ROOT/"source")
    ap.add_argument("--uci-archive",type=Path,help="Re-extract from the original UCI ZIP into the working source directory")
    args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if args.uci_archive:
        uci_extract(args.uci_archive,args.source)
    trial(args.output)
    retail(args.output,args.source)
    international(args.output,args.source)
    welfare(args.output)
