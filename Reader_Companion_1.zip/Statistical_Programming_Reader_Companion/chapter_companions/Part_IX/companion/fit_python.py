"""Independent reference estimates for the four Part IX projects."""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ledger import Ledger

CV = {9: 2.2621571628540993, 10: 2.2281388519649385,
      16: 2.1199052992210112, 23: 2.0686576104190406}


def trial(data, l):
    a,r,d=(data(k) for k in ("assignment33","roster33","draws33"))
    assert a.village.is_unique and r.household.is_unique and len(d)==499
    assert a.groupby("pair").offer.agg(["size","sum"]).eq([2,1]).all().all()
    x=r.merge(a,on="village",validate="many_to_one")
    assert len(x)==len(r) and ((x.followup>=0)==(x.observed==1)).all()
    assert not ((x.eligible==0)&(x.observed==1)).any()
    for arm,s in x.groupby("offer"):
        m=l.model("CH33",f"arm{arm}")
        m.scalars(screened=len(s),eligible=s.eligible.sum(),observed=s.observed.sum(),
                  missing=s.eligible.sum()-s.observed.sum(),
                  attrition=1-s.observed.sum()/s.eligible.sum())
        m.vector("reason",(1,2,3),((s.reason==k).sum() for k in (1,2,3)))
    rows=[]
    for village,s in x[x.eligible==1].groupby("village"):
        complete=s[s.observed==1]
        dy=(complete.followup-complete.baseline).mean()
        row=[village,s.pair.iat[0],s.offer.iat[0],len(s),len(complete),dy,s.baseline.mean(),
             (complete.followup.sum()-s.baseline.sum())/len(s),
             (complete.followup.sum()+100*(len(s)-len(complete))-s.baseline.sum())/len(s)]
        rows.append(row)
        l.model("CH33","village").vector("value",(f"{village}/{k}" for k in ("n","obs","change","baseline","lo","hi")),row[3:])
    v=pd.DataFrame(rows,columns="village pair offer n obs change baseline lo hi".split())
    v["miss"]=1-v.obs/v.n
    w=v.pivot(index="pair",columns="offer")
    delta=w.change[1]-w.change[0]
    m=l.model("CH33","trial")
    m.vector("pair",delta.index,delta)
    est=delta.mean()
    se=delta.std(ddof=1)/np.sqrt(len(delta))
    perm=d.iloc[:,1:].to_numpy()@delta.to_numpy()/len(delta)
    m.vector("permuted",d.draw,perm)
    shift=(w.miss[1]+w.miss[0]).mean()
    m.scalars(pairs=len(w),villages=len(v),estimate=est,se=se,df=len(w)-1,
              lo=est-CV[23]*se,hi=est+CV[23]*se,baseline_gap=(w.baseline[1]-w.baseline[0]).mean(),
              attrition_gap=(w.miss[1]-w.miss[0]).mean(),
              randomisation_p=(1+np.sum(np.abs(perm)>=abs(est)-1e-12))/(1+len(perm)),
              bound_lo=(w.lo[1]-w.hi[0]).mean(),bound_hi=(w.hi[1]-w.lo[0]).mean(),
              delta3_lo=est-3*shift,delta3_hi=est+3*shift,delta6_lo=est-6*shift,delta6_hi=est+6*shift,
              mde=(1.95996398454+0.841621233573)*8*np.sqrt(2*(1+19*0.1)/(24*20)))


def retail(data,l):
    x,r=(data(k) for k in ("retail34","returns34"))
    assert x.line.is_unique and r.line.is_unique
    sales=(x.cancel==0)&(x.units>0)&(x.pence>0)
    cancel=(x.cancel==1)&(x.units<0)&(x.pence>0)
    other=(x.cancel==0)&(x.units<0)&(x.pence>0)
    v=x[sales|cancel].copy()
    v["value"]=v.units*v.pence
    gross=v.loc[sales,"value"].sum()
    deduction=-v.loc[cancel,"value"].sum()
    m=l.model("CH34","revenue")
    totals=v.groupby("invoice").value.sum()
    double=v.invoice.map(totals).sum()
    m.scalars(lines=len(x),sales=sales.sum(),cancel=cancel.sum(),other=other.sum(),
              omitted=(~(sales|cancel)).sum(),anonymous=(sales&(x.customer==0)).sum(),
              invoices=len(totals),gross=gross,cancel_value=deduction,net=gross-deduction,
              repeated_total=double,overcount=double-(gross-deduction))
    m.vector("invoice",totals.index,totals)
    buy=x[sales]
    for product,g in buy.groupby("product"):
        y=g.groupby("week").units.sum().reindex(range(1,53),fill_value=0)
        l.model("CH34",f"product{product}").vector("demand",y.index,y)
        actual=y.loc[41:52].to_numpy()
        for method in ("naive","mean4"):
            p=np.array([y.loc[o] if method=="naive" else y.loc[o-3:o].mean() for o in range(40,52)])
            err=actual-p
            ledger=l.model("CH34",f"p{product}_{method}")
            ledger.vector("forecast",range(41,53),p)
            ledger.vector("error",range(41,53),err)
            ledger.scalars(n=12,mae=np.abs(err).mean(),rmse=np.sqrt(np.mean(err**2)),
                           cost=np.mean(2*np.maximum(err,0)+np.maximum(-err,0)),
                           shortage=np.maximum(err,0).sum(),changed_n=6,changed_mae=np.abs(err[:6]).mean())
    buyer=buy[buy.customer>0]
    for origin in (27,33,39,45,48):
        past=buyer[buyer.week.between(origin-11,origin)].groupby("customer").week.max()
        future=set(buyer.loc[buyer.week.between(origin+1,origin+4),"customer"])
        for k in (0,1):
            ids=past[(origin-past<=3)==bool(k)].index
            y=np.array([int(i in future) for i in ids])
            l.model("CH34","customer").vector("snapshot",(f"{origin}/{k}/{f}" for f in ("n","events","rate")),
                                              (len(ids),y.sum(),y.mean()))
    booked=r[r.status==1].set_index("line")
    returned=r[r.status==3]
    j=returned.join(booked[["pence","units"]],on="original",rsuffix="_orig",validate="many_to_one")
    assert (j.pence==j.pence_orig).all() and (j.units<0).all()
    qty=-j.groupby("original").units.sum()
    assert (qty<=booked.units.reindex(qty.index)).all()
    u=(booked.units*booked.pence).sum()
    w=-(returned.units*returned.pence).sum()
    void=r[r.status==2]
    l.model("CH34","linked").scalars(booked=u,returned=w,net=u-w,void=(void.units*void.pence).sum(),
                                     linked=len(j),valid_originals=j.original.nunique())


def regression(s,x,weights):
    countries=sorted(s.economy.unique())
    years=sorted(s.year.unique())
    y=s.life.to_numpy()
    a=np.column_stack([np.ones(len(s)),x,*[(s.economy==i).to_numpy() for i in countries[1:]],
                       *[(s.year==t).to_numpy() for t in years[1:]]])
    b,_,rank,_=np.linalg.lstsq(a*np.sqrt(weights)[:,None], y*np.sqrt(weights), rcond=None)
    n,k=a.shape
    assert rank==k
    e=y-a@b
    bread=np.linalg.inv(a.T@(a*weights[:,None]))
    scores=np.array([a[s.economy==i,:].T@(weights[s.economy==i]*e[s.economy==i]) for i in countries])
    g=len(countries)
    vc=(g/(g-1))*((n-1)/(n-k))*(bread@scores.T@scores@bread)
    return b[1],np.sqrt(vc[1,1]),g,n,k


def development(data,l):
    d,p,m=(data(k) for k in ("wdi35","pwt35","map35"))
    for f in (d,p):
        assert not f.duplicated(["economy","year"]).any()
    z=d.merge(m,on="economy",validate="many_to_one").merge(p,on=["economy","year"],how="left",
                  indicator=True,validate="one_to_one")
    z["good"]=(z.include==1)&z.life.notna()&(z.population>0)&(z.rgdpe>0)&(z["pop"]>0)
    z["pc"]=z.rgdpe/z["pop"]
    for i,s in z.groupby("economy"):
        ml=l.model("CH35",f"country{i}")
        ml.scalars(wdi=len(s),pwt=(s._merge=="both").sum(),good=s.good.sum(),
                   unmatched=(s._merge=="left_only").sum())
        for row in s.itertuples():
            if row.good:
                ml.add("income",row.year,row.pc)
                if row.year in (2000,2023):
                    for k,v in dict(life=row.life,u5=row.u5,gdp2015=row.gdp2015,productivity=row.rgdpo/row.emp).items():
                        if np.isfinite(v):
                            ml.add("endpoint",f"{row.year}/{k}",v)
    joined=z[z.good].copy()
    balanced=joined.groupby("economy").filter(lambda g:len(g)==24)
    for name,s,field,weight in (
        ("common",balanced,"pc",False),("weighted",balanced,"pc",True),
        ("expanded",joined,"pc",False),("national",balanced,"gdp2015",False)
    ):
        assert (s[field]>0).all()
        x=np.log(s[field].to_numpy())
        w=s.population.to_numpy()/1e6 if weight else np.ones(len(s))
        b,se,g,n,k=regression(s,x,w)
        l.model("CH35",name).scalars(estimate=b,se=se,n=n,countries=g,k=k,df=g-1,
                                     lo=b-CV[g-1]*se,hi=b+CV[g-1]*se)
    for year,s in balanced[balanced.year.isin([2000,2023])].groupby("year"):
        l.model("CH35","headline").vector("endpoint",
            (f"{year}/{k}" for k in ("countries","mean_life","weighted_life","mean_pc","weighted_pc")),
            (len(s),s.life.mean(),np.average(s.life,weights=s.population),s.pc.mean(),
             np.average(s.pc,weights=s.population)))


def group_se(u,f):
    v=0.0
    for _,s in f.assign(u=u).groupby("stratum"):
        k=s.groupby("psu").u.sum().to_numpy()
        v+=len(k)*k.var(ddof=1)
    return np.sqrt(v)


def domain(f,y,keep,l,name):
    weights=f.weight.to_numpy()*keep
    y=np.asarray(y)
    den=weights.sum()
    num=weights@y
    p=num/den
    se=group_se(weights*(y-p)/den,f)
    n=int(np.sum(keep))
    yes=int(np.sum(keep & (y==1)))
    support=f.loc[keep,"psu"].nunique()
    l.model("CH36",name).scalars(n=n,yes=yes,psus=support,den=den,num=num,estimate=p,se=se,df=16,
        lo=p-CV[16]*se,hi=p+CV[16]*se)
    if n<30 or min(yes,n-yes)<5:
        return 0
    return 1 if support<4 or 2*CV[16]*se>0.28 else 2


def concentration(y,income,w):
    z=pd.DataFrame(dict(y=y,income=income,w=w))
    z["wy"]=z.w*z.y
    q=z.groupby("income")[["w","wy"]].sum()
    rank=(q.w.cumsum()-q.w/2)/q.w.sum()
    return 2*(q.wy@(rank-0.5))/q.wy.sum(),q.wy.sum()/q.w.sum()


def social(data,l):
    f=data("welfare36")
    assert f.household.is_unique and ((f.unmet<0)|(f.need==1)).all()
    n=f.need==1
    obs=n&f.unmet.isin([0,1])
    y=f.unmet==1
    eligible=(f.score<=55)&(f.priority==1)
    covered=f.transfer==1
    l.model("CH36","flow").scalars(households=len(f),need=n.sum(),known=obs.sum(),
                                   missing=(n&~obs).sum(),eligible=eligible.sum(),covered=covered.sum())
    for name,y0,keep in (("coverage",covered,eligible),("exclusion",~covered,eligible),
                         ("inclusion",~eligible,covered),("unmet",y,obs),
                         ("unmet_rural",y,obs&(f.rural==1)),("unmet_urban",y,obs&(f.rural==0)),
                         ("insured",f.insurance==1,np.ones(len(f),dtype=bool))):
        domain(f,y0,keep,l,name)
    for d in range(1,5):
        model=f"domain{d}"
        status=domain(f,y,obs&(f.domain==d),l,model)
        l.model("CH36",model).scalars(status=status)
    h=f[obs].copy()
    a,mean=concentration(h.unmet,h.welfare,h.weight)
    estimates=[]
    for s,sub in f.groupby("stratum"):
        vals=[]
        for j in sorted(sub.psu.unique()):
            w=h.weight.to_numpy()*np.where(h.psu==j,0,np.where(h.stratum==s,1.25,1))
            v,m=concentration(h.unmet,h.welfare,w)
            vals.append(v)
            l.model("CH36","inequality").add("jackknife",j,v)
            l.model("CH36","inequality").add("bounded_jk",j,4*m*v)
        estimates.append(vals)
    se=np.sqrt(sum(4/5*np.sum((v-np.mean(v))**2) for v in np.array(estimates)))
    l.model("CH36","inequality").scalars(estimate=a,se=se,df=16,lo=a-CV[16]*se,hi=a+CV[16]*se,mean=mean,corrected=4*mean*a)
    for line in (2200,2600):
        for basis,wt in (("household",f.weight),("person",f.weight*f["size"])):
            l.model("CH36",f"{basis}{line}").scalars(head=np.average(f.welfare<line,weights=wt),
                      gap=np.average(np.maximum(1-f.welfare/line,0),weights=wt),den=wt.sum())


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data",type=Path)
    ap.add_argument("output",type=Path)
    args=ap.parse_args()
    def data(name):
        return pd.read_csv(args.data/(name+".csv"))
    ledger=Ledger()
    for fit in (trial,retail,development,social):
        fit(data,ledger)
    args.output.mkdir(parents=True,exist_ok=True)
    ledger.save(args.output/"metrics.csv")
    print("Python",np.__version__,pd.__version__,len(ledger.rows),"keyed values")
