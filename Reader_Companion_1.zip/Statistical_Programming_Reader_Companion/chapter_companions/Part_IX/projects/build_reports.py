"""Regenerate the five decision outputs and the approved synthetic domain CSV."""

import argparse
import csv
from pathlib import Path

from project_data import (COUNTRIES, METRICS, MODELS, PRODUCTS, RATE_LABELS, ROOT,
                          Results, decimal, gbp, interval, percent, table)


def evaluation(r):
    v = r.values(33, "trial")
    rows = []
    for arm, label in ((0, "Comparison"), (1, "Offer")):
        a = r.values(33, f"arm{arm}")
        rows.append((label, *[decimal(a[k], 0) for k in ("screened", "eligible", "observed", "missing")]))
    flow = table(("Assignment", "Screened", "Eligible", "Observed", "Missing"), rows, (1, 2, 3, 4))
    scenarios = table(("Sensitivity", "Range in score points"), [
        ("Three-point departures", interval(v["delta3_lo"], v["delta3_hi"])),
        ("Six-point departures", interval(v["delta6_lo"], v["delta6_hi"])),
        ("Zero-to-100 completion", interval(v["bound_lo"], v["bound_hi"])),
    ], (1,))
    return f"""# Evaluation note

**Decision for the fictional programme.** Continue measured implementation and improve follow-up before using a three-point gain as the basis for expansion. The matched-pair point estimate exceeds three, while its reference interval and the adverse six-point scenario include values below that threshold.

{flow}

Across 24 matched pairs the observed-case offer contrast is {decimal(v['estimate'])} points (SE {decimal(v['se'])}, 95% paired interval {interval(v['lo'], v['hi'])}). The fixed-observation sign diagnostic gives p = {v['randomisation_p']:.3f} with 499 archived draws. Its interpretation depends on exchangeability of the observed pattern under the null.

{scenarios}

The first two ranges change the missing groups' mean changes in opposite directions across arms. The third completes the realised cohort under the 0–100 outcome support. These ranges express assumptions about follow-up. They carry no separate sampling interval. Use the prespecified estimand, 12-month score and original village assignment when rerunning the analysis.

**Evidence.** See [pre-analysis plan](../design/ch33_pre_analysis_plan.md), [deviation ledger](../design/ch33_deviations.csv), and the companion comparisons. All household and assignment records are synthetic.
"""


def management(r):
    v = r.values(34, "revenue")
    linked = r.values(34, "linked")
    scores = []
    for number, label in enumerate(PRODUCTS, 1):
        for method, name in (("naive", "Previous week"), ("mean4", "Four-week mean")):
            p = r.values(34, f"p{number}_{method}")
            scores.append((label, name, *[decimal(p[k]) for k in ("mae", "rmse", "cost", "changed_mae")]))
    scores = table(("Product", "Rule", "MAE", "RMSE", "Mean loss", "Short MAE"), scores, (2, 3, 4, 5))
    cohorts = []
    for origin in (45, 48):
        rows = [r.get(34, "customer", f"{origin}/{k}/rate", "snapshot") for k in (1, 0)]
        cohorts.append((origin, *map(percent, rows)))
    cohort = table(("Test origin", "Recent", "Other eligible"), cohorts, (0, 1, 2))
    return f"""# Management decision memo

**Decision.** Use the four-week mean as the first ordering benchmark under the specified shortage and surplus costs. It has a lower common-window mean loss for each selected product. Review lead times, stockouts, pack sizes and realised costs before adopting an ordering policy.

The scoped extract has {v['lines']:,.0f} lines and {v['invoices']:,.0f} eligible invoices. Gross booked sales of {gbp(v['gross'])} less cancellation deductions of {gbp(v['cancel_value'])} give {gbp(v['net'])} net. Repeating each invoice's balance on every eligible line produces {gbp(v['repeated_total'])}, an overstatement of {gbp(v['overcount'])}. Reconcile the invoice balance and the line sum before publishing the dashboard. A separate synthetic ledger links booked sales of {gbp(linked['booked'])} to physical returns of {gbp(linked['returned'])}, yielding {gbp(linked['net'])} net under its own contract.

{scores}

Primary scores use weeks 41–52. Short MAE uses weeks 41–46. Ranking a shortened-window score against a full-window score changes the observations being scored.

{cohort}

The cohort comparison covers identified buyers of the three products. A label matures four weeks after its origin. The two test outcome windows share week 49. A contact decision would require a defined incremental benefit and cost, and evidence on response to contact.

**Evidence.** See the [metric dictionary](../design/ch34_metric_dictionary.csv), [timing and decision contract](../design/ch34_decision_contract.md), and the Chapter 34 ledgers. Retail data are adapted from [UCI Online Retail](https://doi.org/10.24432/C5BW33).
"""


def development(r):
    countries = []
    for number, (iso, name) in enumerate(COUNTRIES, 1):
        v = r.values(35, f"country{number}")
        countries.append((iso, name, *[decimal(v[k], 0) for k in ("wdi", "pwt", "unmatched", "good")]))
    coverage = table(("Code", "Economy", "WDI", "PWT matches", "Unmatched", "Usable"), countries, (2, 3, 4, 5))
    fits = []
    for key, name in MODELS.items():
        v = r.values(35, key)
        fits.append((name, f"{v['n']:.0f}", decimal(v["estimate"]), interval(v["lo"], v["hi"])))
    fits = table(("Specification", "Rows", "Slope", "95% interval"), fits, (1, 2, 3))
    gh = r.series(35, "country1", "endpoint")
    pwt = r.series(35, "country1", "income")
    return f"""# Ghana-centred comparative development note

Ghana's life expectancy rose from {decimal(gh['2000/life'])} to {decimal(gh['2023/life'])} years from 2000 to 2023. Under-five mortality fell from {decimal(gh['2000/u5'], 1)} to {decimal(gh['2023/u5'], 1)} per 1,000 live births. Expenditure-side chained PPP GDP per resident increased from {decimal(pwt['2000'], 0)} to {decimal(pwt['2023'], 0)} in 2021 US dollars. The WDI constant-2015-US-dollar income concept is retained separately.

{coverage}

The World aggregate is outside the economy estimand. South Sudan contributes 16 usable years and is outside the ten-economy balanced set. Timor-Leste remains visible in the unmatched ledger.

{fits}

Each estimate includes economy and year effects and uses economy-clustered reference inference. Slopes measure years per log income point. The estimated sign depends on weighting and coverage. All four intervals include zero. Use the Ghana endpoints as dated descriptions and the panel estimates as specification-sensitive associations.

**Evidence.** See the [country crosswalk](../design/ch35_crosswalk.csv), source fingerprints and independent fits. Sources are [World Development Indicators](https://databank.worldbank.org/source/world-development-indicators) and [Penn World Table 11.0](https://doi.org/10.34894/FABVLR).
"""


def social(r):
    f = r.values(36, "flow")
    idx = r.values(36, "inequality")
    rows = []
    for model, label in RATE_LABELS.items():
        v = r.values(36, model)
        rows.append((label, decimal(v["n"], 0), decimal(v["den"]), percent(v["estimate"]),
                     interval(v["lo"], v["hi"], pct=True)))
    rates = table(("Measure", "Records", "Weight", "Rate", "95% interval"), rows, (1, 2, 3, 4))
    welfare_rows = []
    for line in (2200, 2600):
        for unit in ("household", "person"):
            v = r.values(36, f"{unit}{line}")
            welfare_rows.append((f"GHS {line:,}", unit, percent(v["head"]), percent(v["gap"])))
    welfare = table(("Threshold", "Weighting", "Headcount", "Gap"), welfare_rows, (2, 3))
    public = table(("Domain", "Status", "Unmet care", "95% interval"), [
        (name, status, "—" if rate is None else percent(rate),
         "—" if rate is None else interval(lo, hi, pct=True))
        for name, status, rate, lo, hi in r.public_domains()
    ], (2, 3))
    technical = f"""# Household survey technical appendix

The teaching population contains {f['households']:.0f} households and four strata with five primary sampling units each. The transfer rule uses score at most 55 and a priority flag. An outcome is known for {f['known']:.0f} of {f['need']:.0f} households with recorded care need. The eight unresolved records remain in the flow ledger. The ratio denominator for unmet care uses households with known outcomes and reported need.

{rates}

Each linearised household score contributes to its PSU total. Keep zero-contribution sampled PSUs in the design. Use the with-replacement stratified variance approximation and 16 degrees of freedom. The welfare rank uses weighted tied midranks in the known-need domain. Each of 20 delete-PSU replicates scales the four remaining PSUs in the affected stratum by 5/4 and recomputes the ranks. Conventional concentration is {decimal(idx['estimate'], 4)} (95% reference interval {interval(idx['lo'], idx['hi'], digits=4)}). The Erreygers correction is {decimal(idx['corrected'], 4)}.

{welfare}

The fictional thresholds apply per person per month. The gap averages proportional shortfalls over the full selected population. Person weighting multiplies the household weight by household size.

Apply the [public projection rules](../design/ch36_release_rules.md) before export. A real rerun requires authorised access, definitions, linkage rules if applicable, and output review. Every household in this companion is synthetic.
"""
    brief = f"""# Policy brief

**Decision for the fictional programme.** Verify eligibility and payment records where coverage gaps are greatest. Investigate access barriers separately before allocating service capacity. The evidence describes the teaching survey.

Transfer coverage is {percent(r.get(36, 'coverage', 'estimate'))} among eligible households and exclusion is {percent(r.get(36, 'exclusion', 'estimate'))} on that same denominator. Among households with care need and known outcomes, unmet care is {percent(r.get(36, 'unmet', 'estimate'))}. Its concentration index is {decimal(idx['estimate'], 4)}, consistent with concentration among lower-welfare households.

{public}

Domain estimates appear only after both disclosure and precision gates. An insufficient-precision label can motivate a larger sample or a reviewed aggregation. The release file omits domain counts and weights. See the [technical appendix](ch36_technical_appendix.md) for the weighted definitions and [public domain projection](ch36_public_domains.csv) for machine-readable reporting.
"""
    return technical, brief


def publish(r, out):
    out.mkdir(parents=True, exist_ok=True)
    technical, brief = social(r)
    reports = {
        "ch33_evaluation_note.md": evaluation(r),
        "ch34_management_memo.md": management(r),
        "ch35_development_note.md": development(r),
        "ch36_technical_appendix.md": technical,
        "ch36_policy_brief.md": brief,
    }
    for name, body in reports.items():
        (out / name).write_text(body, encoding="utf-8")
    with (out / "ch36_public_domains.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(("domain", "status", "estimate", "lower_95", "upper_95"))
        for domain, status, estimate, lo, hi in r.public_domains():
            numeric = ["", "", ""] if estimate is None else [f"{v:.6f}" for v in (estimate, lo, hi)]
            writer.writerow((domain, status, *numeric))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metrics", type=Path, default=METRICS)
    parser.add_argument("--output", type=Path, default=ROOT / "projects/outputs")
    args = parser.parse_args()
    publish(Results(args.metrics), args.output)
