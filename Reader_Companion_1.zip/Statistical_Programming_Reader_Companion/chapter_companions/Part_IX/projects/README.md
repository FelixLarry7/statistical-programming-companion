# End-to-end research projects

| Chapter | Design record | Generated work |
| --- | --- | --- |
| 33 | [Protocol](design/ch33_pre_analysis_plan.md) and [deviations](design/ch33_deviations.csv) | [Evaluation note](outputs/ch33_evaluation_note.md) |
| 34 | [Metric dictionary](design/ch34_metric_dictionary.csv) and [decision contract](design/ch34_decision_contract.md) | [Management memo](outputs/ch34_management_memo.md) |
| 35 | [Country crosswalk](design/ch35_crosswalk.csv) and [model contract](design/ch35_model_contract.md) | [Development note](outputs/ch35_development_note.md) |
| 36 | [Disclosure and precision rules](design/ch36_release_rules.md) | [Technical appendix](outputs/ch36_technical_appendix.md), [policy brief](outputs/ch36_policy_brief.md) and [public domain CSV](outputs/ch36_public_domains.csv) |

Run `python projects/build_reports.py` from the package root. To use a new
verified ledger, pass `--metrics PATH` and `--output NEW_DIRECTORY`.
The public Chapter 36 CSV is generated from the same permitted fields used
for the chapter table and figure. The remaining companion evidence can be
inspected to reproduce the synthetic project.
