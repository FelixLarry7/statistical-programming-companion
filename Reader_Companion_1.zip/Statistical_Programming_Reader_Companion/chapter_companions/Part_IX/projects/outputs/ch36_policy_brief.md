# Policy brief

**Decision for the fictional programme.** Verify eligibility and payment records where coverage gaps are greatest. Investigate access barriers separately before allocating service capacity. The evidence describes the teaching survey.

Transfer coverage is 75.05% among eligible households and exclusion is 24.95% on that same denominator. Among households with care need and known outcomes, unmet care is 41.16%. Its concentration index is −0.1963, consistent with concentration among lower-welfare households.

| Domain | Status | Unmet care | 95% interval |
| :--- | :--- | ---: | ---: |
| Domain 1 | Released | 37.84% | 27.00–48.67% |
| Domain 2 | Released | 39.81% | 29.75–49.87% |
| Domain 3 | Insufficient precision | — | — |
| Domain 4 | Withheld | — | — |

Domain estimates appear only after both disclosure and precision gates. An insufficient-precision label can motivate a larger sample or a reviewed aggregation. The release file omits domain counts and weights. See the [technical appendix](ch36_technical_appendix.md) for the weighted definitions and [public domain projection](ch36_public_domains.csv) for machine-readable reporting.
