# Chapter 36 public release rules

These rules govern the synthetic reporting exercise. An authorised study must
obtain the applicable data-owner release rules and approvals.

1. Form the domain of households reporting care need with an observed care outcome.
2. Withhold a domain with fewer than 30 known records or fewer than five cases in either outcome category.
3. For domains passing the first rule, require at least four contributing PSUs and a full-precision interval width at most 0.28.
4. Apply Released, Insufficient precision or Withheld to each domain. For the latter two, leave the rate and interval fields empty.
5. Export only domain, status, estimate, lower_95 and upper_95. Omit all case counts, weighted totals and domain identifiers from source records.
6. Review the figure, its descriptions, table, brief and CSV together for indirect disclosure. Consult prior outputs and assess whether complementary suppression is needed for a real release.

The package contains a wholly synthetic analysis ledger for learning. A real
authorised run would retain row data, executable diagnostics and restricted
outputs inside the approved environment. DHS, LEAP and the CFSVA have
different populations and purposes. Joining them requires approved access,
validated common identifiers and linkage review.
