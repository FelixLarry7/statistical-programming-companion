# Chapter 33 pre-analysis plan

Teaching protocol for a synthetic paired-village cash-transfer evaluation.

| Component | Declared rule |
| --- | --- |
| Target population | Screen all 24 listed households per village. Twenty are eligible under the fixed pre-offer roster rule. |
| Assignment | Forty-eight villages in 24 matched pairs, one offered village per pair. Keep the original pair and assignment after offer delivery. |
| Outcome | Change from baseline to the 12-month score on a 0–100 scale. A follow-up value of −1 encodes unavailable. Eligibility is a separate field. |
| Observed-case estimand | Average offered-minus-comparison change across 24 equally weighted pairs. Each village mean uses its eligible households with a valid follow-up. |
| Full-cohort target | Same equal-pair contrast with the eligible household mean in each village. Report completion limits and explicit departures when follow-up is missing. |
| Power | Normal approximation, 5% two-sided size, 80% power, 20 households per village, SD eight and ICC 0.10. Omit matching gains in this planning calculation. |
| Primary uncertainty | Standard deviation of 24 pair contrasts divided by the square root of 24. Student critical value with 23 degrees of freedom. |
| Assignment diagnostic | Two-sided test with 499 frozen sign vectors, observed availability fixed, plus-one correction and a 1e−12 numerical comparison allowance. |
| Attrition | Count observed, unobserved and reason codes by original assignment. Evaluate adverse and favourable departures of three and six points in the missing-group changes. |
| Support | Use 0 and 100 for unavailable follow-up outcomes while retaining every observed baseline. Label the resulting cohort-completion limits. |
| Decision | Assess the three-point planning threshold against the estimate, the paired reference interval and the missingness ranges. Report the conclusion for the fictional programme. |

In a real study, timestamp eligibility, outcome definitions, assignment,
protocol versions, authorisation and deviations. Freeze source records and
check the policy question against the actual assignment and survey
procedures. The companion generator records its seeds, input identifiers
and frozen sign vectors.
