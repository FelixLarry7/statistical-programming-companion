"""Independent answers worked from the original inputs.

The answers describe a fixed teaching release. Changing an input requires
reviewing the reference ledger and revalidating its values.
"""

from math import sqrt


def reference():
    result = {}

    def add(chapter, metric, entries):
        for key, value in entries.items():
            identity = (chapter, metric, key)
            if identity in result:
                raise ValueError(f'Repeated reference identity {identity}')
            result[identity] = value

    c = 'CH05'
    for key, day, label, value in (
        ('00123', 20241231, 'Field', 123450), ('123', 20250101, 'Office', 425),
        ('00401', 20250228, 'Office', None), ('00402', 20240229, 'Field', 0),
        ('00007', 20250301, 'Field', 9995), ('00008', 20250331, 'Office', 810),
    ):
        add(c, 'date', {key: day})
        add(c, 'label', {key + '/' + label: 1})
        add(c, 'state', {key + ('/unavailable' if value is None else '/observed'): 1})
        if value is not None:
            add(c, 'value_minor', {key: value})
    add(c, 'count', {'integer_ids': 5, 'text_ids': 6, 'missing': 1})
    add(c, 'total', {'observed_minor': 134680})

    c = 'CH06'
    for key, net, rate in (
        ('I01', 25000, 1250), ('I02', 6487, 1300), ('I03', -6487, 1300),
        ('I07', 450000, 100), ('I08', 0, 100), ('I09', 1238, 1250), ('I10', -1238, 1250),
    ):
        add(c, 'invoice_state', {key + '/retained': 1})
        add(c, 'net_minor', {key: net})
        add(c, 'rate', {key: rate})
        add(c, 'high_flag', {key: int(key == 'I07')})
    add(c, 'invoice_state', {'I04/cancelled': 1, 'I05/missing_price': 1, 'I06/missing_rate': 1})
    add(c, 'count', {'source': 10, 'retained': 7, 'currency_join_rows': 17, 'train': 3})
    add(c, 'total', {'posted_minor': 482725, 'returned_minor': -7725, 'net_minor': 475000})
    add(c, 'scale', {'train_mean': 20, 'train_sd': sqrt(200/3), 'full_mean': 40, 'full_sd': sqrt(1000)})
    add(c, 'z_train', {'F04': sqrt(6), 'F05': 4*sqrt(6)})
    add(c, 'z_full', {'F04': 0, 'F05': 60/sqrt(1000)})

    c = 'CH07'
    add(c, 'count', {'headers': 8, 'lines': 13, 'orphan_lines': 1, 'raw_join_rows': 23,
                     'unmatched_headers': 1, 'retained': 7})
    add(c, 'total', {'headers_minor': 860, 'matched_lines_minor': 860, 'raw_join_minor': 1470,
                     'unmatched_minor': 200, 'retained_minor': 660})
    add(c, 'customer_version', {'C01': 3, 'C02': 1, 'C03': 1, 'C04': 1})
    for key, net, zone, row, peer in (
        ('T01', 130, 'Coastal', 130, 200), ('T02', 70, 'Coastal', 200, 200),
        ('T03', 80, 'Inland', 80, 80), ('T04', 120, 'Coastal', 320, 320),
        ('T05', 60, 'Coastal', 60, 60), ('T06', 90, 'Inland', 170, 170),
        ('T07', 110, 'Coastal', 170, 170),
    ):
        add(c, 'invoice_minor', {key: net})
        add(c, 'region', {key + '/' + zone: 1})
        add(c, 'rows_running', {key: row})
        add(c, 'peer_running', {key: peer})
    for key, n, value in (
        ('2025-01/Coastal', 2, 200), ('2025-01/Inland', 1, 80), ('2025-02/Coastal', 2, 180),
        ('2025-03/Coastal', 1, 110), ('2025-03/Inland', 1, 90),
    ):
        add(c, 'period_n', {key: n})
        add(c, 'period_minor', {key: value})
    add(c, 'cohort_active', {'2025-01/2025-01': 2, '2025-01/2025-02': 1, '2025-01/2025-03': 1,
                             '2025-02/2025-02': 1, '2025-02/2025-03': 1})

    c = 'CH08'
    add(c, 'count', {'households': 6, 'eligible_households': 5, 'members': 13,
                     'eligible_members': 11, 'known_ages': 10, 'known_children': 5,
                     'plots': 7, 'retained_plots': 5, 'person_plot_join_rows': 12})
    add(c, 'defect', dict.fromkeys(('duplicate_excess', 'duplicate_gate_rejects',
                                  'orphan_members', 'orphan_gate_rejects'), 1))
    add(c, 'member_state', dict.fromkeys((
        'H01/M01/known', 'H01/M02/known', 'H01/M03/known', 'H02/M01/known',
        'H02/M02/unknown_age', 'H03/M01/known', 'H03/M02/known', 'H04/M01/out_scope',
        'H05/M01/known', 'H05/M02/known', 'H05/M03/known', 'H06/M01/invalid_age', 'H06/M02/known'
    ), 1))
    add(c, 'plot_state', dict.fromkeys(('A01/retained', 'A02/retained', 'A03/retained', 'A04/invalid_area',
                                      'A05/out_scope', 'A06/retained', 'A07/retained'), 1))
    add(c, 'total', {'plot_area_m2': 21000})
    add(c, 'weight10', {'known': 205, 'children': 110, 'eligible': 220,
                        'join_known': 245, 'join_children': 140})
    add(c, 'share', {'known_age': 110/205, 'unknown_as_adult': 110/220})
    return result
