# Base R calculations for the four Part II cases.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
options(digits = 17, OutDec = ".")
load_csv <- function(name) {
  read.csv(file.path(args[1], paste0(name, ".csv")), colClasses = "character",
           na.strings = "", check.names = FALSE)
}
iso <- function(token) {
  day <- as.Date(token, format = "%Y-%m-%d")
  stopifnot(!anyNA(day), all(format(day, "%Y-%m-%d") == token))
  day
}
unique_key <- function(frame, fields) {
  stopifnot(!anyNA(frame[fields]), !anyDuplicated(frame[fields]))
}
output <- list()
emit <- function(metric, key, value) {
  stopifnot(length(key) == length(value), all(is.finite(value)))
  output[[length(output) + 1L]] <<- data.frame(chapter, metric, key, value)
}
state_key <- function(x, y) paste(x, y, sep = "/")

chapter <- "CH05"
d <- load_csv("ch05_import")
unique_key(d, "record_id")
stopifnot(all(grepl("^[0-9]{1,5}$", d$record_id)), all(d$category %in% c("A", "B")))
absent <- d$value_token == ".."
stopifnot(all(grepl("^([0-9]{1,3}([.][0-9]{3})+|[0-9]+),[0-9]{2}$", d$value_token[!absent])))
value <- as.numeric(gsub("[.,]", "", d$value_token[!absent]))
emit("date", d$record_id, as.numeric(format(iso(d$observed_on), "%Y%m%d")))
emit("label", state_key(d$record_id, c(A = "Field", B = "Office")[d$category]), rep(1, nrow(d)))
emit("state", state_key(d$record_id, ifelse(absent, "unavailable", "observed")), rep(1, nrow(d)))
emit("value_minor", d$record_id[!absent], value)
emit("count", c("integer_ids", "text_ids", "missing"),
     c(length(unique(as.numeric(d$record_id))), nrow(d), sum(absent)))
emit("total", "observed_minor", sum(value))

chapter <- "CH06"
d <- load_csv("ch06_invoices")
fx <- load_csv("ch06_fx")
unique_key(d, "invoice_id")
unique_key(fx, c("currency", "effective_date"))
invoice_day <- iso(d$invoice_date)
fx_day <- iso(fx$effective_date)
fx_value <- as.numeric(fx$fx_pp100)
stopifnot(all(fx_value > 0 & fx_value == floor(fx_value)))
candidate <- lapply(d$currency, function(code) which(fx$currency == code))
emit("count", "currency_join_rows", sum(vapply(candidate, function(i) max(1L, length(i)), integer(1))))
rate <- vapply(seq_len(nrow(d)), function(i) {
  idx <- candidate[[i]]
  before <- idx[fx_day[idx] <= invoice_day[i]]
  if (!length(before)) return(NA_real_)
  fx_value[before[which.max(fx_day[before])]]
}, numeric(1))
price <- as.numeric(d$price_minor)
qty <- as.numeric(d$quantity)
stopifnot(all(qty > 0 & qty == floor(qty)), all(is.na(price) | (price >= 0 & price == floor(price))))
stopifnot(all(d$state %in% c("posted", "returned", "cancelled")))
state <- ifelse(d$state == "cancelled", "cancelled",
                ifelse(is.na(price), "missing_price", ifelse(is.na(rate), "missing_rate", "retained")))
ok <- state == "retained"
numer <- qty[ok] * price[ok] * rate[ok] * ifelse(d$state[ok] == "returned", -1, 1)
stopifnot(all(abs(numer) < 2^53 - 50))
net <- sign(numer) * floor((abs(numer) + 50)/100)
emit("invoice_state", state_key(d$invoice_id, state), rep(1, nrow(d)))
emit("net_minor", d$invoice_id[ok], net)
emit("rate", d$invoice_id[ok], rate[ok])
emit("high_flag", d$invoice_id[ok], as.integer(abs(net) > 100000))
emit("count", c("source", "retained"), c(nrow(d), sum(ok)))
emit("total", c("posted_minor", "returned_minor", "net_minor"),
     c(sum(net[d$state[ok] == "posted"]), sum(net[d$state[ok] == "returned"]), sum(net)))

f <- load_csv("ch06_features")
unique_key(f, "record_id")
train <- f$partition == "train"
stopifnot(all(f$partition %in% c("train", "holdout")),
          max(iso(f$observed_on[train])) < min(iso(f$observed_on[!train])))
x <- as.numeric(f$input_value)
emit("count", "train", sum(train))
for (part in c("train", "full")) {
  z <- if (part == "train") x[train] else x
  mu <- mean(z)
  sigma <- sqrt(mean((z - mu)^2))
  stopifnot(is.finite(sigma), sigma > 0)
  emit("scale", paste(part, c("mean", "sd"), sep = "_"), c(mu, sigma))
  emit(paste0("z_", part), f$record_id[!train], (x[!train] - mu)/sigma)
}

chapter <- "CH07"
history <- load_csv("ch07_customers")
d <- load_csv("ch07_invoices")
lines <- load_csv("ch07_lines")
unique_key(history, c("customer_id", "effective_date", "version"))
unique_key(d, "invoice_id")
unique_key(lines, c("invoice_id", "line_id"))
history$day <- iso(history$effective_date)
history$version <- as.numeric(history$version)
asof <- history[history$day <= as.Date("2025-03-31"), ]
asof <- asof[order(asof$customer_id, -as.numeric(asof$day), -asof$version), ]
asof <- asof[!duplicated(asof$customer_id), ]
emit("customer_version", asof$customer_id, asof$version)

d$total_minor <- as.numeric(d$total_minor)
lines$amount_minor <- as.numeric(lines$amount_minor)
detail_key <- match(lines$invoice_id, d$invoice_id)
line_ok <- !is.na(detail_key)
matches <- merge(data.frame(customer_id = d$customer_id[detail_key[line_ok]],
                            amount_minor = lines$amount_minor[line_ok]), history, by = "customer_id")
detail <- tapply(lines$amount_minor[line_ok], lines$invoice_id[line_ok], sum)
stopifnot(all(d$total_minor == detail[d$invoice_id]), length(detail) == nrow(d))
dim_key <- match(d$customer_id, asof$customer_id)
good <- !is.na(dim_key)
emit("count", c("headers", "lines", "orphan_lines", "raw_join_rows", "unmatched_headers", "retained"),
     c(nrow(d), nrow(lines), sum(!line_ok), nrow(matches), sum(!good), sum(good)))
emit("total", c("headers_minor", "matched_lines_minor", "raw_join_minor", "unmatched_minor", "retained_minor"),
     c(sum(d$total_minor), sum(detail), sum(matches$amount_minor),
       sum(d$total_minor[!good]), sum(d$total_minor[good])))
d$region <- asof$region[dim_key]
d <- d[good, ]
d$day <- iso(d$invoice_date)
d <- d[order(d$customer_id, d$day, d$invoice_id), ]
d$period <- substr(d$invoice_date, 1, 7)
emit("invoice_minor", d$invoice_id, d$total_minor)
emit("region", state_key(d$invoice_id, d$region), rep(1, nrow(d)))
emit("rows_running", d$invoice_id, ave(d$total_minor, d$customer_id, FUN = cumsum))
peer <- vapply(seq_len(nrow(d)), function(i) sum(d$total_minor[d$customer_id == d$customer_id[i] &
                                                                  d$day <= d$day[i]]), numeric(1))
emit("peer_running", d$invoice_id, peer)
cell <- state_key(d$period, d$region)
counts <- table(cell)
amounts <- tapply(d$total_minor, cell, sum)
emit("period_n", names(counts), as.numeric(counts))
emit("period_minor", names(amounts), as.numeric(amounts))
d$cohort <- ave(d$period, d$customer_id, FUN = function(values) rep(min(values), length(values)))
active <- unique(d[c("cohort", "period", "customer_id")])
cohorts <- table(state_key(active$cohort, active$period))
emit("cohort_active", names(cohorts), as.numeric(cohorts))

chapter <- "CH08"
hh <- load_csv("ch08_households")
people <- load_csv("ch08_members")
plots <- load_csv("ch08_plots")
unique_key(hh, "hh_id")
unique_key(people, c("hh_id", "member_id"))
unique_key(plots, "plot_id")
stopifnot(all(hh$stratum %in% c("A", "B")), all(hh$eligible %in% c("0", "1")))
hh$weight10 <- as.numeric(hh$weight10)
stopifnot(all(hh$weight10 > 0 & hh$weight10 == floor(hh$weight10)))
bad <- load_csv("ch08_households_defect")
dup <- sum(duplicated(bad$hh_id))
orphan <- sum(!load_csv("ch08_members_defect")$hh_id %in% hh$hh_id)
emit("defect", c("duplicate_excess", "duplicate_gate_rejects", "orphan_members", "orphan_gate_rejects"),
     c(dup, dup > 0, orphan, orphan > 0))

person_hh <- match(people$hh_id, hh$hh_id)
plot_hh <- match(plots$hh_id, hh$hh_id)
stopifnot(!anyNA(person_hh), !anyNA(plot_hh), all(plots$crop %in% c("maize", "rice")))
age <- as.numeric(people$age)
valid_age <- !is.na(age) & age >= 0 & age <= 110 & age == floor(age)
state <- ifelse(hh$eligible[person_hh] == "0", "out_scope",
                ifelse(!is.na(age) & age == -99, "unknown_age",
                       ifelse(valid_age, "known", "invalid_age")))
people$w <- hh$weight10[person_hh]
people$known <- state == "known"
people$child <- people$known & age < 18
people$child[is.na(people$child)] <- FALSE
kept <- state %in% c("known", "unknown_age")
known_w <- sum(people$w[people$known])
child_w <- sum(people$w[people$child])
total_w <- sum(people$w[kept])
emit("member_state", paste(people$hh_id, people$member_id, state, sep = "/"), rep(1, nrow(people)))
emit("count", c("households", "eligible_households", "members", "eligible_members", "known_ages", "known_children"),
     c(nrow(hh), sum(hh$eligible == "1"), nrow(people), sum(kept), sum(people$known), sum(people$child)))
emit("weight10", c("known", "children", "eligible"), c(known_w, child_w, total_w))
emit("share", c("known_age", "unknown_as_adult"), c(child_w/known_w, child_w/total_w))

area <- as.numeric(plots$area_m2)
state <- ifelse(hh$eligible[plot_hh] == "0", "out_scope",
                ifelse(!is.na(area) & area > 0 & area == floor(area), "retained", "invalid_area"))
good <- state == "retained"
emit("plot_state", state_key(plots$plot_id, state), rep(1, nrow(plots)))
emit("count", c("plots", "retained_plots"), c(nrow(plots), sum(good)))
emit("total", "plot_area_m2", sum(area[good]))
joined <- merge(people[kept, ], plots[good, ], by = "hh_id")
emit("count", "person_plot_join_rows", nrow(joined))
emit("weight10", c("join_known", "join_children"), c(sum(joined$w[joined$known]), sum(joined$w[joined$child])))

observed <- do.call(rbind, output)
observed <- observed[order(observed$chapter, observed$metric, observed$key), ]
stopifnot(!anyDuplicated(observed[c("chapter", "metric", "key")]))
write.table(observed, args[2], sep = ",", quote = FALSE, row.names = FALSE, na = "")
cat(R.version.string, "\n", sep = "")
