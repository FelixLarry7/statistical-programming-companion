*! Run the Part II computational labs offline and package the observed results.
version 16.0
args folder
local starting `"`c(pwd)'"'
if `"`folder'"' != "" {
    cd `"`folder'"'
}
local root `"`c(pwd)'"'
capture confirm file "inputs/ch05_import.csv"
if _rc {
    display as error "Set the working directory to the extracted kit, then run do run_part2.do."
    quietly cd `"`starting'"'
    exit 601
}
local stamp = subinstr(subinstr("`c(current_date)'_`c(current_time)'", " ", "", .), ":", "", .)
local evidence `"`root'/stata_part2_`stamp'"'
mkdir `"`evidence'"'
cd `"`evidence'"'
mkdir "inputs"
local inputs : dir `"`root'/inputs"' files "*.csv"
foreach name of local inputs {
    copy `"`root'/inputs/`name'"' `"inputs/`name'"'
    copy `"inputs/`name'"' `"input_`name'"'
}
copy `"`root'/part2_driver.do"' "part2_driver.do"

tempname work record sessionlog
frame create `work'
local dp "`c(dp)'"
set dp period
log using "part2_run.log", text name(`sessionlog')
capture noisily frame `work': do "part2_driver.do" "inputs" "part2_metrics.csv"
local rc = _rc
log close `sessionlog'
frame drop `work'
capture quietly set dp `dp'
capture confirm file "part2_metrics.csv"
if _rc & `rc' == 0 {
    local rc = 601
}

file open `record' using "run_info.txt", write text
file write `record' "stata_version=`c(stata_version)'" _n ///
    "edition=`c(flavor)'" _n "build_date=`c(born_date)'" _n "platform=`c(os)'" _n ///
    "run_date=`c(current_date)'" _n "run_time=`c(current_time)'" _n "part2_rc=`rc'" _n
file close `record'

local files : dir "." files "*"
local result `"`root'/Stata_Verification_Part_II_`stamp'.zip"'
capture noisily zipfile `files', saving(`"`result'"')
local zipped = (_rc == 0)
cd `"`starting'"'
display as result "Part II return code `rc'."
if `zipped' {
    display as result `"Upload this evidence ZIP: `result'"'
}
else {
    display as result `"Compress this evidence folder and upload it: `evidence'"'
}
