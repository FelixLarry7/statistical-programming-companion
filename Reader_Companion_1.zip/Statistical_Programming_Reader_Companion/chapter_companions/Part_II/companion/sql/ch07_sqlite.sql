-- Input dates are ISO 8601 text and amounts are integer minor units.
CREATE TEMP VIEW ch07_selected_customer AS
WITH ranked AS (
    SELECT customer_id, version, region,
           row_number() OVER (
               PARTITION BY customer_id ORDER BY effective_date DESC, version DESC
           ) AS sequence
    FROM customers
    WHERE effective_date <= '2025-03-31'
)
SELECT customer_id, version, region FROM ranked WHERE sequence = 1;

CREATE TEMP VIEW ch07_invoice_report AS
SELECT i.invoice_id, i.customer_id, i.invoice_date AS invoice_day,
       i.total_minor, d.region, substr(i.invoice_date, 1, 7) AS period,
       sum(i.total_minor) OVER (
           PARTITION BY i.customer_id ORDER BY i.invoice_date, i.invoice_id
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS rows_running,
       sum(i.total_minor) OVER (
           PARTITION BY i.customer_id ORDER BY i.invoice_date
           RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS peer_running,
       substr(min(i.invoice_date) OVER (PARTITION BY i.customer_id), 1, 7) AS cohort
FROM invoices i JOIN ch07_selected_customer d USING (customer_id);

CREATE TEMP VIEW ch07_orphan_line AS
SELECT invoice_id, line_id, amount_minor FROM lines l
WHERE NOT EXISTS (SELECT 1 FROM invoices i WHERE i.invoice_id = l.invoice_id);

CREATE TEMP VIEW ch07_inconsistent_header AS
SELECT i.invoice_id FROM invoices i
LEFT JOIN (
    SELECT invoice_id, SUM(amount_minor) AS detail_total
    FROM lines GROUP BY invoice_id
) d USING (invoice_id)
WHERE d.detail_total IS NULL OR d.detail_total <> i.total_minor;
