SELECT CASE WHEN count(*) = count(DISTINCT (customer_id, effective_date, version))
    THEN 'ok' ELSE error('Duplicate customer version key') END FROM ch07_customers;
SELECT CASE WHEN count(*) = count(DISTINCT invoice_id)
    THEN 'ok' ELSE error('Duplicate invoice key') END FROM ch07_invoices;
SELECT CASE WHEN count(*) = count(DISTINCT (invoice_id, line_id))
    THEN 'ok' ELSE error('Duplicate detail key') END FROM ch07_lines;

CREATE TEMP VIEW history07 AS
SELECT customer_id, CAST(effective_date AS DATE) AS effective_day,
       CAST(version AS INTEGER) AS version, region
FROM ch07_customers;
CREATE TEMP TABLE selected07 AS
WITH ranked AS (
    SELECT *, row_number() OVER (
      PARTITION BY customer_id ORDER BY effective_day DESC, version DESC
    ) AS seq
    FROM history07 WHERE effective_day <= DATE '2025-03-31'
)
SELECT customer_id, version, region FROM ranked WHERE seq = 1;

CREATE TEMP VIEW headers07 AS
SELECT invoice_id, customer_id, CAST(invoice_date AS DATE) AS invoice_day,
       CAST(total_minor AS BIGINT) AS total_minor
FROM ch07_invoices;
CREATE TEMP VIEW lines07 AS
SELECT invoice_id, line_id, CAST(amount_minor AS BIGINT) AS amount_minor FROM ch07_lines;
CREATE TEMP TABLE detail07 AS
SELECT l.invoice_id, sum(l.amount_minor) AS detail_total
FROM lines07 l JOIN headers07 h ON l.invoice_id = h.invoice_id
GROUP BY l.invoice_id;

SELECT CASE WHEN count(*) = count(detail_total) AND bool_and(detail_total = total_minor)
    THEN 'ok' ELSE error('Invoice lines do not reconcile to headers') END
FROM headers07 LEFT JOIN detail07 USING (invoice_id);

CREATE TEMP TABLE joined07 AS
SELECT h.*, d.version, d.region
FROM headers07 h LEFT JOIN selected07 d ON h.customer_id = d.customer_id;

CREATE TEMP TABLE ledger07 AS
SELECT invoice_id, customer_id, invoice_day, total_minor, region,
       strftime(invoice_day, '%Y-%m') AS period,
       sum(total_minor) OVER (
           PARTITION BY customer_id ORDER BY invoice_day, invoice_id
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS rows_running,
       sum(total_minor) OVER (
           PARTITION BY customer_id ORDER BY invoice_day
           RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS peer_running,
       strftime(min(invoice_day) OVER (PARTITION BY customer_id), '%Y-%m') AS cohort
FROM joined07 WHERE region IS NOT NULL;

CREATE TEMP VIEW multiplied07 AS
SELECT l.amount_minor FROM lines07 l
JOIN headers07 h ON l.invoice_id = h.invoice_id
JOIN history07 d ON h.customer_id = d.customer_id;

INSERT INTO part2_metrics
SELECT 'CH07', 'count', 'headers', count(*) FROM headers07
UNION ALL SELECT 'CH07', 'count', 'lines', count(*) FROM lines07
UNION ALL SELECT 'CH07', 'count', 'orphan_lines', count(*) FROM lines07 l
    WHERE NOT EXISTS (SELECT 1 FROM headers07 h WHERE h.invoice_id = l.invoice_id)
UNION ALL SELECT 'CH07', 'count', 'raw_join_rows', count(*) FROM multiplied07
UNION ALL SELECT 'CH07', 'total', 'raw_join_minor', sum(amount_minor) FROM multiplied07
UNION ALL SELECT 'CH07', 'count', 'unmatched_headers', count(*) FROM joined07 WHERE region IS NULL
UNION ALL SELECT 'CH07', 'count', 'retained', count(*) FROM ledger07
UNION ALL SELECT 'CH07', 'total', 'headers_minor', sum(total_minor) FROM headers07
UNION ALL SELECT 'CH07', 'total', 'matched_lines_minor', sum(detail_total) FROM detail07
UNION ALL SELECT 'CH07', 'total', 'unmatched_minor', sum(total_minor) FROM joined07 WHERE region IS NULL
UNION ALL SELECT 'CH07', 'total', 'retained_minor', sum(total_minor) FROM ledger07
UNION ALL SELECT 'CH07', 'customer_version', customer_id, version FROM selected07
UNION ALL SELECT 'CH07', 'invoice_minor', invoice_id, total_minor FROM ledger07
UNION ALL SELECT 'CH07', 'region', invoice_id || '/' || region, 1 FROM ledger07
UNION ALL SELECT 'CH07', 'rows_running', invoice_id, rows_running FROM ledger07
UNION ALL SELECT 'CH07', 'peer_running', invoice_id, peer_running FROM ledger07
UNION ALL SELECT 'CH07', 'period_minor', period || '/' || region, sum(total_minor)
    FROM ledger07 GROUP BY period, region
UNION ALL SELECT 'CH07', 'period_n', period || '/' || region, count(*)
    FROM ledger07 GROUP BY period, region
UNION ALL SELECT 'CH07', 'cohort_active', cohort || '/' || period, count(DISTINCT customer_id)
    FROM ledger07 GROUP BY cohort, period;
