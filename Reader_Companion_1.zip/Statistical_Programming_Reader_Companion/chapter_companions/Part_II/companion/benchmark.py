"""Compare equivalent invoice-detail summaries on the same expanded fixture."""

from hashlib import sha256
from statistics import median
from time import perf_counter_ns


QUERIES = {
    'grouped': """
      SELECT replicate, invoice_id, sum(amount_minor) AS total_minor
      FROM benchmark_lines
      GROUP BY replicate, invoice_id
      ORDER BY replicate, invoice_id
    """,
    'window_distinct': """
      SELECT DISTINCT replicate, invoice_id,
          sum(amount_minor) OVER (PARTITION BY replicate, invoice_id) AS total_minor
      FROM benchmark_lines
      ORDER BY replicate, invoice_id
    """,
}


def benchmark(db, out, copies=10000, repetitions=5):
    if copies < 1 or repetitions < 1:
        raise ValueError('Copies and repetitions must be positive.')
    db.execute("""
       CREATE TEMP TABLE benchmark_lines AS
       SELECT replicate, invoice_id, line_id, amount_minor
       FROM lines07 CROSS JOIN range(?) AS repeats(replicate)
    """, [copies])
    inputs = db.execute('select count(*) from benchmark_lines').fetchone()[0]
    input_rows = db.execute('select * from benchmark_lines order by replicate, invoice_id, line_id').fetchall()
    input_hash = sha256(repr(input_rows).encode('utf-8')).hexdigest()
    expected = db.execute(QUERIES['grouped']).fetchall()
    assert db.execute(QUERIES['window_distinct']).fetchall() == expected
    times = {name: [] for name in QUERIES}
    for rep in range(repetitions):
        order = tuple(QUERIES) if rep % 2 == 0 else tuple(reversed(QUERIES))
        for name in order:
            start = perf_counter_ns()
            result = db.execute(QUERIES[name]).fetchall()
            elapsed = (perf_counter_ns() - start)/1e6
            if result != expected:
                raise ValueError(f'Timing comparison changed the output for {name}.')
            times[name].append(elapsed)
    plans = {}
    for name, query in QUERIES.items():
        plan = db.execute('EXPLAIN ANALYZE ' + query).fetchall()
        plans[name] = '\n'.join(str(x[1]) for x in plan)
        (out / f'ch07_{name}_plan.txt').write_text(plans[name], encoding='utf-8')
    return {
        'input_rows': inputs, 'output_rows': len(expected), 'input_sha256': input_hash,
        'input_digest_representation': 'Python repr of the ordered typed input tuples, UTF-8',
        'result_sha256': sha256(repr(expected).encode('utf-8')).hexdigest(),
        'repetitions': repetitions, 'copies': copies,
        'timer_scope': 'Elapsed milliseconds including the ordered query and fetchall. Inputs preloaded.',
        'median_ms': {name: median(values) for name, values in times.items()},
        'times_ms': times, 'duckdb_threads': 1,
        'plan_operators': {name: [op for op in ('HASH_GROUP_BY', 'WINDOW', 'ORDER_BY') if op in plan]
                           for name, plan in plans.items()},
    }
