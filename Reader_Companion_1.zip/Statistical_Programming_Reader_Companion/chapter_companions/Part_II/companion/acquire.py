"""Replay the frozen indicator pages or acquire a separate public World Bank example."""

import argparse
import csv
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
from urllib.parse import urlencode
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'data/raw'
FIELDS = ('record_id', 'observed_on', 'category', 'value_token')
WORLD_BANK = 'https://api.worldbank.org/v2/country/GHA/indicator/SP.POP.TOTL'
SERVICE = 'https://indicator.example/v1/observations'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def json_file(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def replay(pages):
    if len(pages) != 2:
        raise ValueError('Expected the two frozen pages.')
    rows, sources = [], []
    expected = {'pages': 2, 'per_page': 3, 'total': 6,
                'dataset': 'SERVICE-INDEX', 'snapshot': '2025Q1.1'}
    for number, path in enumerate(pages, 1):
        header, body = json.loads(path.read_bytes().decode('utf-8'))
        if header.get('page') != number or any(header.get(k) != v for k, v in expected.items()):
            raise ValueError(f'Pagination or snapshot mismatch at page {number}.')
        if len(body) != 3 or header.get('content_type') != 'application/json; charset=utf-8':
            raise ValueError(f'Unexpected response body or content type on page {number}.')
        if any(set(row) != set(FIELDS) or any(type(row[f]) is not str for f in FIELDS) for row in body):
            raise ValueError(f'Unexpected record schema on page {number}.')
        rows.extend(body)
        query = urlencode({'dataset': 'SERVICE-INDEX', 'snapshot': '2025Q1.1',
                           'per_page': 3, 'page': number})
        sources.append({'page': number, 'path': path.name, 'request': SERVICE + '?' + query,
                        'sha256': digest(path), 'media_type': header['content_type']})
    keys = [row['record_id'] for row in rows]
    if len(keys) != expected['total'] or len(set(keys)) != len(keys):
        raise ValueError('The returned count or the distinct key count differs from the manifest.')
    return rows, {'source': 'Original synthetic service responses', 'mode': 'offline replay',
                  'capture_time': None, 'release': expected['snapshot'], 'pages': sources}


def prepare(out):
    # The exchange directory is disposable. The raw files are retained byte for byte.
    paths = sorted(RAW.glob('ch05_page_*.json'))
    rows, record = replay(paths)
    out.mkdir(parents=True, exist_ok=False)
    with (out / 'ch05_import.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, FIELDS, lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
    for path in sorted(RAW.glob('*.csv')):
        shutil.copyfile(path, out / path.name)
    record['input_sha256'] = {path.name: digest(path) for path in sorted(out.glob('*.csv'))}
    return record


def fetch_wdi(out):
    """Retain response bytes for a user-initiated Ghana WDI acquisition."""
    out.mkdir(parents=True, exist_ok=False)
    responses, rows = [], []
    update = None
    for page in (1, 2):
        params = {'date': '2021:2023', 'source': 2, 'format': 'json', 'per_page': 2, 'page': page}
        request = WORLD_BANK + '?' + urlencode(params)
        with urlopen(request, timeout=25) as stream:
            payload = stream.read(1_000_001)
            if len(payload) > 1_000_000:
                raise ValueError('The response exceeds the byte bound for the example.')
            path = out / f'page_{page}.json'
            path.write_bytes(payload)
            retrieved = datetime.now(timezone.utc).isoformat()
            responses.append({
                'request': request, 'url': stream.geturl(), 'http_status': stream.status,
                'retrieved_utc': retrieved, 'content_type': stream.headers.get('Content-Type'),
                'etag': stream.headers.get('ETag'), 'last_modified': stream.headers.get('Last-Modified'),
                'response_path': path.name, 'sha256': digest(path),
            })
        header, items = json.loads(payload)
        dimensions = {k: int(header[k]) for k in ('page', 'pages', 'per_page', 'total', 'sourceid')}
        if dimensions != {'page': page, 'pages': 2, 'per_page': 2, 'total': 3, 'sourceid': 2}:
            raise ValueError(f'Unexpected WDI metadata on page {page}: {dimensions}')
        if page == 1:
            update = header.get('lastupdated')
        if header.get('lastupdated') != update or len(items) != 3 - page:
            raise ValueError('The source revision or number of items changed across pages.')
        for item in items:
            if item['indicator']['id'] != 'SP.POP.TOTL' or item['countryiso3code'] != 'GHA':
                raise ValueError('The response contains a different indicator or geography.')
            if item['value'] is not None and (type(item['value']) is not int or item['value'] < 0):
                raise ValueError('A population value is neither a count nor null.')
            rows.append((int(item['date']), item['value']))
    if sorted(year for year, _ in rows) != [2021, 2022, 2023]:
        raise ValueError('Expected one record for each requested year.')
    with (out / 'ghana_population.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(('country', 'year', 'population_persons', 'value_state'))
        writer.writerows(('GHA', year, value, 'missing' if value is None else 'observed')
                         for year, value in sorted(rows))
    json_file(out / 'acquisition.json', {
        'provider': 'World Bank', 'dataset': 'World Development Indicators',
        'indicator': 'SP.POP.TOTL', 'source_id': 2, 'lastupdated': update,
        'terms_url': 'https://www.worldbank.org/en/about/legal/terms-of-use-for-datasets',
        'responses': responses, 'derived_csv_sha256': digest(out / 'ghana_population.csv'),
    })


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('replay', 'fetch-wdi'))
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    if args.mode == 'replay':
        json_file(args.directory / 'acquisition.json', prepare(args.directory))
    else:
        fetch_wdi(args.directory)
