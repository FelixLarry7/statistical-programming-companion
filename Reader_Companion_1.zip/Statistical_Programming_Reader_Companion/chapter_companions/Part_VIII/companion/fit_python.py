"""Independent Python reference for the Part VIII sector labs."""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ledger import Ledger


MACRO_FIELDS = ("growth","cpi","deflator","unemployment","tax","lending")


def as_matrix(*columns):
    return np.column_stack(columns)


def logistic(x):
    return 1 / (1 + np.exp(-np.clip(x, -40, 40)))


def logit_fit(x, y, w):
    beta = np.zeros(x.shape[1])
    for _ in range(60):
        p = logistic(x @ beta)
        score = x.T @ (w * (y - p))
        bread = x.T @ ((w * p * (1-p))[:, None] * x)
        step = np.linalg.solve(bread, score)
        beta += step
        if np.max(np.abs(step)) < 1e-10:
            return beta
    raise ValueError("Logistic Newton fit did not converge.")


def emit_interval(m, p, se, df):
    # Critical value is fixed by the four-stratum design and compared independently.
    critical = 2.1199052992210112
    assert df == 16
    m.scalars(estimate=p, se=se, df=df, lo=p-critical*se, hi=p+critical*se)


def design_se(u, stratum, psu):
    v, df = 0.0, 0
    for h in np.unique(stratum):
        sums = np.array([u[(stratum == h) & (psu == j)].sum()
                         for j in np.unique(psu[stratum == h])])
        n = len(sums)
        assert n > 1
        v += n/(n-1)*np.sum((sums-sums.mean())**2)
        df += n-1
    return np.sqrt(v), df


def coverage(frame, y, domains, ledger, ch, weight_col="weight"):
    y = np.asarray(y, dtype=float)
    w = frame[weight_col].to_numpy()
    for model, domain in domains:
        weight = w * np.asarray(domain)
        den = weight.sum()
        num = weight @ y
        p = num / den
        se, df = design_se(weight*(y-p)/den, frame.stratum.to_numpy(), frame.psu.to_numpy())
        m = ledger.model(ch, model)
        m.scalars(n=np.sum(domain), denominator=den, numerator=num)
        emit_interval(m, p, se, df)


def macro(data, ledger):
    d, policy, rev = (data(x) for x in ("macro29","policy29","revision29"))
    assert not d.duplicated(["country","year"]).any() and len(d) == 75
    for c, group in d.groupby("country"):
        group = group.sort_values("year")
        assert np.array_equal(group.year, np.arange(2000,2025))
        m = ledger.model("CH29", f"country{c}")
        for field in MACRO_FIELDS:
            m.add("available", field, group[field].count())
        y = group.set_index("year")
        for field in MACRO_FIELDS:
            for year in (2023,2024):
                if pd.notna(y.loc[year,field]):
                    m.add("snapshot",f"{year}/{field}",y.loc[year,field])
        factor = (1+y.growth/100)*(1+y.deflator/100)
        m.vector("nominal", y.index, 100*(factor-1))
        index = 100*(1+y.loc[2020:,"growth"]/100).cumprod()
        m.vector("index2019", [2019,*index.index], [100,*index])
        m.add("scalar","cagr2014",100*(np.prod(1+y.loc[2015:,"growth"]/100)**0.1-1))
        errors = {method: [] for method in ("average","ar")}
        for origin in range(2015,2023):
            seq = y.loc[2000:origin,"growth"].to_numpy()
            a,b = np.linalg.lstsq(as_matrix(np.ones(len(seq)-1),seq[:-1]),seq[1:],rcond=None)[0]
            next_y = seq[-1]
            avg = seq[-5:].mean()
            for horizon in (1,2):
                next_y = a+b*next_y
                observed = y.loc[origin+horizon,"growth"]
                for method, predicted in (("average",avg),("ar",next_y)):
                    key = f"{origin}/{horizon}"
                    m.add(f"forecast_{method}",key,predicted)
                    m.add(f"error_{method}",key,observed-predicted)
                    errors[method].append((horizon,observed-predicted))
        for method, rows in errors.items():
            for h in (1,2):
                err = np.array([e for t,e in rows if t==h])
                m.add(f"rmse_{method}",h,np.sqrt(np.mean(err**2)))
                m.add(f"mae_{method}",h,np.mean(abs(err)))
    m = ledger.model("CH29","policy")
    assert not policy.duplicated(["year","day"]).any()
    annual = policy.groupby("year").policy.agg(["size","mean","last"])
    for y,row in annual.iterrows():
        for q,k in (("days","size"),("annual_mean","mean"),("year_end","last")):
            m.add(q,y,row[k])
    gh = d[d.country == 1].set_index("year")
    year = np.arange(2004,2025)
    rate = annual.loc[year-1,"mean"].to_numpy()
    m.scalars(n_association=len(year), correlation=np.corrcoef(rate,gh.loc[year,"growth"])[0,1],
              real_policy_2024=100*((1+annual.loc[2024,"mean"]/100)/(1+gh.loc[2024,"cpi"]/100)-1))
    m = ledger.model("CH29","vintage")
    for origin in (2020,2022):
        available = rev[(rev.available <= origin) & rev.year.between(origin-3,origin-1)]
        current = available.sort_values(["year","vintage"]).drop_duplicates("year",keep="last")
        final = rev[(rev.vintage==2)&rev.year.isin(current.year)]
        assert len(current)==len(final)==3
        m.add("asof_mean",origin,current.value.mean())
        m.add("final_mean",origin,final.value.mean())
        for row in current.itertuples():
            m.add("selected",f"{origin}/{row.year}",row.vintage)


def health(data, ledger):
    d, costs, s = (data(k) for k in ("births30","expenditure30","followup30"))
    assert d.person.is_unique and costs.household.is_unique
    window=(d.live==1)&(d.months<24)
    eligible=window & d.facility.isin([0,1])
    y=(d.facility==1).to_numpy(dtype=float)
    ledger.model("CH30","flow").scalars(records=len(d), window=window.sum(),
        observed=eligible.sum(), missing=(window & ~eligible).sum())
    coverage(d,y,[("all",eligible),("urban",eligible&(d.rural==0)),("rural",eligible&(d.rural==1))],ledger,"CH30")
    w=d.weight.to_numpy()*eligible.to_numpy()
    urban=(d.rural==0).to_numpy()
    rural=~urban
    u, r = w*urban, w*rural
    p_u,p_r = u@y/u.sum(),r@y/r.sum()
    delta = r*(y-p_r)/r.sum()-u*(y-p_u)/u.sum()
    m=ledger.model("CH30","rural_gap")
    emit_interval(m,p_r-p_u,*design_se(delta,d.stratum.to_numpy(),d.psu.to_numpy()))
    d1=d[eligible].copy()
    w1=d1.weight.to_numpy()
    y1=d1.facility.to_numpy()
    x=as_matrix(np.ones(len(d1)),d1.insured,d1.rural,(d1.age-27)/10,d1.parity,d1.wealth)
    b=logit_fit(x,y1,w1)
    x0,x1=x.copy(),x.copy()
    x0[:,1],x1[:,1]=0,1
    p=logistic(x@b)
    p0,p1=logistic(x0@b),logistic(x1@b)
    wn=w1/w1.sum()
    rd=wn@(p1-p0)
    gradient=x1.T@(wn*p1*(1-p1))-x0.T@(wn*p0*(1-p0))
    bread=x.T@((w1*p*(1-p))[:,None]*x)
    score=(w1*(y1-p))[:,None]*x
    lin=np.zeros(len(d))
    lin[eligible]=wn*(p1-p0-rd)+score@np.linalg.solve(bread,gradient)
    m=ledger.model("CH30","insurance")
    m.vector("beta",("intercept","insured","rural","age","parity","wealth"),b)
    m.scalars(odds_ratio=np.exp(b[1]),risk0=wn@p0,risk1=wn@p1,
              naive_gap=np.average(y1[d1.insured==1],weights=w1[d1.insured==1])-
                        np.average(y1[d1.insured==0],weights=w1[d1.insured==0]))
    emit_interval(m,rd,*design_se(lin,d.stratum.to_numpy(),d.psu.to_numpy()))
    obs=d[eligible]
    ledger.model("CH30","sensitivity").scalars(unweighted=obs.facility.mean(),
        extended36=d.loc[(d.live==1)&d.facility.isin([0,1]),"facility"].mean(),
        lower_bound=d.loc[window & (d.facility==1),"weight"].sum()/d.loc[window,"weight"].sum(),
        upper_bound=d.loc[window & (d.facility!=0),"weight"].sum()/d.loc[window,"weight"].sum())
    x=as_matrix(np.ones(len(costs)),costs.rural,costs.chronic,costs.insured)
    spend=costs.spend.to_numpy()
    pos=spend>0
    b1=logit_fit(x,pos,np.ones(len(x)))
    b2=np.linalg.lstsq(x[pos],np.log(spend[pos]),rcond=None)[0]
    smear=np.exp(np.log(spend[pos])-x[pos]@b2).mean()
    m=ledger.model("CH30","spending")
    m.scalars(n=len(spend),positive=pos.sum(),unconditional=spend.mean(),
              positive_mean=spend[pos].mean(),smear=smear)
    for arm in (0,1):
        z=x.copy()
        z[:,3]=arm
        p=logistic(z@b1)
        v=smear*np.exp(z@b2)
        m.add("prob_positive",arm,p.mean())
        m.add("mean_positive",arm,v.mean())
        m.add("mean_spend",arm,np.mean(p*v))
    m=ledger.model("CH30","survival")
    surv=1.0
    for t in sorted(s.time.unique()):
        risk=(s.time>=t).sum()
        events=((s.time==t)&(s.event==1)).sum()
        censor=((s.time==t)&(s.event==0)).sum()
        surv*=1-events/risk
        for q,v in (("risk",risk),("events",events),("censor",censor),("survival",surv)):
            m.add(q,t,v)


def probability_metrics(y,p):
    pos=p[y==1]
    neg=p[y==0]
    assert len(pos) and len(neg)
    gap=pos[:,None]-neg
    flag=p>=0.35
    z=np.clip(p,1e-12,1-1e-12)
    return dict(n=len(y), events=len(pos), mean_p=p.mean(), event_rate=y.mean(),
        auc=np.mean((gap>0)+0.5*(gap==0)), brier=np.mean((y-p)**2),
        logloss=-np.mean(y*np.log(z)+(1-y)*np.log1p(-z)),
        tp=np.sum(flag&(y==1)), fp=np.sum(flag&(y==0)),
        tn=np.sum(~flag&(y==0)), fn=np.sum(~flag&(y==1)))


def finance(data,ledger):
    f, ids, tx, asset = (data(k) for k in ("bank_filings31","bank_ids31","transactions31","assets31"))
    assert not f.duplicated(["source","quarter","version"]).any()
    assert not ids.duplicated(["source","quarter"]).any()
    x=f.merge(ids,on=["source","quarter"],validate="many_to_one")
    assert len(x)==len(f) and ((x.npl>=0)&(x.npl<=x.gross)&(x.gross>0)).all()
    x["ratio"]=x.npl/x.gross
    initial=x[x.release<=x.quarter+1].sort_values("release").drop_duplicates(["bank","quarter"],keep="last")
    latest=x.sort_values("release").drop_duplicates(["bank","quarter"],keep="last")
    assert len(initial)==len(latest)==len(ids)
    g=initial[["bank","segment","quarter","ratio"]].copy()
    g["quarter"]-=1
    g=g.rename(columns={"ratio":"future_ratio"})
    s=initial.merge(g,on=["bank","segment","quarter"],validate="one_to_one")
    s=s.merge(latest[["bank","quarter","ratio","release"]],on=["bank","quarter"],
              suffixes=("","_latest"),validate="one_to_one")
    s=s.sort_values(["bank","quarter"])
    s["event"]=(s.future_ratio>=.080).astype(int)
    m=ledger.model("CH31","flow")
    m.scalars(filings=len(f),quarter_rows=len(initial),outcome_rows=len(s),excluded=len(initial)-len(s),
              rename_in_scope=((initial.bank==2)&(initial.source==102)).sum(),
              merged_in_scope=(initial.segment==105).sum())
    for row in initial.itertuples():
        m.add("initial_npl",f"{row.bank}/{row.quarter}",row.ratio)
    train,test=s[s.quarter<=15],s[s.quarter.between(18,23)]
    assert train.quarter.max()+2 < test.quarter.min()+1
    y=train.event.to_numpy()
    target=test.event.to_numpy()
    for name, col in (("initial","ratio"),("latest","ratio_latest"),("constant",None)):
        m=ledger.model("CH31",name)
        m.scalars(n_train=len(y),train_events=y.sum(),
                  late_features=(test.release_latest>test.quarter+1).sum() if name=="latest" else 0)
        if col:
            def features(a):
                return as_matrix(np.ones(len(a)),(100*a[col]-8)/3,(100*a.capital-14)/3,(100*a.funding-22)/8)
            b=logit_fit(features(train),y,np.ones(len(y)))
            p=logistic(features(test)@b)
            m.vector("beta",("intercept","npl","capital","funding"),b)
        else:
            p=np.repeat(y.mean(),len(test))
        m.scalars(**probability_metrics(target,p))
        m.vector("prediction",(f"{a.bank}/{a.quarter}" for a in test.itertuples()),p)
        for j in range(1,6):
            k=np.minimum(4,np.floor(5*p)).astype(int)==j-1
            m.add("bin_n",j,k.sum())
            if k.any():
                m.add("bin_p",j,p[k].mean())
                m.add("bin_y",j,target[k].mean())
    posted=tx[tx.posted==1].copy()
    posted["value"]=posted.units*posted.price*posted.fx
    pos=posted[posted.units>0]
    negative=posted[posted.units<0]
    linked=negative.merge(pos,left_on="original",right_on="line",validate="many_to_one",suffixes=("","_sale"))
    assert len(linked)==len(negative)
    assert ((linked.currency==linked.currency_sale)&(linked.customer==linked.customer_sale)&
            (linked.price==linked.price_sale)&(linked.month>=linked.month_sale)).all()
    assert all(-group.units.sum()<=group.units_sale.iloc[0] for _,group in linked.groupby("original"))
    m=ledger.model("CH31","retail")
    seen=set()
    for month,a in posted.groupby("month"):
        active=set(a.loc[(a.units>0)&(a.customer>0),"customer"])
        sales=a.loc[a.units>0,"value"].sum()
        returns=-a.loc[a.units<0,"value"].sum()
        for q,v in dict(sales=sales,returns=returns,net=sales-returns,
                         buyers=len(active),repeat=len(active&seen),
                         anonymous_sales=a.loc[(a.units>0)&(a.customer==0),"value"].sum()).items():
            m.add(q,month,v)
        seen |= active
    m=ledger.model("CH31","investment")
    total=price_only=peak=1.0
    worst=0.0
    for j in range(1,len(asset)):
        a,b=asset.iloc[j-1],asset.iloc[j]
        value=(0.6*(b.equity+b.equity_cash)/a.equity+0.4*(b.bond+b.bond_cash)/a.bond)-1
        price=(0.6*b.equity/a.equity+0.4*b.bond/a.bond)-1
        total*=1+value
        price_only*=1+price
        peak=max(peak,total)
        draw=total/peak-1
        worst=min(worst,draw)
        for q,v in (("return",value),("wealth",total),("drawdown",draw)):
            m.add(q,int(b.month),v)
    m.scalars(total_return=total-1,price_return=price_only-1,max_drawdown=worst)


def agriculture(data,ledger):
    h,p,t=(data(k) for k in ("households32","plots32","trial32"))
    assert h.household.is_unique and p["plot"].is_unique and t["plot"].is_unique
    d=p.merge(h,on="household",validate="many_to_one")
    assert len(p)==len(d)
    crop=d.maize==1
    valid=crop&(d.harvest>=0)&(d.gps>0)&(d.reported>0)&d.unit.isin([1,2])
    a=d[valid].copy()
    a["kg"]=a.harvest*np.where(a.unit==2,50,1)*(1-a.moisture)/0.85
    a["gps_ha"]=a.gps*a.share/10000
    a["reported_ha"]=a.reported*a.share/10000
    m=ledger.model("CH32","flow")
    m.scalars(households=len(h),plots=len(d),maize=crop.sum(),usable=len(a),
              missing_harvest=(crop&(d.harvest<0)).sum(),zero=(a.kg==0).sum(),
              intercropped=(a.share<1).sum(),bag_units=(a.unit==2).sum())
    for row in a.itertuples():
        m.add("harvest_kg",row.plot,row.kg)
        m.add("gps_ha",row.plot,row.gps_ha)
    for name,mask,field in (("gps",np.ones(len(a),dtype=bool),"gps_ha"),
              ("reported",np.ones(len(a),dtype=bool),"reported_ha"),
              ("harvested",a.kg>0,"gps_ha"),("main_season",a.season==1,"gps_ha")):
        q=a[mask]
        area=q[field].to_numpy()*(q.harvested if name=="harvested" else 1)
        m=ledger.model("CH32",name)
        m.scalars(n=len(q),kg=q.kg.sum(),hectares=area.sum(),ratio=q.kg.sum()/area.sum(),
                  plot_mean=np.mean(q.kg.to_numpy()/area))
    y=(h.meal_shortfall==1).to_numpy()
    obs=h.meal_shortfall.isin([0,1])
    coverage(h,y,[("all_food",obs),("rural_food",obs&(h.rural==1)),
                  ("urban_food",obs&(h.rural==0))],ledger,"CH32")
    r=h[h.rural==1]
    w=r.weight.to_numpy()
    m=ledger.model("CH32","welfare")
    m.scalars(n_rural=len(r), missing_rural=(r.meal_shortfall==-1).sum(),
        per_person=(w@r.food_spend)/(w@r["size"]),
        household_pc=np.average(r.food_spend/r["size"],weights=w),
        per_equivalent=(w@r.food_spend)/(w@(r.adults+0.5*(r["size"]-r.adults))))
    by=t.pivot(index="pair",columns="offer",values=["adopt","yield_kg_ha"])
    dy=(by["yield_kg_ha"][1]-by["yield_kg_ha"][0]).to_numpy()
    dx=(by["adopt"][1]-by["adopt"][0]).to_numpy()
    late=dy.mean()/dx.mean()
    n=len(dy)
    m=ledger.model("CH32","trial")
    m.scalars(pairs=n,itt=dy.mean(),first=dx.mean(),late=late,itt_se=dy.std(ddof=1)/np.sqrt(n),
              late_se=(dy-late*dx).std(ddof=1)/(dx.mean()*np.sqrt(n)),
              naive=t.loc[t.adopt==1,"yield_kg_ha"].mean()-t.loc[t.adopt==0,"yield_kg_ha"].mean())
    m.vector("pair_y",by.index,dy)
    m.vector("pair_a",by.index,dx)


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data",type=Path)
    ap.add_argument("output",type=Path)
    args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    def get(name):
        return pd.read_csv(args.data/(name+".csv"))
    ledger=Ledger()
    for method in (macro,health,finance,agriculture):
        method(get,ledger)
    ledger.save(args.output/"metrics.csv")
    print("Python",np.__version__,pd.__version__,len(ledger.rows),"keyed values")
