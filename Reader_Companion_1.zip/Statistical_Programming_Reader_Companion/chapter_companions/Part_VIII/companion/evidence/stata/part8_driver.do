*! Part VIII comparative labs. Stata 16/17 and built-in Mata.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide input and output folders."
    exit 198
}
mata:
string scalar p8_id(real scalar x)
{
    return(strtrim(strofreal(x,"%12.0f")))
}

void p8_put(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string scalar key, real scalar value)
{
    assert(value<.)
    fput(f,ch+","+model+","+quantity+","+key+","+strtrim(strofreal(value,"%24.16g")))
}

void p8_vec(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string rowvector keys, real rowvector values)
{
    real scalar j
    assert(cols(keys)==cols(values))
    for (j=1;j<=cols(keys);j++) p8_put(f,ch,model,quantity,keys[j],values[j])
}

real colvector p8_p(real colvector eta)
{
    return(1:/(1:+exp(-rowmin((rowmax((eta,J(rows(eta),1,-40))),J(rows(eta),1,40))))))
}

real colvector p8_ridge(real matrix x, real colvector y, real colvector weights, real scalar lam)
{
    real colvector b, p, w, g, change
    real matrix h, penalty
    real scalar j
    w=weights:/sum(weights)
    b=J(cols(x),1,0)
    penalty=diag((0 \ J(cols(x)-1,1,lam)))
    for (j=1;j<=50;j++) {
        p=p8_p(x*b)
        g=quadcross(x,w:*(p-y))+penalty*b
        h=quadcross(x,(w:*p:*(1:-p)):*x)+penalty
        change=qrsolve(h,g)
        b=b-change
        if (max(abs(change))<1e-10) return(b)
    }
    assert(0)
    return(b)
}

real scalar p8_var(real colvector x)
{
    return(sum((x:-mean(x)):^2)/(rows(x)-1))
}


real scalar p8_design_se(real colvector u, real matrix d)
{
    real scalar h,j,ss
    real colvector g
    ss=0
    for (h=1;h<=4;h++) {
        g=J(5,1,0)
        for (j=1;j<=5;j++) {
            assert(sum(d[,2]:==100*h+j)>0)
            g[j]=sum(select(u,d[,2]:==100*h+j))
        }
        ss=ss+5*p8_var(g)
    }
    return(sqrt(ss))
}

void p8_interval(real scalar f,string scalar ch,string scalar model,real scalar p,real scalar se)
{
    real scalar q
    q=invttail(16,0.025)
    p8_vec(f,ch,model,"scalar",("estimate","se","df","lo","hi"),(p,se,16,p-q*se,p+q*se))
}

real colvector p8_domain(real scalar f,string scalar ch,string scalar model,
    real colvector y,real colvector weight,real colvector keep,real matrix design)
{
    real colvector w,u
    real scalar p,den,num
    w=weight:*keep
    den=sum(w)
    num=sum(w:*y)
    p=num/den
    u=w:*(y:-p):/den
    p8_vec(f,ch,model,"scalar",("n","denominator","numerator"),(sum(keep),den,num))
    p8_interval(f,ch,model,p,p8_design_se(u,design))
    return(u\p)
}

void p8_macro(real scalar f,real matrix d,real matrix policy,real matrix rev)
{
    real matrix g, annual, err, a, b
    real colvector seq, zz, yy, valid, e, dates, cur
    real scalar c,j,k,n,o,h,obs,avg,ar,idx,ix, yr, r, q, final, asof, cc
    string scalar model,key
    string rowvector fields, methods
    fields=("growth","cpi","deflator","unemployment","tax","lending")
    methods=("average","ar")
    for (c=1;c<=3;c++) {
        g=select(d,d[,1]:==c)
        assert(rows(g)==25 & sum(g[,2]:!=(2000::2024))==0)
        model="country"+p8_id(c)
        for (j=1;j<=6;j++) {
            p8_put(f,"CH29",model,"available",fields[j],sum(g[,j+2]:<.))
            for (k=24;k<=25;k++) if (g[k,j+2]<.)
                p8_put(f,"CH29",model,"snapshot",p8_id(g[k,2])+"/"+fields[j],g[k,j+2])
        }
        r=100
        p8_put(f,"CH29",model,"index2019","2019",r)
        for (j=1;j<=25;j++) {
            p8_put(f,"CH29",model,"nominal",p8_id(g[j,2]),100*((1+g[j,3]/100)*(1+g[j,5]/100)-1))
            if (g[j,2]>=2020) {
                r=r*(1+g[j,3]/100)
                p8_put(f,"CH29",model,"index2019",p8_id(g[j,2]),r)
            }
        }
        r=1
        for (j=16;j<=25;j++) r=r*(1+g[j,3]/100)
        p8_put(f,"CH29",model,"scalar","cagr2014",100*(r^0.1-1))
        err=J(8,4,.)
        for (o=2015;o<=2022;o++) {
            n=o-1999
            seq=g[1..n,3]
            zz=seq[1..(n-1)]
            yy=seq[2..n]
            b=qrsolve((J(n-1,1,1),zz),yy)
            ar=seq[n]
            avg=mean(seq[(n-4)..n])
            for (h=1;h<=2;h++) {
                obs=g[n+h,3]
                ar=b[1]+b[2]*ar
                key=p8_id(o)+"/"+p8_id(h)
                p8_put(f,"CH29",model,"forecast_average",key,avg)
                p8_put(f,"CH29",model,"forecast_ar",key,ar)
                p8_put(f,"CH29",model,"error_average",key,obs-avg)
                p8_put(f,"CH29",model,"error_ar",key,obs-ar)
                err[o-2014,h]=obs-avg
                err[o-2014,h+2]=obs-ar
            }
        }
        for (j=1;j<=2;j++) for (h=1;h<=2;h++) {
            e=err[,2*(j-1)+h]
            p8_put(f,"CH29",model,"rmse_"+methods[j],p8_id(h),sqrt(mean(e:^2)))
            p8_put(f,"CH29",model,"mae_"+methods[j],p8_id(h),mean(abs(e)))
        }
    }
    annual=J(22,1,.)
    for (yr=2003;yr<=2024;yr++) {
        seq=select(policy[,3],policy[,1]:==yr)
        annual[yr-2002]=mean(seq)
        p8_put(f,"CH29","policy","days",p8_id(yr),rows(seq))
        p8_put(f,"CH29","policy","annual_mean",p8_id(yr),mean(seq))
        p8_put(f,"CH29","policy","year_end",p8_id(yr),seq[rows(seq)])
    }
    g=select(d,d[,1]:==1)
    yy=g[5..25,3]
    zz=annual[1..21]
    yy=yy:-mean(yy)
    zz=zz:-mean(zz)
    cc=sum(yy:*zz)/sqrt(sum(yy:^2)*sum(zz:^2))
    r=100*((1+annual[22]/100)/(1+g[25,4]/100)-1)
    p8_vec(f,"CH29","policy","scalar",("n_association","correlation","real_policy_2024"),(21,cc,r))
    for (o=2020;o<=2022;o=o+2) {
        asof=0
        final=0
        for (yr=o-3;yr<=o-1;yr++) {
            a=select(rev,(rev[,1]:==yr):*(rev[,3]:<=o))
            q=rows(a)
            asof=asof+a[q,4]
            final=final+sum(select(rev[,4],(rev[,1]:==yr):*(rev[,2]:==2)))
            p8_put(f,"CH29","vintage","selected",p8_id(o)+"/"+p8_id(yr),a[q,2])
        }
        p8_put(f,"CH29","vintage","asof_mean",p8_id(o),asof/3)
        p8_put(f,"CH29","vintage","final_mean",p8_id(o),final/3)
    }
}

void p8_health(real scalar f,real matrix d,real matrix costs,real matrix follow)
{
    real colvector y,w,window,use,rural,u,r,v,idx,yy,ww,p,p0,p1,grad,lin,spend,pos,b,b2,res,times
    real matrix ds,a,x,x0,x1,bread,score,z
    real scalar n,pr,pu,rd,smear,arm,i,t,risk,event,censor,surv
    y=d[,11]:==1
    w=d[,12]
    window=(d[,10]:==1):*(d[,9]:<24)
    use=window:*(d[,11]:>=0)
    rural=d[,4]
    ds=d[,2..3]
    p8_vec(f,"CH30","flow","scalar",("records","window","observed","missing"),
        (rows(d),sum(window),sum(use),sum(window)-sum(use)))
    v=p8_domain(f,"CH30","all",y,w,use,ds)
    u=p8_domain(f,"CH30","urban",y,w,use:*(1:-rural),ds)
    r=p8_domain(f,"CH30","rural",y,w,use:*rural,ds)
    n=rows(d)
    p8_interval(f,"CH30","rural_gap",r[n+1]-u[n+1],p8_design_se(r[1..n]-u[1..n],ds))
    idx=selectindex(use)
    a=d[idx,]
    yy=a[,11]
    ww=a[,12]
    x=(J(rows(a),1,1),a[,8],a[,4],(a[,5]:-27):/10,a[,6..7])
    b=p8_ridge(x,yy,ww,0)
    x0=x
    x1=x
    x0[,2]=J(rows(a),1,0)
    x1[,2]=J(rows(a),1,1)
    p=p8_p(x*b)
    p0=p8_p(x0*b)
    p1=p8_p(x1*b)
    rd=sum(ww:*(p1-p0))/sum(ww)
    grad=(quadcross(x1,ww:*p1:*(1:-p1))-quadcross(x0,ww:*p0:*(1:-p0)))/sum(ww)
    bread=quadcross(x,(ww:*p:*(1:-p)):*x)
    score=(ww:*(yy-p)):*x
    lin=J(rows(d),1,0)
    lin[idx]=ww:*(p1-p0:-rd):/sum(ww)+score*qrsolve(bread,grad)
    p8_vec(f,"CH30","insurance","beta",("intercept","insured","rural","age","parity","wealth"),b')
    v=ww:*a[,8]
    r=ww:*(1:-a[,8])
    p8_vec(f,"CH30","insurance","scalar",("odds_ratio","risk0","risk1","naive_gap"),
        (exp(b[2]),sum(ww:*p0)/sum(ww),sum(ww:*p1)/sum(ww),sum(v:*yy)/sum(v)-sum(r:*yy)/sum(r)))
    p8_interval(f,"CH30","insurance",rd,p8_design_se(lin,ds))
    p8_vec(f,"CH30","sensitivity","scalar",("unweighted","extended36","lower_bound","upper_bound"),
        (mean(yy),mean(select(d[,11],(d[,10]:==1):*(d[,11]:>=0))),
        sum(w:*window:*y)/sum(w:*window),sum(w:*window:*(d[,11]:!=0))/sum(w:*window)))

    x=(J(rows(costs),1,1),costs[,2..4])
    spend=costs[,5]
    pos=spend:>0
    b=p8_ridge(x,pos,J(rows(x),1,1),0)
    idx=selectindex(pos)
    b2=qrsolve(x[idx,],ln(spend[idx]))
    res=ln(spend[idx])-x[idx,]*b2
    smear=mean(exp(res))
    p8_vec(f,"CH30","spending","scalar",("n","positive","unconditional","positive_mean","smear"),
        (rows(spend),sum(pos),mean(spend),mean(spend[idx]),smear))
    for (arm=0;arm<=1;arm++) {
        z=x
        z[,4]=J(rows(z),1,arm)
        p=p8_p(z*b)
        v=smear:*exp(z*b2)
        p8_put(f,"CH30","spending","prob_positive",p8_id(arm),mean(p))
        p8_put(f,"CH30","spending","mean_positive",p8_id(arm),mean(v))
        p8_put(f,"CH30","spending","mean_spend",p8_id(arm),mean(p:*v))
    }
    times=uniqrows(sort(follow[,2],1))
    surv=1
    for (i=1;i<=rows(times);i++) {
        t=times[i]
        risk=sum(follow[,2]:>=t)
        event=sum((follow[,2]:==t):*(follow[,3]:==1))
        censor=sum((follow[,2]:==t):*(follow[,3]:==0))
        surv=surv*(1-event/risk)
        p8_put(f,"CH30","survival","risk",p8_id(t),risk)
        p8_put(f,"CH30","survival","events",p8_id(t),event)
        p8_put(f,"CH30","survival","censor",p8_id(t),censor)
        p8_put(f,"CH30","survival","survival",p8_id(t),surv)
    }
}

void p8_risk_metrics(real scalar f,string scalar model,real colvector y,real colvector p)
{
    real colvector positive,negative,flag,z,k
    real scalar i,j,a,b,auc
    positive=select(p,y:==1)
    negative=select(p,y:==0)
    auc=0
    for (i=1;i<=rows(positive);i++) {
        auc=auc+sum(negative:<positive[i])+0.5*sum(negative:==positive[i])
    }
    auc=auc/(rows(positive)*rows(negative))
    flag=p:>=0.35
    z=rowmin((rowmax((p,J(rows(p),1,1e-12))),J(rows(p),1,1-1e-12)))
    p8_vec(f,"CH31",model,"scalar",("n","events","mean_p","event_rate","auc","brier","logloss","tp","fp","tn","fn"),
        (rows(y),sum(y),mean(p),mean(y),auc,mean((y-p):^2),-mean(y:*ln(z)+(1:-y):*ln(1:-z)),
        sum(flag:*(y:==1)),sum(flag:*(y:==0)),sum((1:-flag):*(y:==0)),sum((1:-flag):*(y:==1))))
    for (j=1;j<=5;j++) {
        k=selectindex((rowmin((floor(5:*p),J(rows(p),1,4))):+1):==j)
        p8_put(f,"CH31",model,"bin_n",p8_id(j),rows(k))
        if (rows(k)>0) {
            p8_put(f,"CH31",model,"bin_p",p8_id(j),mean(p[k]))
            p8_put(f,"CH31",model,"bin_y",p8_id(j),mean(y[k]))
        }
    }
}

real matrix p8_bank_x(real matrix s, real scalar field)
{
    return((J(rows(s),1,1),(100:*s[,field]:-8):/3,(100:*s[,4]:-14):/3,(100:*s[,5]:-22):/8))
}

void p8_finance(real scalar f,real matrix filings,real matrix ids,real matrix tx,real matrix asset)
{
    real matrix s, initial, latest, map, train, test, a
    real colvector idx,ix,y,p,b,val,active,seen
    real scalar i,j,k,q,bank,c1,c2,n,late,r,sales,ret,rep,gross,net,anon,total,price,peak,dd,worst,pt
    string scalar model,key
    string rowvector models
    n=rows(ids)
    map=J(24,24,.)
    initial=J(n,8,.)
    latest=J(n,8,.)
    for (i=1;i<=n;i++) {
        idx=selectindex((filings[,1]:==ids[i,1]):*(filings[,2]:==ids[i,2]))
        assert(rows(idx)==2)
        c1=idx[1]
        c2=idx[2]
        assert(filings[c1,4]<=ids[i,2]+1 & filings[c2,4]>ids[i,2]+1)
        initial[i,]=filings[c1,]
        latest[i,]=filings[c2,]
        map[ids[i,3],ids[i,2]]=i
        p8_put(f,"CH31","flow","initial_npl",p8_id(ids[i,3])+"/"+p8_id(ids[i,2]),filings[c1,6]/filings[c1,5])
    }
    s=J(0,7,.)
    for (bank=1;bank<=24;bank++) for (q=1;q<=23;q++) {
        i=map[bank,q]
        j=map[bank,q+1]
        if (i<. & j<.) {
            if (ids[i,4]==ids[j,4]) {
                r=initial[j,6]/initial[j,5]
                s=s\(bank,q,initial[i,6]/initial[i,5],initial[i,7..8],latest[i,6]/latest[i,5],r>=0.08)
            }
        }
    }
    p8_vec(f,"CH31","flow","scalar",("filings","quarter_rows","outcome_rows","excluded","rename_in_scope","merged_in_scope"),
        (rows(filings),n,rows(s),n-rows(s),sum((ids[,3]:==2):*(ids[,1]:==102)),sum(ids[,4]:==105)))
    train=select(s,s[,2]:<=15)
    test=select(s,(s[,2]:>=18):*(s[,2]:<=23))
    y=train[,7]
    models=("initial","latest","constant")
    for (i=1;i<=3;i++) {
        model=models[i]
        late=(i==2)*rows(test)
        p8_vec(f,"CH31",model,"scalar",("n_train","train_events","late_features"),(rows(y),sum(y),late))
        if (i==3) p=J(rows(test),1,mean(y))
        else {
            k=3
            if (i==2) k=6
            b=p8_ridge(p8_bank_x(train,k),y,J(rows(y),1,1),0)
            p=p8_p(p8_bank_x(test,k)*b)
            p8_vec(f,"CH31",model,"beta",("intercept","npl","capital","funding"),b')
        }
        p8_risk_metrics(f,model,test[,7],p)
        for (j=1;j<=rows(test);j++) {
            key=p8_id(test[j,1])+"/"+p8_id(test[j,2])
            p8_put(f,"CH31",model,"prediction",key,p[j])
        }
    }
    seen=J(16,1,0)
    for (i=1;i<=3;i++) {
        a=select(tx,(tx[,2]:==i):*(tx[,9]:==1))
        val=a[,5]:*a[,6]:*a[,7]
        active=uniqrows(sort(select(a[,3],(a[,5]:>0):*(a[,3]:>0)),1))
        rep=sum(seen[active])
        seen[active]=J(rows(active),1,1)
        sales=sum(select(val,a[,5]:>0))
        ret=-sum(select(val,a[,5]:<0))
        anon=sum(select(val,(a[,5]:>0):*(a[,3]:==0)))
        key=p8_id(i)
        p8_put(f,"CH31","retail","sales",key,sales)
        p8_put(f,"CH31","retail","returns",key,ret)
        p8_put(f,"CH31","retail","net",key,sales-ret)
        p8_put(f,"CH31","retail","buyers",key,rows(active))
        p8_put(f,"CH31","retail","repeat",key,rep)
        p8_put(f,"CH31","retail","anonymous_sales",key,anon)
    }
    total=1
    price=1
    peak=1
    worst=0
    for (j=2;j<=rows(asset);j++) {
        r=0.6*(asset[j,2]+asset[j,4])/asset[j-1,2]+0.4*(asset[j,3]+asset[j,5])/asset[j-1,3]-1
        pt=0.6*asset[j,2]/asset[j-1,2]+0.4*asset[j,3]/asset[j-1,3]
        total=total*(1+r)
        price=price*pt
        peak=max((peak,total))
        dd=total/peak-1
        worst=min((dd,worst))
        key=p8_id(asset[j,1])
        p8_put(f,"CH31","investment","return",key,r)
        p8_put(f,"CH31","investment","wealth",key,total)
        p8_put(f,"CH31","investment","drawdown",key,dd)
    }
    p8_vec(f,"CH31","investment","scalar",("total_return","price_return","max_drawdown"),(total-1,price-1,worst))
}

void p8_agriculture(real scalar f,real matrix h,real matrix plots,real matrix trial)
{
    real matrix a,r
    real colvector use,kg,gps,reported,area,ii,y,obs,d,w,dy,dx
    real scalar j,k,hh,late,first,itt
    string scalar model,key
    string rowvector models
    use=(plots[,4]:==1):*(plots[,10]:>=0):*(plots[,5]:>0):*(plots[,6]:>0):*
        ((plots[,9]:==1):+(plots[,9]:==2))
    a=select(plots,use)
    kg=a[,10]:*(1:+49:*(a[,9]:==2)):*(1:-a[,11]):/0.85
    gps=a[,5]:*a[,7]:/10000
    reported=a[,6]:*a[,7]:/10000
    p8_vec(f,"CH32","flow","scalar",("households","plots","maize","usable","missing_harvest","zero","intercropped","bag_units"),
        (rows(h),rows(plots),sum(plots[,4]:==1),rows(a),sum((plots[,4]:==1):*(plots[,10]:<0)),
         sum(kg:==0),sum(a[,7]:<1),sum(a[,9]:==2)))
    for (j=1;j<=rows(a);j++) {
        key=p8_id(a[j,1])
        p8_put(f,"CH32","flow","harvest_kg",key,kg[j])
        p8_put(f,"CH32","flow","gps_ha",key,gps[j])
    }
    models=("gps","reported","harvested","main_season")
    for (j=1;j<=4;j++) {
        model=models[j]
        ii=1::rows(a)
        area=gps
        if (j==2) area=reported
        if (j==3) {
            ii=selectindex(kg:>0)
            area=gps:*a[,8]
        }
        if (j==4) ii=selectindex(a[,3]:==1)
        p8_vec(f,"CH32",model,"scalar",("n","kg","hectares","ratio","plot_mean"),
            (rows(ii),sum(kg[ii]),sum(area[ii]),sum(kg[ii])/sum(area[ii]),mean(kg[ii]:/area[ii])))
    }
    y=h[,8]:==1
    obs=h[,8]:>=0
    w=h[,10]
    d=p8_domain(f,"CH32","all_food",y,w,obs,h[,2..3])
    d=p8_domain(f,"CH32","rural_food",y,w,obs:*h[,4],h[,2..3])
    d=p8_domain(f,"CH32","urban_food",y,w,obs:*(1:-h[,4]),h[,2..3])
    r=select(h,h[,4]:==1)
    w=r[,10]
    p8_vec(f,"CH32","welfare","scalar",("n_rural","missing_rural","per_person","household_pc","per_equivalent"),
        (rows(r),sum(r[,8]:==-1),sum(w:*r[,9])/sum(w:*r[,5]),
         sum(w:*r[,9]:/r[,5])/sum(w),sum(w:*r[,9])/sum(w:*(r[,6]+0.5:*(r[,5]-r[,6])))))
    dy=J(120,1,.)
    dx=J(120,1,.)
    for (k=1;k<=120;k++) {
        a=select(trial,trial[,2]:==k)
        assert(rows(a)==2 & sum(a[,3])==1)
        dy[k]=sum((2:*a[,3]:-1):*a[,5])
        dx[k]=sum((2:*a[,3]:-1):*a[,4])
        p8_put(f,"CH32","trial","pair_y",p8_id(k),dy[k])
        p8_put(f,"CH32","trial","pair_a",p8_id(k),dx[k])
    }
    first=mean(dx)
    itt=mean(dy)
    late=itt/first
    p8_vec(f,"CH32","trial","scalar",("pairs","itt","first","late","itt_se","late_se","naive"),
        (120,itt,first,late,sqrt(p8_var(dy)/120),sqrt(p8_var(dy:-late:*dx)/120)/first,
         mean(select(trial[,5],trial[,4]:==1))-mean(select(trial[,5],trial[,4]:==0))))
}
end

mata: p8_fh=fopen(st_local("output")+"/metrics.csv","w")
mata: fput(p8_fh,"chapter,model,quantity,key,value")

import delimited using `"`input'/macro29.csv"', clear varnames(1) asdouble
isid country year
sort country year
mata: p8_macro_data=st_data(.,1..8)
import delimited using `"`input'/policy29.csv"', clear varnames(1) asdouble
isid year day
sort year day
mata: p8_policy=st_data(.,1..3)
import delimited using `"`input'/revision29.csv"', clear varnames(1) asdouble
isid year vintage
sort year vintage
mata: p8_rev=st_data(.,1..4)
mata: p8_macro(p8_fh,p8_macro_data,p8_policy,p8_rev)

import delimited using `"`input'/births30.csv"', clear varnames(1) asdouble
isid person
sort person
mata: p8_birth=st_data(.,1..12)
import delimited using `"`input'/expenditure30.csv"', clear varnames(1) asdouble
isid household
sort household
mata: p8_cost=st_data(.,1..5)
import delimited using `"`input'/followup30.csv"', clear varnames(1) asdouble
isid person
sort person
mata: p8_follow=st_data(.,1..3)
mata: p8_health(p8_fh,p8_birth,p8_cost,p8_follow)

import delimited using `"`input'/bank_filings31.csv"', clear varnames(1) asdouble
isid source quarter version
sort source quarter version
mata: p8_filing=st_data(.,1..8)
import delimited using `"`input'/bank_ids31.csv"', clear varnames(1) asdouble
isid source quarter
sort source quarter
mata: p8_ids=st_data(.,1..4)
import delimited using `"`input'/transactions31.csv"', clear varnames(1) asdouble
isid line
sort line
mata: p8_tx=st_data(.,1..9)
import delimited using `"`input'/assets31.csv"', clear varnames(1) asdouble
isid month
sort month
mata: p8_asset=st_data(.,1..5)
mata: p8_finance(p8_fh,p8_filing,p8_ids,p8_tx,p8_asset)

import delimited using `"`input'/households32.csv"', clear varnames(1) asdouble
isid household
sort household
mata: p8_house=st_data(.,1..10)
import delimited using `"`input'/plots32.csv"', clear varnames(1) asdouble
isid plot
sort plot
mata: p8_plot=st_data(.,1..11)
import delimited using `"`input'/trial32.csv"', clear varnames(1) asdouble
isid plot
sort pair offer
mata: p8_trial=st_data(.,1..5)
mata: p8_agriculture(p8_fh,p8_house,p8_plot,p8_trial)

mata: fclose(p8_fh)
display as result "Part VIII generated in Stata."
