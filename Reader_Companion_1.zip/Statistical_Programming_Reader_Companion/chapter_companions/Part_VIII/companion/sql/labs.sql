-- Register each input CSV as a view and register the independent fit ledger.
CREATE VIEW policy_annual AS
SELECT year, count(*) AS days, avg(policy) AS annual_mean,
       arg_max(policy,day) AS year_end
FROM policy29 GROUP BY year;

CREATE VIEW macro_outputs AS
SELECT *,
       100 * ((1 + growth/100)*(1 + deflator/100)-1) AS nominal,
       100 * product(1+growth/100) FILTER(WHERE year>=2020)
           OVER (PARTITION BY country ORDER BY year ROWS UNBOUNDED PRECEDING) AS index2019
FROM macro29;

CREATE VIEW vintage_choices AS
SELECT o.origin, r.year, r.vintage, r.value
FROM (VALUES (2020),(2022)) o(origin) JOIN revision29 r
ON r.year BETWEEN o.origin-3 AND o.origin-1 AND r.available<=o.origin
QUALIFY row_number() OVER(PARTITION BY o.origin,r.year
                         ORDER BY r.available DESC,r.vintage DESC)=1;

CREATE VIEW macro_forecasts AS
WITH time_order AS (
    SELECT *,lag(growth) OVER (PARTITION BY country ORDER BY year) AS previous
    FROM macro29
), training AS (
    SELECT m.country,o.origin,regr_intercept(m.growth,m.previous) AS alpha,
           regr_slope(m.growth,m.previous) AS phi,
           max(m.growth) FILTER(WHERE m.year=o.origin) AS recent,
           avg(m.growth) FILTER(WHERE m.year>o.origin-5) AS average
    FROM range(2015,2023) o(origin) JOIN time_order m ON m.year<=o.origin
    GROUP BY m.country,o.origin
), predicted AS (
    SELECT m.country,m.origin,h.horizon,d.growth AS observed,m.average,
           CASE WHEN h.horizon=1 THEN m.alpha+m.phi*m.recent
                ELSE m.alpha+m.phi*(m.alpha+m.phi*m.recent) END AS ar
    FROM training m CROSS JOIN range(1,3) h(horizon)
    JOIN macro29 d ON d.country=m.country AND d.year=m.origin+h.horizon
)
SELECT *,observed-average AS error_average,observed-ar AS error_ar
FROM predicted;

CREATE VIEW birth_domain AS
SELECT *,live=1 AND months<24 AS recent_live,
          live=1 AND months<24 AND facility IN (0,1) AS eligible
FROM births30;

CREATE VIEW survey_rows AS
SELECT 'CH30' AS chapter, v.model, stratum,psu,weight,
       CAST(facility=1 AS INTEGER) AS y,CAST(v.eligible AS INTEGER) AS keep
FROM birth_domain
CROSS JOIN LATERAL (VALUES ('all',eligible),('urban',eligible AND rural=0),
                           ('rural',eligible AND rural=1)) v(model,eligible)
UNION ALL
SELECT 'CH32',v.model,stratum,psu,weight,
       CAST(meal_shortfall=1 AS INTEGER),CAST(v.eligible AS INTEGER)
FROM households32
CROSS JOIN LATERAL (VALUES ('all_food',meal_shortfall IN (0,1)),
 ('urban_food',meal_shortfall IN (0,1) AND rural=0),
 ('rural_food',meal_shortfall IN (0,1) AND rural=1)) v(model,eligible);

CREATE VIEW survey_totals AS
SELECT chapter,model,sum(keep) AS n,sum(weight*keep) AS denominator,
       sum(weight*keep*y) AS numerator,numerator/denominator AS estimate
FROM survey_rows GROUP BY chapter,model;

CREATE VIEW survey_psu AS
SELECT r.chapter,r.model,r.stratum,r.psu,
       sum(r.weight*r.keep*(r.y-t.estimate)/t.denominator) AS score
FROM survey_rows r JOIN survey_totals t USING(chapter,model)
GROUP BY r.chapter,r.model,r.stratum,r.psu;

CREATE VIEW survey_variance AS
WITH clusters AS (
    SELECT chapter,model,stratum,count(*) AS m,var_samp(score) AS s2
    FROM survey_psu GROUP BY chapter,model,stratum
)
SELECT chapter,model,sqrt(sum(m*s2)) AS se,sum(m-1) AS df
FROM clusters GROUP BY chapter,model;

CREATE VIEW bank_joined AS
SELECT i.bank,i.segment,f.*, f.npl/f.gross AS ratio
FROM bank_filings31 f JOIN bank_ids31 i USING(source,quarter);

CREATE VIEW bank_initial AS
SELECT * FROM bank_joined
WHERE release<=quarter+1
QUALIFY row_number() OVER(PARTITION BY bank,quarter ORDER BY release DESC,version DESC)=1;

CREATE VIEW bank_latest AS
SELECT * FROM bank_joined
QUALIFY row_number() OVER(PARTITION BY bank,quarter ORDER BY release DESC,version DESC)=1;

CREATE VIEW bank_outcome AS
SELECT x.*, y.ratio AS future_ratio, CAST(y.ratio>=0.080 AS INTEGER) AS event,
       z.ratio AS latest_ratio,z.release AS latest_release
FROM bank_initial x
JOIN bank_initial y ON y.bank=x.bank AND y.segment=x.segment AND y.quarter=x.quarter+1
JOIN bank_latest z ON z.bank=x.bank AND z.quarter=x.quarter;

CREATE VIEW bank_predictions AS
SELECT m.model,d.bank,d.quarter,d.event,m.value AS p
FROM fit_ledger m JOIN bank_outcome d
ON m.key=concat(d.bank,'/',d.quarter)
WHERE m.chapter='CH31' AND m.quantity='prediction' AND d.quarter BETWEEN 18 AND 23;

CREATE VIEW bank_metrics AS
WITH pairs AS (
    SELECT a.model,avg(CASE WHEN a.p>b.p THEN 1.0 WHEN a.p=b.p THEN 0.5 ELSE 0.0 END) AS auc
    FROM bank_predictions a JOIN bank_predictions b USING(model)
    WHERE a.event=1 AND b.event=0 GROUP BY a.model
), pointwise AS (
    SELECT model,count(*) AS n,sum(event) AS events,avg(p) AS mean_p,avg(event) AS event_rate,
           avg(power(p-event,2)) AS brier,
           -avg(event*ln(greatest(1e-12,p))+(1-event)*ln(greatest(1e-12,1-p))) AS logloss,
           count_if(event=1 AND p>=0.35) AS tp,count_if(event=0 AND p>=0.35) AS fp,
           count_if(event=0 AND p<0.35) AS tn,count_if(event=1 AND p<0.35) AS fn
    FROM bank_predictions GROUP BY model
)
SELECT p.*,z.auc FROM pointwise p JOIN pairs z USING(model);

CREATE VIEW retail_lines AS
SELECT *, units*price*fx AS value FROM transactions31 WHERE posted=1;

CREATE VIEW retail_month AS
WITH first_month AS (
    SELECT customer,min(month) AS first_month
    FROM retail_lines WHERE customer>0 AND units>0 GROUP BY customer
)
SELECT r.month,
       sum(r.value) FILTER(WHERE r.units>0) AS sales,
       -sum(r.value) FILTER(WHERE r.units<0) AS returns,sum(r.value) AS net,
       count(DISTINCT r.customer) FILTER(WHERE r.units>0 AND r.customer>0) AS buyers,
       count(DISTINCT r.customer) FILTER(WHERE r.units>0 AND f.first_month<r.month) AS repeat_buyers,
       coalesce(sum(r.value) FILTER(WHERE r.units>0 AND r.customer=0),0) AS anonymous_sales
FROM retail_lines r LEFT JOIN first_month f USING(customer)
GROUP BY r.month;

CREATE VIEW valid_maize AS
SELECT p.*,h.rural,
       p.harvest*CASE WHEN p.unit=2 THEN 50 ELSE 1 END*(1-p.moisture)/0.85 AS kg,
       p.gps*p.share/10000 AS gps_ha,p.reported*p.share/10000 AS reported_ha
FROM plots32 p JOIN households32 h USING(household)
WHERE p.maize=1 AND p.harvest>=0 AND p.gps>0 AND p.reported>0 AND p.unit IN (1,2);

CREATE VIEW yield_choices AS
WITH option_rows AS (
    SELECT v.model,p.kg,v.area
    FROM valid_maize p CROSS JOIN LATERAL (
        VALUES ('gps',p.gps_ha,true),('reported',p.reported_ha,true),
               ('harvested',p.gps_ha*p.harvested,p.kg>0),
               ('main_season',p.gps_ha,p.season=1)
    ) v(model,area,include)
    WHERE v.include
)
SELECT model,count(*) AS n,sum(kg) AS kg,sum(area) AS hectares,
       sum(kg)/sum(area) AS ratio,avg(kg/area) AS plot_mean
FROM option_rows GROUP BY model;

CREATE VIEW pair_contrasts AS
SELECT pair,sum((2*offer-1)*yield_kg_ha) AS dy,sum((2*offer-1)*adopt) AS dx
FROM trial32 GROUP BY pair;

CREATE VIEW portfolio_intervals AS
WITH prior AS (
    SELECT *,lag(equity) OVER (ORDER BY month) AS equity0,
             lag(bond) OVER (ORDER BY month) AS bond0
    FROM assets31
), factors AS (
    SELECT month, 0.6*(equity+equity_cash)/equity0+0.4*(bond+bond_cash)/bond0 AS total,
                  0.6*equity/equity0+0.4*bond/bond0 AS price
    FROM prior WHERE equity0 IS NOT NULL
), wealth AS (
    SELECT *, product(total) OVER (ORDER BY month ROWS UNBOUNDED PRECEDING) AS value,
              product(price) OVER (ORDER BY month ROWS UNBOUNDED PRECEDING) AS value_price
    FROM factors
)
SELECT *,value/greatest(1,max(value) OVER (ORDER BY month ROWS UNBOUNDED PRECEDING))-1 AS drawdown
FROM wealth;
