"""Generate original teaching fixtures and standardise the frozen public macro inputs."""

import argparse
from collections import defaultdict
import csv
from datetime import date, timedelta
import io
import json
from math import exp
from pathlib import Path
from random import Random
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
MACRO = {
    "growth": "NY.GDP.MKTP.KD.ZG",
    "cpi": "FP.CPI.TOTL.ZG",
    "deflator": "NY.GDP.DEFL.KD.ZG",
    "unemployment": "SL.UEM.TOTL.ZS",
    "tax": "GC.TAX.TOTL.GD.ZS",
    "lending": "FR.INR.LEND",
}
COUNTRIES = {"GHA": 1, "KEN": 2, "SEN": 3}


def write(folder, name, fields, rows):
    with (folder / (name + ".csv")).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields.split())
        writer.writerows(rows)


def logit(x):
    return 1 / (1 + exp(-x))


def macro(folder):
    snapshot = json.loads((ROOT / "source/wdi_snapshot_metadata.json").read_text())
    rows = defaultdict(dict)
    for field, code in MACRO.items():
        assert snapshot[field]["indicator"] == code
        with ZipFile(ROOT / f"source/{code}.zip") as z:
            name = next(n for n in z.namelist() if n.startswith("API_"))
            records = list(csv.reader(io.StringIO(z.read(name).decode("utf-8-sig"))))
        assert next(r[1] for r in records[:4] if r and r[0] == "Last Updated Date") == snapshot[field]["updated"]
        header = records[4]
        for row in records[5:]:
            if row[1] in COUNTRIES:
                for year in range(2000, 2025):
                    value = row[header.index(str(year))]
                    rows[COUNTRIES[row[1]], year][field] = round(float(value), 10) if value else None
    assert len(rows) == 75 and all(set(r) == set(MACRO) for r in rows.values())
    write(folder, "macro29", "country year " + " ".join(MACRO),
          ((c, y, *(rows[c, y][field] for field in MACRO)) for c, y in sorted(rows)))
    with (ROOT / "source/bog_mpc_effective_dates.csv").open(newline="") as stream:
        changes = [(date.fromisoformat(r["effective_date"]), float(r["policy_rate"])) for r in csv.DictReader(stream)]
    daily = []
    change = 0
    for y in range(2003, 2025):
        for offset in range((date(y+1,1,1)-date(y,1,1)).days):
            day = date(y,1,1)+timedelta(days=offset)
            while change+1 < len(changes) and changes[change+1][0] <= day:
                change += 1
            assert changes[change][0] <= day
            daily.append((y, offset+1, changes[change][1]))
    write(folder, "policy29", "year day policy", daily)
    # Two explicitly synthetic publication versions illustrate availability.
    revision = [(year, vintage, year + vintage,
                 round(rows[1,year]["growth"] + shift, 8))
                for year in range(2012, 2025)
                for vintage, shift in ((1, (-1)**year*(0.35+0.14*(year % 4))), (2, 0.0))]
    write(folder, "revision29", "year vintage available value", revision)


def health(folder):
    rng = Random(30149)
    births = []
    for s in range(1,5):
        for cluster in range(1,6):
            psu = 100*s+cluster
            effect = rng.gauss(0,0.36)
            for k in range(1,31):
                person = 100*psu+k
                rural = int(rng.random() < (0.28+0.12*s))
                age = rng.randint(17,44)
                parity = rng.randint(0,5)
                agec = (age-27)/10
                wealth = rng.gauss(0.2-0.6*rural,0.8)
                insured = int(rng.random()<logit(0.3-0.6*rural+0.7*wealth+0.2*agec))
                recent = rng.randint(0,35)
                live = int(rng.random()>0.028)
                delivery = int(rng.random()<logit(1.8-0.95*rural+0.52*insured
                    +0.50*wealth+0.26*agec-0.12*parity+effect))
                if rng.random()<0.027+0.012*rural:
                    delivery=-1
                w=round(0.7+0.17*s+0.32*rural+0.1*(k%3),2)
                births.append((person,s,psu,rural,age,parity,round(wealth,8),insured,
                               recent,live,delivery,w))
    write(folder,"births30","person stratum psu rural age parity wealth insured months live facility weight",births)
    costs=[]
    for h in range(1,501):
        rural=int(rng.random()<0.49)
        chronic=int(rng.random()<0.36+0.1*rural)
        insured=int(rng.random()<logit(0.8-0.9*rural+0.6*chronic))
        positive=int(rng.random()<logit(-0.45+0.28*rural+0.95*chronic-0.18*insured))
        spend=round(exp(4.1+0.30*rural+0.64*chronic-0.32*insured+rng.gauss(0,0.56)),4) if positive else 0
        costs.append((h,rural,chronic,insured,spend))
    write(folder,"expenditure30","household rural chronic insured spend",costs)
    # Teaching cohort: right censoring, with simultaneous events and censoring at some times.
    survival = [(i + 1, time, event) for i,(time,event) in enumerate(
        [(2,1),(3,1),(3,0),(4,1),(5,0),(6,1),(6,1),(7,0),(8,1),(9,0),(10,1),(10,0)])]
    write(folder,"followup30","person time event",survival)


def finance(folder):
    rng=Random(31253)
    actual={}
    ids=[]
    for bank in range(1,25):
        base=rng.gauss(0,1)
        state=rng.gauss(0,0.5)
        for q in range(1,25):
            if bank==6 and q>=17:
                continue
            group=bank+100 if bank==5 and q>=17 else bank
            source=bank+100 if bank==2 and q>=10 else bank+200 if bank==5 and q>=17 else bank
            ids.append((source,q,bank,group))
            state=0.6*state+rng.gauss(0,0.85)+0.20*(q>=15)
            gross=round((280+35*bank)*exp(0.025*q+rng.gauss(0,0.09)),6)
            ratio=0.018+0.117*logit(-0.4+0.35*base+0.78*state)
            npl=round(gross*ratio,8)
            capital=round(0.095+0.10*logit(0.10-0.48*base-0.48*state+rng.gauss(0,0.58)),8)
            funding=round(0.10+0.25*logit(0.45*base+0.40*state+rng.gauss(0,0.71)),8)
            actual[bank,q]=(source,group,gross,npl,capital,funding)
    filings=[]
    for (bank,q),(source,group,gross,npl,capital,funding) in actual.items():
        following=actual.get((bank,q+1))
        bad=following[3]/following[2]>=0.080 if following and following[1]==group else npl/gross>=0.080
        revised=min(gross*0.22,max(0,gross*(npl/gross+(0.033 if bad else -0.018)+rng.gauss(0,0.007))))
        filings.extend(((source,q,1,q+1,gross,npl,capital,funding),
                        (source,q,2,q+3,gross,round(revised,8),capital,funding)))
    write(folder,"bank_ids31","source quarter bank segment",sorted(ids))
    write(folder,"bank_filings31","source quarter version release gross npl capital funding",sorted(filings))
    tx=[
        (1,1,11,1,2,40,1,0,1),(2,1,12,2,1,25,12,0,1),
        (3,1,11,2,2,20,12,0,1),(4,1,0,1,1,30,1,0,1),
        (5,1,13,1,1,100,1,0,0),(6,1,12,2,-1,25,12.4,2,1),
        (7,2,13,2,3,22,12.8,0,1),(8,2,11,1,1,90,1,0,1),
        (9,2,11,2,-1,20,12.8,3,1),(10,2,14,1,5,25,1,0,1),
        (11,2,13,2,-2,22,13,7,1),(12,2,12,1,2,15,1,0,1),
        (13,3,14,1,-1,25,1,10,1),(14,3,11,2,4,20,13.4,0,1),
        (15,3,15,2,1,60,13.5,0,1),(16,3,0,1,2,30,1,0,1),
        (17,3,14,1,1,90,1,0,1),(18,3,13,2,-1,22,13.4,7,1),
        (19,3,15,2,-1,60,13.7,15,1),(20,3,16,1,1,50,1,0,0)]
    write(folder,"transactions31","line month customer currency units price fx original posted",tx)
    assets=[(1,100,100,0,0),(2,103,98,0,0.8),(3,99,100,0.5,0.7),
            (4,105,101,0,0.7),(5,102,100,0,0.7),(6,108,102,0.6,0.7),
            (7,109,101,0,0.7),(8,106,104,0,0.7),(9,112,105,0.5,0.7),
            (10,111,104,0,0.7),(11,115,106,0,0.7),(12,117,106,0.6,0.7)]
    write(folder,"assets31","month equity bond equity_cash bond_cash",assets)


def agriculture(folder):
    rng=Random(32241)
    households=[]
    plots=[]
    for s in range(1,5):
        for cluster in range(1,6):
            psu=100*s+cluster
            shift=rng.gauss(0,0.36)
            for k in range(1,13):
                h=100*psu+k
                rural=int(rng.random()<0.49+0.08*(s%3))
                distance=round(max(0.5,rng.gauss(6+6*rural,4)),6)
                size=rng.randint(2,8)
                adults=rng.randint(1,size)
                meals=int(rng.random()<logit(-1.65+0.65*rural+0.05*distance+shift))
                if rng.random()<0.042:
                    meals=-1
                expenditure=round(340+size*145+adults*70+150*(1-rural)+rng.random()*550,4)
                w=round(0.9+0.24*s+0.42*rural+0.08*(k%4),2)
                households.append((h,s,psu,rural,size,adults,distance,meals,expenditure,w))
                for j in range(1,2+(k%3==0)):
                    season=1+int(j==2)
                    maize=int(rng.random()<0.86)
                    gps=max(500,exp(rng.gauss(8.45,0.58)))
                    reported=gps*exp(rng.gauss(0.14-0.12*(gps>5500),0.16))
                    share=1 if rng.random()>0.32 else (0.50,0.65,0.75)[k%3]
                    harvest_ratio=1 if rng.random()>0.19 else 0.7
                    mo=round(0.16+0.08*rng.random(),6)
                    units=2 if (k+j)%4==0 else 1
                    harvest=0 if rng.random()<0.09 else max(0.1,rng.gauss(1840,510))*gps/10000*share
                    harvest=harvest/(50 if units==2 else 1)
                    if rng.random()<0.041:
                        harvest=-1
                    plots.append((h*10+j,h,season,maize,round(gps,6),round(reported,6),share,
                                  harvest_ratio,units,round(harvest,6),mo))
    write(folder,"households32","household stratum psu rural size adults distance meal_shortfall food_spend weight",households)
    write(folder,"plots32","plot household season maize gps reported share harvested unit harvest moisture",plots)
    trial=[]
    for pair in range(1,121):
        draw=rng.randint(0,1)
        centre=rng.gauss(1600,260)
        for j in range(2):
            offer=int(j==draw)
            kind=rng.random()
            adopt=int(kind<0.2 or (kind<0.75 and offer==1))
            effect=180+15*(pair%5)
            outcome=round(centre+adopt*effect+rng.gauss(0,110),6)
            trial.append((pair*10+j+1,pair,offer,adopt,outcome))
    write(folder,"trial32","plot pair offer adopt yield_kg_ha",trial)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=ROOT/"data")
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    for generate in (macro,health,finance,agriculture):
        generate(args.output)
