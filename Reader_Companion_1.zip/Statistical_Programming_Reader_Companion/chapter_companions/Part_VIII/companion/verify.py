"""Reproduce Part VIII and compare keyed evidence, including a local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED


from ledger import read

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
EXACT = {"available", "selected", "days", "records", "window", "missing", "observed",
         "n", "df", "events", "censor", "risk", "bin_n", "filings", "quarter_rows",
         "outcome_rows", "excluded", "merged_in_scope", "rename_in_scope", "n_train",
         "train_events", "late_features", "tp", "fp", "tn", "fn", "buyers", "repeat",
         "households", "plots", "maize", "usable", "missing_harvest", "zero",
         "intercropped", "bag_units", "n_rural", "missing_rural", "pairs",
         "n_association", "positive"}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def run(argv, log):
    with log.open("w", encoding="utf-8") as f:
        result = subprocess.run([str(x) for x in argv], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
    if result.returncode != 0:
        raise RuntimeError(f"Exit code {result.returncode}. Read {log}.")


def import_stata(path, out):
    out.mkdir()
    driver = "part8_driver.do"
    with ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate evidence member name.")
        info = dict(row.split("=", 1) for row in z.read("run_info.txt").decode().splitlines() if row)
        if info["part8_rc"] != "0":
            raise ValueError(f"Local Stata returned {info['part8_rc']}. Inspect part8_run.log.")
        if info["stata_version"] not in {"16", "16.0", "17", "17.0"}:
            raise ValueError(f"Unexpected local Stata version {info['stata_version']}.")
        source = z.read(driver)
        if source != (ROOT / "stata" / driver).read_bytes():
            raise ValueError("Executed driver differs from the released driver.")
        for file in sorted(DATA.glob("*.csv")):
            if z.read("input_" + file.name) != file.read_bytes():
                raise ValueError(f"Executed input differs: {file.name}.")
        log = z.read("part8_run.log").decode("utf-8", errors="replace")
        if "Part VIII generated in Stata" not in log:
            raise ValueError("Stata completion line was not found.")
        for name in ("metrics.csv", "run_info.txt", driver):
            (out / name).write_bytes(z.read(name))
    clean = []
    for line in log.splitlines():
        if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)", line):
            clean.append("[Local path removed]")
        elif not (line.startswith("> ") and clean and clean[-1] == "[Local path removed]"):
            clean.append(line)
    (out / "part8_run.log").write_text("\n".join(clean) + "\n")
    report = dict(info, input_archive_sha256=sha(path.read_bytes()), driver_sha256=sha(source))
    (out / "environment.json").write_text(json.dumps(report, indent=2) + "\n")
    with ZipFile(out / "evidence_replay.zip", "w", ZIP_DEFLATED) as z:
        for name in ("metrics.csv", "run_info.txt", driver, "part8_run.log"):
            z.write(out / name, name)
        for file in sorted(DATA.glob("*.csv")):
            z.write(file, "input_" + file.name)
    return report


def anchors():
    # Manually derived sentinels for each data contract. These are counts and
    # individual input transformations, independent of model-fitting code.
    return {
        ("CH29", "country1", "available", "lending"): 0,
        ("CH29", "country2", "available", "lending"): 25,
        ("CH29", "country3", "available", "lending"): 12,
        ("CH29", "policy", "days", "2024"): 366,
        ("CH29", "policy", "year_end", "2024"): 27,
        ("CH29", "vintage", "selected", "2020/2019"): 1,
        ("CH30", "flow", "scalar", "records"): 600,
        ("CH30", "flow", "scalar", "observed"): 374,
        ("CH30", "all", "scalar", "df"): 16,
        ("CH30", "survival", "risk", "4"): 9,
        ("CH30", "survival", "survival", "3"): (11/12)*(10/11),
        ("CH31", "flow", "scalar", "quarter_rows"): 23*24+16,
        ("CH31", "flow", "scalar", "filings"): 2*(23*24+16),
        ("CH31", "flow", "scalar", "outcome_rows"): 23*23+15-1,
        ("CH31", "initial", "scalar", "n"): 23*6,
        ("CH31", "latest", "scalar", "late_features"): 23*6,
        ("CH31", "retail", "net", "1"): 890-310,
        ("CH32", "flow", "scalar", "households"): 4*5*12,
        ("CH32", "flow", "scalar", "usable"): 276-9,
        ("CH32", "trial", "scalar", "pairs"): 120,
    }


def compare(out, stata):
    reference = read(out / "python/metrics.csv")
    if len(reference) != 2502:
        raise ValueError(f"Incorrect Python coverage: {len(reference)}.")
    engines = ["anchor", "r", "duckdb"] + (["stata"] if stata else [])
    comparisons = []
    for engine in engines:
        other = anchors() if engine == "anchor" else read(out / engine / "metrics.csv")
        if engine in {"r", "stata"} and other.keys() != reference.keys():
            raise ValueError(f"{engine} ledger keys differ. Missing {sorted(reference.keys()-other.keys())[:8]}, "
                             f"extra {sorted(other.keys()-reference.keys())[:8]}.")
        if engine == "duckdb" and len(other) != 2050:
            raise ValueError(f"Incorrect DuckDB coverage: {len(other)}.")
        for key, value in sorted(other.items()):
            ref = reference[key]
            quantity = key[3] if key[2] == "scalar" else key[2]
            tolerance = 0 if quantity in EXACT else 2e-8 + 2e-8*abs(ref)
            gap = abs(value-ref)
            comparisons.append((engine, *key, value, ref, gap, tolerance, gap <= tolerance))
    with (out / "comparisons.csv").open("w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(("engine","chapter","model","quantity","key","value","python","abs_error","tolerance","passed"))
        w.writerows(comparisons)
    errors = [row for row in comparisons if not row[-1]]
    if errors:
        raise ValueError(f"{len(errors)} failed checks. First results: {errors[:5]}")
    return (dict(Counter(row[0] for row in comparisons)), dict(Counter(row[1] for row in comparisons)))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--rscript", default="Rscript")
    ap.add_argument("--sql-python", default=sys.executable)
    ap.add_argument("--stata-evidence", type=Path)
    ap.add_argument("--require-four", action="store_true")
    args = ap.parse_args()
    if args.require_four and not args.stata_evidence:
        ap.error("--require-four requires a local Stata evidence ZIP")
    out = args.output.resolve()
    if out.exists() and any(out.iterdir()):
        ap.error("Use a new or empty output directory.")
    for engine in ("python", "r", "duckdb"):
        (out / engine).mkdir(parents=True, exist_ok=True)
    run([sys.executable, ROOT/"fit_python.py", DATA, out/"python"], out/"python/environment.txt")
    run([args.rscript, "--vanilla", ROOT/"fit_r.R", DATA, out/"r"], out/"r/environment.txt")
    run([args.sql_python, ROOT/"fit_sql.py", DATA, out/"python/metrics.csv", out/"duckdb"],
        out/"duckdb/environment.txt")
    stata = import_stata(args.stata_evidence.resolve(), out/"stata") if args.stata_evidence else None
    counts, chapters = compare(out, stata)
    report = dict(status="VERIFIED" if stata else "STATA EVIDENCE PENDING", comparisons=sum(counts.values()),
                  failures=0, comparisons_by_engine=counts, comparisons_by_chapter=chapters,
                  duckdb_scope="Macro transformations and independent AR fits, survey domain and PSU "
                  "calculations, initial and revised filing timing, shared probability scoring, retail, "
                  "portfolio, agricultural yield and paired adoption checks. Nonlinear models are "
                  "fitted independently in Python, R and Stata when execution evidence is present.",
                  input_sha256={p.name: sha(p.read_bytes()) for p in sorted(DATA.glob("*.csv"))},
                  stata=stata)
    (out/"verification.json").write_text(json.dumps(report, indent=2)+"\n")
    print(report["status"], report["comparisons"], counts, chapters)


if __name__ == "__main__":
    main()
