# Part VIII computational companion

This companion reproduces the calculations for Chapters 29–32. The frozen
inputs mix public macroeconomic aggregates with clearly labelled synthetic
teaching records. Consult [DATA_DICTIONARY.md](DATA_DICTIONARY.md) for keys,
units and missing codes, [SPECIFICATION.md](SPECIFICATION.md) for the
model and population definitions, and [SOURCES.md](SOURCES.md) for provenance.

| Chapter | Aligned analytical outputs |
| :-- | :-- |
| 29 | WDI coverage and snapshots, implied nominal growth, chained real growth, annual policy-rate summaries, recursive and trailing-mean forecasts, release cutoffs |
| 30 | Eligible delivery counts, weighted domain ratios and intervals, joint rural–urban contrast, common-grid insurance contrast, missing-place bounds, two-part expenditure and survival risk sets |
| 31 | Time-admissible filings, same-segment outcomes, held-out probabilities and scores, late-feature counts, booked transactions and rebalanced portfolio |
| 32 | Harvest and area conversions, four yield rules, design-weighted food-access estimates, three welfare units and paired offer, uptake and Wald statistics |

## Run the public route

Run these commands from the extracted package root. The example uses an empty
output directory. Python 3.12 and R 4.5.0 were used for the verified execution.

~~~sh
python -m pip install -r companion/requirements.txt
python companion/prepare_inputs.py --output build/rebuilt_inputs
python companion/verify.py --output build/public_verification
~~~

The input regeneration uses the frozen source snapshots and deterministic
synthetic generators. The verifier fits the analytical inputs in `data/`.
Compare the checksums of regenerated inputs with the distributed files before
using them in a run. Use `--rscript` to specify the Rscript executable and
`--sql-python` if DuckDB uses a separate Python environment. R uses base
packages. The frozen CSVs also support direct use without regeneration.

## Include Stata

A local Stata 17 IC run on macOS completed on 13 November 2026 with return
code 0. Its inputs and executed driver matched the distributed files. The
archived evidence can be replayed with the same verification commands.

~~~sh
python companion/verify.py --output build/four_tool_verification \
  --stata-evidence companion/evidence/stata/evidence_replay.zip \
  --require-four
~~~

For an independent local execution, copy the do-files and all CSV inputs as
described in [stata/LOCAL_RUN.md](stata/LOCAL_RUN.md). The wrapper is written
for Stata 16 or 17, uses built-in Mata and ran on Stata 17 IC for this
release. A replay verifies the captured Stata output. The local do-files
produce new execution evidence.

## Interpret the comparison

The four-field key is `chapter,model,quantity,key`. The comparison joins
on that key before checking numerical values. Integer counts, choices and
design degrees of freedom require exact agreement. Continuous values pass
when the absolute difference is at most `2e-8 + 2e-8 * abs(reference)`.
The releases use the same 2,502 keys in Python, R and Stata. DuckDB
independently reproduces 2,050 keyed results. It evaluates the bank
probabilities on the independently reconstructed label and timing grid
using the Python scores as input. It fits the AR(1) regressions in SQL. The DuckDB runner uses one
thread to keep aggregation order stable for replays in the verified runtime.
The nonlinear likelihoods are fitted independently in Python, R and Stata.

| Comparison to Python | Passed |
| :-- | --: |
| R | 2,502 |
| Stata 17 IC | 2,502 |
| DuckDB | 2,050 |
| Hand-check anchors | 20 |
| Total | 7,074 |

The evidence directory contains the original-output ledgers, environment
reports, comparison tolerances and the pass flag for each result. Stata
`evidence_replay.zip` includes the executed driver, inputs and log. The log
removes local filesystem paths and the environment record gives the SHA-256
of the original upload. Chapter tables and figures are regenerated from
`evidence/python/metrics.csv` by `publishing/make_exhibits.py`.
