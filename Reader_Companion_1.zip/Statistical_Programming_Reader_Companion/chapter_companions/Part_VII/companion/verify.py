"""Reproduce Part VII and compare keyed evidence, including a local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np
import pandas as pd

from ledger import read

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
EXACT = {"n", "events", "n_all", "n_train", "n_train_id", "n_test_id", "tp", "fp", "tn", "fn",
         "missing", "missing_labels", "non_events", "chosen", "publish", "bin_n", "validation_n",
         "last_label_month", "first_test_month", "future_violations", "fold_n", "fold_train",
         "fold_treat", "fold_train_treat", "treated", "group_tp", "group_fp", "group_tn", "group_fn"}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def run(argv, log):
    with log.open("w", encoding="utf-8") as f:
        result = subprocess.run([str(x) for x in argv], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
    if result.returncode != 0:
        raise RuntimeError(f"Exit code {result.returncode}. Read {log}.")


def import_stata(path, out):
    out.mkdir()
    driver = "part7_driver.do"
    with ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate evidence member name.")
        info = dict(row.split("=", 1) for row in z.read("run_info.txt").decode().splitlines() if row)
        if info["part7_rc"] != "0":
            raise ValueError(f"Local Stata returned {info['part7_rc']}. Inspect part7_run.log.")
        if info["stata_version"] not in {"16", "16.0", "17", "17.0"}:
            raise ValueError(f"Unexpected local Stata version {info['stata_version']}.")
        source = z.read(driver)
        if source != (ROOT / "stata" / driver).read_bytes():
            raise ValueError("Executed driver differs from the released driver.")
        for file in sorted(DATA.glob("*.csv")):
            if z.read("input_" + file.name) != file.read_bytes():
                raise ValueError(f"Executed input differs: {file.name}.")
        log = z.read("part7_run.log").decode("utf-8", errors="replace")
        if "Part VII generated in Stata" not in log:
            raise ValueError("Stata completion line was not found.")
        for name in ("metrics.csv", "run_info.txt", driver):
            (out / name).write_bytes(z.read(name))
    clean = []
    for line in log.splitlines():
        if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)", line):
            clean.append("[Local path removed]")
        elif not (line.startswith("> ") and clean and clean[-1] == "[Local path removed]"):
            clean.append(line)
    (out / "part7_run.log").write_text("\n".join(clean) + "\n")
    report = dict(info, input_archive_sha256=sha(path.read_bytes()), driver_sha256=sha(source))
    (out / "environment.json").write_text(json.dumps(report, indent=2) + "\n")
    with ZipFile(out / "evidence_replay.zip", "w", ZIP_DEFLATED) as z:
        for name in ("metrics.csv", "run_info.txt", driver, "part7_run.log"):
            z.write(out / name, name)
        for file in sorted(DATA.glob("*.csv")):
            z.write(file, "input_" + file.name)
    return report


def anchors():
    c = pd.read_csv(DATA / "customers25.csv")
    p = pd.read_csv(DATA / "credit_predictions.csv")
    d = pd.read_csv(DATA / "programme28.csv")
    n = pd.read_csv(DATA / "nuisance28.csv").iloc[0]
    v = d.iloc[0]
    values = {}
    for k, held, origin in [(1, 1, 7), (2, 2, 8), (3, 3, 9), (4, 0, 11)]:
        name = f"split{k}" if k < 4 else "holdout"
        values.update({
            ("CH25", name, "scalar", "n_train"): (2 if k < 4 else 3) * 120 * (origin-1),
            ("CH25", name, "scalar", "n_test_id"): 120,
            ("CH25", name, "scalar", "events"): int(c.loc[(c.cohort == held) &
                                                         c.month.between(origin, origin+1), "outcome"].sum()),
        })
    values.update({
        ("CH25", "leaked", "scalar", "future_violations"): 240,
        ("CH27", "audit", "scalar", "n_all"): 240,
        ("CH27", "audit", "scalar", "missing_labels"): int((p.outcome == -1).sum()),
        ("CH27", "audit", "publish", "3"): 0,
        ("CH28", "shared", "n", "all"): 1200,
        ("CH28", "shared", "fold_train", "4"): 900,
        ("CH28", "shared", "truth", "all"): float(d.true_effect.mean()),
        ("CH28", "shared", "score", "1"): n.m1-n.m0 +
        ((v.outcome-n.m1)/n.e if v.treated == 1 else -(v.outcome-n.m0)/(1-n.e)),
    })
    return values


def compare(out, stata):
    reference = read(out / "python/metrics.csv")
    if len(reference) != 5042:
        raise ValueError(f"Incorrect Python coverage: {len(reference)}.")
    engines = ["anchor", "r", "duckdb"] + (["stata"] if stata else [])
    comparisons = []
    for engine in engines:
        other = anchors() if engine == "anchor" else read(out / engine / "metrics.csv")
        if engine in {"r", "stata"} and other.keys() != reference.keys():
            raise ValueError(f"{engine} ledger keys differ. Missing {sorted(reference.keys()-other.keys())[:8]}, "
                             f"extra {sorted(other.keys()-reference.keys())[:8]}.")
        if engine == "duckdb" and len(other) != 2045:
            raise ValueError(f"Incorrect DuckDB coverage: {len(other)}.")
        for key, value in sorted(other.items()):
            ref = reference[key]
            quantity = key[3] if key[2] == "scalar" else key[2]
            tolerance = 0 if quantity in EXACT else 2e-8 + 2e-8*abs(ref)
            gap = abs(value-ref)
            comparisons.append((engine, *key, value, ref, gap, tolerance, gap <= tolerance))
    with (out / "comparisons.csv").open("w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(("engine","chapter","model","quantity","key","value","python","abs_error","tolerance","passed"))
        w.writerows(comparisons)
    errors = [row for row in comparisons if not row[-1]]
    if errors:
        raise ValueError(f"{len(errors)} failed checks. First results: {errors[:5]}")
    return (dict(Counter(row[0] for row in comparisons)), dict(Counter(row[1] for row in comparisons)))


def verify_ensembles(out):
    f = pd.read_csv(DATA / "ensemble26.csv")
    frames = []
    for engine in ("python", "r"):
        runfile = out / engine / "ensemble_predictions.csv"
        a = pd.read_csv(runfile)
        if not a[["borrower","outcome"]].equals(f[["borrower","outcome"]]):
            raise ValueError(f"{engine} ensemble identifiers differ.")
        columns = a.columns[2:]
        if not np.allclose(a[columns], f[columns], rtol=2e-8, atol=2e-8):
            raise ValueError(f"{engine} ensemble rerun differs from its frozen reference.")
        t = pd.read_csv(out / engine / "ensemble_tuning.csv")
        for _, g in t.groupby("model"):
            assert len(g) == 8 and (g.trees == 64).all() and set(g.depth) == {1, 2}
            valid = g[g.split != 0]
            pooled = g[g.split == 0].sort_values("depth")
            assert len(valid) == 6 and (valid.groupby("split").size() == 2).all()
            totals = valid.groupby("depth")[["loss_sum","n"]].sum()
            assert np.allclose(totals.to_numpy(), pooled[["loss_sum","n"]].to_numpy())
            assert pooled.iloc[int(np.argmin(totals.loss_sum))].chosen == 1
        frames.append(t)
    pd.concat(frames, ignore_index=True).to_csv(out / "ensemble_tuning.csv", index=False)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--rscript", default="Rscript")
    ap.add_argument("--sql-python", default=sys.executable)
    ap.add_argument("--stata-evidence", type=Path)
    ap.add_argument("--require-four", action="store_true")
    args = ap.parse_args()
    if args.require_four and not args.stata_evidence:
        ap.error("--require-four requires a local Stata evidence ZIP")
    out = args.output.resolve()
    if out.exists() and any(out.iterdir()):
        ap.error("Use a new or empty output directory.")
    for engine in ("python", "r", "duckdb"):
        (out / engine).mkdir(parents=True, exist_ok=True)
    run([sys.executable, ROOT/"fit_python.py", DATA, out/"python"], out/"python/environment.txt")
    run([args.rscript, "--vanilla", ROOT/"fit_r.R", DATA, out/"r"], out/"r/environment.txt")
    run([args.sql_python, ROOT/"fit_sql.py", DATA, out/"python/metrics.csv", out/"duckdb"],
        out/"duckdb/environment.txt")
    run([sys.executable, ROOT/"ensemble_python.py", DATA, out/"python"], out/"python/ensemble.log")
    run([args.rscript, "--vanilla", ROOT/"ensemble_r.R", DATA, out/"r"], out/"r/ensemble.log")
    verify_ensembles(out)
    stata = import_stata(args.stata_evidence.resolve(), out/"stata") if args.stata_evidence else None
    counts, chapters = compare(out, stata)
    report = dict(status="VERIFIED" if stata else "STATA EVIDENCE PENDING", comparisons=sum(counts.values()),
                  failures=0, comparisons_by_engine=counts, comparisons_by_chapter=chapters,
                  duckdb_scope="Split keys and training transforms, common prediction scoring, "
                  "entity bootstrap, frozen calibration and subgroup diagnostics, shared AIPW scores and balance.",
                  input_sha256={p.name: sha(p.read_bytes()) for p in sorted(DATA.glob("*.csv"))},
                  stata=stata)
    (out/"verification.json").write_text(json.dumps(report, indent=2)+"\n")
    print(report["status"], report["comparisons"], counts, chapters)


if __name__ == "__main__":
    main()
