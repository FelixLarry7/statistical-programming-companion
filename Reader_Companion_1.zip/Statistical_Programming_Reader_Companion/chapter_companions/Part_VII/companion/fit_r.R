# Independent R implementation of the aligned Part VII analyses.
customer_columns <- c("tenure", "spend", "contacts", "decline")
credit_columns <- c("utilisation", "volatility", "late", "history", "ratio", "thin")
lambdas <- c(0.005, 0.03, 0.12)
thresholds <- c(0.15, 0.25, 0.35)
eps <- 1e-12

make_ledger <- function(path) {
  state <- new.env(parent=emptyenv())
  state$parts <- list()
  add <- function(chapter, model, quantity, key, value) {
    stopifnot(length(key) == length(value), all(is.finite(value)))
    j <- length(state$parts) + 1L
    state$parts[[j]] <- data.frame(chapter, model, quantity, key=as.character(key), value)
  }
  save <- function() {
    all <- do.call(rbind, state$parts)
    stopifnot(!anyDuplicated(all[1:4]))
    write.table(all, path, row.names=FALSE, sep=",", quote=FALSE)
    nrow(all)
  }
  list(add=add, save=save)
}

sigmoid <- function(z) 1 / (1 + exp(-pmin(pmax(z, -40), 40)))

fill_features <- function(x, med) {
  for (i in seq_len(ncol(x))) x[is.na(x[,i]),i] <- med[i]
  x
}

fit_scaler <- function(x) {
  med <- apply(x, 2, median, na.rm=TRUE)
  stopifnot(all(is.finite(med)))
  filled <- fill_features(x, med)
  centre <- colMeans(filled)
  scale <- sqrt(colMeans(sweep(filled, 2, centre)^2))
  scale[scale == 0] <- 1
  list(median=med, centre=centre, scale=scale)
}

transform_x <- function(x, s) {
  cbind(1, sweep(sweep(fill_features(x, s$median), 2, s$centre), 2, s$scale, "/"))
}

fit_ridge <- function(x, y, weight, lam) {
  w <- weight / sum(weight)
  b <- rep(0, ncol(x))
  penalty <- diag(c(0, rep(lam, ncol(x)-1)))
  for (i in 1:50) {
    p <- sigmoid(drop(x %*% b))
    g <- crossprod(x, w*(p-y)) + penalty %*% b
    h <- crossprod(x, x*(w*p*(1-p))) + penalty
    change <- drop(solve(h, g))
    b <- b - change
    if (max(abs(change)) < 1e-10) return(b)
  }
  stop("Ridge Newton solver did not converge")
}

log_losses <- function(y,p) {
  p <- pmin(pmax(p, eps), 1-eps)
  -y*log(p)-(1-y)*log1p(-p)
}

confusion <- function(y,p,t) {
  pos <- p >= t
  c(tp=sum(pos & y==1), fp=sum(pos & y==0), tn=sum(!pos & y==0), fn=sum(!pos & y==1))
}

scoring <- function(y,p) {
  stopifnot(all(y %in% 0:1), sum(y)>0, sum(y)<length(y))
  o <- order(p)
  counts <- rle(p[o])$lengths
  positive <- drop(rowsum(matrix(y[o],ncol=1), rep(seq_along(counts), counts)))
  negative <- counts - positive
  auc <- sum(positive * (cumsum(negative)-negative/2)) / (sum(y)*(length(y)-sum(y)))
  ap <- sum(rev(positive)*cumsum(rev(positive))/cumsum(rev(counts))) / sum(y)
  c(n=length(y), events=sum(y), prevalence=mean(y), mean_p=mean(p), brier=mean((y-p)^2),
    logloss=mean(log_losses(y,p)), auc=auc, ap=ap, confusion(y,p,0.25))
}

put_scalar <- function(m, ch, name, values) m$add(ch, name, "scalar", names(values), unname(values))
emit_fit <- function(m, ch, name, cols, scaler, b) {
  for (k in names(scaler)) m$add(ch, name, k, cols, scaler[[k]])
  m$add(ch, name, "beta", c("intercept",cols), b)
}

customer_lab <- function(m, read) {
  d <- read("customers25")
  manifest <- read("splits25")
  draws <- read("bootstrap25")
  stopifnot(!anyDuplicated(d$row_id), !anyDuplicated(d[c("customer","month")]))
  for (s in 1:4) {
    held <- if (s==4) 0 else s
    origin <- if (s==4) 11 else s+6
    train <- d[d$cohort!=0 & d$cohort!=held & d$label_month<=origin,]
    test <- d[d$cohort==held & d$month>=origin & d$month<=origin+1,]
    stopifnot(identical(train$row_id,manifest$row_id[manifest$split==s & manifest$role==1]),
              identical(test$row_id,manifest$row_id[manifest$split==s & manifest$role==2]),
              length(intersect(train$customer,test$customer))==0,
              max(train$label_month)<=min(test$month))
    models <- if (s<4) paste0("split",s) else c("holdout","leaked")
    for (name in models) {
      cols <- if (name=="leaked") c(customer_columns,"future") else customer_columns
      scaler <- fit_scaler(as.matrix(train[cols]))
      x <- transform_x(as.matrix(train[cols]),scaler)
      v <- transform_x(as.matrix(test[cols]),scaler)
      b <- fit_ridge(x,train$outcome,rep(1,nrow(train)),0.04)
      p <- sigmoid(drop(v %*% b))
      y <- test$outcome
      emit_fit(m,"CH25",name,cols,scaler,b)
      m$add("CH25",name,"prediction",test$row_id,p)
      put_scalar(m,"CH25",name,
                 c(n_train=nrow(train), n_train_id=length(unique(train$customer)),
                   n_test_id=length(unique(test$customer)), last_label_month=max(train$label_month),
                   first_test_month=min(test$month), train_rate=mean(train$outcome),
                   future_violations=if (name=="leaked") sum(test$future_month>test$month) else 0,
                   scoring(y,p)))
      if (name=="holdout") {
        delta <- (y-p)^2 - (y-mean(train$outcome))^2
        by_id <- tapply(delta,test$customer,mean)
        stopifnot(all(tapply(draws$multiplicity, draws$draw, sum)==120))
        value <- tapply(by_id[as.character(draws$customer)]*draws$multiplicity,draws$draw,sum)/120
        m$add("CH25",name,"bootstrap",names(value),as.numeric(value))
        q <- quantile(value,c(0.025,0.975),names=FALSE,type=7)
        put_scalar(m,"CH25",name,c(paired_delta=mean(delta),paired_lo=q[1],paired_hi=q[2]))
      }
    }
  }
}

credit_lab <- function(m, read) {
  d <- read("credit26")
  stopifnot(!anyDuplicated(d$borrower))
  dev <- d[d$fold!=0 & d$outcome!=-1,]
  test <- d[d$fold==0,]
  labels <- test$outcome!=-1
  objective <- numeric(3)
  for (s in 1:3) {
    train <- dev[dev$fold!=s,]
    val <- dev[dev$fold==s,]
    scaler <- fit_scaler(as.matrix(train[credit_columns]))
    x <- transform_x(as.matrix(train[credit_columns]),scaler)
    v <- transform_x(as.matrix(val[credit_columns]),scaler)
    for (j in 1:3) {
      b <- fit_ridge(x,train$outcome,train$weight,lambdas[j])
      loss <- sum(log_losses(val$outcome,sigmoid(drop(v %*% b))))
      m$add("CH26","tuning","loss_sum",paste(s,j,sep="/"),loss)
      objective[j] <- objective[j]+loss
    }
    m$add("CH26","tuning","validation_n",s,nrow(val))
  }
  m$add("CH26","tuning","mean_logloss",1:3,objective/nrow(dev))
  best <- which.min(objective)
  scaler <- fit_scaler(as.matrix(dev[credit_columns]))
  x <- transform_x(as.matrix(dev[credit_columns]),scaler)
  v <- transform_x(as.matrix(test[credit_columns]),scaler)
  y <- dev$outcome
  for (name in c("ridge","class2")) {
    w <- if (name=="class2") dev$weight*(1+y) else dev$weight
    b <- fit_ridge(x,y,w,lambdas[best])
    p <- sigmoid(drop(v %*% b))
    loss <- weighted.mean(log_losses(y,sigmoid(drop(x %*% b))),w) + lambdas[best]*sum(b[-1]^2)/2
    emit_fit(m,"CH26",name,credit_columns,scaler,b)
    m$add("CH26",name,"prediction",test$borrower,p)
    put_scalar(m,"CH26",name,c(chosen=best,lambda_value=lambdas[best],n_train=length(y),
                             weight_sum=sum(w),objective=loss,scoring(test$outcome[labels],p[labels])))
  }
}

wilson <- function(x,n) {
  p <- x/n
  z <- 1.96
  den <- 1+z^2/n
  mid <- (p+z^2/(2*n))/den
  half <- z*sqrt(p*(1-p)/n+z^2/(4*n^2))/den
  c(max(0,mid-half),min(1,mid+half))
}

diagnostic_lab <- function(m, pred) {
  stopifnot(!anyDuplicated(pred$borrower), all(pred$outcome %in% -1:1),
            all(pred$ridge>=0 & pred$ridge<=1))
  d <- pred[pred$outcome!=-1,]
  put_scalar(m,"CH27","audit",c(n_all=nrow(pred),missing_labels=nrow(pred)-nrow(d),
                               scoring(d$outcome,d$ridge)))
  bins <- pmin(floor(5*d$ridge),4)+1
  error <- 0
  for (j in 1:5) {
    v <- d[bins==j,]
    m$add("CH27","audit","bin_n",j,nrow(v))
    if (nrow(v)) {
      y <- mean(v$outcome)
      p <- mean(v$ridge)
      m$add("CH27","audit","bin_event_rate",j,y)
      m$add("CH27","audit","bin_mean_p",j,p)
      error <- error+nrow(v)*abs(y-p)
    }
  }
  put_scalar(m,"CH27","audit",c(ece=error/nrow(d)))
  for (g in 1:3) {
    v <- d[d$audit_group==g,]
    total <- sum(pred$audit_group==g)
    events <- sum(v$outcome)
    non <- nrow(v)-events
    publish <- nrow(v)>=25 && events>=5 && non>=5
    values <- c(n_all=total,n=nrow(v),events=events,non_events=non,missing=total-nrow(v),publish=publish)
    for (k in names(values)) m$add("CH27","audit",k,g,values[[k]])
    if (publish) for (j in 1:3) {
      z <- confusion(v$outcome,v$ridge,thresholds[j])
      tp <- z[["tp"]]
      fp <- z[["fp"]]
      a <- wilson(tp,events)
      b <- wilson(fp,non)
      values <- c(z,tpr=tp/events,fpr=fp/non,selection=(tp+fp)/nrow(v),
                  tpr_lo=a[1],tpr_hi=a[2],fpr_lo=b[1],fpr_hi=b[2])
      for (k in names(values)) m$add("CH27","audit",paste0("group_",k),paste(g,j,sep="/"),values[[k]])
    }
  }
}

plain_nuisance <- function(d) {
  x <- cbind(1,as.matrix(d[c("rural","need","distance","baseline")]))
  out <- d[c("person","fold")]
  out$e <- out$m0 <- out$m1 <- NA_real_
  for (j in 1:4) {
    held <- d$fold==j
    g <- glm.fit(x[!held,],d$treated[!held],family=binomial(),control=glm.control(epsilon=1e-13))
    stopifnot(g$converged)
    out$e[held] <- plogis(x[held,] %*% g$coefficients)
    for (a in 0:1) {
      fit <- !held & d$treated==a
      out[held,paste0("m",a)] <- drop(x[held,] %*% lm.fit(x[fit,],d$outcome[fit])$coefficients)
    }
  }
  out
}

score28 <- function(m, d, nuisance, name) {
  stopifnot(identical(d[c("person","fold")],nuisance[c("person","fold")]))
  a <- d$treated
  y <- d$outcome
  e <- nuisance$e
  m0 <- nuisance$m0
  m1 <- nuisance$m1
  stopifnot(all(e>0 & e<1))
  score <- m1-m0 + a*(y-m1)/e - (1-a)*(y-m0)/(1-e)
  m$add("CH28",name,"score",d$person,score)
  samples <- list(all=rep(TRUE,nrow(d)),trim=e>=0.10 & e<=0.90,urban=d$rural==0,rural=d$rural==1)
  for (k in names(samples)) {
    keep <- samples[[k]]
    z <- score[keep]
    se <- sd(z)/sqrt(length(z))
    values <- c(n=length(z),ate=mean(z),se=se,lo=mean(z)-1.96*se,hi=mean(z)+1.96*se,
                truth=mean(d$true_effect[keep]))
    for (q in names(values)) m$add("CH28",name,q,k,values[[q]])
  }
  for (j in 1:4) {
    h <- d$fold==j
    values <- c(fold_n=sum(h),fold_train=sum(!h),fold_treat=sum(a[h]),fold_train_treat=sum(a[!h]),
                fold_mean_e=mean(e[h]))
    for (q in names(values)) m$add("CH28",name,q,j,values[[q]])
  }
  wt <- a/e
  wc <- (1-a)/(1-e)
  put_scalar(m,"CH28",name,c(naive=mean(y[a==1])-mean(y[a==0]),treated=sum(a),
                            e_min=min(e),e_max=max(e),e_mean=mean(e),
                            ess_t=sum(wt)^2/sum(wt^2),ess_c=sum(wc)^2/sum(wc^2)))
  for (col in c("rural","need","distance","baseline")) {
    v <- d[[col]]
    scale <- sqrt((var(v[a==1])+var(v[a==0]))/2)
    m$add("CH28",name,"smd_raw",col,(mean(v[a==1])-mean(v[a==0]))/scale)
    m$add("CH28",name,"smd_ipw",col,(weighted.mean(v,wt)-weighted.mean(v,wc))/scale)
  }
}

main <- function() {
  args <- commandArgs(trailingOnly=TRUE)
  stopifnot(length(args)==2)
  read <- function(name) read.csv(file.path(args[1],paste0(name,".csv")),check.names=FALSE)
  dir.create(args[2],recursive=TRUE,showWarnings=FALSE)
  m <- make_ledger(file.path(args[2],"metrics.csv"))
  customer_lab(m,read)
  credit_lab(m,read)
  pred <- read("credit_predictions")
  diagnostic_lab(m,pred)
  d <- read("programme28")
  score28(m,d,read("nuisance28"),"shared")
  score28(m,d,plain_nuisance(d),"plain")
  if (file.exists(file.path(args[1],"ensemble26.csv"))) {
    ens <- read("ensemble26")
    stopifnot(identical(ens$borrower,pred$borrower),identical(ens$outcome,pred$outcome))
    ok <- ens$outcome!=-1
    for (name in names(ens)[-(1:2)])
      put_scalar(m,"CH26",name,scoring(ens$outcome[ok],ens[ok,name]))
  }
  cat(R.version.string, m$save(), "keyed values\n")
}

if (sys.nframe()==0L) main()
