# Run Part VII in Stata 16 or 17

1. Extract the entire ZIP. Keep the inputs folder and both do-files together.
2. In Stata, set the working directory to the extracted Part_VII_Stata_Local_Run_R2 folder.
3. Enter `do run_part7.do` in the Command window.
4. Upload the resulting Stata_Verification_Part_VII_*.zip file. If Stata reports a nonzero return code, upload the same evidence archive so the log can be inspected.

This offline run uses built-in Stata and Mata. It fits the shared ridge models and
plain nuisance regressions, and independently scores the frozen ensemble and
diagnostic inputs. It records its Stata version, return code, driver and exact
input copies. The original working directory and active data frame are restored.
