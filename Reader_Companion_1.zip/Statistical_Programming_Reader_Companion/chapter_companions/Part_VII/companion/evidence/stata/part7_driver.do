*! Part VII comparative labs. Stata 16/17 and built-in Mata.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide input and output folders."
    exit 198
}
mata:
string scalar p7_id(real scalar x)
{
    return(strtrim(strofreal(x,"%12.0f")))
}

void p7_put(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string scalar key, real scalar value)
{
    assert(value<.)
    fput(f,ch+","+model+","+quantity+","+key+","+strtrim(strofreal(value,"%24.16g")))
}

void p7_vec(real scalar f, string scalar ch, string scalar model,
    string scalar quantity, string rowvector keys, real rowvector values)
{
    real scalar j
    assert(cols(keys)==cols(values))
    for (j=1;j<=cols(keys);j++) p7_put(f,ch,model,quantity,keys[j],values[j])
}

real scalar p7_quantile(real colvector v, real scalar probability)
{
    real scalar a, k
    real colvector x
    assert(rows(v)>0)
    x=sort(v,1)
    a=1+(rows(x)-1)*probability
    k=floor(a)
    return(x[k]+(a-k)*(x[ceil(a)]-x[k]))
}

real matrix p7_fill(real matrix x, real rowvector med)
{
    real matrix z
    real colvector ii
    real scalar j
    z=x
    for (j=1;j<=cols(z);j++) {
        ii=selectindex(z[,j]:>=.)
        if (rows(ii)>0) z[ii,j]=J(rows(ii),1,med[j])
    }
    return(z)
}

real matrix p7_scaler(real matrix x)
{
    real matrix z
    real rowvector med, centre, scale
    real scalar j
    med=J(1,cols(x),.)
    for (j=1;j<=cols(x);j++) med[j]=p7_quantile(select(x[,j],x[,j]:<.),0.5)
    z=p7_fill(x,med)
    centre=mean(z)
    scale=sqrt(mean((z:-centre):^2))
    for (j=1;j<=cols(x);j++) if (scale[j]==0) scale[j]=1
    return(med \ centre \ scale)
}

real matrix p7_design(real matrix x, real matrix s)
{
    return((J(rows(x),1,1),(p7_fill(x,s[1,]):-s[2,]):/s[3,]))
}

real colvector p7_p(real colvector eta)
{
    return(1:/(1:+exp(-rowmin((rowmax((eta,J(rows(eta),1,-40))),J(rows(eta),1,40))))))
}

real colvector p7_ridge(real matrix x, real colvector y, real colvector weights, real scalar lam)
{
    real colvector b, p, w, g, change
    real matrix h, penalty
    real scalar j
    w=weights:/sum(weights)
    b=J(cols(x),1,0)
    penalty=diag((0 \ J(cols(x)-1,1,lam)))
    for (j=1;j<=50;j++) {
        p=p7_p(x*b)
        g=quadcross(x,w:*(p-y))+penalty*b
        h=quadcross(x,(w:*p:*(1:-p)):*x)+penalty
        change=qrsolve(h,g)
        b=b-change
        if (max(abs(change))<1e-10) return(b)
    }
    assert(0)
    return(b)
}

real colvector p7_loss(real colvector y, real colvector p)
{
    real colvector q
    q=rowmin((rowmax((p,J(rows(p),1,1e-12))),J(rows(p),1,1-1e-12)))
    return(-y:*ln(q)-(1:-y):*ln(1:-q))
}

real rowvector p7_counts(real colvector y, real colvector p, real scalar t)
{
    real colvector flag
    flag=p:>=t
    return((sum(flag:*(y:==1)),sum(flag:*(y:==0)),
            sum((1:-flag):*(y:==0)),sum((1:-flag):*(y:==1))))
}

void p7_metrics(real scalar f, string scalar ch, string scalar model,
    real colvector y, real colvector p)
{
    real scalar n, ev, j, k, pos, neg, bpos, bneg, auc, ap
    real matrix sorted
    n=rows(y)
    ev=sum(y)
    assert(ev>0 & ev<n & rows(p)==n & min(p)>=0 & max(p)<=1)
    assert(sum((y:!=0):*(y:!=1))==0)
    sorted=sort((p,y),1)
    bpos=0
    bneg=0
    auc=0
    ap=0
    j=1
    while (j<=n) {
        k=j
        while (k<n) {
            if (sorted[k+1,1]!=sorted[j,1]) break
            k=k+1
        }
        pos=sum(sorted[|j,2\k,2|])
        neg=k-j+1-pos
        auc=auc+pos*(bneg+neg/2)
        ap=ap+pos*(ev-bpos)/(n-j+1)
        bneg=bneg+neg
        bpos=bpos+pos
        j=k+1
    }
    p7_vec(f,ch,model,"scalar",("n","events","prevalence","mean_p","brier","logloss","auc","ap"),
        (n,ev,mean(y),mean(p),mean((y-p):^2),mean(p7_loss(y,p)),auc/(ev*(n-ev)),ap/ev))
    p7_vec(f,ch,model,"scalar",("tp","fp","tn","fn"),p7_counts(y,p,0.25))
}

void p7_emit_fit(real scalar f, string scalar ch, string scalar model, string rowvector names,
    real matrix s, real colvector b)
{
    p7_vec(f,ch,model,"median",names,s[1,])
    p7_vec(f,ch,model,"centre",names,s[2,])
    p7_vec(f,ch,model,"scale",names,s[3,])
    p7_vec(f,ch,model,"beta",("intercept",names),b')
}

void p7_ch25(real scalar f, real matrix d, real matrix manifest, real matrix draws)
{
    real scalar split, held, origin, variant, j, k, rate, n
    real matrix train, test, s, x, v
    real colvector b, y, p, delta, perid, values, counts, ids
    real rowvector cols
    string scalar name
    string rowvector names
    for (split=1;split<=4;split++) {
        held=split
        origin=6+split
        if (split==4) {
            held=0
            origin=11
        }
        train=select(d,(d[,3]:!=0):*(d[,3]:!=held):*(d[,5]:<=origin))
        test=select(d,(d[,3]:==held):*(d[,4]:>=origin):*(d[,4]:<=origin+1))
        ids=select(manifest[,2],(manifest[,1]:==split):*(manifest[,3]:==1))
        assert(rows(train)==rows(ids) & sum(train[,1]:!=ids)==0)
        ids=select(manifest[,2],(manifest[,1]:==split):*(manifest[,3]:==2))
        assert(rows(test)==rows(ids) & sum(test[,1]:!=ids)==0)
        assert(max(train[,5])<=min(test[,4]))
        n=1+(split==4)
        for (variant=1;variant<=n;variant++) {
            name="split"+p7_id(split)
            if (split==4) name="holdout"
            cols=7..10
            names=("tenure","spend","contacts","decline")
            if (variant==2) {
                name="leaked"
                cols=7..11
                names=(names,"future")
            }
            s=p7_scaler(train[,cols])
            x=p7_design(train[,cols],s)
            v=p7_design(test[,cols],s)
            b=p7_ridge(x,train[,6],J(rows(train),1,1),0.04)
            p=p7_p(v*b)
            y=test[,6]
            rate=mean(train[,6])
            p7_emit_fit(f,"CH25",name,names,s,b)
            for (j=1;j<=rows(test);j++) p7_put(f,"CH25",name,"prediction",p7_id(test[j,1]),p[j])
            p7_vec(f,"CH25",name,"scalar",
                ("n_train","n_train_id","n_test_id","last_label_month","first_test_month","train_rate","future_violations"),
                (rows(train),rows(uniqrows(sort(train[,2],1))),rows(uniqrows(sort(test[,2],1))),
                 max(train[,5]),min(test[,4]),rate,(variant==2)*sum(test[,12]:>test[,4])))
            p7_metrics(f,"CH25",name,y,p)
            if (name=="holdout") {
                delta=(y-p):^2-(y:-rate):^2
                perid=J(480,1,.)
                ids=uniqrows(sort(test[,2],1))
                for (j=1;j<=rows(ids);j++) perid[ids[j]]=mean(select(delta,test[,2]:==ids[j]))
                values=J(400,1,0)
                counts=J(400,1,0)
                for (j=1;j<=rows(draws);j++) {
                    k=draws[j,1]
                    assert(perid[draws[j,2]]<.)
                    values[k]=values[k]+draws[j,3]*perid[draws[j,2]]
                    counts[k]=counts[k]+draws[j,3]
                }
                assert(sum(counts:!=120)==0)
                values=values:/120
                for (j=1;j<=400;j++) p7_put(f,"CH25",name,"bootstrap",p7_id(j),values[j])
                p7_vec(f,"CH25",name,"scalar",("paired_delta","paired_lo","paired_hi"),
                    (mean(delta),p7_quantile(values,0.025),p7_quantile(values,0.975)))
            }
        }
    }
}

void p7_ch26(real scalar f, real matrix d, real matrix ens)
{
    real matrix train, valid, dev, test, s, x, v
    real colvector b, y, p, w, ii, ranking
    real rowvector loss, lam
    real scalar split, j, k, best, total, objective
    string rowvector names, models
    string scalar model
    dev=select(d,(d[,2]:!=0):*(d[,4]:!=-1))
    test=select(d,d[,2]:==0)
    lam=(0.005,0.03,0.12)
    loss=J(1,3,0)
    for (split=1;split<=3;split++) {
        train=select(dev,dev[,2]:!=split)
        valid=select(dev,dev[,2]:==split)
        s=p7_scaler(train[,6..11])
        x=p7_design(train[,6..11],s)
        v=p7_design(valid[,6..11],s)
        for (j=1;j<=3;j++) {
            b=p7_ridge(x,train[,4],train[,5],lam[j])
            total=sum(p7_loss(valid[,4],p7_p(v*b)))
            p7_put(f,"CH26","tuning","loss_sum",p7_id(split)+"/"+p7_id(j),total)
            loss[j]=loss[j]+total
        }
        p7_put(f,"CH26","tuning","validation_n",p7_id(split),rows(valid))
    }
    p7_vec(f,"CH26","tuning","mean_logloss",("1","2","3"),loss:/rows(dev))
    ranking=order(loss',1)
    best=ranking[1]
    names=("utilisation","volatility","late","history","ratio","thin")
    s=p7_scaler(dev[,6..11])
    x=p7_design(dev[,6..11],s)
    v=p7_design(test[,6..11],s)
    y=dev[,4]
    models=("ridge","class2")
    ii=selectindex(test[,4]:!=-1)
    for (k=1;k<=2;k++) {
        model=models[k]
        w=dev[,5]:*(1:+(k==2):*y)
        b=p7_ridge(x,y,w,lam[best])
        p=p7_p(v*b)
        objective=sum(w:*p7_loss(y,p7_p(x*b)))/sum(w)+lam[best]*sum(b[|2\rows(b)|]:^2)/2
        p7_emit_fit(f,"CH26",model,names,s,b)
        for (j=1;j<=rows(test);j++) p7_put(f,"CH26",model,"prediction",p7_id(test[j,1]),p[j])
        p7_vec(f,"CH26",model,"scalar",("chosen","lambda_value","n_train","weight_sum","objective"),
            (best,lam[best],rows(y),sum(w),objective))
        p7_metrics(f,"CH26",model,test[ii,4],p[ii])
    }
    assert(rows(ens)==rows(test) & sum(ens[,1]:!=test[,1])==0 & sum(ens[,2]:!=test[,4])==0)
    models=("py_forest","py_boost","r_forest","r_boost")
    for (j=1;j<=4;j++) p7_metrics(f,"CH26",models[j],ens[ii,2],ens[ii,j+2])
}

real rowvector p7_wilson(real scalar x, real scalar n)
{
    real scalar p, z, den, centre, half
    p=x/n
    z=1.96
    den=1+z^2/n
    centre=(p+z^2/(2*n))/den
    half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/den
    return((max((0,centre-half)),min((1,centre+half))))
}

void p7_ch27(real scalar f, real matrix pred)
{
    real matrix d, v
    real colvector bins
    real scalar j, g, tot, n, ev, non, yes, a, b, err
    real rowvector ts, cnt, tpr, fpr
    string scalar key
    d=select(pred,pred[,2]:!=-1)
    p7_vec(f,"CH27","audit","scalar",("n_all","missing_labels"),(rows(pred),rows(pred)-rows(d)))
    p7_metrics(f,"CH27","audit",d[,2],d[,4])
    bins=rowmin((floor(5:*d[,4]),J(rows(d),1,4))):+1
    err=0
    for (j=1;j<=5;j++) {
        v=select(d,bins:==j)
        n=rows(v)
        key=p7_id(j)
        p7_put(f,"CH27","audit","bin_n",key,n)
        if (n>0) {
            a=mean(v[,2])
            b=mean(v[,4])
            p7_put(f,"CH27","audit","bin_event_rate",key,a)
            p7_put(f,"CH27","audit","bin_mean_p",key,b)
            err=err+n*abs(a-b)
        }
    }
    p7_put(f,"CH27","audit","scalar","ece",err/rows(d))
    ts=(0.15,0.25,0.35)
    for (g=1;g<=3;g++) {
        v=select(d,d[,3]:==g)
        n=rows(v)
        tot=sum(pred[,3]:==g)
        ev=sum(v[,2])
        non=n-ev
        yes=(n>=25 & ev>=5 & non>=5)
        key=p7_id(g)
        p7_put(f,"CH27","audit","n_all",key,tot)
        p7_put(f,"CH27","audit","n",key,n)
        p7_put(f,"CH27","audit","events",key,ev)
        p7_put(f,"CH27","audit","non_events",key,non)
        p7_put(f,"CH27","audit","missing",key,tot-n)
        p7_put(f,"CH27","audit","publish",key,yes)
        if (yes) for (j=1;j<=3;j++) {
            cnt=p7_counts(v[,2],v[,4],ts[j])
            tpr=p7_wilson(cnt[1],ev)
            fpr=p7_wilson(cnt[2],non)
            key=p7_id(g)+"/"+p7_id(j)
            p7_put(f,"CH27","audit","group_tp",key,cnt[1])
            p7_put(f,"CH27","audit","group_fp",key,cnt[2])
            p7_put(f,"CH27","audit","group_tn",key,cnt[3])
            p7_put(f,"CH27","audit","group_fn",key,cnt[4])
            p7_put(f,"CH27","audit","group_tpr",key,cnt[1]/ev)
            p7_put(f,"CH27","audit","group_fpr",key,cnt[2]/non)
            p7_put(f,"CH27","audit","group_selection",key,(cnt[1]+cnt[2])/n)
            p7_put(f,"CH27","audit","group_tpr_lo",key,tpr[1])
            p7_put(f,"CH27","audit","group_tpr_hi",key,tpr[2])
            p7_put(f,"CH27","audit","group_fpr_lo",key,fpr[1])
            p7_put(f,"CH27","audit","group_fpr_hi",key,fpr[2])
        }
    }
}

real scalar p7_var(real colvector x)
{
    return(sum((x:-mean(x)):^2)/(rows(x)-1))
}

real matrix p7_plain(real matrix d)
{
    real matrix x, out
    real colvector tr, te, ii, y, a
    real scalar j, arm
    x=(J(rows(d),1,1),d[,3..6])
    out=(d[,1..2],J(rows(d),3,.))
    y=d[,8]
    a=d[,7]
    for (j=1;j<=4;j++) {
        tr=selectindex(d[,2]:!=j)
        te=selectindex(d[,2]:==j)
        out[te,3]=p7_p(x[te,]*p7_ridge(x[tr,],a[tr],J(rows(tr),1,1),0))
        for (arm=0;arm<=1;arm++) {
            ii=selectindex((d[,2]:!=j):*(a:==arm))
            out[te,arm+4]=x[te,]*qrsolve(x[ii,],y[ii])
        }
    }
    return(out)
}

void p7_ch28(real scalar f, real matrix d, real matrix u, string scalar model)
{
    real colvector a, y, e, m0, m1, score, ii, z, w1, w0, v, v1, v0
    real matrix groups
    real scalar j, n, se, effect, scale, treated
    string rowvector cols, samples
    string scalar key
    assert(rows(d)==rows(u) & sum(d[,1]:!=u[,1])==0 & sum(d[,2]:!=u[,2])==0)
    a=d[,7]
    y=d[,8]
    e=u[,3]
    m0=u[,4]
    m1=u[,5]
    assert(min(e)>0 & max(e)<1)
    score=m1-m0+a:*(y-m1):/e-(1:-a):*(y-m0):/(1:-e)
    for (j=1;j<=rows(d);j++) p7_put(f,"CH28",model,"score",p7_id(d[j,1]),score[j])
    groups=(J(rows(d),1,1),(e:>=0.10):*(e:<=0.90),d[,3]:==0,d[,3]:==1)
    samples=("all","trim","urban","rural")
    for (j=1;j<=4;j++) {
        ii=selectindex(groups[,j])
        z=score[ii]
        n=rows(z)
        effect=mean(z)
        se=sqrt(p7_var(z)/n)
        key=samples[j]
        p7_put(f,"CH28",model,"n",key,n)
        p7_put(f,"CH28",model,"ate",key,effect)
        p7_put(f,"CH28",model,"se",key,se)
        p7_put(f,"CH28",model,"lo",key,effect-1.96*se)
        p7_put(f,"CH28",model,"hi",key,effect+1.96*se)
        p7_put(f,"CH28",model,"truth",key,mean(d[ii,9]))
        ii=selectindex(d[,2]:==j)
        treated=sum(a[ii])
        key=p7_id(j)
        p7_put(f,"CH28",model,"fold_n",key,rows(ii))
        p7_put(f,"CH28",model,"fold_train",key,rows(d)-rows(ii))
        p7_put(f,"CH28",model,"fold_treat",key,treated)
        p7_put(f,"CH28",model,"fold_train_treat",key,sum(a)-treated)
        p7_put(f,"CH28",model,"fold_mean_e",key,mean(e[ii]))
    }
    w1=a:/e
    w0=(1:-a):/(1:-e)
    p7_vec(f,"CH28",model,"scalar",("naive","treated","e_min","e_max","e_mean","ess_t","ess_c"),
        (mean(select(y,a:==1))-mean(select(y,a:==0)),sum(a),min(e),max(e),mean(e),
         sum(w1)^2/sum(w1:^2),sum(w0)^2/sum(w0:^2)))
    cols=("rural","need","distance","baseline")
    for (j=1;j<=4;j++) {
        v=d[,j+2]
        v1=select(v,a:==1)
        v0=select(v,a:==0)
        scale=sqrt((p7_var(v1)+p7_var(v0))/2)
        p7_put(f,"CH28",model,"smd_raw",cols[j],(mean(v1)-mean(v0))/scale)
        p7_put(f,"CH28",model,"smd_ipw",cols[j],(sum(w1:*v)/sum(w1)-sum(w0:*v)/sum(w0))/scale)
    }
}
end

mata: p7_fh=fopen(st_local("output")+"/metrics.csv","w")
mata: fput(p7_fh,"chapter,model,quantity,key,value")

import delimited using `"`input'/customers25.csv"', clear varnames(1) asdouble
isid row_id
isid customer month
sort row_id
mata: p7_customers=st_data(.,1..12)
import delimited using `"`input'/splits25.csv"', clear varnames(1) asdouble
isid split row_id
sort split row_id
mata: p7_splits=st_data(.,1..3)
import delimited using `"`input'/bootstrap25.csv"', clear varnames(1) asdouble
isid draw customer
mata: p7_ch25(p7_fh,p7_customers,p7_splits,st_data(.,1..3))
display as text "Chapter 25 completed."

import delimited using `"`input'/credit26.csv"', clear varnames(1) asdouble
isid borrower
sort borrower
mata: p7_credit=st_data(.,1..11)
import delimited using `"`input'/ensemble26.csv"', clear varnames(1) asdouble
isid borrower
sort borrower
mata: p7_ch26(p7_fh,p7_credit,st_data(.,1..6))
display as text "Chapter 26 completed."

import delimited using `"`input'/credit_predictions.csv"', clear varnames(1) asdouble
isid borrower
sort borrower
mata: p7_ch27(p7_fh,st_data(.,1..5))
display as text "Chapter 27 completed."

import delimited using `"`input'/programme28.csv"', clear varnames(1) asdouble
isid person
sort person
mata: p7_programme=st_data(.,1..9)
import delimited using `"`input'/nuisance28.csv"', clear varnames(1) asdouble
isid person
sort person
mata: p7_ch28(p7_fh,p7_programme,st_data(.,1..5),"shared")
mata: p7_ch28(p7_fh,p7_programme,p7_plain(p7_programme),"plain")
display as text "Chapter 28 completed."
mata: fclose(p7_fh)
display as result "Part VII generated in Stata."
