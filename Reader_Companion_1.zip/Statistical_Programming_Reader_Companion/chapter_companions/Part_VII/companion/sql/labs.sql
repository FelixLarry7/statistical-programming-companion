-- Register the eight named input views and the Python prediction ledger first.
CREATE VIEW fold_rules AS
SELECT * FROM (VALUES
    (1, 1, 7, 'split1'), (2, 2, 8, 'split2'),
    (3, 3, 9, 'split3'), (4, 0, 11, 'holdout')
) AS v(split, held, origin, model);

CREATE VIEW customer_roles AS
SELECT f.split, f.model, c.*,
       CASE
           WHEN c.cohort = f.held AND c.month BETWEEN f.origin AND f.origin + 1 THEN 2
           WHEN c.cohort <> 0 AND c.cohort <> f.held AND c.label_month <= f.origin THEN 1
       END AS role
FROM customers25 c CROSS JOIN fold_rules f
WHERE role IS NOT NULL;

CREATE VIEW customer_fit_rows AS
SELECT model, row_id, outcome, customer, month, label_month, 0 AS future_violation
FROM customer_roles WHERE role = 1
UNION ALL
SELECT 'leaked', row_id, outcome, customer, month, label_month, 0
FROM customer_roles WHERE model = 'holdout' AND role = 1;

CREATE VIEW customer_fit_counts AS
SELECT model, count(*) AS n_train, count(DISTINCT customer) AS n_train_id,
       max(label_month) AS last_label_month, avg(outcome) AS train_rate
FROM customer_fit_rows GROUP BY model;

CREATE VIEW customer_validation_counts AS
SELECT model, count(DISTINCT customer) AS n_test_id, min(month) AS first_test_month,
       0 AS future_violations
FROM customer_roles WHERE role = 2 GROUP BY model
UNION ALL
SELECT 'leaked', count(DISTINCT customer), min(month), count_if(future_month > month)
FROM customer_roles WHERE model = 'holdout' AND role = 2;

CREATE VIEW customer_feature_values AS
SELECT r.model, p.feature, p.x
FROM customer_roles r
CROSS JOIN LATERAL (VALUES
    ('tenure', r.tenure), ('spend', r.spend),
    ('contacts', r.contacts), ('decline', r.decline)
) p(feature,x)
WHERE r.role = 1
UNION ALL
SELECT 'leaked', p.feature, p.x
FROM customer_roles r
CROSS JOIN LATERAL (VALUES
    ('tenure', r.tenure), ('spend', r.spend), ('contacts', r.contacts),
    ('decline', r.decline), ('future', r.future)
) p(feature,x)
WHERE r.role = 1 AND r.model = 'holdout';

CREATE VIEW credit_feature_values AS
SELECT m.model, p.feature, p.x
FROM credit26 r
CROSS JOIN (VALUES ('ridge'), ('class2')) m(model)
CROSS JOIN LATERAL (VALUES
    ('utilisation', r.utilisation), ('volatility', r.volatility),
    ('late', r.late), ('history', r.history),
    ('ratio', r.ratio), ('thin', r.thin)
) p(feature,x)
WHERE r.fold <> 0 AND r.outcome <> -1;

CREATE VIEW feature_statistics AS
WITH values_long AS (
    SELECT 'CH25' AS chapter, * FROM customer_feature_values
    UNION ALL SELECT 'CH26', * FROM credit_feature_values
), filled AS (
    SELECT *, median(x) OVER (PARTITION BY chapter, model, feature) AS med
    FROM values_long
)
SELECT chapter, model, feature, max(med) AS median,
       avg(coalesce(x,med)) AS centre,
       CASE WHEN stddev_pop(coalesce(x,med)) = 0 THEN 1
            ELSE stddev_pop(coalesce(x,med)) END AS scale
FROM filled GROUP BY chapter, model, feature;

CREATE VIEW scoring_rows AS
SELECT 'CH25' AS chapter, m.model, d.row_id AS id, d.customer AS entity,
       d.outcome AS y, m.value AS p
FROM python_metrics m JOIN customers25 d ON try_cast(m.key AS BIGINT) = d.row_id
WHERE m.chapter = 'CH25' AND m.quantity = 'prediction'
UNION ALL
SELECT 'CH26', s.model, c.borrower, c.borrower, c.outcome, s.p
FROM credit_predictions c
CROSS JOIN LATERAL (VALUES ('ridge', c.ridge), ('class2', c.class2)) s(model,p)
WHERE c.outcome IN (0,1)
UNION ALL
SELECT 'CH26', s.model, e.borrower, e.borrower, e.outcome, s.p
FROM ensemble26 e CROSS JOIN LATERAL (VALUES
  ('py_forest', e.py_forest), ('py_boost', e.py_boost),
  ('r_forest', e.r_forest), ('r_boost', e.r_boost)
) s(model,p)
WHERE e.outcome IN (0,1)
UNION ALL
SELECT 'CH27', 'audit', borrower, borrower, outcome, ridge
FROM credit_predictions WHERE outcome IN (0,1);

CREATE VIEW scores AS
WITH grouped AS (
    SELECT chapter, model, p, sum(y) AS pos, count(*) - sum(y) AS neg
    FROM scoring_rows GROUP BY chapter, model, p
), cumulative AS (
    SELECT *,
      sum(neg) OVER (PARTITION BY chapter,model ORDER BY p ROWS UNBOUNDED PRECEDING) AS neg_below_tied,
      sum(pos) OVER (PARTITION BY chapter,model ORDER BY p DESC ROWS UNBOUNDED PRECEDING) AS pos_above_tied,
      sum(pos+neg) OVER (PARTITION BY chapter,model ORDER BY p DESC ROWS UNBOUNDED PRECEDING) AS n_above_tied
    FROM grouped
), ranks AS (
    SELECT chapter, model, sum(pos * (neg_below_tied-neg/2.0))/(sum(pos)*sum(neg)) AS auc,
           sum(pos * pos_above_tied/n_above_tied)/sum(pos) AS ap
    FROM cumulative GROUP BY chapter,model
), pointwise AS (
    SELECT chapter,model,count(*) AS n,sum(y) AS events,avg(y) AS prevalence,avg(p) AS mean_p,
           avg(power(y-p,2)) AS brier,
           avg(-y*ln(greatest(1e-12,p))-(1-y)*ln(greatest(1e-12,1-p))) AS logloss,
           count_if(y=1 AND p>=0.25) AS tp,count_if(y=0 AND p>=0.25) AS fp,
           count_if(y=0 AND p<0.25) AS tn,count_if(y=1 AND p<0.25) AS fn
    FROM scoring_rows GROUP BY chapter,model
)
SELECT pointwise.*, ranks.auc, ranks.ap FROM pointwise JOIN ranks USING (chapter,model);

CREATE VIEW customer_delta AS
SELECT s.id,s.entity,
       power(s.y-s.p,2)-power(s.y-c.train_rate,2) AS delta
FROM scoring_rows s JOIN customer_fit_counts c USING (model)
WHERE s.chapter='CH25' AND s.model='holdout';

CREATE VIEW bootstrap_values AS
WITH paired AS (SELECT entity, avg(delta) AS delta FROM customer_delta GROUP BY entity)
SELECT b.draw, sum(b.multiplicity*p.delta)/sum(b.multiplicity) AS value,
       sum(b.multiplicity) AS weight
FROM bootstrap25 b JOIN paired p ON b.customer=p.entity
GROUP BY b.draw;

CREATE VIEW credit_fit_counts AS
SELECT 'ridge' AS model, count(*) AS n_train, sum(weight) AS weight_sum
FROM credit26 WHERE fold<>0 AND outcome IN (0,1)
UNION ALL
SELECT 'class2', count(*), sum(weight*(1+outcome))
FROM credit26 WHERE fold<>0 AND outcome IN (0,1);

CREATE VIEW calibration_bins AS
SELECT b.bin,count(c.borrower) AS bin_n, avg(c.ridge) AS bin_mean_p,
       avg(c.outcome) AS bin_event_rate
FROM range(1,6) b(bin)
LEFT JOIN credit_predictions c ON c.outcome IN (0,1)
    AND b.bin=least(5,1+floor(5*c.ridge))
GROUP BY b.bin;

CREATE VIEW group_coverage AS
SELECT audit_group, count(*) AS n_all,count_if(outcome IN (0,1)) AS n,
       count_if(outcome=1) AS events,count_if(outcome=0) AS non_events,
       count_if(outcome=-1) AS missing,
       CAST(n>=25 AND events>=5 AND non_events>=5 AS INT) AS publish
FROM credit_predictions GROUP BY audit_group;

CREATE VIEW group_thresholds AS
WITH threshold_values AS (
  SELECT * FROM (VALUES (1,0.15),(2,0.25),(3,0.35)) t(t_index,threshold)
), counts AS (
  SELECT c.audit_group,t_index,max(n) AS n,max(events) AS events,max(non_events) AS non_events,
         count_if(c.outcome=1 AND ridge>=threshold) AS tp,
         count_if(c.outcome=0 AND ridge>=threshold) AS fp,
         count_if(c.outcome=0 AND ridge<threshold) AS tn,
         count_if(c.outcome=1 AND ridge<threshold) AS fn
  FROM credit_predictions c JOIN group_coverage g USING (audit_group)
  CROSS JOIN threshold_values WHERE publish=1
  GROUP BY c.audit_group,t_index
), rates AS (
  SELECT *,tp/events AS tpr,fp/non_events AS fpr,(tp+fp)/n AS selection
  FROM counts
), intervals AS (
  SELECT *,
    (tpr+1.96^2/(2*events))/(1+1.96^2/events) AS c_tpr,
    (fpr+1.96^2/(2*non_events))/(1+1.96^2/non_events) AS c_fpr,
    1.96*sqrt(tpr*(1-tpr)/events+1.96^2/(4*events^2))/(1+1.96^2/events) AS h_tpr,
    1.96*sqrt(fpr*(1-fpr)/non_events+1.96^2/(4*non_events^2))/(1+1.96^2/non_events) AS h_fpr
  FROM rates
)
SELECT audit_group,t_index,tp,fp,tn,fn,tpr,fpr,selection,
       greatest(0,c_tpr-h_tpr) AS tpr_lo,least(1,c_tpr+h_tpr) AS tpr_hi,
       greatest(0,c_fpr-h_fpr) AS fpr_lo,least(1,c_fpr+h_fpr) AS fpr_hi
FROM intervals;

CREATE VIEW causal_scores AS
SELECT d.*,n.e,n.m0,n.m1,n.m1-n.m0 + d.treated*(d.outcome-n.m1)/n.e
       - (1-d.treated)*(d.outcome-n.m0)/(1-n.e) AS psi,
       d.treated/n.e AS w_t,(1-d.treated)/(1-n.e) AS w_c
FROM programme28 d JOIN nuisance28 n USING (person,fold);

CREATE VIEW causal_summaries AS
SELECT p.sample,count(*) AS n,avg(c.psi) AS ate,stddev_samp(c.psi)/sqrt(count(*)) AS se,
       ate-1.96*se AS lo,ate+1.96*se AS hi,avg(c.true_effect) AS truth
FROM causal_scores c CROSS JOIN LATERAL (VALUES
   ('all', true), ('trim', c.e BETWEEN 0.10 AND 0.90),
   ('urban', c.rural=0), ('rural', c.rural=1)
) p(sample,keep)
WHERE p.keep GROUP BY p.sample;

CREATE VIEW causal_balance AS
WITH long AS (
    SELECT p.feature,p.x,s.treated,s.w_t,s.w_c
    FROM causal_scores s CROSS JOIN LATERAL (VALUES
      ('rural',s.rural),('need',s.need),('distance',s.distance),('baseline',s.baseline)
    ) p(feature,x)
), grouped AS (
    SELECT feature,avg(x) FILTER (WHERE treated=1)-avg(x) FILTER (WHERE treated=0) AS diff,
           sqrt((var_samp(x) FILTER (WHERE treated=1)+var_samp(x) FILTER (WHERE treated=0))/2) AS sd_pool,
           sum(x*w_t)/sum(w_t)-sum(x*w_c)/sum(w_c) AS diff_ipw
    FROM long GROUP BY feature
)
SELECT feature,diff/sd_pool AS smd_raw,diff_ipw/sd_pool AS smd_ipw FROM grouped;
