"""Reference Python analysis for the four aligned Part VII labs."""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ledger import Ledger


CUSTOMER = ["tenure", "spend", "contacts", "decline"]
CREDIT = ["utilisation", "volatility", "late", "history", "ratio", "thin"]
LAMBDAS = (0.005, 0.03, 0.12)
THRESHOLDS = (0.15, 0.25, 0.35)
EPSILON = 1e-12


def sigmoid(eta):
    return 1 / (1 + np.exp(-np.clip(eta, -40, 40)))


def design(x, median, centre, scale):
    filled = np.where(np.isnan(x), median, x)
    return np.column_stack((np.ones(len(x)), (filled - centre) / scale))


def fit_scaler(x):
    median = np.nanmedian(x, axis=0)
    if not np.isfinite(median).all():
        raise ValueError("Every feature must have an observed training value.")
    filled = np.where(np.isnan(x), median, x)
    scale = filled.std(axis=0, ddof=0)
    return median, filled.mean(axis=0), np.where(scale == 0, 1, scale)


def fit_ridge(x, y, weight, lam):
    """Newton solve for weighted mean log loss plus lam * ||slopes||^2 / 2."""
    w = weight / weight.sum()
    beta = np.zeros(x.shape[1])
    penalty = np.diag([0, *([lam] * (x.shape[1] - 1))])
    for _ in range(50):
        p = sigmoid(x @ beta)
        g = x.T @ (w * (p - y)) + penalty @ beta
        h = x.T @ ((w * p * (1 - p))[:, None] * x) + penalty
        step = np.linalg.solve(h, g)
        beta -= step
        if np.max(np.abs(step)) < 1e-10:
            return beta
    raise ArithmeticError("The ridge Newton solver did not converge.")


def logistic_objective(x, y, w, b, lam):
    eta = x @ b
    return np.average(np.logaddexp(0, eta) - y * eta, weights=w) + lam * (b[1:] @ b[1:]) / 2


def log_losses(y, p):
    p = np.clip(p, EPSILON, 1 - EPSILON)
    return -y * np.log(p) - (1 - y) * np.log1p(-p)


def confusion(y, p, threshold):
    flag = p >= threshold
    return dict(tp=np.sum(flag & (y == 1)), fp=np.sum(flag & (y == 0)),
                tn=np.sum(~flag & (y == 0)), fn=np.sum(~flag & (y == 1)))


def scoring(y, p, threshold=0.25):
    if len(y) != len(p) or not np.isfinite(p).all() or not np.isin(y, (0, 1)).all():
        raise ValueError("Scoring requires matched probabilities and observed binary labels.")
    positives = y.sum()
    negatives = len(y) - positives
    if not positives or not negatives:
        raise ValueError("AUC and average precision require both classes here.")
    rank = np.argsort(p, kind="stable")
    p_sorted, y_sorted = p[rank], y[rank]
    start = np.r_[0, 1 + np.flatnonzero(p_sorted[1:] != p_sorted[:-1])]
    counts = np.diff(np.r_[start, len(y)])
    pos = np.add.reduceat(y_sorted, start)
    neg = counts - pos
    auc = np.sum(pos * (np.cumsum(neg) - neg / 2)) / (positives * negatives)
    precision = np.cumsum(pos[::-1]) / np.cumsum(counts[::-1])
    ap = np.sum(pos[::-1] * precision) / positives
    return dict(n=len(y), events=positives, prevalence=np.mean(y),
                mean_p=np.mean(p), brier=np.mean((y - p)**2),
                logloss=np.mean(log_losses(y, p)), auc=auc, ap=ap,
                **confusion(y, p, threshold))


def emit_model(m, columns, scaler, beta):
    for name, values in zip(("median", "centre", "scale"), scaler, strict=True):
        m.vector(name, columns, values)
    m.vector("beta", ["intercept", *columns], beta)


def customer_lab(data, ledger):
    d = pd.read_csv(data / "customers25.csv")
    manifest = pd.read_csv(data / "splits25.csv")
    draws = pd.read_csv(data / "bootstrap25.csv")
    assert d.row_id.is_unique and not d.duplicated(["customer", "month"]).any()
    for split in range(1, 5):
        held, origin = (split, 6 + split) if split < 4 else (0, 11)
        train = d[(d.cohort != 0) & (d.cohort != held) & (d.label_month <= origin)]
        test = d[(d.cohort == held) & d.month.between(origin, origin + 1)]
        keys = manifest[manifest.split == split]
        assert np.array_equal(train.row_id, keys.loc[keys.role == 1, "row_id"])
        assert np.array_equal(test.row_id, keys.loc[keys.role == 2, "row_id"])
        assert not set(train.customer) & set(test.customer)
        assert train.label_month.max() <= test.month.min()
        model = f"split{split}" if split < 4 else "holdout"
        for variant in (model, "leaked") if split == 4 else (model,):
            cols = CUSTOMER + (["future"] if variant == "leaked" else [])
            scaler = fit_scaler(train[cols].to_numpy())
            x = design(train[cols].to_numpy(), *scaler)
            y = train.outcome.to_numpy()
            b = fit_ridge(x, y, np.ones(len(y)), 0.04)
            p = sigmoid(design(test[cols].to_numpy(), *scaler) @ b)
            target = test.outcome.to_numpy()
            m = ledger.model("CH25", variant)
            emit_model(m, cols, scaler, b)
            m.vector("prediction", test.row_id, p)
            m.scalars(n_train=len(y), n_train_id=train.customer.nunique(),
                      n_test_id=test.customer.nunique(), last_label_month=train.label_month.max(),
                      first_test_month=test.month.min(), train_rate=y.mean(),
                      future_violations=np.sum(test.future_month > test.month) if variant == "leaked" else 0,
                      **scoring(target, p))
            if variant == "holdout":
                delta = (target - p)**2 - (target - y.mean())**2
                by_id = pd.Series(delta).groupby(test.customer.to_numpy()).mean().rename("delta")
                joined = draws.join(by_id, on="customer", validate="many_to_one")
                assert joined.delta.notna().all() and (joined.groupby("draw").multiplicity.sum() == 120).all()
                values = (joined.delta * joined.multiplicity).groupby(joined.draw).sum() / 120
                m.vector("bootstrap", values.index, values.to_numpy())
                lo, hi = np.quantile(values, (0.025, 0.975))
                m.scalars(paired_delta=delta.mean(), paired_lo=lo, paired_hi=hi)


def credit_lab(data, ledger):
    d = pd.read_csv(data / "credit26.csv")
    assert d.borrower.is_unique
    labelled = d[d.outcome != -1]
    dev, test = labelled[labelled.fold != 0], d[d.fold == 0]
    tlabel = test.outcome != -1
    objectives = np.zeros(len(LAMBDAS))
    tune = ledger.model("CH26", "tuning")
    for split in range(1, 4):
        train, validation = dev[dev.fold != split], dev[dev.fold == split]
        scale = fit_scaler(train[CREDIT].to_numpy())
        x = design(train[CREDIT].to_numpy(), *scale)
        v = design(validation[CREDIT].to_numpy(), *scale)
        for j, lam in enumerate(LAMBDAS, 1):
            b = fit_ridge(x, train.outcome.to_numpy(), train.weight.to_numpy(), lam)
            loss = log_losses(validation.outcome.to_numpy(), sigmoid(v @ b)).sum()
            tune.add("loss_sum", f"{split}/{j}", loss)
            objectives[j - 1] += loss
        tune.add("validation_n", split, len(validation))
    tune.vector("mean_logloss", range(1, 4), objectives / len(dev))
    best = int(np.argmin(objectives))
    scaler = fit_scaler(dev[CREDIT].to_numpy())
    x = design(dev[CREDIT].to_numpy(), *scaler)
    v = design(test[CREDIT].to_numpy(), *scaler)
    y = dev.outcome.to_numpy()
    results = test[["borrower", "outcome", "audit_group"]].copy()
    for model, weight in (("ridge", dev.weight.to_numpy()),
                          ("class2", dev.weight.to_numpy() * (1 + y))):
        b = fit_ridge(x, y, weight, LAMBDAS[best])
        p = sigmoid(v @ b)
        m = ledger.model("CH26", model)
        emit_model(m, CREDIT, scaler, b)
        m.vector("prediction", test.borrower, p)
        m.scalars(chosen=best + 1, lambda_value=LAMBDAS[best],
                  n_train=len(y), weight_sum=weight.sum(),
                  objective=logistic_objective(x, y, weight, b, LAMBDAS[best]),
                  **scoring(test.outcome.to_numpy()[tlabel], p[tlabel]))
        results[model] = p
    return results


def wilson(success, total):
    q = success / total
    z = 1.96
    centre = (q + z*z / (2 * total)) / (1 + z*z / total)
    half = z * np.sqrt(q * (1 - q) / total + z*z / (4 * total**2)) / (1 + z*z / total)
    return max(0, centre - half), min(1, centre + half)


def diagnostics_lab(pred, ledger):
    assert pred.borrower.is_unique and np.isin(pred.outcome, (-1, 0, 1)).all()
    assert pred.ridge.between(0, 1).all()
    m = ledger.model("CH27", "audit")
    d = pred[pred.outcome != -1]
    m.scalars(n_all=len(pred), missing_labels=len(pred)-len(d),
              **scoring(d.outcome.to_numpy(), d.ridge.to_numpy()))
    bins = np.minimum(np.floor(5 * d.ridge.to_numpy()).astype(int), 4)
    error = 0.0
    for j in range(5):
        sub = d[bins == j]
        m.add("bin_n", j+1, len(sub))
        if len(sub):
            y, p = sub.outcome.mean(), sub.ridge.mean()
            m.add("bin_event_rate", j+1, y)
            m.add("bin_mean_p", j+1, p)
            error += len(sub) * abs(y-p)
    m.scalars(ece=error / len(d))
    for group in (1, 2, 3):
        sub = d[d.audit_group == group]
        total = (pred.audit_group == group).sum()
        y, p = sub.outcome.to_numpy(), sub.ridge.to_numpy()
        positives, negatives = y.sum(), len(y) - y.sum()
        eligible = len(sub) >= 25 and positives >= 5 and negatives >= 5
        for name, value in dict(n_all=total, n=len(sub), events=positives,
                                non_events=negatives, missing=total-len(sub),
                                publish=int(eligible)).items():
            m.add(name, group, value)
        if eligible:
            for j, t in enumerate(THRESHOLDS, 1):
                values = confusion(y, p, t)
                tp, fp = values["tp"], values["fp"]
                tpr_lo, tpr_hi = wilson(tp, positives)
                fpr_lo, fpr_hi = wilson(fp, negatives)
                values.update(tpr=tp/positives, fpr=fp/negatives,
                              selection=(tp+fp)/len(sub), tpr_lo=tpr_lo, tpr_hi=tpr_hi,
                              fpr_lo=fpr_lo, fpr_hi=fpr_hi)
                for name, value in values.items():
                    m.add("group_" + name, f"{group}/{j}", value)


def nuisance(d, *, rich=True):
    columns = ["rural", "need", "distance", "baseline"]
    raw = d[columns].to_numpy()
    if rich:
        raw = np.column_stack((raw, d.need**2, d.need*d.rural))
    y, a = d.outcome.to_numpy(), d.treated.to_numpy()
    result = d[["person", "fold"]].copy()
    result[["e", "m0", "m1"]] = np.nan
    for k in range(1, 5):
        test = d.fold.to_numpy() == k
        scaler = fit_scaler(raw[~test])
        x = design(raw[~test], *scaler)
        z = design(raw[test], *scaler)
        lam = 0.008 if rich else 0
        b = fit_ridge(x, a[~test], np.ones(len(x)), lam)
        result.loc[test, "e"] = sigmoid(z @ b)
        for arm in (0, 1):
            active = a[~test] == arm
            coefficients = np.linalg.lstsq(x[active], y[~test][active], rcond=None)[0]
            result.loc[test, f"m{arm}"] = z @ coefficients
    assert result.notna().all().all()
    return result


def score28(d, frozen, ledger, name="shared"):
    x = d.merge(frozen, on=["person", "fold"], validate="one_to_one")
    assert len(x) == len(d)
    a, y, e = (x[name].to_numpy() for name in ("treated", "outcome", "e"))
    assert np.all((e > 0) & (e < 1))
    m0, m1 = x.m0.to_numpy(), x.m1.to_numpy()
    score = m1-m0 + a*(y-m1)/e - (1-a)*(y-m0)/(1-e)
    m = ledger.model("CH28", name)
    m.vector("score", x.person, score)
    for sample, keep in (("all", np.ones(len(x), dtype=bool)),
                         ("trim", (e >= 0.10) & (e <= 0.90)),
                         ("urban", x.rural == 0), ("rural", x.rural == 1)):
        v = score[keep]
        se = v.std(ddof=1) / np.sqrt(len(v))
        vals = dict(n=len(v), ate=v.mean(), se=se, lo=v.mean()-1.96*se,
                    hi=v.mean()+1.96*se, truth=x.true_effect.to_numpy()[keep].mean())
        for quantity, value in vals.items():
            m.add(quantity, sample, value)
    for k in range(1, 5):
        held = x.fold == k
        train = ~held
        for quantity, value in dict(fold_n=held.sum(), fold_train=train.sum(),
                                    fold_treat=a[held].sum(), fold_train_treat=a[train].sum(),
                                    fold_mean_e=e[held].mean()).items():
            m.add(quantity, k, value)
    treated_w, control_w = a/e, (1-a)/(1-e)
    m.scalars(naive=y[a == 1].mean()-y[a == 0].mean(), treated=a.sum(),
              e_min=e.min(), e_max=e.max(), e_mean=e.mean(),
              ess_t=treated_w.sum()**2/(treated_w@treated_w),
              ess_c=control_w.sum()**2/(control_w@control_w))
    for column in ("rural", "need", "distance", "baseline"):
        v = x[column].to_numpy()
        scale = np.sqrt((v[a == 1].var(ddof=1) + v[a == 0].var(ddof=1))/2)
        m.add("smd_raw", column, (v[a == 1].mean()-v[a == 0].mean())/scale)
        m.add("smd_ipw", column, (np.average(v, weights=treated_w)-np.average(v, weights=control_w))/scale)


def write_frame(frame, path):
    frame.to_csv(path, index=False, lineterminator="\n", float_format="%.15g")


def assert_frame(actual, frozen, keys):
    assert list(actual.columns) == list(frozen.columns)
    assert np.array_equal(actual[keys], frozen[keys])
    numeric = [c for c in actual.columns if c not in keys]
    assert np.allclose(actual[numeric], frozen[numeric], atol=2e-12, rtol=2e-12)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("data", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--freeze", action="store_true")
    args = ap.parse_args()
    data, out = args.data, args.output
    out.mkdir(parents=True, exist_ok=True)
    ledger = Ledger()
    customer_lab(data, ledger)
    credit = credit_lab(data, ledger)
    d = pd.read_csv(data / "programme28.csv")
    shared = nuisance(d)
    if args.freeze:
        write_frame(credit, data / "credit_predictions.csv")
        write_frame(shared, data / "nuisance28.csv")
    pred = pd.read_csv(data / "credit_predictions.csv")
    shared_disk = pd.read_csv(data / "nuisance28.csv")
    assert_frame(credit, pred, ["borrower", "outcome", "audit_group"])
    assert_frame(shared, shared_disk, ["person", "fold"])
    diagnostics_lab(pred, ledger)
    score28(d, shared_disk, ledger)
    score28(d, nuisance(d, rich=False), ledger, "plain")
    if (data / "ensemble26.csv").exists():
        ensembles = pd.read_csv(data / "ensemble26.csv")
        assert ensembles.borrower.equals(pred.borrower)
        assert ensembles.outcome.equals(pred.outcome)
        labelled = ensembles.outcome != -1
        for model in ensembles.columns[2:]:
            ledger.model("CH26", model).scalars(**scoring(
                ensembles.loc[labelled, "outcome"].to_numpy(), ensembles.loc[labelled, model].to_numpy()))
    ledger.save(out / "metrics.csv")
    print(f"Python {np.__version__=} {pd.__version__=} {len(ledger.rows)} keyed values")


if __name__ == "__main__":
    main()
