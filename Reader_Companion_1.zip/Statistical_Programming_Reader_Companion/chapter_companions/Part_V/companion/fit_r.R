# Part V statistical labs. Base R, without external packages.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
read <- function(stem) read.csv(file.path(args[1], paste0(stem, ".csv")))
ledger <- list()
put <- function(ch, model, quantity, key, value) {
    stopifnot(length(key) == length(value), all(is.finite(value)))
    ledger[[length(ledger)+1L]] <<- data.frame(chapter=ch, model=model,
        quantity=quantity, key=as.character(key), value=as.numeric(value))
}
lab <- function(ch, model) function(q, k, v) put(ch, model, q, k, v)
scalar <- function(add, ...) {
    a <- unlist(lapply(list(...), unname))
    add("scalar", names(a), a)
}
ols <- function(x, y) qr.coef(qr(x), y)
hc0 <- function(x, u, w=rep(1,nrow(x))) {
    b <- solve(crossprod(x,x*w))
    b %*% crossprod(x*(w*u)) %*% b
}

trial <- function() {
    roster <- read("households17")
    v <- read("villages17")
    stopifnot(!anyDuplicated(roster$household), !anyDuplicated(v$village))
    d <- subset(roster, eligible==1)
    stopifnot(all(d$baseline_wave<d$outcome_wave), all(!is.na(d$admin)),
              all(is.na(d$survey)==(d$measured==0)))
    d$n <- 1
    d$survey[is.na(d$survey)] <- 0
    c <- merge(v,aggregate(cbind(n,baseline,admin,receipt,measured,survey)~village,d,sum),
               by="village",sort=TRUE)
    z <- c$offer
    a <- read("allocations17")
    perm <- as.matrix(a[-1])
    stopifnot(all(c$n==8), !anyDuplicated(perm), nrow(perm)==400L,
              all(rowSums(perm[,1:6])==3), all(rowSums(perm[,7:12])==3),
              sum(rowSums(abs(sweep(perm,2,z)))==0)==1L)
    n <- sum(z*c$n)
    num <- 2*sum(z*c$admin)-sum(c$admin)
    draws <- as.vector(2*perm %*% c$admin-sum(c$admin))
    ext <- sum(abs(draws)>=abs(num))
    add <- lab("CH17","trial")
    scalar(add,roster=nrow(roster),n=nrow(d),villages=nrow(c),treated_villages=sum(z),
           itt=num/n,permutations=nrow(perm),extreme=ext,ri_p=ext/nrow(perm))
    add("permutation",a$draw,draws/n)
    add("village_mean",c$village,c$admin/c$n)
    a <- aggregate(cbind(n,baseline,admin,receipt,measured,survey)~offer,c,sum)
    for (j in 1:2) {
        add("arm_n",j-1,a$n[j])
        add("arm_measured",j-1,a$measured[j])
        add("arm_baseline",j-1,a$baseline[j]/a$n[j])
        add("arm_admin",j-1,a$admin[j]/a$n[j])
        add("arm_survey",j-1,a$survey[j]/a$measured[j])
    }
    lo <- a$survey/a$n
    hi <- (a$survey+100*(a$n-a$measured))/a$n
    v <- 0
    for (h in 1:2) {
        yy <- c$admin/c$n
        y1 <- yy[c$block==h & z==1]
        y0 <- yy[c$block==h & z==0]
        add("block_itt",h,mean(y1)-mean(y0))
        v <- v+(var(y1)/length(y1)+var(y0)/length(y0))/4
    }
    fs <- diff(a$receipt/a$n)
    de <- 1+7*.1
    scalar(add,se_neyman=sqrt(v),receipt_itt=fs,wald=num/n/fs,
           response_itt=diff(a$measured/a$n),bound_low=lo[2]-hi[1],
           bound_high=hi[2]-lo[1],design_effect=de,mde=sum(qnorm(c(.975,.8)))*10*sqrt(4*de/96))
}
rollout <- function() {
    d <- subset(read("rollout18"),in_scope==1)
    d <- d[order(d$unit,d$period),]
    stopifnot(nrow(d)==390,all(d$period==rep(0:9,39)),!anyDuplicated(d[c("unit","period")]))
    unit <- d[!duplicated(d$unit),]
    g <- unit$cohort
    x <- unit$x
    y <- matrix(d$outcome,39,10,byrow=TRUE)
    draws <- read("multipliers18")
    for (model in c("never","notyet","risky")) {
        add <- lab("CH18",model)
        a <- as.integer(model!="risky")
        n <- effect <- numeric(14)
        influence <- matrix(0,39,14)
        for (c0 in c(3,5,7)) {
            base <- c0-a-1
            target <- g==c0
            nt <- sum(target)
            for (t in setdiff(0:9,base)) {
                control <- g==0 | (model!="never" & g!=c0 & g>max(t,base)+a)
                change <- y[,t+1]-y[,base+1]
                key <- paste(c0,t,sep="/")
                add("target_n",key,nt)
                add("control_n",key,sum(control))
                add("raw",key,mean(change[target])-mean(change[control]))
                tau <- 0
                psi <- numeric(39)
                for (cov in 0:1) {
                    gt <- target & x==cov
                    gc <- control & x==cov
                    stopifnot(any(gt),any(gc))
                    sh <- sum(gt)/nt
                    mt <- mean(change[gt])
                    mc <- mean(change[gc])
                    tau <- tau+sh*(mt-mc)
                    psi[gt] <- sh*(change[gt]-mt)/sum(gt)
                    psi[gc] <- -sh*(change[gc]-mc)/sum(gc)
                    add("support",paste(key,cov,sep="/"),sum(gc))
                }
                add("att",key,tau)
                k <- t-c0+8
                effect[k] <- effect[k]+nt*tau
                n[k] <- n[k]+nt
                influence[,k] <- influence[,k]+nt*psi
            }
        }
        k <- which(n>0)
        add("event_n",k-8,n[k])
        add("event_att",k-8,effect[k]/n[k])
        if (model=="notyet") {
            k <- 8:10
            psi <- sweep(influence[,k],2,n[k],"/")
            se <- sqrt(colSums(psi^2))
            maximum <- apply(abs(sweep(as.matrix(draws[-1])%*%psi,2,se,"/")),1,max)
            q <- sort(maximum)[190]
            band <- lab("CH18","band")
            scalar(band,critical=q)
            band("max_t",draws$draw,maximum)
            band("se",0:2,se)
            band("low",0:2,effect[k]/n[k]-q*se)
            band("high",0:2,effect[k]/n[k]+q*se)
        }
    }
    k <- d$period-d$cohort
    use <- d$cohort>0
    d$pre <- as.integer(use & k<=-3)
    d$anticip <- as.integer(use & k==-1)
    d$k0 <- as.integer(use & k==0)
    d$k1 <- as.integer(use & k==1)
    d$k2 <- as.integer(use & k==2)
    d$tail <- as.integer(use & k>=3)
    b <- coef(lm(outcome~pre+anticip+k0+k1+k2+tail+factor(unit)+factor(period),d))
    terms <- c("pre","anticip","k0","k1","k2","tail")
    put("CH18","twfe","beta",terms,b[terms])
}
instruments <- function() {
    d <- read("encourage19")
    w <- cbind(1,d$x)
    z <- cbind(w,d$z)
    for (model in c("strong","weak")) {
        dose <- if (model=="strong") d$dose else d$weak
        y <- if (model=="strong") d$outcome else d$weak_outcome
        x <- cbind(w,dose)
        xp <- z%*%ols(z,x)
        beta <- ols(xp,y)
        first <- ols(z,dose)
        reduced <- ols(z,y)
        v <- hc0(xp,as.vector(y-x%*%beta))
        f <- first[3]^2/hc0(z,as.vector(dose-z%*%first))[3,3]
        add <- lab("CH19",model)
        scalar(add,n=nrow(x),first=first[3],reduced=reduced[3],first_t2=f,
               effect=beta[3],se_hc0=sqrt(v[3,3]))
        for (q in -40:48) {
            u <- y-q*dose/4
            b <- ols(z,u)
            a <- b[3]^2/hc0(z,as.vector(u-z%*%b))[3,3]
            add("ar_stat",q,a)
            add("ar_p",q,pchisq(a,1,lower.tail=FALSE))
        }
    }
    x <- cbind(w,d$dose)
    z <- cbind(w,d$z,d$z2)
    y <- d$outcome
    n <- length(y)
    a <- crossprod(z,x)/n
    b <- crossprod(z,y)/n
    w <- solve(crossprod(z)/n)
    add <- lab("CH19","gmm")
    for (s in 1:2) {
        beta <- solve(crossprod(a,w%*%a),crossprod(a,w%*%b))
        e <- as.vector(y-x%*%beta)
        g <- crossprod(z,e)/n
        add(paste0("beta",s),c("intercept","x","dose"),beta)
        add(paste0("moment",s),c("intercept","x","z","z2"),g)
        add("objective",s,n*crossprod(g,w%*%g))
        w <- solve(crossprod(z*e)/n)
    }
    d <- read("threshold19")
    stopifnot(!anyDuplicated(d$record),all(d$eligible==(d$running>=0)))
    add <- lab("CH19","rd")
    for (h in c(125,250,375)) {
        a <- subset(d,abs(running)<h/100)
        r <- a$running
        z <- a$eligible
        w <- 1-abs(r)/(h/100)
        x <- cbind(1,z,r,z*r)
        terms <- c("sharp","fuzzy","receipt","baseline")
        y <- as.matrix(a[terms])
        b <- ols(x*sqrt(w),y*sqrt(w))
        e <- y-x%*%b
        for (j in 1:4) add(terms[j],h,b[2,j])
        add("left_n",h,sum(z==0))
        add("right_n",h,sum(z==1))
        add("sharp_se",h,sqrt(hc0(x,e[,1],w)[2,2]))
        ratio <- b[2,2]/b[2,3]
        add("ratio",h,ratio)
        add("ratio_se",h,sqrt(hc0(x,(e[,2]-ratio*e[,3])/b[2,3],w)[2,2]))
        if (h==250) add("kernel",a$record,w)
    }
}
selection <- function() {
    d <- subset(read("selection20"),eligible==1)
    stopifnot(!anyDuplicated(d$record),setequal(d$fold,0:3))
    x <- cbind(1,d$x,d$rural)
    y <- d$outcome
    a <- d$treated
    p <- m0 <- m1 <- rep(NA_real_,nrow(d))
    add <- lab("CH20","nuisance")
    for (f in 0:3) {
        test <- d$fold==f
        b <- glm.fit(x[!test,],a[!test],family=binomial(),control=glm.control(epsilon=1e-12))
        stopifnot(b$converged)
        p[test] <- plogis(x[test,]%*%b$coefficients)
        keys <- paste(f,c("intercept","x","rural"),sep="/")
        add("logit",keys,b$coefficients)
        for (arm in 0:1) {
            train <- !test & a==arm
            fit <- ols(x[train,],y[train])
            add(paste0("outcome",arm),keys,fit)
            if (arm==0) m0[test] <- x[test,]%*%fit
            if (arm==1) m1[test] <- x[test,]%*%fit
        }
    }
    add("p",d$record,p)
    add("mu0",d$record,m0)
    add("mu1",d$record,m1)
    for (model in c("full","trim")) {
        use <- if (model=="full") rep(TRUE,length(p)) else p>=.1 & p<=.9
        aa <- a[use]
        yy <- y[use]
        pp <- p[use]
        lo <- m0[use]
        hi <- m1[use]
        w1 <- aa/pp
        w0 <- (1-aa)/(1-pp)
        wc <- pp*w0
        s <- mean(aa)
        score <- hi-lo+w1*(yy-hi)-w0*(yy-lo)
        add <- lab("CH20",model)
        scalar(add,n=length(aa),treated=sum(aa),p_min=min(pp),p_max=max(pp),w1=sum(w1),w0=sum(w0),
            stable1=s*sum(w1),stable0=(1-s)*sum(w0),ess1=sum(w1)^2/sum(w1^2),ess0=sum(w0)^2/sum(w0^2),
            ipw=weighted.mean(yy,w1)-weighted.mean(yy,w0),
            ipw_att=weighted.mean(yy,aa)-weighted.mean(yy,wc),aipw=mean(score),
            aipw_att=mean((aa-wc)*(yy-lo))/s,score_se=sd(score)/sqrt(length(aa)))
        add("score",d$record[use],score)
        for (j in 2:3) {
            z <- x[use,j]
            p0 <- sqrt((var(z[aa==1])+var(z[aa==0]))/2)
            name <- c("x","rural")[j-1]
            add("balance_raw",name,(mean(z[aa==1])-mean(z[aa==0]))/p0)
            add("balance_ipw",name,(weighted.mean(z,w1)-weighted.mean(z,w0))/p0)
        }
    }
}
simplex <- function(y,a) {
    best <- Inf
    w <- numeric(ncol(a))
    for (s in seq_len(ncol(a))) for (i in combn(ncol(a),s,simplify=FALSE)) {
        x <- a[,i,drop=FALSE]
        kkt <- rbind(cbind(crossprod(x),1),c(rep(1,s),0))
        b <- solve(kkt,c(crossprod(x,y),1))[seq_len(s)]
        loss <- mean((y-x%*%b)^2)
        if (min(b)>=-1e-9 && loss<best-1e-10) {
            best <- loss
            w[] <- 0
            w[i] <- b
        }
    }
    stopifnot(abs(sum(w)-1)<1e-8)
    w
}
places <- function() {
    d <- read("places20")
    d <- d[order(d$period,d$place),]
    stopifnot(nrow(d)==84,!anyDuplicated(d[c("place","period")]))
    a <- matrix(d$outcome,12,7,byrow=TRUE)
    stopifnot(all(a[1:7,2]==a[1:7,3]))
    y <- a[,1]
    pair <- rowMeans(a[,2:3])
    for (model in c("scm","exclude4")) {
        ids <- if (model=="scm") c(3,4,5,6) else c(3,5,6)
        x <- cbind(pair,a[,ids+1])
        b <- simplex(y[1:7],x[1:7,])
        fit <- as.vector(x%*%b)
        gap <- y-fit
        w <- numeric(6)
        w[1:2] <- b[1]/2
        w[ids] <- b[-1]
        add <- lab("CH20",model)
        add("weight",1:6,w)
        add("fit",0:11,fit)
        add("gap",0:11,gap)
        scalar(add,pre_mse=mean(gap[1:7]^2),post_gap=mean(gap[8:12]),weight_sum=sum(w))
        if (model=="scm") {
            add("all_d1",0:11,fit+b[1]*(a[,2]-pair))
            add("all_d2",0:11,fit+b[1]*(a[,3]-pair))
        }
    }
}
trial()
rollout()
instruments()
selection()
places()
result <- do.call(rbind,ledger)
stopifnot(!anyDuplicated(result[1:4]))
dir.create(args[2],recursive=TRUE,showWarnings=FALSE)
write.table(result,file.path(args[2],"metrics.csv"),sep=",",quote=FALSE,row.names=FALSE)
cat(R.version.string,"\n",nrow(result),"values\n")
