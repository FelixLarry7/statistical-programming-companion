# Part V computational companion

Use Python 3.12 with the versions in requirements.txt and base R with Rscript available. The archived R run used R 4.5.0. The nine original synthetic inputs and their conventions are described in data/codebook.md. The data generator can recreate them in a separate directory with `python make_fixtures.py --output rebuilt`.

From this directory run:

~~~bash
python verify.py --output rerun --require-four \
  --stata-evidence evidence/stata/evidence_replay.zip
~~~

Use a new or empty destination. The command reruns Python, R, and DuckDB and verifies the retained local Stata result against the shipped driver and input bytes. If needed, supply an absolute Rscript path via `--rscript`. To run Stata anew, place the files in data/raw in an inputs subfolder next to the Stata wrapper and driver and follow stata/LOCAL_RUN.md. Then supply the new verification ZIP in the same command.

| Chapter | Shared statistical computations | DuckDB checks |
|:--|:--|:--|
| 17 | Blocked ITT, exact randomisation, variance, power, receipt and response | Sample, all legal allocations, arm denominators, ITTs, and bounds |
| 18 | Conditional group-time effects, aggregation, fixed-effects diagnostic, and joint band | Control eligibility, capacity support, and cell and horizon effects |
| 19 | 2SLS, HC0, Anderson–Rubin grid, two GMM steps, and RD | Partialled IV contrasts, moments at shared coefficients, exact RD rows and weighted jumps |
| 20 | Held-out nuisance fits, scores and balance, and constrained donor optimisation | Scoring at shared fold coefficients, weights and overlap, and paths at shared donor weights |

The archived report records 9,514 passing checks, including 3,376 keyed Stata results. Read evidence/verification.json for scope and runtime metadata and evidence/comparisons.csv for keyed values, errors and tolerances. The diagnostics directory includes the deliberately invalid household assignment, the early fixed-effects decomposition, analytical Anderson–Rubin inversion, and matching checks. Plotted values and table outputs are in the figure_data and table_data directories.
