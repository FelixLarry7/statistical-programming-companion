"""Recreate assignment-unit, projection-weight, weak-IV, and matching diagnostics."""

from pathlib import Path
from random import Random
import sys

import numpy as np
import pandas as pd
from scipy.stats import chi2

from fit_python import ols, twfe_design


def invalid_assignment(raw,out):
    d = pd.read_csv(raw/'households17.csv').query('eligible == 1')
    v = pd.read_csv(raw/'villages17.csv')
    d = d.merge(v,validate='many_to_one',on='village').sort_values(['block','village','household'])
    r = Random(17024)
    y = d.admin.to_numpy()
    total = y.sum()
    observed = 2*(y @ d.offer)-total
    rows = []
    for b in range(1,2001):
        selected = r.sample(range(48),24)+r.sample(range(48,96),24)
        z = np.zeros(96,dtype=int)
        z[selected] = 1
        a = z.reshape(12,8).sum(1)
        s = 2*(y @ z)-total
        rows.append((b,s/48,abs(s)>=abs(observed),sum((a>0)&(a<8))))
    pd.DataFrame(rows,columns=['draw','statistic','extreme','mixed_villages']).to_csv(
        out/'invalid_household_draws.csv',index=False)


def attribution(raw,out):
    d = pd.read_csv(raw/'rollout18.csv').query('in_scope == 1').sort_values(['unit','period'])
    g = d.cohort.to_numpy()
    k = (d.period-d.cohort).to_numpy()
    design,_ = twfe_design(d)
    nuisance = np.delete(design,-6,axis=1)
    early = design[:,-6]
    residual = early-nuisance @ ols(nuisance,early)
    w = residual/(residual @ early)
    a = np.where((g>0)&(k==-1),.5+.2*(g-3),0)
    start = np.select((g==3,g==5,g==7),(2.2,3.6,1.4))
    slope = np.select((g==3,g==5,g==7),(.95,.45,.30))
    post = np.where((g>0)&(k>=0),start+slope*k+.4*d.x,0)
    untreated = d.outcome.to_numpy()-a-post
    rows = [(name,w @ term) for name,term in (
        ('untreated path',untreated),('anticipation',a),('post-adoption effects',post),
        ('observed outcome',d.outcome))]
    assert abs(sum(v for _,v in rows[:3])-rows[-1][1])<1e-9
    pd.DataFrame(rows,columns=['component','pre_coefficient']).to_csv(out/'twfe_attribution.csv',index=False)
    d.assign(pre_weight=w,anticipation=a,post_effect=post).to_csv(out/'twfe_weights.csv',index=False)


def inversion(raw,out):
    d = pd.read_csv(raw/'encourage19.csv')
    z = np.column_stack((np.ones(len(d)),d.x,d.z))
    row = np.linalg.solve(z.T @ z,z.T)[2]
    c = chi2.ppf(.95,1)
    results = []
    for model,dose,y in (('strong','dose','outcome'),('weak','weak','weak_outcome')):
        y = d[[y,dose]].to_numpy()
        fit = ols(z,y)
        reduced, first = fit[2]
        score = row[:,None]*(y-z @ fit)
        v = score.T @ score
        q2 = first**2-c*v[1,1]
        q1 = -2*reduced*first+2*c*v[0,1]
        q0 = reduced**2-c*v[0,0]
        delta = q1**2-4*q2*q0
        roots = sorted(np.roots([q2,q1,q0]).real) if delta>=0 else [None,None]
        results.append((model,q2,q1,q0,delta,*roots))
    pd.DataFrame(results,columns=['model','q2','q1','q0','discriminant','root1','root2']).to_csv(
        out/'ar_inversion.csv',index=False)


def observational(sql,out):
    d = pd.read_csv(sql/'observational.csv').sort_values('record')
    d['logit'] = np.log(d.p/(1-d.p))
    d['conditional_effect'] = 3.3+.9*d.x+.65*d.rural
    rows = []
    for unit in d[d.treated==1].itertuples():
        c = d[(d.treated==0)&(d.rural==unit.rural)].copy()
        c['distance'] = abs(c.logit-unit.logit)
        nearest = c.sort_values(['distance','record']).iloc[0]
        rows.append((unit.record,int(nearest.record),nearest.distance,nearest.distance<=.35,
                     unit.outcome-nearest.outcome,unit.x-nearest.x))
    pd.DataFrame(rows,columns=['treated_record','candidate_control','distance','within_caliper',
                 'outcome_difference','score_difference']).to_csv(out/'matching_pairs.csv',index=False)
    pd.DataFrame([(name,len(a),a.conditional_effect.mean(),
        a.loc[a.treated==1,'conditional_effect'].mean()) for name,a in
        (('full',d),('trim',d[d.p.between(.1,.9)]))],
        columns=['model','rows','known_ate','known_att']).to_csv(out/'observational_truth.csv',index=False)


if __name__=='__main__':
    raw,sql,out = map(Path,sys.argv[1:])
    out.mkdir(parents=True,exist_ok=True)
    invalid_assignment(raw,out)
    attribution(raw,out)
    inversion(raw,out)
    observational(sql,out)
