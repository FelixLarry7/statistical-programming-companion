*! Part V analytical workflows for Stata 16 and 17. No external packages.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide the input and output folders."
    exit 198
}
mata:
string scalar pv_id(real scalar value)
{
    return(strtrim(strofreal(value, "%12.0f")))
}

void pv_put(real scalar handle, string scalar ch, string scalar model,
    string scalar quantity, string scalar key, real scalar value)
{
    assert(value < .)
    fput(handle, ch+","+model+","+quantity+","+key+","+strtrim(strofreal(value,"%24.16g")))
}

void pv17(real scalar f, real matrix villages, real matrix d, real matrix allocations)
{
    real matrix c, a, x
    real colvector z, sums, permutation, mask, means
    real rowvector arm, low, high, rcpt, response, blockmean
    real scalar j, h, n, s, o, denom, num, extreme, variance, de, mde
    string scalar ch, model, id
    ch="CH17"
    model="trial"
    c=J(12,6,0)
    for (j=1; j<=12; j++) {
        x=select(d, (d[,1]:==j):&(d[,2]:==1))
        assert(rows(x)==8)
        c[j,]=(rows(x),colsum(x[,3..6]),sum(select(x[,7],x[,6]:==1)))
    }
    z=villages[,2]
    sums=c[,3]
    denom=quadcross(z,c[,1])
    num=2*quadcross(z,sums)-sum(sums)
    a=allocations[,2..13]
    assert(rows(a)==400 & sum(rowsum(a[,1..6]):!=3)==0 & sum(rowsum(a[,7..12]):!=3)==0)
    assert(rows(uniqrows(sort(a,1..12)))==400)
    assert(sum(rowsum(abs(a:-z')):==0)==1)
    permutation=2*a*sums:-sum(sums)
    extreme=sum(abs(permutation):>=abs(num))
    pv_put(f,ch,model,"scalar","roster",rows(d))
    pv_put(f,ch,model,"scalar","n",sum(c[,1]))
    pv_put(f,ch,model,"scalar","villages",rows(c))
    pv_put(f,ch,model,"scalar","treated_villages",sum(z))
    pv_put(f,ch,model,"scalar","itt",num/denom)
    pv_put(f,ch,model,"scalar","permutations",rows(a))
    pv_put(f,ch,model,"scalar","extreme",extreme)
    pv_put(f,ch,model,"scalar","ri_p",extreme/rows(a))
    for (j=1; j<=rows(a); j++) pv_put(f,ch,model,"permutation",pv_id(allocations[j,1]),permutation[j]/denom)
    for (j=1; j<=rows(c); j++) pv_put(f,ch,model,"village_mean",pv_id(j),c[j,3]/c[j,1])
    low=J(1,2,0)
    high=low
    rcpt=low
    response=low
    for (s=0; s<=1; s++) {
        arm=colsum(select(c,z:==s))
        n=arm[1]
        o=arm[5]
        id=pv_id(s)
        pv_put(f,ch,model,"arm_n",id,n)
        pv_put(f,ch,model,"arm_measured",id,o)
        pv_put(f,ch,model,"arm_baseline",id,arm[2]/n)
        pv_put(f,ch,model,"arm_admin",id,arm[3]/n)
        pv_put(f,ch,model,"arm_survey",id,arm[6]/o)
        low[s+1]=arm[6]/n
        high[s+1]=(arm[6]+100*(n-o))/n
        rcpt[s+1]=arm[4]/n
        response[s+1]=o/n
    }
    variance=0
    for (h=1; h<=2; h++) {
        blockmean=J(1,2,0)
        for (s=0; s<=1; s++) {
            mask=(villages[,1]:==h):&(z:==s)
            means=select(c[,3]:/c[,1],mask)
            n=rows(means)
            assert(n==3)
            blockmean[s+1]=mean(means)
            variance=variance+sum((means:-mean(means)):^2)/(4*n*(n-1))
        }
        pv_put(f,ch,model,"block_itt",pv_id(h),blockmean[2]-blockmean[1])
    }
    de=1+7*.1
    mde=(invnormal(.975)+invnormal(.80))*10*sqrt(4*de/96)
    pv_put(f,ch,model,"scalar","se_neyman",sqrt(variance))
    pv_put(f,ch,model,"scalar","receipt_itt",rcpt[2]-rcpt[1])
    pv_put(f,ch,model,"scalar","wald",num/(denom*(rcpt[2]-rcpt[1])))
    pv_put(f,ch,model,"scalar","response_itt",response[2]-response[1])
    pv_put(f,ch,model,"scalar","bound_low",low[2]-high[1])
    pv_put(f,ch,model,"scalar","bound_high",high[2]-low[1])
    pv_put(f,ch,model,"scalar","design_effect",de)
    pv_put(f,ch,model,"scalar","mde",mde)
}

void pv18(real scalar f, real matrix d, real matrix mult, real rowvector twfe)
{
    real matrix y, espsi, boot
    real colvector rowids, g, x, dy, target, control, gt, gc, psi, est, en, amax
    real rowvector se
    real scalar i, rule, a, c, b, t, nt, nc, cov, sh, mt, mc, tau, k, ki, critical
    string rowvector rules, terms
    string scalar ch, model, id
    ch="CH18"
    rowids=(0::38):*10:+1
    assert(rows(d)==390 & rows(mult)==199)
    assert(sum(d[rowids,1]:!=(1::39))==0)
    g=d[rowids,3]
    x=d[rowids,4]
    y=J(39,10,.)
    for (t=0; t<=9; t++) y[,t+1]=d[rowids:+t,5]
    rules=("never","notyet","risky")
    for (rule=1; rule<=3; rule++) {
        model=rules[rule]
        a=(rule!=3)
        est=J(14,1,0)
        en=est
        espsi=J(39,14,0)
        for (c=3; c<=7; c=c+2) {
            b=c-a-1
            target=(g:==c)
            nt=sum(target)
            for (t=0; t<=9; t++) {
                if (t==b) continue
                control=(g:==0)
                if (rule!=1) control=control:|((g:!=c):&(g:>(max((b,t))+a)))
                dy=y[,t+1]-y[,b+1]
                id=pv_id(c)+"/"+pv_id(t)
                pv_put(f,ch,model,"target_n",id,nt)
                pv_put(f,ch,model,"control_n",id,sum(control))
                pv_put(f,ch,model,"raw",id,mean(select(dy,target))-mean(select(dy,control)))
                tau=0
                psi=J(39,1,0)
                for (cov=0; cov<=1; cov++) {
                    gt=target:&(x:==cov)
                    gc=control:&(x:==cov)
                    nc=sum(gc)
                    assert(sum(gt)>0 & nc>0)
                    sh=sum(gt)/nt
                    mt=mean(select(dy,gt))
                    mc=mean(select(dy,gc))
                    tau=tau+sh*(mt-mc)
                    psi=psi+gt:*sh:*(dy:-mt):/sum(gt)-gc:*sh:*(dy:-mc):/nc
                    pv_put(f,ch,model,"support",id+"/"+pv_id(cov),nc)
                }
                ki=t-c+8
                est[ki]=est[ki]+nt*tau
                en[ki]=en[ki]+nt
                espsi[,ki]=espsi[,ki]+nt*psi
                pv_put(f,ch,model,"att",id,tau)
            }
        }
        for (k=-7; k<=6; k++) {
            ki=k+8
            if (en[ki]==0) continue
            est[ki]=est[ki]/en[ki]
            espsi[,ki]=espsi[,ki]/en[ki]
            pv_put(f,ch,model,"event_att",pv_id(k),est[ki])
            pv_put(f,ch,model,"event_n",pv_id(k),en[ki])
        }
        if (rule==2) {
            se=sqrt(colsum(espsi[,8..10]:^2))
            boot=(mult[,2..40]*espsi[,8..10]):/se
            amax=rowmax(abs(boot))
            boot=sort(amax,1)
            critical=boot[190]
            pv_put(f,ch,"band","scalar","critical",critical)
            for (i=1; i<=rows(mult); i++) pv_put(f,ch,"band","max_t",pv_id(mult[i,1]),amax[i])
            for (k=0; k<=2; k++) {
                pv_put(f,ch,"band","se",pv_id(k),se[k+1])
                pv_put(f,ch,"band","low",pv_id(k),est[k+8]-critical*se[k+1])
                pv_put(f,ch,"band","high",pv_id(k),est[k+8]+critical*se[k+1])
            }
        }
    }
    terms=("pre","anticip","k0","k1","k2","tail")
    for (i=1; i<=6; i++) pv_put(f,ch,"twfe","beta",terms[i],twfe[i])
}

real matrix pv_hc0(real matrix x, real colvector u, real colvector w)
{
    real matrix bread, scores
    bread=invsym(quadcross(x,w,x))
    scores=x:*(w:*u)
    return(bread*quadcross(scores,scores)*bread)
}

void pv19iv(real scalar f, real matrix d, real rowvector native_iv)
{
    real matrix x, z, bproj, v, ex, gmma, w, scores
    real colvector y, e, coef, bfirst, bred, ar, modified, gmmb, mom, one
    real scalar i, q, stat, n, step
    string scalar ch, model, key
    string rowvector xt, zt
    ch="CH19"
    n=rows(d)
    one=J(n,1,1)
    ex=(one,d[,1])
    z=(ex,d[,2])
    for (i=1; i<=2; i++) {
        model=(i==1 ? "strong" : "weak")
        x=(ex,d[,3+i])
        y=d[,5+i]
        bproj=z*qrsolve(z,x)
        coef=qrsolve(bproj,y)
        assert(abs(coef[3]-native_iv[i])<1e-7)
        e=y-x*coef
        v=pv_hc0(bproj,e,one)
        pv_put(f,ch,model,"scalar","se_hc0",sqrt(v[3,3]))
        bfirst=qrsolve(z,x[,3])
        bred=qrsolve(z,y)
        v=pv_hc0(z,x[,3]-z*bfirst,one)
        pv_put(f,ch,model,"scalar","n",n)
        pv_put(f,ch,model,"scalar","effect",native_iv[i])
        pv_put(f,ch,model,"scalar","first",bfirst[3])
        pv_put(f,ch,model,"scalar","reduced",bred[3])
        pv_put(f,ch,model,"scalar","first_t2",bfirst[3]^2/v[3,3])
        for (q=-40; q<=48; q++) {
            modified=y-(q/4)*x[,3]
            ar=qrsolve(z,modified)
            v=pv_hc0(z,modified-z*ar,one)
            stat=ar[3]^2/v[3,3]
            pv_put(f,ch,model,"ar_stat",pv_id(q),stat)
            pv_put(f,ch,model,"ar_p",pv_id(q),chi2tail(1,stat))
        }
    }
    x=(ex,d[,4])
    z=(ex,d[,2..3])
    y=d[,6]
    gmma=quadcross(z,x)/n
    gmmb=quadcross(z,y)/n
    w=invsym(quadcross(z,z)/n)
    xt=("intercept","x","dose")
    zt=("intercept","x","z","z2")
    for (step=1; step<=2; step++) {
        key=pv_id(step)
        coef=invsym(quadcross(gmma,w*gmma))*quadcross(gmma,w*gmmb)
        e=y-x*coef
        mom=quadcross(z,e)/n
        for (i=1; i<=3; i++) pv_put(f,ch,"gmm","beta"+key,xt[i],coef[i])
        for (i=1; i<=4; i++) pv_put(f,ch,"gmm","moment"+key,zt[i],mom[i])
        pv_put(f,ch,"gmm","objective",key,n*quadcross(mom,w*mom))
        scores=z:*e
        w=invsym(quadcross(scores,scores)/n)
    }
}

void pv19rd(real scalar f, real matrix d, real scalar native_sharp)
{
    real matrix a, x, y, b, e, v
    real colvector r, z, w, u
    real scalar j, i, hcode, h, fuzzy
    string scalar ch, model, id
    string rowvector terms
    ch="CH19"
    model="rd"
    terms=("sharp","fuzzy","receipt","baseline")
    for (hcode=125; hcode<=375; hcode=hcode+125) {
        h=hcode/100
        id=pv_id(hcode)
        a=select(d,abs(d[,2]):<h)
        r=a[,2]
        z=a[,3]
        w=1:-abs(r):/h
        x=(J(rows(a),1,1),z,r,z:*r)
        y=a[,(5,6,4,7)]
        b=qrsolve(x:*sqrt(w),y:*sqrt(w))
        e=y-x*b
        pv_put(f,ch,model,"left_n",id,sum(z:==0))
        pv_put(f,ch,model,"right_n",id,sum(z:==1))
        for (j=1; j<=4; j++) pv_put(f,ch,model,terms[j],id,b[2,j])
        v=pv_hc0(x,e[,1],w)
        pv_put(f,ch,model,"sharp_se",id,sqrt(v[2,2]))
        fuzzy=b[2,2]/b[2,3]
        u=(e[,2]-fuzzy*e[,3])/b[2,3]
        v=pv_hc0(x,u,w)
        pv_put(f,ch,model,"ratio",id,fuzzy)
        pv_put(f,ch,model,"ratio_se",id,sqrt(v[2,2]))
        if (hcode==250) {
            assert(abs(b[2,1]-native_sharp)<1e-7)
            for (i=1; i<=rows(a); i++) pv_put(f,ch,model,"kernel",pv_id(a[i,1]),w[i])
        }
    }
}

void pv_coef(real scalar f, string scalar quantity, real scalar fold, real rowvector b)
{
    real scalar j
    string rowvector terms
    terms=("intercept","x","rural")
    for (j=1; j<=3; j++) pv_put(f,"CH20","nuisance",quantity,pv_id(fold)+"/"+terms[j],b[j])
}

real scalar pv_var(real colvector a)
{
    return(sum((a:-mean(a)):^2)/(rows(a)-1))
}

void pv20obs(real scalar f, real matrix data)
{
    real matrix d
    real colvector y, a, p, m0, m1, w1, w0, wc, score, satt, cov, c1, c0
    real scalar i, j, modelno, n, share, sw1, sw0, pooled
    string scalar ch, model, label
    string rowvector terms
    ch="CH20"
    terms=("x","rural")
    for (i=1; i<=rows(data); i++) {
        pv_put(f,ch,"nuisance","p",pv_id(data[i,1]),data[i,6])
        pv_put(f,ch,"nuisance","mu0",pv_id(data[i,1]),data[i,7])
        pv_put(f,ch,"nuisance","mu1",pv_id(data[i,1]),data[i,8])
    }
    for (modelno=1; modelno<=2; modelno++) {
        model=(modelno==1 ? "full" : "trim")
        d=data
        if (modelno==2) d=select(d,(d[,6]:>=.1):&(d[,6]:<=.9))
        y=d[,5]
        a=d[,4]
        p=d[,6]
        m0=d[,7]
        m1=d[,8]
        n=rows(y)
        share=mean(a)
        w1=a:/p
        w0=(1:-a):/(1:-p)
        wc=p:*w0
        sw1=sum(w1)
        sw0=sum(w0)
        score=m1-m0+w1:*(y-m1)-w0:*(y-m0)
        satt=(a-wc):*(y-m0):/share
        pv_put(f,ch,model,"scalar","n",n)
        pv_put(f,ch,model,"scalar","treated",sum(a))
        pv_put(f,ch,model,"scalar","p_min",min(p))
        pv_put(f,ch,model,"scalar","p_max",max(p))
        pv_put(f,ch,model,"scalar","w1",sw1)
        pv_put(f,ch,model,"scalar","w0",sw0)
        pv_put(f,ch,model,"scalar","stable1",share*sw1)
        pv_put(f,ch,model,"scalar","stable0",(1-share)*sw0)
        pv_put(f,ch,model,"scalar","ess1",sw1^2/quadcross(w1,w1))
        pv_put(f,ch,model,"scalar","ess0",sw0^2/quadcross(w0,w0))
        pv_put(f,ch,model,"scalar","ipw",quadcross(w1,y)/sw1-quadcross(w0,y)/sw0)
        pv_put(f,ch,model,"scalar","ipw_att",quadcross(a,y)/sum(a)-quadcross(wc,y)/sum(wc))
        pv_put(f,ch,model,"scalar","aipw",mean(score))
        pv_put(f,ch,model,"scalar","aipw_att",mean(satt))
        pv_put(f,ch,model,"scalar","score_se",sqrt(pv_var(score)/n))
        for (i=1; i<=n; i++) pv_put(f,ch,model,"score",pv_id(d[i,1]),score[i])
        for (j=1; j<=2; j++) {
            cov=d[,j+1]
            label=terms[j]
            c1=select(cov,a:==1)
            c0=select(cov,a:==0)
            pooled=sqrt((pv_var(c1)+pv_var(c0))/2)
            pv_put(f,ch,model,"balance_raw",label,(mean(c1)-mean(c0))/pooled)
            pv_put(f,ch,model,"balance_ipw",label,(quadcross(w1,cov)/sw1-quadcross(w0,cov)/sw0)/pooled)
        }
    }
}

real colvector pv_simplex(real colvector y, real matrix donors)
{
    real matrix a, kkt
    real rowvector ids
    real colvector solution, fitted, w
    real scalar mask, j, m, s, best, loss
    m=cols(donors)
    best=.
    w=J(m,1,0)
    for (mask=1; mask<2^m; mask++) {
        ids=J(1,0,.)
        for (j=1; j<=m; j++) {
            if (mod(floor(mask/(2^(j-1))),2)==1) ids=(ids,j)
        }
        a=donors[,ids]
        s=cols(a)
        kkt=(quadcross(a,a),J(s,1,1) \ J(1,s,1),0)
        solution=lusolve(kkt,(quadcross(a,y) \ 1))
        fitted=solution[1..s]
        assert(sum(fitted:>=.)==0)
        if (min(fitted)<-1e-9) continue
        loss=mean((y-a*fitted):^2)
        if (missing(best) | loss<best-1e-10) {
            best=loss
            w=J(m,1,0)
            w[ids]=fitted
        }
    }
    assert(abs(sum(w)-1)<1e-8)
    return(w)
}

void pv20scm(real scalar f, real matrix paths)
{
    real matrix donor
    real colvector y, w, fitted, gap, full
    real rowvector ids
    real scalar m, j, t
    string scalar model, ch
    ch="CH20"
    assert(sum(paths[1..7,2]:!=paths[1..7,3])==0)
    y=paths[,1]
    for (m=1; m<=2; m++) {
        model=(m==1 ? "scm" : "exclude4")
        ids=(3,4,5,6)
        if (m==2) ids=(3,5,6)
        donor=((paths[,2]+paths[,3])/2,paths[,ids:+1])
        w=pv_simplex(y[1..7],donor[1..7,])
        fitted=donor*w
        gap=y-fitted
        full=J(6,1,0)
        full[1..2]=J(2,1,w[1]/2)
        full[ids]=w[2..rows(w)]
        for (j=1; j<=6; j++) pv_put(f,ch,model,"weight",pv_id(j),full[j])
        for (t=0; t<=11; t++) {
            pv_put(f,ch,model,"fit",pv_id(t),fitted[t+1])
            pv_put(f,ch,model,"gap",pv_id(t),gap[t+1])
            if (m==1) {
                pv_put(f,ch,model,"all_d1",pv_id(t),fitted[t+1]+w[1]*(paths[t+1,2]-donor[t+1,1]))
                pv_put(f,ch,model,"all_d2",pv_id(t),fitted[t+1]+w[1]*(paths[t+1,3]-donor[t+1,1]))
            }
        }
        pv_put(f,ch,model,"scalar","pre_mse",mean(gap[1..7]:^2))
        pv_put(f,ch,model,"scalar","post_gap",mean(gap[8..12]))
        pv_put(f,ch,model,"scalar","weight_sum",sum(full))
    }
}
end

import delimited using `"`input'/villages17.csv"', clear varnames(1) asdouble
isid village
sort village
assert village==_n
assert block==1+(village>6) & inlist(offer,0,1)
mata: pv_villages=st_data(.,("block","offer"))
import delimited using `"`input'/households17.csv"', clear varnames(1) asdouble
isid household
assert inrange(village,1,12)
assert baseline_wave<outcome_wave & admin<. if eligible==1
assert (survey<.)==measured & inlist(receipt,0,1) if eligible==1
mata: pv_hh=st_data(.,("village","eligible","baseline","admin","receipt","measured","survey"))
import delimited using `"`input'/allocations17.csv"', clear varnames(1) asdouble
isid draw
sort draw
foreach v of varlist z1-z12 {
    assert inlist(`v',0,1)
}
mata: pv_fh=fopen(st_local("output")+"/metrics.csv","w")
mata: fput(pv_fh,"chapter,model,quantity,key,value")
mata: pv17(pv_fh,pv_villages,pv_hh,st_data(.,1..13))
display as text "Chapter 17 completed."

import delimited using `"`input'/rollout18.csv"', clear varnames(1) asdouble
keep if in_scope==1
isid unit period
sort unit period
by unit: assert _N==10 & period==_n-1 & cohort==cohort[1] & x==x[1]
gen int event=period-cohort
gen byte pre=cohort>0 & event<=-3
gen byte anticip=cohort>0 & event==-1
gen byte k0=cohort>0 & event==0
gen byte k1=cohort>0 & event==1
gen byte k2=cohort>0 & event==2
gen byte tail=cohort>0 & event>=3
quietly regress outcome pre anticip k0 k1 k2 tail i.unit i.period
tempname twfe ivb strong sharpb cb
matrix `twfe'=(_b[pre],_b[anticip],_b[k0],_b[k1],_b[k2],_b[tail])
mata: pv_panel=st_data(.,("unit","period","cohort","x","outcome"))
import delimited using `"`input'/multipliers18.csv"', clear varnames(1) asdouble
isid draw
sort draw
foreach v of varlist u1-u39 {
    assert inlist(`v',-1,1)
}
mata: pv18(pv_fh,pv_panel,st_data(.,1..40),st_matrix("`twfe'"))
display as text "Chapter 18 completed."

import delimited using `"`input'/encourage19.csv"', clear varnames(1) asdouble
isid record
sort record
quietly ivregress 2sls outcome x (dose=z)
scalar `strong'=_b[dose]
quietly ivregress 2sls weak_outcome x (weak=z)
matrix `ivb'=(`strong',_b[weak])
mata: pv19iv(pv_fh,st_data(.,("x","z","z2","dose","weak","outcome","weak_outcome")),st_matrix("`ivb'"))
import delimited using `"`input'/threshold19.csv"', clear varnames(1) asdouble
isid record
sort record
assert eligible==(running>=0)
gen double kernel=1-abs(running)/2.5 if abs(running)<2.5
gen double right_slope=running*eligible
quietly regress sharp eligible running right_slope if kernel<. [aw=kernel]
scalar `sharpb'=_b[eligible]
mata: pv19rd(pv_fh,st_data(.,("record","running","eligible","receipt","sharp","fuzzy","baseline")),st_numscalar("`sharpb'"))
display as text "Chapter 19 completed."

import delimited using `"`input'/selection20.csv"', clear varnames(1) asdouble
keep if eligible==1
isid record
sort record
assert inrange(fold,0,3) & inlist(treated,0,1)
gen double p=.
gen double mu0=.
gen double mu1=.
forvalues fold=0/3 {
    quietly logit treated x rural if fold!=`fold', nolog
    assert e(converged)==1
    matrix `cb'=(_b[_cons],_b[x],_b[rural])
    mata: pv_coef(pv_fh,"logit",`fold',st_matrix("`cb'"))
    quietly predict double held, pr
    quietly replace p=held if fold==`fold'
    drop held
    forvalues arm=0/1 {
        quietly regress outcome x rural if fold!=`fold' & treated==`arm'
        matrix `cb'=(_b[_cons],_b[x],_b[rural])
        mata: pv_coef(pv_fh,"outcome`arm'",`fold',st_matrix("`cb'"))
        quietly predict double held, xb
        quietly replace mu`arm'=held if fold==`fold'
        drop held
    }
}
assert p>0 & p<1 & mu0<. & mu1<.
mata: pv20obs(pv_fh,st_data(.,("record","x","rural","treated","outcome","p","mu0","mu1")))
import delimited using `"`input'/places20.csv"', clear varnames(1) asdouble
isid place period
reshape wide outcome, i(period) j(place)
sort period
assert _N==12 & period==_n-1
mata: pv20scm(pv_fh,st_data(.,("outcome0","outcome1","outcome2","outcome3","outcome4","outcome5","outcome6")))
mata: fclose(pv_fh)
display as result "Part V generated in Stata."
