"""Reference computations for the four Part V labs."""

from itertools import combinations
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy.stats import chi2, norm
import scipy
import statsmodels
import statsmodels.api as sm

from ledger import Ledger


def ols(x, y):
    return np.linalg.lstsq(x, y, rcond=None)[0]


def hc0(x, residual, weight=None):
    if weight is None:
        weight = np.ones(len(x))
    bread = np.linalg.inv(x.T @ (weight[:, None] * x))
    score = x * (weight * residual)[:, None]
    return bread @ (score.T @ score) @ bread


def trial(read, ledger):
    v = read('villages17').sort_values('village')
    r = read('households17')
    assert v.village.is_unique and r.household.is_unique and set(r.village) == set(v.village)
    d = r.query('eligible == 1')
    assert d.admin.notna().all() and (d.survey.notna() == (d.measured == 1)).all()
    assert (d.baseline_wave < d.outcome_wave).all()
    c = d.groupby('village').agg(n=('household', 'size'), baseline=('baseline', 'sum'),
        admin=('admin', 'sum'), receipt=('receipt', 'sum'), measured=('measured', 'sum'),
        survey=('survey', 'sum')).reset_index().merge(v, on='village', validate='1:1').sort_values('village')
    assert c.n.eq(8).all() and c.groupby('block').offer.agg(['size','sum']).eq([6,3]).all().all()
    a = read('allocations17').sort_values('draw')
    z, av, yy = c.offer.to_numpy(), a.iloc[:, 1:].to_numpy(), c.admin.to_numpy()
    assert av.shape == (400,12) and len(np.unique(av, axis=0)) == 400 and np.isin(av,[0,1]).all()
    assert (av[:,:6].sum(1)==3).all() and (av[:,6:].sum(1)==3).all() and (av==z).all(1).sum()==1
    denom = z @ c.n
    num = 2 * z @ yy - yy.sum()
    perm = 2 * av @ yy - yy.sum()
    extreme = (abs(perm) >= abs(num)).sum()
    m = ledger.model('CH17','trial')
    m.scalars(roster=len(r), n=len(d), villages=len(c), treated_villages=z.sum(),
              itt=num/denom, permutations=len(av), extreme=extreme, ri_p=extreme/len(av))
    m.vector('permutation', a.draw, perm/denom)
    m.vector('village_mean', c.village, c.admin/c.n)
    a = c.groupby('offer').sum(numeric_only=True)
    for key, col in {'arm_n':a.n,'arm_measured':a.measured,'arm_baseline':a.baseline/a.n,
                     'arm_admin':a.admin/a.n,'arm_survey':a.survey/a.measured}.items():
        m.vector(key, a.index, col)
    low = a.survey/a.n
    high = (a.survey+100*(a.n-a.measured))/a.n
    fs = (a.receipt/a.n).diff().iloc[1]
    variance = 0.
    for block, c0 in c.groupby('block'):
        y = c0.assign(mean_y=c0.admin/c0.n).groupby('offer').mean_y
        variance += (y.var()/y.size()).sum()/4
        m.add('block_itt',block,y.mean().diff().iloc[1])
    de = 1+7*.1
    m.scalars(se_neyman=np.sqrt(variance), receipt_itt=fs, wald=(num/denom)/fs,
              response_itt=(a.measured/a.n).diff().iloc[1], bound_low=low[1]-high[0],
              bound_high=high[1]-low[0], design_effect=de,
              mde=(norm.ppf(.975)+norm.ppf(.8))*10*np.sqrt(4*de/96))


def rollout(read, ledger):
    d = read('rollout18').query('in_scope == 1').sort_values(['unit','period'])
    y = d.pivot(index='unit', columns='period', values='outcome').to_numpy()
    units = d.drop_duplicates('unit')
    g, x = units.cohort.to_numpy(), units.x.to_numpy()
    assert y.shape == (39,10) and np.isfinite(y).all()
    assert d.groupby('unit')[['cohort','x']].nunique().eq(1).all().all()
    for rule, anticipation in (('never',1),('notyet',1),('risky',0)):
        m = ledger.model('CH18',rule)
        event = {}
        for cohort in (3,5,7):
            base = cohort-anticipation-1
            target = g == cohort
            nt = target.sum()
            for t in range(10):
                if t == base:
                    continue
                control = (g == 0) | ((rule != 'never') & (g != cohort) & (g > max(t,base)+anticipation))
                change = y[:,t]-y[:,base]
                key = f'{cohort}/{t}'
                m.add('target_n', key, nt)
                m.add('control_n', key, control.sum())
                m.add('raw', key, change[target].mean()-change[control].mean())
                effect, psi = 0., np.zeros(len(g))
                for cov in (0,1):
                    at, ac = target & (x == cov), control & (x == cov)
                    assert at.any() and ac.any()
                    share = at.sum()/nt
                    mt, mc = change[at].mean(), change[ac].mean()
                    effect += share*(mt-mc)
                    psi[at] = share*(change[at]-mt)/at.sum()
                    psi[ac] = -share*(change[ac]-mc)/ac.sum()
                    m.add('support', f'{key}/{cov}',ac.sum())
                m.add('att',key,effect)
                event.setdefault(t-cohort, []).append((nt,effect,psi))
        combined = {}
        for k, cells in event.items():
            n = sum(a[0] for a in cells)
            effect = sum(w*t for w,t,_ in cells)/n
            combined[k] = (effect,sum(w*psi for w,_,psi in cells)/n)
            m.add('event_n',k,n)
            m.add('event_att',k,effect)
        if rule == 'notyet':
            w = read('multipliers18').sort_values('draw')
            psi = np.column_stack([combined[k][1] for k in range(3)])
            se = np.sqrt((psi**2).sum(0))
            maximum = np.abs((w.iloc[:,1:].to_numpy() @ psi)/se).max(1)
            q = np.sort(maximum)[189]
            band = ledger.model('CH18','band')
            band.add('scalar','critical',q)
            band.vector('max_t',w.draw,maximum)
            band.vector('se',range(3),se)
            for k in range(3):
                band.add('low',k,combined[k][0]-q*se[k])
                band.add('high',k,combined[k][0]+q*se[k])
    des, names = twfe_design(d)
    ledger.model('CH18','twfe').vector('beta',names,ols(des,d.outcome)[-6:])


def twfe_design(d):
    g = d.cohort.to_numpy()
    k = (d.period-d.cohort).to_numpy()
    event = np.column_stack((k<=-3,k==-1,k==0,k==1,k==2,k>=3)) & (g[:,None]>0)
    fe = pd.get_dummies(d[['unit','period']].astype(str), drop_first=True, dtype=float)
    return np.column_stack((np.ones(len(d)),fe,event)), ('pre','anticip','k0','k1','k2','tail')


def instruments(read, ledger):
    d = read('encourage19')
    assert d.record.is_unique
    w = np.column_stack((np.ones(len(d)),d.x))
    z = np.column_stack((w,d.z))
    for model, dose, y in (('strong',d.dose,d.outcome),('weak',d.weak,d.weak_outcome)):
        dose, y = np.asarray(dose), np.asarray(y)
        x = np.column_stack((w,dose))
        yp, dp = ols(z,y), ols(z,dose)
        xp = z @ ols(z,x)
        beta = ols(xp,y)
        first_v = hc0(z,dose-z @ dp)[2,2]
        v = hc0(xp,y-x @ beta)
        m = ledger.model('CH19',model)
        m.scalars(n=len(x),first=dp[2],reduced=yp[2],first_t2=dp[2]**2/first_v,
                  effect=beta[2],se_hc0=np.sqrt(v[2,2]))
        for q in range(-40,49):
            u = y-q*dose/4
            b = ols(z,u)
            a = b[2]**2/hc0(z,u-z @ b)[2,2]
            m.add('ar_stat',q,a)
            m.add('ar_p',q,chi2.sf(a,1))
    x = np.column_stack((w,d.dose))
    z = np.column_stack((w,d.z,d.z2))
    y, n = d.outcome.to_numpy(), len(d)
    a, c = z.T @ x/n, z.T @ y/n
    w = np.linalg.inv(z.T @ z/n)
    m = ledger.model('CH19','gmm')
    for step in (1,2):
        beta = np.linalg.solve(a.T @ w @ a,a.T @ w @ c)
        e = y-x @ beta
        g = z.T @ e/n
        m.vector(f'beta{step}',('intercept','x','dose'),beta)
        m.vector(f'moment{step}',('intercept','x','z','z2'),g)
        m.add('objective',step,n*g @ w @ g)
        score = z*e[:,None]
        w = np.linalg.inv(score.T @ score/n)
    d = read('threshold19')
    assert d.record.is_unique and d.eligible.eq(d.running.ge(0)).all()
    m = ledger.model('CH19','rd')
    for hcode in (125,250,375):
        h = hcode/100
        a = d.loc[d.running.abs() < h]
        r, z = a.running.to_numpy(), a.eligible.to_numpy()
        w = 1-abs(r)/h
        x = np.column_stack((np.ones(len(r)),z,r,z*r))
        names = ('sharp','fuzzy','receipt','baseline')
        y = a[list(names)].to_numpy()
        b = ols(x*np.sqrt(w)[:,None],y*np.sqrt(w)[:,None])
        u = y-x @ b
        for j, name in enumerate(names):
            m.add(name,hcode,b[1,j])
        ratio = b[1,1]/b[1,2]
        for name, value in (('left_n',(z==0).sum()),('right_n',(z==1).sum()),
            ('sharp_se',np.sqrt(hc0(x,u[:,0],w)[1,1])),('ratio',ratio),
            ('ratio_se',np.sqrt(hc0(x,(u[:,1]-ratio*u[:,2])/b[1,2],w)[1,1]))):
            m.add(name,hcode,value)
        if hcode==250:
            m.vector('kernel',a.record,w)


def simplex(target, donors):
    best = np.inf
    fit = None
    for s in range(1,donors.shape[1]+1):
        for ix in combinations(range(donors.shape[1]),s):
            x = donors[:,ix]
            a = np.block([[x.T @ x,np.ones((s,1))],[np.ones((1,s)),np.zeros((1,1))]])
            b = np.linalg.solve(a,np.r_[x.T @ target,1])[:-1]
            loss = np.mean((target-x @ b)**2)
            if min(b)>=-1e-9 and loss < best-1e-10:
                best, fit = loss, np.zeros(donors.shape[1])
                fit[list(ix)] = b
    assert fit is not None and abs(fit.sum()-1)<1e-8
    return fit


def individual(read, ledger):
    d = read('selection20').query('eligible == 1').sort_values('record')
    x = np.column_stack((np.ones(len(d)),d.x,d.rural))
    y, a = d.outcome.to_numpy(), d.treated.to_numpy()
    p, m0, m1 = (np.full(len(d),np.nan) for _ in range(3))
    m = ledger.model('CH20','nuisance')
    for f in range(4):
        test = d.fold.to_numpy()==f
        pfit = sm.GLM(a[~test],x[~test],family=sm.families.Binomial()).fit(tol=1e-12)
        assert pfit.converged
        p[test] = pfit.predict(x[test])
        keys = [f'{f}/{name}' for name in ('intercept','x','rural')]
        m.vector('logit',keys,pfit.params)
        for arm, mu in ((0,m0),(1,m1)):
            train = ~test & (a==arm)
            b = ols(x[train],y[train])
            mu[test] = x[test] @ b
            m.vector(f'outcome{arm}',keys,b)
    for key, values in (('p',p),('mu0',m0),('mu1',m1)):
        m.vector(key,d.record,values)
    assert ((p>0)&(p<1)).all()
    for model, i in (('full',np.ones(len(d),dtype=bool)),('trim',(p>=.1)&(p<=.9))):
        yy, aa, pp, mm0, mm1 = y[i],a[i],p[i],m0[i],m1[i]
        share = aa.mean()
        w1, w0 = aa/pp,(1-aa)/(1-pp)
        wc = pp*w0
        score = mm1-mm0+w1*(yy-mm1)-w0*(yy-mm0)
        m = ledger.model('CH20',model)
        m.scalars(n=len(aa),treated=aa.sum(),p_min=pp.min(),p_max=pp.max(),w1=w1.sum(),w0=w0.sum(),
            stable1=share*w1.sum(),stable0=(1-share)*w0.sum(),
            ess1=w1.sum()**2/(w1 @ w1),ess0=w0.sum()**2/(w0 @ w0),
            ipw=np.average(yy,weights=w1)-np.average(yy,weights=w0),
            ipw_att=np.average(yy,weights=aa)-np.average(yy,weights=wc),
            aipw=score.mean(),aipw_att=np.mean((aa-wc)*(yy-mm0))/share,
            score_se=score.std(ddof=1)/np.sqrt(len(aa)))
        m.vector('score',d.record[i],score)
        for j,label in enumerate(('x','rural'),1):
            v = x[i,j]
            v1,v0 = v[aa==1],v[aa==0]
            sd = np.sqrt((v1.var(ddof=1)+v0.var(ddof=1))/2)
            m.add('balance_raw',label,(v1.mean()-v0.mean())/sd)
            m.add('balance_ipw',label,(np.average(v,weights=w1)-np.average(v,weights=w0))/sd)


def places(read, ledger):
    paths = read('places20').pivot(index='period',columns='place',values='outcome').to_numpy()
    assert paths.shape==(12,7) and np.isfinite(paths).all() and (paths[:7,1]==paths[:7,2]).all()
    target, pair = paths[:,0],paths[:,1:3].mean(1)
    for model, ids in (('scm',(3,4,5,6)),('exclude4',(3,5,6))):
        donor = np.column_stack((pair,paths[:,ids]))
        w = simplex(target[:7],donor[:7])
        fit = donor @ w
        gap = target-fit
        full = np.zeros(6)
        full[:2] = w[0]/2
        full[np.asarray(ids)-1] = w[1:]
        m = ledger.model('CH20',model)
        m.vector('weight',range(1,7),full)
        m.vector('fit',range(12),fit)
        m.vector('gap',range(12),gap)
        m.scalars(pre_mse=np.mean(gap[:7]**2),post_gap=gap[7:].mean(),weight_sum=full.sum())
        if model=='scm':
            m.vector('all_d1',range(12),fit+w[0]*(paths[:,1]-pair))
            m.vector('all_d2',range(12),fit+w[0]*(paths[:,2]-pair))


if __name__ == '__main__':
    root, output = map(Path,sys.argv[1:])
    def read(stem):
        return pd.read_csv(root/f'{stem}.csv')
    ledger = Ledger()
    for run in (trial,rollout,instruments,individual,places):
        run(read,ledger)
    output.mkdir(parents=True,exist_ok=True)
    ledger.save(output/'metrics.csv')
    print('Python',sys.version.split()[0],'NumPy',np.__version__,'pandas',pd.__version__,
          'SciPy',scipy.__version__,'statsmodels',statsmodels.__version__,len(ledger.rows),'values')
