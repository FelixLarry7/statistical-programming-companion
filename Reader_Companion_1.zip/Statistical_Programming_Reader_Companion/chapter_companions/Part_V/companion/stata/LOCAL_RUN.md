# Part V verification on local Stata

Use the installed, licensed Stata 17 or 16. The scripts use built-in commands and Mata. The kit includes the nine original synthetic inputs.

1. Extract the archive and set Stata’s working directory to the inner Part_V_Stata_Local_Run folder. In the command window, enter cd followed by the quoted absolute path to that folder.
2. Enter **do run_part5.do**. The wrapper uses a temporary data frame and writes output in a new dated directory.
3. Upload the resulting **Stata_Verification_Part_V_*.zip**. The run should report return code 0. If automatic compression fails, zip the files directly inside the displayed evidence directory. If Stata reports a nonzero return code, share its evidence ZIP or the text log for diagnosis.

Run the wrapper from an ordinary interactive Stata session. The input CSVs, the driver, and the results are retained in the archive to let the verifier confirm the exact run. 
