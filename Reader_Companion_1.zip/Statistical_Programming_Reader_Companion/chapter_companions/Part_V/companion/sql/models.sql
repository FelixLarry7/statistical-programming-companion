-- Independent sample, design and arithmetic checks.
create view trial_rows as
select h.*,v.block,v.offer from households17 h
join villages17 v using(village) where h.eligible=1;

create view trial_cluster as
select village,block,offer,count(*) as n,sum(baseline) as baseline,sum(admin) as admin,
       sum(receipt) as receipt,sum(measured) as measured,sum(survey) as survey
from trial_rows group by all;

create view trial_arm as
select offer,count(*) as villages,sum(n) as n,sum(baseline) as baseline,sum(admin) as admin,
       sum(receipt) as receipt,sum(measured) as measured,sum(survey) as survey
from trial_cluster group by offer;

create view trial_totals as
select sum(admin) as total,sum(n) filter(where offer=1) as n,
       2*sum(admin) filter(where offer=1)-sum(admin) as observed
from trial_cluster;

create view randomisation as
with assignments as (
    unpivot allocations17 on columns('^z[0-9]+$') into name village_label value assigned
), totals as (
    select draw,count(*) as villages,
           sum(assigned) filter(where block=1) as b1,
           sum(assigned) filter(where block=2) as b2,
           sum(assigned<>offer) as mismatches,sum(assigned*admin) as offered
    from assignments a join trial_cluster c
      on cast(substr(a.village_label,2) as integer)=c.village
    group by draw
)
select *,2*offered-total as numerator,(2*offered-total)/n as statistic,
       abs(2*offered-total)>=abs(observed) as extreme
from totals cross join trial_totals;

create view rollout_panel as select * from rollout18 where in_scope=1;
create view did_cells as
select model,g,t,a,g-a-1 as base
from (values ('never',1),('notyet',1),('risky',0)) r(model,a)
cross join (values (3),(5),(7)) c(g)
cross join range(0,10) p(t) where t<>g-a-1;

create view did_stratum as
with changes as (
    select c.*,t.unit,t.x,t.cohort=g as target,t.outcome-b.outcome as dy
    from did_cells c
    join rollout_panel t on t.period=c.t
    join rollout_panel b on b.unit=t.unit and b.period=c.base
    where t.cohort=c.g or t.cohort=0
      or (c.model<>'never' and t.cohort>greatest(c.t,c.base)+c.a)
)
select model,g,t,x,count(*) filter(where target) as nt,count(*) filter(where not target) as nc,
       avg(dy) filter(where target) as mt,avg(dy) filter(where not target) as mc
from changes group by all;

create view did_att as
select model,g,t,t-g as event,sum(nt) as nt,sum(nc) as nc,
       sum(nt*mt)/sum(nt)-sum(nc*mc)/sum(nc) as raw,
       sum(nt*(mt-mc))/sum(nt) as att
from did_stratum group by model,g,t;

create view did_event as
select model,event,sum(nt) as nt,sum(nt*att)/sum(nt) as effect
from did_att group by model,event;

create view iv_partials as
select d.*,z-(r.ic+r.slope*x) as rz from encourage19 d
cross join (select regr_intercept(z,x) as ic,regr_slope(z,x) as slope from encourage19) r;

create view rd_samples as
select d.*,hcode,1-abs(running)/(hcode/100.0) as kernel
from threshold19 d cross join (values (125),(250),(375)) b(hcode)
where abs(running)<hcode/100.0;

create view rd_jumps as
with stacked as (
    unpivot rd_samples on sharp,fuzzy,receipt,baseline into name term value y
), moments as (
    select term,hcode,eligible,sum(kernel) as sw,sum(kernel*running) as sx,
           sum(kernel*running^2) as sxx,sum(kernel*y) as sy,sum(kernel*running*y) as sxy
    from stacked group by all
), fit as (
    select term,hcode,eligible,(sxx*sy-sx*sxy)/(sw*sxx-sx^2) as a from moments
)
select term,hcode,max(a) filter(where eligible=1)-max(a) filter(where eligible=0) as jump
from fit group by all;

create view fold_coefficients as
select quantity,cast(split_part(key,'/',1) as integer) as fold,
       max(value) filter(where split_part(key,'/',2)='intercept') as ic,
       max(value) filter(where split_part(key,'/',2)='x') as bx,
       max(value) filter(where split_part(key,'/',2)='rural') as br
from reference where chapter='CH20' and model='nuisance'
and quantity in ('logit','outcome0','outcome1') group by all;

create view observational as
select d.*,1/(1+exp(-(p.ic+p.bx*x+p.br*rural))) as p,
       a.ic+a.bx*x+a.br*rural as mu0,b.ic+b.bx*x+b.br*rural as mu1
from selection20 d
join fold_coefficients p on p.fold=d.fold and p.quantity='logit'
join fold_coefficients a on a.fold=d.fold and a.quantity='outcome0'
join fold_coefficients b on b.fold=d.fold and b.quantity='outcome1'
where d.eligible=1;

create view weighted_rows as
with populations as (
    select *, 'full' as model from observational
    union all select *, 'trim' as model from observational where p between .1 and .9
), weights as (
    select *,treated/p as w1,(1-treated)/(1-p) as w0,p*(1-treated)/(1-p) as wc
    from populations
)
select *,mu1-mu0+w1*(outcome-mu1)-w0*(outcome-mu0) as score,
       (treated-wc)*(outcome-mu0) as score_att_num from weights;

create view weighted_summary as
select model,count(*) as n,sum(treated) as treated,min(p) as p_min,max(p) as p_max,
       sum(w1) as w1,sum(w0) as w0,avg(treated)*sum(w1) as stable1,
       (1-avg(treated))*sum(w0) as stable0,
       sum(w1)^2/sum(w1^2) as ess1,sum(w0)^2/sum(w0^2) as ess0,
       sum(w1*outcome)/sum(w1)-sum(w0*outcome)/sum(w0) as ipw,
       sum(treated*outcome)/sum(treated)-sum(wc*outcome)/sum(wc) as ipw_att,
       avg(score) as aipw,avg(score_att_num)/avg(treated) as aipw_att,
       stddev_samp(score)/sqrt(count(*)) as score_se
from weighted_rows group by model;

create view weighted_balance as
with a as (unpivot weighted_rows on x,rural into name covariate value z)
select model,covariate,
       (avg(z) filter(where treated=1)-avg(z) filter(where treated=0)) /
       sqrt((var_samp(z) filter(where treated=1)+var_samp(z) filter(where treated=0))/2) as raw,
       (sum(w1*z)/sum(w1)-sum(w0*z)/sum(w0)) /
       sqrt((var_samp(z) filter(where treated=1)+var_samp(z) filter(where treated=0))/2) as ipw
from a group by all;

create view donor_weights as
select model,cast(key as integer) as place,value as weight
from reference where chapter='CH20' and model in ('scm','exclude4') and quantity='weight';

create view donor_fit as
with a as (
    select model,period,sum(weight*outcome) as fit,sum(weight) as weight_sum
    from places20 join donor_weights using(place) group by all
)
select a.*,p.outcome,p.outcome-a.fit as gap
from a join places20 p on p.period=a.period and p.place=0;
