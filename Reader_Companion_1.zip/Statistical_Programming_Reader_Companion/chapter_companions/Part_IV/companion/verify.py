"""Reproduce the Part IV evaluations and verify the optional local Stata run."""

import argparse
from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

from ledger import read


ROOT=Path(__file__).resolve().parent
RAW=ROOT/"data/raw"


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def run(args, log):
    with log.open("w") as stream:
        result=subprocess.run([str(arg) for arg in args],stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Engine returned {result.returncode}. See {log}.")


def stata_evidence(path,out):
    out.mkdir()
    with ZipFile(path) as z:
        if len(z.namelist())!=len(set(z.namelist())):
            raise ValueError("Duplicate member name in Stata evidence.")
        info=dict(line.split("=",1) for line in z.read("run_info.txt").decode().splitlines())
        if info["part4_rc"]!="0":
            raise ValueError(f"The local Stata run returned {info['part4_rc']}.")
        if info["stata_version"] not in {"16","17"}:
            raise ValueError("Expected a licensed Stata 16 or 17 run.")
        driver=z.read("part4_driver.do")
        if driver!=(ROOT/"stata/part4_driver.do").read_bytes():
            raise ValueError("The executed Stata driver differs from the shipped driver.")
        for p in sorted(RAW.glob("*.csv")):
            if p.read_bytes()!=z.read("input_"+p.name):
                raise ValueError(f"The Stata input differs: {p.name}.")
        log=z.read("part4_run.log").decode("utf-8",errors="replace")
        if "Part IV generated in Stata" not in log:
            raise ValueError("Stata completion line is missing.")
        lines=[]
        for line in log.splitlines():
            if re.search(r"(?i)(/Users/|/var/folders/|[a-z]:\\|/home/|/private/)",line):
                lines.append("[Local path removed]")
            elif not (line.startswith("> ") and lines and lines[-1]=="[Local path removed]"):
                lines.append(line)
        (out/"part4_run.log").write_text("\n".join(lines)+"\n")
        for file in ("metrics.csv","run_info.txt","part4_driver.do"):
            (out/file).write_bytes(z.read(file))
    report=dict(info,original_archive_sha256=digest(path.read_bytes()),driver_sha256=digest(driver))
    (out/"environment.json").write_text(json.dumps(report,indent=2)+"\n")
    with ZipFile(out/"evidence_replay.zip","w",ZIP_DEFLATED) as z:
        for name in ("metrics.csv","run_info.txt","part4_driver.do","part4_run.log"):
            z.write(out/name,name)
        for p in sorted(RAW.glob("*.csv")):
            z.write(p,"input_"+p.name)
    return report


def hand_anchors():
    hc1=1.2*sum(2*(x-2.5)**2*(10+5*x)**2 for x in range(6))/35**2
    return {
        ("CH13","pilot","scalar","n"):12,
        ("CH13","pilot","scalar","rank"):2,
        ("CH13","pilot","scalar","df"):10,
        ("CH13","pilot","scalar","rss"):6950,
        ("CH13","pilot","scalar","r2"):1-6950/230950,
        ("CH13","pilot","beta","intercept"):1200,
        ("CH13","pilot","beta","sessions"):80,
        ("CH13","pilot","classical","sessions/sessions"):695/35,
        ("CH13","pilot","hc1","sessions/sessions"):hc1,
        ("CH13","pilot","residual","P001"):-10,
        ("CH13","pilot","residual","P012"):35,
        ("CH13","pilot","leverage","P001"):1/12+2.5**2/35,
        ("CH13","multiple","scalar","df"):33,
        ("CH14","logit","scalar","n"):240,
        ("CH14","poisson","scalar","n"):210,
        ("CH15","riskset","risk","2"):92,
        ("CH15","riskset","events","2"):13,
        ("CH15","riskset","censored","2"):4,
        ("CH15","riskset","km","2"):.79,
        ("CH16","balanced","scalar","n"):60,
        ("CH16","unbalanced","scalar","n"):55,
        ("CH16","balanced","scalar","groups"):10,
    }


def tolerance(key,reference,engine):
    chapter, model, quantity, label=key
    if quantity in {"risk","events","censored"} or (quantity=="scalar" and label in {"n","rank","df","groups"}):
        return 0.
    if engine=="anchor" or chapter=="CH13":
        return 2e-8+1e-9*abs(reference)
    if engine=="duckdb":
        # Normal CDF in SQL is a bounded polynomial approximation.
        return 1.5e-5+2e-8*abs(reference)
    # Independently optimised maximum likelihood with different stopping rules.
    return 2e-6+2e-5*abs(reference)


def audit(out,with_stata):
    base=read(out/"python/metrics.csv")
    other=("r","duckdb","stata") if with_stata else ("r","duckdb")
    if len(base)!=2813:
        raise ValueError("Reference ledger has an unexpected key count.")
    checks=[]
    for engine in ("anchor",*other):
        candidate=hand_anchors() if engine=="anchor" else read(out/engine/"metrics.csv")
        if engine in {"stata","r"} and candidate.keys()!=base.keys():
            raise ValueError(f"{engine}: unmatched keys, missing {list(base.keys()-candidate.keys())[:8]}, extra {list(candidate.keys()-base.keys())[:8]}.")
        if engine=="duckdb" and len(candidate)!=2584:
            raise ValueError("DuckDB evaluation ledger has an unexpected key count.")
        for key,value in sorted(candidate.items()):
            reference=base[key]
            error=abs(value-reference)
            limit=tolerance(key,reference,engine)
            checks.append((engine,*key,value,reference,error,limit,error<=limit))
    with (out/"comparisons.csv").open("w",newline="") as f:
        writer=csv.writer(f,lineterminator="\n")
        writer.writerow(("engine","chapter","model","quantity","key","value","python","abs_error","tolerance","passed"))
        writer.writerows(checks)
    fails=[row for row in checks if not row[-1]]
    if fails:
        raise ValueError(f"{len(fails)} failed comparisons. First failures: {fails[:6]}")
    return dict(Counter(row[0] for row in checks)),dict(Counter(row[1] for row in checks))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    p.add_argument("--rscript",default="Rscript")
    p.add_argument("--stata-evidence",type=Path)
    p.add_argument("--require-four",action="store_true")
    a=p.parse_args()
    if a.require_four and not a.stata_evidence:
        p.error("--require-four needs the evidence ZIP from the local Stata run.")
    out=a.output.resolve()
    if out.exists() and any(out.iterdir()):
        p.error("Choose a new or empty output directory.")
    for engine in ("python","r","duckdb"):
        (out/engine).mkdir(parents=True,exist_ok=True)
    run([sys.executable,ROOT/"fit_python.py",RAW,out/"python"],out/"python/environment.txt")
    run([a.rscript,"--vanilla",ROOT/"fit_r.R",RAW,out/"r"],out/"r/environment.txt")
    run([sys.executable,ROOT/"fit_sql.py",RAW,out/"python/metrics.csv",out/"duckdb"],out/"duckdb/environment.txt")
    stata=stata_evidence(a.stata_evidence,out/"stata") if a.stata_evidence else None
    counts,chapters=audit(out,bool(stata))
    report={
        "status":"VERIFIED" if stata else "STATA EVIDENCE PENDING",
        "comparisons":sum(counts.values()),"failures":0,
        "comparisons_by_engine":counts,"comparisons_by_chapter":chapters,
        "native_fit_engines":["python","r"]+(["stata"] if stata else []),
        "duckdb_scope":"OLS from sufficient statistics, GLM means and likelihood at shared coefficients, censored scores, Cox risk sets and fixed-point likelihood, Gaussian mixed log likelihood and conditional predictions",
        "input_sha256":{p.name:digest(p.read_bytes()) for p in sorted(RAW.glob("*.csv"))},
        "stata":stata,
    }
    (out/"verification.json").write_text(json.dumps(report,indent=2)+"\n")
    print(report["status"],report["comparisons"],counts,chapters)


if __name__=="__main__":
    main()
