-- All named inputs are loaded by fit_sql.py from frozen CSV files.
CREATE TEMP VIEW ols_rows AS
SELECT 'pilot' AS model, plot_id, sessions::DOUBLE AS x, 0.0::DOUBLE AS z,
       yield_kg_ha AS y FROM pilot13
UNION ALL
SELECT 'multiple', plot_id, sessions::DOUBLE, irrigated::DOUBLE, yield_kg_ha
FROM regression13;

CREATE TEMP VIEW ols_moments AS
SELECT model, count(*) AS n, sum(x) AS sx, sum(z) AS sz,
       sum(x*x) AS sxx, sum(x*z) AS sxz, sum(z*z) AS szz,
       sum(y) AS sy, sum(x*y) AS sxy, sum(z*y) AS szy,
       var_pop(y)*count(*) AS tss
FROM ols_rows GROUP BY model;

-- The normal CDF approximation is used only in the fixture's moderate index range.
CREATE MACRO normal_pdf(q) AS exp(-q*q/2)/sqrt(2*pi());
CREATE MACRO normal_t(q) AS 1/(1+0.2316419*abs(q));
CREATE MACRO normal_poly(t) AS
    t*(0.319381530+t*(-0.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));
CREATE MACRO normal_tail(q) AS normal_pdf(q)*normal_poly(normal_t(q));
CREATE MACRO normal_cdf(q) AS
    CASE WHEN q<0 THEN normal_tail(q) ELSE 1-normal_tail(q) END;
CREATE MACRO inverse_link(model, q) AS
    CASE model WHEN 'logit' THEN 1/(1+exp(-q))
               WHEN 'probit' THEN normal_cdf(q) ELSE exp(q) END;

CREATE TEMP VIEW glm_design AS
SELECT model, case_id AS id, contacts AS x, rural AS z, event AS y, 0.0::DOUBLE AS off
FROM delivery14 CROSS JOIN (VALUES ('logit'), ('probit')) b(model)
UNION ALL
SELECT model, count_id, capacity, rural, appointments, ln(days/30.0)
FROM appointments14 CROSS JOIN (VALUES ('poisson'), ('nb2')) c(model);

CREATE TEMP VIEW glm_grid AS
SELECT model, scenario_id AS id, contacts AS x, rural AS z, 0.0::DOUBLE AS off
FROM prediction14 CROSS JOIN (VALUES ('logit'), ('probit')) b(model)
UNION ALL
SELECT model, scenario_id, capacity, rural, ln(days/30.0)
FROM prediction14 CROSS JOIN (VALUES ('poisson'), ('nb2')) c(model);

CREATE TEMP VIEW censored_normal AS
WITH zscores AS (
  SELECT *, (-.9-.8*resources)/1.2 AS a,
         (expenditure-.9-.8*resources)/1.2 AS z
  FROM censor15
), contributions AS (
  SELECT *, normal_pdf(a)/normal_cdf(a) AS mills
  FROM zscores
), scores AS (
  SELECT case_id, resources,
         CASE WHEN censored=1 THEN ln(normal_cdf(a))
              ELSE ln(normal_pdf(z))-ln(1.2) END AS ll,
         CASE WHEN censored=1 THEN -mills/1.2 ELSE z/1.2 END AS intercept,
         CASE WHEN censored=1 THEN -a*mills ELSE z*z-1 END AS logsig
  FROM contributions
)
SELECT case_id,ll,intercept,resources*intercept AS beta,logsig
FROM scores;

CREATE TEMP VIEW risk_sets AS
WITH times AS (SELECT DISTINCT duration AS t FROM duration15 WHERE event=1),
subjects AS (
    SELECT *, .30*risk-.25*supported AS eta FROM duration15
)
SELECT t, count(*) AS risk,
       count(*) FILTER (duration=t AND event=1) AS failures,
       count(*) FILTER (duration=t AND event=0) AS censored,
       sum(exp(eta)) AS r_weight,
       sum(exp(eta)) FILTER (duration=t AND event=1) AS d_weight,
       sum(eta) FILTER (duration=t AND event=1) AS d_index
FROM times JOIN subjects ON duration>=t
GROUP BY t;

CREATE TEMP VIEW cox_fixed AS
SELECT model,t,d_index-sum(ln(r_weight-frac*d_weight)) AS ll
FROM risk_sets
CROSS JOIN (VALUES ('breslow'), ('efron')) a(model)
CROSS JOIN LATERAL (
    SELECT CASE WHEN model='efron' THEN i/failures ELSE 0 END AS frac
    FROM range(failures) j(i)
) frac
GROUP BY model,t,d_index;

CREATE TEMP VIEW mixed_rows AS
SELECT 'balanced' AS model,patient_id,facility_id,baseline,outcome
FROM facilities16 WHERE balanced=1
UNION ALL
SELECT 'unbalanced',patient_id,facility_id,baseline,outcome
FROM facilities16 WHERE unbalanced=1;
