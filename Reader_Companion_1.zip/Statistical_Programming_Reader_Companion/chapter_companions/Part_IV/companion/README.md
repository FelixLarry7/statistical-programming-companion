# Part IV computational companion

The companion aligns model inputs and output keys across four analytical environments. All records are synthetic teaching data, including the reconstructed Stage 2 agricultural pilot. `data/codebook.csv` and `data/provenance.json` identify the fields, units, rows, and origin. `make_fixtures.py` can regenerate the input CSVs with the pinned NumPy release. Regenerate into a working directory to compare checksums with the frozen inputs.

## Reproduce the checks

The release used Python 3.12 with statsmodels 0.14.6, SciPy 1.17.0, NumPy 2.3.5, pandas 2.2.3, and DuckDB 1.4.4. R 4.5.0 used MASS 7.3-65, survival 3.8-3, and nlme 3.1-168. A licensed Stata 17 IC installation produced the native Stata output. The offline do-files use syntax for Stata 16 or 17.

From this directory, choose a new or empty output folder:

```bash
python -m pip install -r requirements.txt
python verify.py --output ./my_run \
  --stata-evidence ./evidence/stata/evidence_replay.zip \
  --require-four
```

This runs Python, R, and DuckDB and checks their results against the retained local Stata evidence. Use `--rscript` to specify the location of Rscript. For a fresh Stata execution, copy the eight CSVs from `data/raw/` into an `inputs` folder beside the two do-files in a clean folder, then follow `stata/LOCAL_RUN.md`. Pass the new evidence ZIP to the verifier. Its executed script, exact input bytes, completion line, and zero return code are checked. The supplied replay archive contains the original results and the local execution log with personal paths removed.

## Scope of numerical agreement

| Chapter | Native model or calculation | DuckDB contribution |
|---|---|---|
| 13 | Simple and multiple OLS, two covariance matrices, residuals, leverage, and Cook’s distance | Rebuild the pilot sample and compute cross-products, covariance components, and diagnostics |
| 14 | Logit, probit, Poisson, and NB2 fits, linear predictors, marginal effects, and predictions | Validate inputs and offset, export the common grid, and evaluate means and likelihoods at shared coefficients |
| 15 | Breslow and Efron Cox fits and fixed-parameter censored-normal likelihoods and scores | Construct risk sets, check ties and survival, and calculate censored scores |
| 16 | Balanced and unbalanced Gaussian random-intercept ML, variances, and conditional predictions | Validate nesting and evaluate the common likelihood and shrinkage from facility sums |

The selection discussion develops the identifying model. The companion’s additional Tobit optimisation and ML–REML sensitivity are Python demonstrations. The matched Tobit verification uses the fixed evaluation vector. SQL uses the Abramowitz–Stegun central-range normal-CDF polynomial for the probit and censored calculations, evaluated against native normal functions on the frozen data. The licensed verification uses built-in Stata commands.

## Inspect the evidence

Each `metrics.csv` has the columns chapter, model, quantity, key, and value. A key is a parameter, row, facility, time, or named summary within its quantity. `comparisons.csv` reports the full-precision values, errors, and acceptance tolerances. The total comprises 2,813 R comparisons, 2,813 Stata comparisons, 2,584 DuckDB evaluations, and 22 independent analytical or count anchors, all referenced to the Python ledger. Counts, rank, degrees of freedom, and risk-set totals compare exactly. Linear algebra uses tight absolute and relative tolerances. Maximum-likelihood comparisons allow for small differences in stopping rules. Each comparison records its tolerance explicitly.

The `duckdb/` directory contains the pilot disposition audit, design checks, grid, risk sets, and facility sums. The `python/diagnostics.json` file includes the failed-rank design, deletion and intercept changes, the separation path, the one-unit offset check, and the optional REML sensitivity. `r/proportional_hazards.csv` reports the rank-time diagnostic. `figure_data/` preserves the plotted values. `verification.json` identifies the confirmed inputs, scopes, and Stata environment.
