"""Keyed numeric output shared by the companion runners."""

import csv
import math


FIELDS=("chapter","model","quantity","key","value")


class Ledger:
    def __init__(self):
        self.rows={}

    def model(self, chapter, model):
        return ModelLedger(self,chapter,model)

    def save(self, path):
        with path.open("w",newline="") as stream:
            writer=csv.writer(stream,lineterminator="\n")
            writer.writerow(FIELDS)
            writer.writerows((*key,value) for key,value in sorted(self.rows.items()))


class ModelLedger:
    def __init__(self, ledger, chapter, model):
        self.ledger,self.prefix=ledger,(chapter,model)

    def add(self, quantity, key, value):
        k=(*self.prefix,quantity,str(key))
        if k in self.ledger.rows or not math.isfinite(float(value)):
            raise ValueError(f"Duplicate or non-finite metric {k}: {value}")
        self.ledger.rows[k]=float(value)

    def vector(self, quantity, keys, values):
        for key,value in zip(keys,values,strict=True):
            self.add(quantity,key,value)

    def matrix(self, quantity, keys, values):
        for a,row in zip(keys,values,strict=True):
            for b,value in zip(keys,row,strict=True):
                self.add(quantity,f"{a}/{b}",value)

    def scalars(self, **values):
        self.vector("scalar",values.keys(),values.values())


def read(path):
    result={}
    with path.open(newline="") as stream:
        rows=csv.DictReader(stream)
        if rows.fieldnames!=list(FIELDS):
            raise ValueError(f"{path}: incorrect ledger columns {rows.fieldnames}.")
        for row in rows:
            key=tuple(row[k] for k in FIELDS[:-1])
            value=float(row["value"])
            if key in result or not math.isfinite(value):
                raise ValueError(f"{path}: invalid metric {key}.")
            result[key]=value
    return result
