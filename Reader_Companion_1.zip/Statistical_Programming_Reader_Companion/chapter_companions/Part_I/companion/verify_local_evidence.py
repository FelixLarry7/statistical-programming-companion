"""Verify the two runs returned by the offline Stata driver."""

import argparse
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile

from run import EXTRACTS, ROOT, digest


STAGE2_RESULTS = ('coefficients.csv', 'covariance.csv', 'predictions.csv',
                  'fit.json', 'environment.txt', 'completed.txt')
EXPECTED = {
    'run_info.txt', 'stage2_run.log', 'part1_run.log', 'stage2_analytical.csv',
    'stage2_driver.do', 'part1_driver.do', 'part1_metrics.csv',
    *('stage2_' + name for name in STAGE2_RESULTS),
    *(f'part1_{name}.csv' for name in EXTRACTS),
}


def read_zip(archive, folder):
    with ZipFile(archive) as bundle:
        seen = set()
        for member in bundle.infolist():
            name = Path(member.filename).name
            if member.is_dir() or name not in EXPECTED:
                continue
            if name in seen:
                raise ValueError(f'Duplicate evidence file in ZIP: {name}')
            seen.add(name)
            (folder / name).write_bytes(bundle.read(member))
    if 'run_info.txt' not in seen:
        raise ValueError('The evidence ZIP lacks run_info.txt.')


def verify_stage2(evidence, stage2_root, rscript, output):
    expected_input = stage2_root / 'evidence/baseline/duckdb/analytical.csv'
    if digest(evidence / 'stage2_analytical.csv') != digest(expected_input):
        raise ValueError('The Stage 2 analytical input differs from the frozen extract.')
    if digest(evidence / 'stage2_driver.do') != digest(stage2_root / 'stata/pilot/fit_ols.do'):
        raise ValueError('The Stage 2 do-file differs from the frozen verification driver.')
    staged = output / 'stage2_input'
    staged.mkdir()
    for name in STAGE2_RESULTS:
        shutil.copyfile(evidence / ('stage2_' + name), staged / name)
    (staged / 'input_sha256.txt').write_text(digest(expected_input) + '\n', encoding='ascii')
    return subprocess.run([
        sys.executable, str(stage2_root / 'run.py'), '--output', str(output / 'stage2'),
        '--rscript', rscript, '--stata-results', str(staged), '--require-all',
    ], cwd=stage2_root, check=False).returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--stage2-root', type=Path, required=True, help='Extracted Stage 2 package')
    parser.add_argument('--output', type=Path, required=True, help='New verification output folder')
    parser.add_argument('--rscript', default=shutil.which('Rscript'))
    args = parser.parse_args()
    if not args.rscript:
        parser.error('Provide the Rscript executable.')
    output = args.output.resolve()
    evidence = output / 'returned'
    evidence.mkdir(parents=True, exist_ok=False)
    read_zip(args.archive, evidence)
    info = dict(line.split('=', 1) for line in (evidence / 'run_info.txt').read_text().splitlines()
                if '=' in line)
    if float(info.get('stata_version', '0')) < 16:
        raise ValueError('The evidence must identify the installed Stata version.')
    codes = {}
    if info.get('stage2_rc') == '0':
        codes['Stage 2'] = verify_stage2(evidence, args.stage2_root.resolve(), args.rscript, output)
    else:
        print('Stage 2 stopped on the local computer. Read returned/stage2_run.log.')
        codes['Stage 2'] = 1
    if info.get('part1_rc') == '0':
        codes['Part I'] = subprocess.run([
            sys.executable, str(ROOT / 'run.py'), '--output', str(output / 'part1'),
            '--rscript', args.rscript, '--stata-results', str(evidence),
        ], cwd=ROOT, check=False).returncode
    else:
        print('Part I stopped on the local computer. Read returned/part1_run.log.')
        codes['Part I'] = 1
    print('Verification return codes', codes)
    return int(any(codes.values()))


if __name__ == '__main__':
    raise SystemExit(main())
