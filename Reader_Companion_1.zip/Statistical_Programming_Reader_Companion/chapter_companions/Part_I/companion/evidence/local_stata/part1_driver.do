*! Part I. Requires a licensed installation with Stata 16 syntax or newer.
version 16.0
set more off
args folder output
if `"`folder'"' == "" | `"`output'"' == "" {
    display as error "Supply the canonical directory and output CSV"
    exit 198
}

tempfile results
tempname p control offered stratified
postfile `p' str4 chapter str20 metric str20 grp double value using `"`results'"'

import delimited using `"`folder'/ch02.csv"', clear varnames(1) stringcols(1 2) asdouble
isid invoice_id
foreach channel in agent branch digital {
    quietly summarize net_minor if channel == "`channel'", meanonly
    post `p' ("CH02") ("invoices") ("`channel'") (r(N))
    post `p' ("CH02") ("net_minor") ("`channel'") (r(sum))
}
quietly summarize net_minor, meanonly
post `p' ("CH02") ("net_minor") ("all") (r(sum))

import delimited using `"`folder'/ch03.csv"', clear varnames(1) stringcols(1 2 3 5 6 7) asdouble
isid row_id, sort
assert valid_key == !missing(unit_id)
assert usable == (!missing(unit_id) & !missing(value_double))
quietly count if valid_key == 1
post `p' ("CH03") ("valid_keys") ("all") (r(N))
egen byte first_key = tag(unit_id) if valid_key == 1
quietly count if first_key == 1
post `p' ("CH03") ("distinct_keys") ("all") (r(N))
quietly summarize value_double if usable == 1, meanonly
post `p' ("CH03") ("usable") ("all") (r(N))
post `p' ("CH03") ("mean_usable") ("all") (r(mean))
foreach state in blank extended_missing finite infinite nan {
    quietly count if value_state == "`state'"
    post `p' ("CH03") ("value_state") ("`state'") (r(N))
}
generate byte mapped_rank = cond(rank_label == "low", 1, cond(rank_label == "medium", 2, 3))
assert mapped_rank == rank_code
forvalues row = 1/`=_N' {
    post `p' ("CH03") ("rank_code") (row_id[`row']) (mapped_rank[`row'])
}
quietly summarize value_double if row_id == "r02", meanonly
post `p' ("CH03") ("float32_loss") ("r02") (r(mean) - float(r(mean)))
import delimited using `"`folder'/draws.csv"', clear varnames(1) stringcols(1) asdouble
quietly count if u < .5 & !missing(u)
post `p' ("CH03") ("draw_lt_half") ("all") (r(N))

import delimited using `"`folder'/ch04.csv"', clear varnames(1) stringcols(1) asdouble
isid episode_id
post `p' ("CH04") ("eligible") ("all") (_N)
quietly summarize reached_30d, meanonly
post `p' ("CH04") ("coverage") ("all") (r(mean))
quietly summarize reached_30d if offer == 0, meanonly
scalar `control' = r(mean)
quietly summarize reached_30d if offer == 1, meanonly
scalar `offered' = r(mean)
post `p' ("CH04") ("coverage") ("control") (`control')
post `p' ("CH04") ("coverage") ("offered") (`offered')
post `p' ("CH04") ("difference") ("crude") (`offered' - `control')
scalar `stratified' = 0
foreach risk in 0 1 {
    quietly summarize reached_30d if offer == 0 & baseline_high == `risk', meanonly
    scalar `control' = r(mean)
    quietly summarize reached_30d if offer == 1 & baseline_high == `risk', meanonly
    scalar `stratified' = `stratified' + .5 * (r(mean) - `control')
}
post `p' ("CH04") ("difference") ("standardised") (`stratified')
generate double brier = (cond(baseline_high == 1, .3, .7) - reached_30d)^2
quietly summarize brier, meanonly
post `p' ("CH04") ("brier") ("frozen") (r(mean))
replace brier = (.5 - reached_30d)^2
quietly summarize brier, meanonly
post `p' ("CH04") ("brier") ("constant") (r(mean))

* Chapter 1. Scenario refits and independent uncertainty checks.
tempfile maize event_rows event_sums ledger
tempname slopec interceptc ssec sec leveragec sxxc n meanx trace det
import delimited using `"`folder'/ch01_maize.csv"', clear varnames(1) stringcols(1) asdouble
isid plot_id season, sort
save `"`maize'"'
foreach scenario in full trim_high scaled_tenth {
    use `"`maize'"', clear
    if "`scenario'" == "trim_high" {
        quietly keep if sessions < 5
    }
    if "`scenario'" == "scaled_tenth" {
        quietly recast double yield_kg_ha
        quietly replace yield_kg_ha = yield_kg_ha / 10
    }
    quietly regress yield_kg_ha sessions
    assert e(rank) == 2 & e(N) == _N
    scalar `n' = e(N)
    scalar `slopec' = _b[sessions]
    scalar `interceptc' = _b[_cons]
    scalar `ssec' = e(rss)
    scalar `sec' = _se[sessions]
    quietly predict double leverage, hat
    quietly summarize leverage, meanonly
    scalar `leveragec' = r(max)
    quietly summarize sessions
    scalar `sxxc' = (r(N)-1)*r(Var)
    quietly regress yield_kg_ha sessions, vce(robust)
    post `p' ("CH01") ("sample_n") ("`scenario'") (`n')
    post `p' ("CH01") ("slope") ("`scenario'") (`slopec')
    post `p' ("CH01") ("intercept") ("`scenario'") (`interceptc')
    post `p' ("CH01") ("sxx") ("`scenario'") (`sxxc')
    post `p' ("CH01") ("sse") ("`scenario'") (`ssec')
    post `p' ("CH01") ("classical_se") ("`scenario'") (`sec')
    post `p' ("CH01") ("hc1_se") ("`scenario'") (_se[sessions])
    post `p' ("CH01") ("max_leverage") ("`scenario'") (`leveragec')
}

* Chapter 2. Compare invoice grain with the expanded event join.
tempname refunds gross incorrect correct
import delimited using `"`folder'/ch02_refunds.csv"', clear varnames(1) stringcols(1 2) asdouble
isid refund_id
quietly summarize refund_minor, meanonly
scalar `refunds' = r(sum)
post `p' ("CH02") ("settled_events") ("all") (_N)
post `p' ("CH02") ("refund_minor") ("all") (`refunds')
save `"`event_rows'"'
quietly collapse (sum) refund_minor, by(invoice_id)
save `"`event_sums'"'
import delimited using `"`folder'/ch02_ledger.csv"', clear varnames(1) stringcols(1 2) asdouble
isid invoice_id
save `"`ledger'"'
quietly summarize amount_minor, meanonly
scalar `gross' = r(sum)
post `p' ("CH02") ("gross_minor") ("all") (`gross')
quietly merge 1:m invoice_id using `"`event_rows'"', assert(master match) nogen
generate double net = amount_minor - cond(missing(refund_minor),0,refund_minor)
quietly summarize net, meanonly
scalar `incorrect' = r(sum)
post `p' ("CH02") ("join_rows") ("unaggregated") (_N)
post `p' ("CH02") ("inflated_net_minor") ("unaggregated") (`incorrect')
use `"`ledger'"', clear
quietly merge 1:1 invoice_id using `"`event_sums'"', assert(master match) nogen
generate double net = amount_minor - cond(missing(refund_minor),0,refund_minor)
quietly summarize net, meanonly
scalar `correct' = r(sum)
post `p' ("CH02") ("pooled_mean_minor") ("all") (r(mean))
post `p' ("CH02") ("excess_minor") ("unaggregated") (`incorrect' - `correct')
quietly collapse (mean) net, by(channel)
quietly summarize net, meanonly
post `p' ("CH02") ("channel_mean_minor") ("all") (r(mean))

* Chapter 3. Change the reference level, then check invariant predictions.
import delimited using `"`folder'/ch03_design.csv"', clear varnames(1) stringcols(1 2) asdouble
isid unit_id
generate byte medium = level == "medium"
generate byte high = level == "high"
generate byte low = level == "low"
quietly regress outcome medium high
assert e(rank) == 3 & e(N) == _N
post `p' ("CH03") ("coef_low_ref") ("intercept") (_b[_cons])
post `p' ("CH03") ("coef_low_ref") ("medium") (_b[medium])
post `p' ("CH03") ("coef_low_ref") ("high") (_b[high])
post `p' ("CH03") ("design_sse") ("low_ref") (e(rss))
post `p' ("CH03") ("design_rank") ("both") (e(rank))
quietly predict double fitted_low, xb
quietly regress outcome low medium
assert e(rank) == 3 & e(N) == _N
post `p' ("CH03") ("coef_high_ref") ("intercept") (_b[_cons])
post `p' ("CH03") ("coef_high_ref") ("low") (_b[low])
post `p' ("CH03") ("coef_high_ref") ("medium") (_b[medium])
post `p' ("CH03") ("design_sse") ("high_ref") (e(rss))
quietly predict double fitted_high, xb
generate double gap = abs(fitted_low-fitted_high)
quietly summarize gap, meanonly
post `p' ("CH03") ("fitted_gap") ("both") (r(max))
tempname big
scalar `big' = 1e16
post `p' ("CH03") ("sum_order") ("left_assoc") ((`big'+1)-`big')
post `p' ("CH03") ("sum_order") ("reordered") ((`big'-`big')+1)
use `"`maize'"', clear
quietly summarize sessions
scalar `n' = r(N)
scalar `meanx' = r(mean)
scalar `sxxc' = (`n'-1)*r(Var)
scalar `trace' = `n'+`sxxc'+`n'*(`meanx'+1000000)^2
scalar `det' = `n'*`sxxc'
post `p' ("CH03") ("condition") ("uncentered") ((`trace'+sqrt(`trace'^2-4*`det'))/(2*sqrt(`det')))
post `p' ("CH03") ("condition") ("centered") (sqrt(max(`n',`sxxc')/min(`n',`sxxc')))

* Chapter 4. Bounds in the eligible population and Brier decomposition.
tempname lo_control hi_control lo_offer hi_offer lo_std hi_std
import delimited using `"`folder'/ch04_eligible.csv"', clear varnames(1) stringcols(1) asdouble
isid episode_id
post `p' ("CH04") ("target_n") ("all") (_N)
quietly count if offer == 1 & missing(reached_30d)
post `p' ("CH04") ("missing_outcome") ("offered") (r(N))
scalar `lo_std' = 0
scalar `hi_std' = 0
foreach risk in 0 1 2 {
    foreach arm in 0 1 {
        quietly count if (baseline_high == `risk' | `risk' == 2) & offer == `arm'
        local count = r(N)
        assert `count' > 0
        quietly count if (baseline_high == `risk' | `risk' == 2) & offer == `arm' & reached_30d == 1
        local hits = r(N)
        quietly count if (baseline_high == `risk' | `risk' == 2) & offer == `arm' & missing(reached_30d)
        if `arm' == 0 {
            scalar `lo_control' = `hits'/`count'
            scalar `hi_control' = (`hits'+r(N))/`count'
        }
        else {
            scalar `lo_offer' = `hits'/`count'
            scalar `hi_offer' = (`hits'+r(N))/`count'
        }
    }
    if `risk' == 2 {
        post `p' ("CH04") ("crude_bound") ("lower") (`lo_offer'-`hi_control')
        post `p' ("CH04") ("crude_bound") ("upper") (`hi_offer'-`lo_control')
    }
    else {
        scalar `lo_std' = `lo_std'+.5*(`lo_offer'-`hi_control')
        scalar `hi_std' = `hi_std'+.5*(`hi_offer'-`lo_control')
    }
}
post `p' ("CH04") ("standardised_bound") ("lower") (`lo_std')
post `p' ("CH04") ("standardised_bound") ("upper") (`hi_std')

tempname outcome_mean rel res unc
import delimited using `"`folder'/ch04.csv"', clear varnames(1) stringcols(1) asdouble
quietly summarize reached_30d, meanonly
scalar `outcome_mean' = r(mean)
scalar `rel' = 0
scalar `res' = 0
foreach risk in 0 1 {
    quietly summarize reached_30d if baseline_high == `risk', meanonly
    scalar `rel' = `rel'+(r(N)/_N)*(cond(`risk'==0,.7,.3)-r(mean))^2
    scalar `res' = `res'+(r(N)/_N)*(r(mean)-`outcome_mean')^2
}
scalar `unc' = `outcome_mean'*(1-`outcome_mean')
post `p' ("CH04") ("brier_component") ("reliability") (`rel')
post `p' ("CH04") ("brier_component") ("resolution") (`res')
post `p' ("CH04") ("brier_component") ("uncertainty") (`unc')
post `p' ("CH04") ("brier_component") ("reconstructed") (`rel'-`res'+`unc')

postclose `p'
use `"`results'"', clear
isid chapter metric grp
sort chapter metric grp
tempname metrics_file
file open `metrics_file' using `"`output'"', write text replace
file write `metrics_file' "chapter,metric,grp,value" _n
forvalues row = 1/`=_N' {
    file write `metrics_file' (chapter[`row']) "," (metric[`row']) "," (grp[`row']) "," ///
        %24.17g (value[`row']) _n
}
file close `metrics_file'
display "Stata `c(stata_version)' `c(flavor)' `c(born_date)'"
