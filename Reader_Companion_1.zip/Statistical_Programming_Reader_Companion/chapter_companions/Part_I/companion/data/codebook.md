# Part I data codebook

All records are original synthetic teaching material. They describe no actual invoice, household or instrument record. The `evidence/verification.json` file binds the source and canonical hashes to the retained run. CSV files use UTF-8 with a header and comma delimiters.

## Chapter 1 maize regression audit

The frozen `maize_pilot.csv` comes from Stage 2 example CH13-OLS-01. Its analytical unit is a plot-season, keyed by plot_id and season. Area is in hectares, harvest is in kilograms, sessions is a count and yield_kg_ha is kilograms per hectare. The scenarios are the twelve eligible observations, the ten eligible observations with session counts below five, and the full observations with yield divided by ten. Each result key includes the scenario. Standard errors are reported on the corresponding outcome scale.

## Chapter 2 invoice ledger

| Field | Representation | Definition |
|---|---|---|
| invoice_id | Unique text | Invoice identifier |
| channel | Text | Agent, branch or digital |
| quarter | Text | Calendar quarter label |
| currency | Text | ISO currency code in the source |
| amount_minor | Nonnegative integer | Invoiced amount in that currency's minor units |
| refund_minor | Nonnegative integer | Refund in the same units, no greater than amount |
| state | Text | Posting status |

Select posted GHS invoices for 2025Q1. The canonical columns are invoice_id, channel and net_minor, computed as amount_minor less refund_minor. Keep posted zero-net amounts.

The extended `refund_events.csv` has one row per refund_id with invoice_id as its parent, a calendar event_day, a status and an integer refund_minor. Select settled events before 1 April 2025 linked to the eligible invoices. The event extract has one row per refund_id, and the gross ledger has one row per invoice_id. The intentional error sums gross less refund on the expanded join. The corrected calculation aggregates refunds first.

## Chapter 3 representation audit

| Field | Representation | Definition |
|---|---|---|
| row_id | Unique text | Raw audit row identifier |
| unit_id | Text or blank | Unit identifier with exact digits and leading zeroes |
| rank_label | Text | Low, medium, or high in that order |
| value_token | Text or blank | Original measurement, extended missing token or non-finite token |
| missing_reason | Text | Reason supplied with the source value |

The audit adds rank_code, value_state, valid_key, usable and value_double. Only finite values populate value_double. The summary includes valid keyed finite values. The fixed draws file contains a unique text draw_id and a number u in [0, 1).

The `encoding_design.csv` file contains six unique unit_id values, the nominal level low, medium or high, and a finite numeric outcome. It supports both intercept-and-indicator fits. The condition-number calculation uses the full maize session predictor and the declared offset of one million.

## Chapter 4 service coverage

| Field | Representation | Definition |
|---|---|---|
| episode_id | Unique text | Household-service episode identifier |
| cohort | Integer | Cohort year |
| consent | Binary | Baseline consent indicator |
| baseline_high | Binary | Pre-offer high-risk indicator |
| offer | Binary | Whether the reminder was offered |
| reached_30d | Binary or blank | Recorded service completion by day 30 |
| opened | Binary | Recorded post-offer message opening |

Exclude records outside 2025, then records without consent, then records with missing outcomes. Record the first applicable reason. The canonical table carries episode_id, baseline_high, offer, reached_30d and opened. The complete-case outputs include coverage, the crude offer contrast and equal-weight standardisation by baseline risk. The frozen probabilities are 0.7 for lower risk and 0.3 for higher risk. The complete-case Brier scores compare that rule with a constant 0.5 rule.

The separate eligible extract applies only the cohort and consent exclusions. It retains the missing outcome and supports bounds on the crude and equal-risk contrasts. The Brier decomposition uses the two distinct frozen probabilities in the complete-case extract and their observed outcome rates.
