# Source within labs.R after reading the original Part I inputs.
maize <- input("ch01_maize.csv", c("character", "integer", "numeric", "numeric", "integer", "numeric"))
stopifnot(!anyDuplicated(maize[c("plot_id", "season")]))
for (scenario in c("full", "trim_high", "scaled_tenth")) {
    data <- if (scenario == "trim_high") subset(maize, sessions < 5) else maize
    if (scenario == "scaled_tenth") data$yield_kg_ha <- data$yield_kg_ha / 10
    fit <- lm(yield_kg_ha ~ sessions, data = data, na.action = na.fail)
    n <- nobs(fit)
    centered <- data$sessions - mean(data$sessions)
    sxx <- sum(centered^2)
    values <- c(sample_n = n, slope = coef(fit)[[2L]], intercept = coef(fit)[[1L]],
                sxx = sxx, sse = sum(resid(fit)^2), classical_se = sqrt(vcov(fit)[2L, 2L]),
                hc1_se = sqrt(n/(n-2)*sum((centered*resid(fit))^2)/sxx^2),
                max_leverage = max(hatvalues(fit)))
    emit("CH01", names(values), scenario, unname(values))
}

ledger <- input("ch02_ledger.csv", c("character", "character", "numeric"))
events <- input("ch02_refunds.csv", c("character", "character", "numeric"))
stopifnot(!anyDuplicated(ledger$invoice_id), !anyDuplicated(events$refund_id))
broken <- merge(ledger, events, by = "invoice_id", all.x = TRUE)
refund_sum <- aggregate(refund_minor ~ invoice_id, events, sum)
valid <- merge(ledger, refund_sum, by = "invoice_id", all.x = TRUE)
net <- valid$amount_minor - ifelse(is.na(valid$refund_minor), 0, valid$refund_minor)
inflated <- sum(broken$amount_minor - ifelse(is.na(broken$refund_minor), 0, broken$refund_minor))
emit("CH02", c("settled_events", "gross_minor", "refund_minor"), "all",
     c(nrow(events), sum(ledger$amount_minor), sum(events$refund_minor)))
emit("CH02", c("join_rows", "inflated_net_minor", "excess_minor"), "unaggregated",
     c(nrow(broken), inflated, inflated-sum(net)))
emit("CH02", c("pooled_mean_minor", "channel_mean_minor"), "all",
     c(mean(net), mean(tapply(net, valid$channel, mean))))

design <- input("ch03_design.csv", c("character", "character", "numeric"))
design$level <- factor(design$level, levels = c("low", "medium", "high"))
low <- lm(outcome ~ level, design, contrasts = list(level = "contr.treatment"))
design$level <- relevel(design$level, ref = "high")
high <- lm(outcome ~ level, design, contrasts = list(level = "contr.treatment"))
stopifnot(low$rank == 3L, high$rank == 3L)
emit("CH03", "coef_low_ref", c("intercept", "medium", "high"), unname(coef(low)))
emit("CH03", "coef_high_ref", c("intercept", "low", "medium"), unname(coef(high)))
emit("CH03", "design_sse", c("low_ref", "high_ref"),
     c(sum(resid(low)^2), sum(resid(high)^2)))
emit("CH03", c("design_rank", "fitted_gap"), "both",
     c(low$rank, max(abs(fitted(low)-fitted(high)))))
big <- 1e16
emit("CH03", "sum_order", c("left_assoc", "reordered"), c((big+1)-big, (big-big)+1))
x <- maize$sessions
sxx <- sum((x-mean(x))^2)
n <- length(x)
trace <- n+sxx+n*(mean(x)+1e6)^2
det <- n*sxx
emit("CH03", "condition", c("uncentered", "centered"),
     c((trace+sqrt(trace^2-4*det))/(2*sqrt(det)), sqrt(max(n,sxx)/min(n,sxx))))

eligible <- input("ch04_eligible.csv", c("character", "integer", "integer", "integer"))
arm_bounds <- function(data) {
    successes <- sum(data, na.rm = TRUE)
    c(lower = successes/length(data), upper = (successes+sum(is.na(data)))/length(data))
}
contrast_bounds <- function(data) {
    control <- arm_bounds(data$reached_30d[data$offer == 0L])
    offered <- arm_bounds(data$reached_30d[data$offer == 1L])
    c(lower = offered[["lower"]]-control[["upper"]],
      upper = offered[["upper"]]-control[["lower"]])
}
crude <- contrast_bounds(eligible)
standardised <- rowMeans(sapply(split(eligible, eligible$baseline_high), contrast_bounds))
emit("CH04", "target_n", "all", nrow(eligible))
emit("CH04", "missing_outcome", "offered", sum(is.na(eligible$reached_30d) & eligible$offer == 1L))
emit("CH04", "crude_bound", names(crude), unname(crude))
emit("CH04", "standardised_bound", names(standardised), unname(standardised))

groups <- split(coverage$reached_30d, coverage$baseline_high)
weights <- lengths(groups)/nrow(coverage)
observed <- vapply(groups, mean, numeric(1))
overall <- mean(coverage$reached_30d)
reliability <- sum(weights*(c(.7,.3)-observed)^2)
resolution <- sum(weights*(observed-overall)^2)
uncertainty <- overall*(1-overall)
emit("CH04", "brier_component", c("reliability", "resolution", "uncertainty", "reconstructed"),
     c(reliability, resolution, uncertainty, reliability-resolution+uncertainty))
