# Part I computational companion

This companion supports Chapters 1–4 of *Statistical Programming and Reproducible Data Science* by Felix Larry Essilfie, PhD. The Chapter 1 extension uses the frozen analytical extract from Stage 2 example CH13-OLS-01, release 0.2.1. The Part I datasets and the fixed-draw file are original synthetic teaching materials.

## Run the examples

Start in this folder. The observed run used CPython 3.12.14 and native R 4.5.0. The R scripts use base R. Install the recorded Python dependencies in a virtual environment. Provide an explicit Rscript path if it is outside PATH.

```sh
python -m pip install -r requirements.txt
python run.py --output results/part1
```

DuckDB validates the inputs and writes sorted canonical tables. Its metric query, the Python script and the R script calculate the same declared quantities. The runner records the comparison results, source and output hashes, versions and Stata status. Each run uses a new output directory.

The independent entry points accept the canonical folder as input.

```sh
python labs.py results/part1/canonical python_metrics.csv
Rscript --vanilla labs.R results/part1/canonical r_metrics.csv
```

The licensed Stata console route accepts `--stata /path/to/stata` on a supported Unix-style installation. In a licensed graphical session, give the do-file the absolute canonical folder and output path.

```stata
do "stata/labs.do" "/path/to/canonical" "/path/to/stata_metrics.csv"
```

The Stata entry point declares version 16 syntax. The observed Part I and Stage 2 runs used Stata 17 IC on macOS. To compare the retained Part I outputs with fresh DuckDB, Python and R results, run the following command from this folder.

```sh
python run.py --output results/verified_part1 --stata-results evidence/local_stata
```

## Interpret the evidence

| File | Use |
|---|---|
| `data/codebook.md` | Data origin, fields, units and eligibility rules |
| `sql/prepare.sql` | Typed ingestion, source guards and canonical data construction |
| `sql/metrics.sql` | Native DuckDB metrics on the shared contracts |
| `evidence/canonical/` | Exact exports, including the Chapter 4 eligibility audit |
| `evidence/verification.json` | Observed status, versions, counts and content hashes |
| `evidence/comparisons.csv` | Independent anchor and cross-environment comparisons |
| `evidence/local_stata/` | Canonical inputs, do-file, results and log from the local Stata 17 IC run |
| `evidence/benchmark_ch02.json` | Timed invoice aggregation with exact result checks |

The retained expanded execution produced 91 metrics per engine and passed all 449 comparisons. Exact checks cover counts, category codes, currency minor units and the deliberate precision loss. Finite numerical summaries use an absolute tolerance of 10⁻⁸ plus a relative tolerance of 10⁻¹⁰ times the larger magnitude. Each engine must emit the same identities. The scope covers the specified synthetic inputs and calculations.

## Verify evidence from a local Stata run

The separate offline kit produces a timestamped evidence ZIP using Stata 16 or 17. Run the comparator from the companion folder with the extracted Stage 2 release and a new output directory.

```sh
python verify_local_evidence.py /path/to/Stata_Verification_Evidence.zip \
  --stage2-root /path/to/Stage2_Statistical_Programming \
  --output results/local_stata
```

The comparator checks the returned input and do-file hashes against the released files. It reruns the Stage 2 four-environment gate and the Part I comparison using the observed Stata results. The output includes the returned logs and the separate comparison records.

## Reproduce the benchmark

```sh
python benchmark.py results/part1/canonical/ch02.csv benchmark.json
```

The script repeats the seven canonical rows 10,000 times with distinct identifiers. It compares DuckDB and pandas on one CSV and checks the full grouped result after each repetition. It records the input hash, execution order, timer scope and observed durations.
