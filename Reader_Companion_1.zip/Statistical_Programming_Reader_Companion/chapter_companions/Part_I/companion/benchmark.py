"""Benchmark two grouped-invoice pipelines on one scaled canonical CSV."""

import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import platform
from statistics import median
from tempfile import TemporaryDirectory
from time import perf_counter

import duckdb
import pandas as pd


def duckdb_summary(path):
    with duckdb.connect(config={'threads': 1}) as connection:
        return connection.execute("""
            SELECT channel, count(*), sum(net_minor)
            FROM read_csv(?, header = true, auto_detect = false,
                columns = {'invoice_id':'VARCHAR','channel':'VARCHAR','net_minor':'BIGINT'})
            GROUP BY channel ORDER BY channel
        """, [str(path)]).fetchall()


def pandas_summary(path):
    rows = pd.read_csv(path, dtype={'invoice_id': 'string', 'channel': 'string',
                                  'net_minor': 'int64'}, engine='c')
    results = rows.groupby('channel', sort=True).net_minor.agg(['size', 'sum'])
    return list(results.itertuples())


def benchmark(source, copies, repeats):
    with source.open(newline='', encoding='utf-8') as stream:
        fixture = list(csv.DictReader(stream))
    if copies <= 0 or repeats <= 0 or not fixture:
        raise ValueError('Copies, repeats and the input row count must be positive.')
    with TemporaryDirectory(prefix='part1-benchmark-') as folder:
        path = Path(folder) / 'scaled.csv'
        with path.open('w', newline='', encoding='utf-8') as stream:
            writer = csv.writer(stream, lineterminator='\n')
            writer.writerow(('invoice_id', 'channel', 'net_minor'))
            for block in range(copies):
                writer.writerows((f'{block}:{row["invoice_id"]}', row['channel'], row['net_minor'])
                                 for row in fixture)
        expected = duckdb_summary(path)
        if pandas_summary(path) != expected:
            raise ValueError('Warm-up results differ.')
        functions = [('DuckDB', duckdb_summary), ('pandas', pandas_summary)]
        timings = {name: [] for name, _ in functions}
        for repetition in range(repeats):
            for name, function in functions if repetition % 2 == 0 else reversed(functions):
                start = perf_counter()
                actual = function(path)
                timings[name].append(perf_counter() - start)
                if actual != expected:
                    raise ValueError(f'{name} differs from the shared expected grouped result.')
        return {'rows': len(fixture) * copies, 'input_sha256': sha256(path.read_bytes()).hexdigest(),
                'control': 'One DuckDB thread and the serial pandas C parser. Identical CSV and output.',
                'scope': 'CSV read, grouped sum and count, and small result materialisation',
                'warmups_each': 1, 'runs_each': repeats, 'execution_order': 'Alternating',
                'platform': platform.platform(), 'versions': {'DuckDB': duckdb.__version__,
                'pandas': pd.__version__}, 'elapsed_seconds': timings,
                'median_seconds': {name: median(values) for name, values in timings.items()},
                'grouped_result': expected}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('invoice_extract', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--copies', type=int, default=10_000)
    parser.add_argument('--repeats', type=int, default=7)
    args = parser.parse_args()
    result = benchmark(args.invoice_extract, args.copies, args.repeats)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(result['rows'], 'rows', result['median_seconds'])
