WITH maize AS (
    SELECT 'full' AS scenario, sessions AS x, yield_kg_ha AS y FROM ch01_maize
    UNION ALL
    SELECT 'trim_high', sessions, yield_kg_ha FROM ch01_maize WHERE sessions < 5
    UNION ALL
    SELECT 'scaled_tenth', sessions, yield_kg_ha / 10.0 FROM ch01_maize
), lines AS (
    SELECT scenario, count(*) AS n, avg(x) AS mx, regr_sxx(y,x) AS sxx,
           regr_intercept(y,x) AS intercept, regr_slope(y,x) AS slope
    FROM maize GROUP BY scenario
), residuals AS (
    SELECT *, y - intercept - slope * x AS residual
    FROM maize JOIN lines USING (scenario)
), fits AS (
    SELECT scenario, n, sxx, intercept, slope, sum(residual^2) AS sse,
           sqrt(sum(residual^2) / ((n-2)*sxx)) AS classical_se,
           sqrt((n::DOUBLE/(n-2)) * sum((x-mx)^2*residual^2)/sxx^2) AS hc1_se,
           max(1.0/n + (x-mx)^2/sxx) AS max_leverage
    FROM residuals GROUP BY scenario, n, sxx, intercept, slope
), refund_sum AS (
    SELECT invoice_id, sum(refund_minor) AS refund_minor
    FROM ch02_refunds GROUP BY invoice_id
), correct_net AS (
    SELECT i.*, amount_minor - coalesce(r.refund_minor,0) AS net_minor
    FROM ch02_ledger i LEFT JOIN refund_sum r USING (invoice_id)
), broken_join AS (
    SELECT count(*) AS rows_joined, sum(i.amount_minor - coalesce(r.refund_minor,0)) AS net
    FROM ch02_ledger i LEFT JOIN ch02_refunds r USING (invoice_id)
), invoice_totals AS (
    SELECT sum(amount_minor) AS gross, sum(net_minor) AS net, avg(net_minor) AS pooled
    FROM correct_net
), means AS (
    SELECT level, avg(outcome) AS mean FROM ch03_design GROUP BY level
), design AS (
    SELECT max(mean) FILTER (WHERE level = 'low') AS low,
           max(mean) FILTER (WHERE level = 'medium') AS medium,
           max(mean) FILTER (WHERE level = 'high') AS high
    FROM means
), design_fit AS (
    SELECT sum((outcome-mean)^2) AS sse, count(DISTINCT level) AS rank
    FROM ch03_design JOIN means USING (level)
), trace_det AS (
    SELECT n + sxx + n*(mx+1000000)^2 AS trace, n*sxx AS det
    FROM lines WHERE scenario='full'
), cells AS (
    SELECT baseline_high, offer, count(*) AS n, count(reached_30d) AS observed,
           sum(coalesce(reached_30d,0)) AS successes
    FROM ch04_eligible GROUP BY baseline_high, offer
), bounds AS (
    SELECT baseline_high,
           max(successes::DOUBLE/n) FILTER (WHERE offer=1)
             - max((successes+n-observed)::DOUBLE/n) FILTER (WHERE offer=0) AS lower,
           max((successes+n-observed)::DOUBLE/n) FILTER (WHERE offer=1)
             - max(successes::DOUBLE/n) FILTER (WHERE offer=0) AS upper
    FROM cells GROUP BY baseline_high
), arms AS (
    SELECT offer, sum(n) AS n, sum(observed) AS observed, sum(successes) AS successes
    FROM cells GROUP BY offer
), calibration_bins AS (
    SELECT count(*) AS n, avg(reached_30d) AS outcome_mean,
           CASE WHEN baseline_high=1 THEN 0.3 ELSE 0.7 END AS score
    FROM ch04 GROUP BY baseline_high
), calibration AS (
    SELECT sum(n*(score-outcome_mean)^2)/sum(n) AS reliability,
           sum(n*(outcome_mean-overall.p)^2)/sum(n) AS resolution,
           max(overall.p*(1-overall.p)) AS uncertainty
    FROM calibration_bins CROSS JOIN (SELECT avg(reached_30d) AS p FROM ch04) overall
)
SELECT 'CH01' AS chapter, 'sample_n' AS metric, scenario AS grp, n::DOUBLE AS value FROM fits
UNION ALL SELECT 'CH01','slope',scenario,slope FROM fits
UNION ALL SELECT 'CH01','intercept',scenario,intercept FROM fits
UNION ALL SELECT 'CH01','sxx',scenario,sxx FROM fits
UNION ALL SELECT 'CH01','sse',scenario,sse FROM fits
UNION ALL SELECT 'CH01','classical_se',scenario,classical_se FROM fits
UNION ALL SELECT 'CH01','hc1_se',scenario,hc1_se FROM fits
UNION ALL SELECT 'CH01','max_leverage',scenario,max_leverage FROM fits
UNION ALL SELECT 'CH02','settled_events','all',count(*) FROM ch02_refunds
UNION ALL SELECT 'CH02','gross_minor','all',gross FROM invoice_totals
UNION ALL SELECT 'CH02','refund_minor','all',gross-net FROM invoice_totals
UNION ALL SELECT 'CH02','join_rows','unaggregated',rows_joined FROM broken_join
UNION ALL SELECT 'CH02','inflated_net_minor','unaggregated',net FROM broken_join
UNION ALL SELECT 'CH02','excess_minor','unaggregated',b.net-i.net FROM broken_join b CROSS JOIN invoice_totals i
UNION ALL SELECT 'CH02','pooled_mean_minor','all',pooled FROM invoice_totals
UNION ALL SELECT 'CH02','channel_mean_minor','all',avg(m)
    FROM (SELECT avg(net_minor) AS m FROM correct_net GROUP BY channel)
UNION ALL SELECT 'CH03','coef_low_ref','intercept',low FROM design
UNION ALL SELECT 'CH03','coef_low_ref','medium',medium-low FROM design
UNION ALL SELECT 'CH03','coef_low_ref','high',high-low FROM design
UNION ALL SELECT 'CH03','coef_high_ref','intercept',high FROM design
UNION ALL SELECT 'CH03','coef_high_ref','low',low-high FROM design
UNION ALL SELECT 'CH03','coef_high_ref','medium',medium-high FROM design
UNION ALL SELECT 'CH03','design_rank','both',rank FROM design_fit
UNION ALL SELECT 'CH03','design_sse','low_ref',sse FROM design_fit
UNION ALL SELECT 'CH03','design_sse','high_ref',sse FROM design_fit
UNION ALL SELECT 'CH03','fitted_gap','both',greatest(abs((low+(medium-low))-(high+(medium-high))),
    abs(low-(high+(low-high))),abs((low+(high-low))-high)) FROM design
UNION ALL SELECT 'CH03','sum_order','left_assoc',(1.0E16::DOUBLE+1.0)-1.0E16::DOUBLE
UNION ALL SELECT 'CH03','sum_order','reordered',(1.0E16::DOUBLE-1.0E16::DOUBLE)+1.0
UNION ALL SELECT 'CH03','condition','uncentered',(trace+sqrt(trace^2-4*det))/(2*sqrt(det)) FROM trace_det
UNION ALL SELECT 'CH03','condition','centered',sqrt(greatest(n,sxx)/least(n,sxx)) FROM lines WHERE scenario='full'
UNION ALL SELECT 'CH04','target_n','all',sum(n) FROM arms
UNION ALL SELECT 'CH04','missing_outcome','offered',n-observed FROM arms WHERE offer=1
UNION ALL SELECT 'CH04','crude_bound','lower',
    max(successes::DOUBLE/n) FILTER (WHERE offer=1)
      - max((successes+n-observed)::DOUBLE/n) FILTER (WHERE offer=0) FROM arms
UNION ALL SELECT 'CH04','crude_bound','upper',
    max((successes+n-observed)::DOUBLE/n) FILTER (WHERE offer=1)
      - max(successes::DOUBLE/n) FILTER (WHERE offer=0) FROM arms
UNION ALL SELECT 'CH04','standardised_bound','lower',avg(lower) FROM bounds
UNION ALL SELECT 'CH04','standardised_bound','upper',avg(upper) FROM bounds
UNION ALL SELECT 'CH04','brier_component','reliability',reliability FROM calibration
UNION ALL SELECT 'CH04','brier_component','resolution',resolution FROM calibration
UNION ALL SELECT 'CH04','brier_component','uncertainty',uncertainty FROM calibration
UNION ALL SELECT 'CH04','brier_component','reconstructed',reliability-resolution+uncertainty FROM calibration
ORDER BY chapter, metric, grp;
