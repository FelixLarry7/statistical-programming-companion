WITH groups AS (
    SELECT channel, count(*) AS n, sum(net_minor) AS amount
    FROM ch02 GROUP BY channel
), scored AS (
    SELECT *, CASE WHEN baseline_high = 1 THEN 0.3 ELSE 0.7 END AS probability
    FROM ch04
), coverage AS (
    SELECT avg(reached_30d) AS overall,
        avg(reached_30d) FILTER (WHERE offer = 0) AS control,
        avg(reached_30d) FILTER (WHERE offer = 1) AS offered,
        avg(pow(probability - reached_30d, 2)) AS brier,
        avg(pow(0.5 - reached_30d, 2)) AS constant_brier
    FROM scored
), strata AS (
    SELECT baseline_high, avg(reached_30d) FILTER (WHERE offer = 1)
        - avg(reached_30d) FILTER (WHERE offer = 0) AS difference
    FROM ch04 GROUP BY baseline_high
), metrics AS (
    SELECT 'CH02' AS chapter, 'invoices' AS metric, channel AS grp, n::DOUBLE AS value FROM groups
    UNION ALL SELECT 'CH02', 'net_minor', channel, amount FROM groups
    UNION ALL SELECT 'CH02', 'net_minor', 'all', sum(amount) FROM groups
    UNION ALL SELECT 'CH03', 'valid_keys', 'all', sum(valid_key) FROM ch03
    UNION ALL SELECT 'CH03', 'distinct_keys', 'all', count(DISTINCT unit_id) FROM ch03
    UNION ALL SELECT 'CH03', 'usable', 'all', sum(usable) FROM ch03
    UNION ALL SELECT 'CH03', 'value_state', value_state, count(*) FROM ch03 GROUP BY value_state
    UNION ALL SELECT 'CH03', 'rank_code', row_id, rank_code FROM ch03
    UNION ALL SELECT 'CH03', 'float32_loss', 'r02', value_double - CAST(value_double AS FLOAT)
        FROM ch03 WHERE row_id = 'r02'
    UNION ALL SELECT 'CH03', 'mean_usable', 'all', avg(value_double) FILTER (WHERE usable = 1) FROM ch03
    UNION ALL SELECT 'CH03', 'draw_lt_half', 'all', count(*) FILTER (WHERE u < 0.5) FROM draws
    UNION ALL SELECT 'CH04', 'eligible', 'all', count(*) FROM ch04
    UNION ALL SELECT 'CH04', 'coverage', 'all', overall FROM coverage
    UNION ALL SELECT 'CH04', 'coverage', 'control', control FROM coverage
    UNION ALL SELECT 'CH04', 'coverage', 'offered', offered FROM coverage
    UNION ALL SELECT 'CH04', 'difference', 'crude', offered - control FROM coverage
    UNION ALL SELECT 'CH04', 'difference', 'standardised', avg(difference) FROM strata
    UNION ALL SELECT 'CH04', 'brier', 'frozen', brier FROM coverage
    UNION ALL SELECT 'CH04', 'brier', 'constant', constant_brier FROM coverage
)
SELECT * FROM metrics ORDER BY chapter, metric, grp;
