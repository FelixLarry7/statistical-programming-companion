"""Independent Python calculations for Part I on the canonical extracts."""

import argparse
import csv
from pathlib import Path

import numpy as np
import pandas as pd
from depth_metrics import deepening_metrics


def invoice_metrics(folder):
    rows = pd.read_csv(folder / 'ch02.csv', dtype={
        'invoice_id': 'string', 'channel': 'string', 'net_minor': 'int64'})
    if rows.invoice_id.isna().any() or not rows.invoice_id.is_unique:
        raise ValueError('Invoice identifiers must be unique and present.')
    grouped = rows.groupby('channel', sort=True, dropna=False).net_minor.agg(['size', 'sum'])
    for channel, result in grouped.iterrows():
        yield 'CH02', 'invoices', channel, int(result['size'])
        yield 'CH02', 'net_minor', channel, int(result['sum'])
    yield 'CH02', 'net_minor', 'all', int(rows.net_minor.sum())


def representation_metrics(folder):
    rows = pd.read_csv(folder / 'ch03.csv', dtype='string', keep_default_na=False)
    values = pd.to_numeric(rows.value_double, errors='coerce').to_numpy(dtype=np.float64)
    valid = rows.unit_id.ne('').to_numpy()
    usable = valid & np.isfinite(values)
    if not np.array_equal(valid, rows.valid_key.astype(int).to_numpy()):
        raise ValueError('Key eligibility differs from the canonical contract.')
    if not np.array_equal(usable, rows.usable.astype(int).to_numpy()):
        raise ValueError('Finite-value eligibility differs from the canonical contract.')
    ranks = rows.rank_label.map({'low': 1, 'medium': 2, 'high': 3})
    yield 'CH03', 'valid_keys', 'all', int(valid.sum())
    yield 'CH03', 'distinct_keys', 'all', rows.loc[valid, 'unit_id'].nunique()
    yield 'CH03', 'usable', 'all', int(usable.sum())
    for state, count in rows.value_state.value_counts().items():
        yield 'CH03', 'value_state', state, int(count)
    for row_id, rank in zip(rows.row_id, ranks, strict=True):
        yield 'CH03', 'rank_code', row_id, int(rank)
    boundary = values[rows.row_id.eq('r02').to_numpy()]
    yield 'CH03', 'float32_loss', 'r02', float((boundary - boundary.astype(np.float32)).item())
    yield 'CH03', 'mean_usable', 'all', float(values[usable].mean())
    draws = pd.read_csv(folder / 'draws.csv', dtype={'draw_id': 'string', 'u': 'float64'})
    yield 'CH03', 'draw_lt_half', 'all', int(draws.u.lt(0.5).sum())


def coverage_metrics(folder):
    rows = pd.read_csv(folder / 'ch04.csv', dtype={
        'episode_id': 'string', 'baseline_high': 'int64', 'offer': 'int64',
        'reached_30d': 'int64', 'opened': 'int64'})
    rates = rows.groupby('offer').reached_30d.mean()
    by_risk = rows.groupby(['baseline_high', 'offer']).reached_30d.mean().unstack('offer')
    frozen = np.where(rows.baseline_high.eq(1), 0.3, 0.7)
    yield 'CH04', 'eligible', 'all', len(rows)
    yield 'CH04', 'coverage', 'all', rows.reached_30d.mean()
    yield 'CH04', 'coverage', 'control', rates[0]
    yield 'CH04', 'coverage', 'offered', rates[1]
    yield 'CH04', 'difference', 'crude', rates[1] - rates[0]
    yield 'CH04', 'difference', 'standardised', (by_risk[1] - by_risk[0]).mean()
    yield 'CH04', 'brier', 'frozen', np.mean((frozen - rows.reached_30d) ** 2)
    yield 'CH04', 'brier', 'constant', np.mean((0.5 - rows.reached_30d) ** 2)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('canonical', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    with args.output.open('w', encoding='utf-8', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(('chapter', 'metric', 'grp', 'value'))
        for calculate in (invoice_metrics, representation_metrics, coverage_metrics, deepening_metrics):
            writer.writerows(calculate(args.canonical))
