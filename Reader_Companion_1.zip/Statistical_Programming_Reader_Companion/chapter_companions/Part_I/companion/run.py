"""Build typed DuckDB extracts and compare independent Part I calculations."""

import argparse
import csv
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

import duckdb
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
FIELDS = ('chapter', 'metric', 'grp', 'value')
EXACT = {'invoices', 'net_minor', 'valid_keys', 'distinct_keys', 'usable', 'rank_code',
         'value_state', 'float32_loss', 'draw_lt_half', 'eligible', 'sample_n', 'settled_events',
         'gross_minor', 'refund_minor', 'join_rows', 'inflated_net_minor', 'excess_minor',
         'design_rank', 'sum_order', 'target_n', 'missing_outcome'}
TOLERANCE = {'absolute': 1e-8, 'relative': 1e-10}
EXTRACTS = {
    'ch02': 'invoice_id', 'ch03': 'row_id', 'draws': 'draw_id', 'ch04': 'episode_id',
    'ch04_audit': 'episode_id', 'ch01_maize': 'plot_id, season', 'ch02_ledger': 'invoice_id',
    'ch02_refunds': 'refund_id', 'ch03_design': 'unit_id', 'ch04_eligible': 'episode_id',
}
ANCHORS = {
    ('CH02', 'invoices', 'agent'): 2, ('CH02', 'invoices', 'branch'): 2,
    ('CH02', 'invoices', 'digital'): 3, ('CH02', 'net_minor', 'all'): 545000,
    ('CH03', 'distinct_keys', 'all'): 8, ('CH03', 'usable', 'all'): 3,
    ('CH03', 'float32_loss', 'r02'): 1, ('CH03', 'draw_lt_half', 'all'): 2,
    ('CH04', 'eligible', 'all'): 8, ('CH04', 'coverage', 'all'): 0.5,
    ('CH04', 'coverage', 'control'): 0.25, ('CH04', 'coverage', 'offered'): 0.75,
    ('CH04', 'difference', 'crude'): 0.5, ('CH04', 'brier', 'frozen'): 0.19,
    ('CH01', 'slope', 'full'): 80, ('CH01', 'classical_se', 'full'): math.sqrt(139/7),
    ('CH01', 'slope', 'trim_high'): 80, ('CH01', 'sse', 'trim_high'): 4500,
    ('CH01', 'classical_se', 'trim_high'): math.sqrt(28.125),
    ('CH01', 'slope', 'scaled_tenth'): 8, ('CH01', 'sse', 'scaled_tenth'): 69.5,
    ('CH02', 'settled_events', 'all'): 7, ('CH02', 'gross_minor', 'all'): 615000,
    ('CH02', 'refund_minor', 'all'): 70000, ('CH02', 'join_rows', 'unaggregated'): 9,
    ('CH02', 'inflated_net_minor', 'unaggregated'): 690000,
    ('CH02', 'excess_minor', 'unaggregated'): 145000,
    ('CH02', 'pooled_mean_minor', 'all'): 545000/7,
    ('CH03', 'coef_low_ref', 'high'): 8, ('CH03', 'coef_high_ref', 'low'): -8,
    ('CH03', 'design_sse', 'low_ref'): 6, ('CH03', 'fitted_gap', 'both'): 0,
    ('CH03', 'sum_order', 'left_assoc'): 0, ('CH03', 'sum_order', 'reordered'): 1,
    ('CH03', 'condition', 'centered'): math.sqrt(35/12),
    ('CH04', 'target_n', 'all'): 9, ('CH04', 'missing_outcome', 'offered'): 1,
    ('CH04', 'crude_bound', 'lower'): .35, ('CH04', 'crude_bound', 'upper'): .55,
    ('CH04', 'standardised_bound', 'lower'): 1/3, ('CH04', 'standardised_bound', 'upper'): .5,
    ('CH04', 'brier_component', 'reliability'): .0025,
    ('CH04', 'brier_component', 'resolution'): .0625,
    ('CH04', 'brier_component', 'reconstructed'): .19,
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write_csv(path, columns, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream, lineterminator='\n')
        writer.writerow(columns)
        writer.writerows(rows)


def prepare(canonical, output):
    with duckdb.connect(config={'threads': 1}) as db:
        db.execute((ROOT / 'sql/prepare.sql').read_text())
        db.execute((ROOT / 'sql/depth_prepare.sql').read_text())
        for table, key in EXTRACTS.items():
            query = db.execute(f'SELECT * FROM {table} ORDER BY {key}')
            write_csv(canonical / (table + '.csv'), [item[0] for item in query.description], query.fetchall())
        rows = db.execute((ROOT / 'sql/metrics.sql').read_text()).fetchall()
        rows += db.execute((ROOT / 'sql/depth_metrics.sql').read_text()).fetchall()
        write_csv(output, FIELDS, rows)


def call(command, log, cwd=ROOT):
    env = {**os.environ, 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC', 'OPENBLAS_NUM_THREADS': '1',
           'MKL_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1', 'PYTHONUTF8': '1'}
    with log.open('w', encoding='utf-8') as stream:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=150, check=False)
    if result.returncode:
        raise RuntimeError(f'Command failed. See {log.name}.')


def read_metrics(path):
    with path.open(newline='', encoding='utf-8') as stream:
        reader = csv.DictReader(stream)
        if tuple(reader.fieldnames or ()) != FIELDS:
            raise ValueError(f'Unexpected output schema in {path.name}.')
        values = {}
        for row in reader:
            key = tuple(row[field] for field in FIELDS[:3])
            value = float(row['value'])
            if key in values or not math.isfinite(value):
                raise ValueError(f'Duplicate key or non-finite value in {path.name}: {key}')
            values[key] = value
    return values


def compare(reference, observed, engine):
    rows = []
    for key, expected in sorted(reference.items()):
        value = observed[key]
        limit = 0.0 if key[1] in EXACT else (
            TOLERANCE['absolute'] + TOLERANCE['relative'] * max(abs(expected), abs(value)))
        difference = abs(expected - value)
        rows.append((engine, *key, expected, value, difference, limit, difference <= limit))
    return rows


def import_stata(evidence, canonical, output):
    source = evidence / 'part1_driver.do'
    if not source.is_file() or digest(source) != digest(ROOT / 'stata/labs.do'):
        raise ValueError('Local Stata do-file differs from the Part I verification driver.')
    info_path = evidence / 'run_info.txt'
    if not info_path.is_file():
        raise ValueError('Local Stata evidence lacks its run information.')
    info = dict(line.split('=', 1) for line in info_path.read_text().splitlines() if '=' in line)
    if info.get('part1_rc') != '0' or float(info.get('stata_version', '0')) < 16:
        raise ValueError('The Part I run did not complete in Stata 16 or later.')
    for name in EXTRACTS:
        expected = canonical / (name + '.csv')
        supplied = evidence / ('part1_' + expected.name)
        if not supplied.is_file() or digest(expected) != digest(supplied):
            raise ValueError(f'Local Stata input differs from the canonical file: {expected.name}')
    for original, name in [('part1_metrics.csv', 'stata.csv'), ('part1_run.log', 'stata-local.log'),
                           ('run_info.txt', 'stata-runtime.txt')]:
        source = evidence / original
        if not source.is_file() or not source.stat().st_size:
            raise ValueError(f'Local Stata evidence is incomplete: {original}')
        shutil.copyfile(source, output / name)


def run(output, rscript, stata, stata_results=None):
    output.mkdir(parents=True, exist_ok=False)
    canonical = output / 'canonical'
    canonical.mkdir()
    prepare(canonical, output / 'duckdb.csv')
    call([sys.executable, str(ROOT / 'labs.py'), str(canonical), str(output / 'python.csv')],
         output / 'python.log')
    call([rscript, '--vanilla', str(ROOT / 'labs.R'), str(canonical), str(output / 'r.csv')],
         output / 'r.log')
    engine_files = {'DuckDB': 'duckdb.csv', 'Python': 'python.csv', 'R': 'r.csv'}
    if stata:
        call([stata, '-b', 'do', str(ROOT / 'stata/labs.do'), str(canonical), str(output / 'stata.csv')],
             output / 'stata-driver.log', cwd=output)
    if stata_results:
        import_stata(stata_results, canonical, output)
    if stata or stata_results:
        engine_files['Stata'] = 'stata.csv'
    reference = read_metrics(output / 'duckdb.csv')
    checks = []
    statuses = {}
    for engine, path in engine_files.items():
        actual = read_metrics(output / path)
        if set(actual) != set(reference):
            raise ValueError(f'{engine} output identities differ from the DuckDB contract.')
        anchor_checks = compare(ANCHORS, actual, engine + ' vs anchors')
        parity_checks = compare(reference, actual, engine + ' vs DuckDB') if engine != 'DuckDB' else []
        checks.extend(anchor_checks + parity_checks)
        statuses[engine] = 'VERIFIED' if all(row[-1] for row in anchor_checks + parity_checks) else 'FAILED VALIDATION'
    if 'Stata' not in engine_files:
        statuses['Stata'] = 'NOT EXECUTED'
    write_csv(output / 'comparisons.csv',
              ('comparison', 'chapter', 'metric', 'grp', 'expected', 'observed', 'absolute_difference',
               'tolerance', 'passed'), checks)
    failed = sum(not row[-1] for row in checks)
    summary = {
        'status': 'FAILED VALIDATION' if failed else 'VERIFIED' if 'Stata' in engine_files else 'PARTIALLY VERIFIED',
        'engines': statuses, 'metrics_per_engine': len(reference), 'comparisons': len(checks),
        'failed': failed, 'tolerances': TOLERANCE,
        'versions': {'Python': platform.python_version(), 'DuckDB': duckdb.__version__,
                     'pandas': pd.__version__, 'numpy': np.__version__,
                     'R': (output / 'r.log').read_text().strip(),
                     **({'Stata': (output / 'stata-runtime.txt').read_text().strip()} if stata_results else {})},
        'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in sorted(
            [*ROOT.glob('data/*.csv'), *ROOT.glob('sql/*.sql'), ROOT / 'run.py', ROOT / 'labs.py',
             ROOT / 'labs.R', ROOT / 'depth_metrics.py', ROOT / 'depth_metrics.R', ROOT / 'stata/labs.do'])},
        'canonical_sha256': {p.name: digest(p) for p in sorted(canonical.glob('*.csv'))},
        'outputs_sha256': {name: digest(output / name) for name in engine_files.values()},
    }
    (output / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(summary['status'], summary['engines'], f'{len(checks)} comparisons, {failed} failed')
    return failed


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rscript', default=shutil.which('Rscript'))
    stata_source = parser.add_mutually_exclusive_group()
    stata_source.add_argument('--stata', help='Licensed Stata console executable')
    stata_source.add_argument('--stata-results', type=Path, help='Extracted offline Stata evidence folder')
    args = parser.parse_args()
    if not args.rscript:
        parser.error('Provide the Rscript executable with --rscript.')
    output = args.output.resolve()
    evidence = args.stata_results.resolve() if args.stata_results else None
    os.chdir(ROOT)
    raise SystemExit(bool(run(output, args.rscript, args.stata, evidence)))
