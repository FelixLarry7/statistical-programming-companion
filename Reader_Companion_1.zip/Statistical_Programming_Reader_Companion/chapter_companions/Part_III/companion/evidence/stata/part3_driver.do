*! Part III native Stata implementation.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide the input and output folders."
    exit 198
}
tempname p xbar s2 med a b V J C hist_i hist_r intervals panels
tempfile metrics sim
postfile `p' str4 chapter str24 metric str52 key double value using `"`metrics'"'

* Chapter 9. Publish the populations, then calculate the moments and quantiles.
import delimited using `"`input'/plots.csv"', clear varnames(1) stringcols(1 2) asdouble
isid plot_id
assert inlist(regime,"Irrigated","Rainfed")
post `p' ("CH09") ("count") ("source") (_N)
foreach field in yield_t_ha fert labour {
    quietly count if missing(`field')
    post `p' ("CH09") ("missing") ("`field'") (r(N))
}
forvalues j=1/`=_N' {
    if !missing(yield_t_ha[`j']) {
        post `p' ("CH09") ("yield_id") (plot_id[`j']) (1)
    }
}
preserve
keep if !missing(yield_t_ha)
sort yield_t_ha plot_id
quietly summarize yield_t_ha
scalar `xbar'=r(mean)
scalar `s2'=r(Var)
post `p' ("CH09") ("count") ("yield") (_N)
post `p' ("CH09") ("moment") ("mean") (`xbar')
post `p' ("CH09") ("moment") ("sample_variance") (`s2')
post `p' ("CH09") ("moment") ("population_variance") (`s2'*(_N-1)/_N)
gen double cubic=(yield_t_ha-`xbar')^3
quietly summarize cubic,meanonly
post `p' ("CH09") ("moment") ("third_central") (r(mean))
post `p' ("CH09") ("moment") ("moment_skewness") (r(mean)/(`s2'*(_N-1)/_N)^1.5)
foreach k in 25 50 75 {
    local h=1+(_N-1)*`k'/100
    local j=floor(`h')
    local jj=min(`j'+1,_N)
    scalar `a'=yield_t_ha[`j']+(`h'-`j')*(yield_t_ha[`jj']-yield_t_ha[`j'])
    local rank=ceil(_N*`k'/100)
    post `p' ("CH09") ("quantile7") ("p`k'") (`a')
    post `p' ("CH09") ("quantile1") ("p`k'") (yield_t_ha[`rank'])
    if `k'==50 scalar `med'=`a'
}
gen double distance=abs(yield_t_ha-`med')
sort distance plot_id
local half=floor((_N+1)/2)
local other=ceil((_N+1)/2)
post `p' ("CH09") ("moment") ("raw_mad") ((distance[`half']+distance[`other'])/2)
restore

foreach g in Irrigated Rainfed pooled {
    quietly summarize yield_t_ha if regime=="`g'" | "`g'"=="pooled",meanonly
    post `p' ("CH09") ("group_n") ("`g'") (r(N))
    post `p' ("CH09") ("group_mean") ("`g'") (r(mean))
    quietly regress yield_t_ha fert if regime=="`g'" | "`g'"=="pooled"
    post `p' ("CH09") ("group_slope") ("`g'") (_b[fert])
}
foreach scope in available common {
    foreach pair in yf yl fl {
        local x "labour"
        local y "yield_t_ha"
        if "`pair'"=="yf" local x "fert"
        if "`pair'"=="fl" local y "fert"
        preserve
        keep if !missing(`x',`y')
        if "`scope'"=="common" keep if !missing(fert,labour,yield_t_ha)
        quietly summarize `x'
        scalar `xbar'=r(mean)
        scalar `a'=r(sd)
        quietly summarize `y'
        scalar `b'=r(sd)
        gen double product=(`x'-`xbar')*(`y'-r(mean))
        quietly summarize product,meanonly
        scalar `s2'=r(sum)/(_N-1)
        post `p' ("CH09") ("pair_n") ("`scope'/`pair'") (_N)
        post `p' ("CH09") ("covariance") ("`scope'/`pair'") (`s2')
        post `p' ("CH09") ("correlation") ("`scope'/`pair'") (`s2'/(`a'*`b'))
        forvalues j=1/`=_N' {
            post `p' ("CH09") ("pair_id") ("`scope'/`pair'/"+plot_id[`j']) (1)
        }
        restore
    }
}

* Chapter 10. Check the numerical encodings, then render the common data.
foreach g in Irrigated Rainfed {
    forvalues bin=1/5 {
        quietly count if regime=="`g'" & yield_t_ha>=`bin' ///
            & (yield_t_ha<`bin'+1 | (`bin'==5 & yield_t_ha==6))
        post `p' ("CH10") ("bin") ("`g'/`bin'") (r(N))
    }
    quietly summarize yield_t_ha if regime=="`g'"
    local df=r(N)-1
    scalar `xbar'=r(mean)
    scalar `a'=r(sd)/sqrt(r(N))
    scalar `b'=invttail(`df',.025)*`a'
    post `p' ("CH10") ("interval_n") ("`g'") (`df'+1)
    post `p' ("CH10") ("interval_df") ("`g'") (`df')
    post `p' ("CH10") ("interval_mean") ("`g'") (`xbar')
    post `p' ("CH10") ("interval_se") ("`g'") (`a')
    post `p' ("CH10") ("interval_lower") ("`g'") (`xbar'-`b')
    post `p' ("CH10") ("interval_upper") ("`g'") (`xbar'+`b')
}
forvalues bin=1/5 {
    quietly count if regime=="Rainfed" & yield_t_ha>=`bin'+.5 ///
        & (yield_t_ha<`bin'+1.5 | (`bin'==5 & yield_t_ha==6.5))
    post `p' ("CH10") ("shifted_rainfed") ("`bin'") (r(N))
}
import delimited using `"`input'/figure_bins.csv"', clear varnames(1) stringcols(1) asdouble
isid regime bin
twoway bar frequency mid if regime=="Irrigated", barwidth(.86) ///
    fcolor(navy) lcolor(navy) title("Irrigated plots") xlabel(1(1)6) ///
    xscale(range(1 6)) yscale(range(0 4)) ylabel(0(1)4) ytitle("Plots") ///
    xtitle("Yield (t/ha)") legend(off) name(`hist_i',replace) scheme(s2color)
twoway bar frequency mid if regime=="Rainfed", barwidth(.86) ///
    fcolor(dkgreen) lcolor(dkgreen) title("Rainfed plots") xlabel(1(1)6) ///
    xscale(range(1 6)) yscale(range(0 4)) ylabel(0(1)4) ytitle("Plots") ///
    xtitle("Yield (t/ha)") legend(off) name(`hist_r',replace) scheme(s2color)
import delimited using `"`input'/figure_intervals.csv"', clear varnames(1) stringcols(1) asdouble
isid regime
gen byte position=cond(regime=="Irrigated",2,1)
twoway (rcap lower upper position,horizontal lcolor(navy)) ///
    (scatter position mean,mcolor(navy) msymbol(D)), ///
    title("Mean and 95% t interval") ylabel(1 "Rainfed" 2 "Irrigated",angle(0)) ///
    yscale(range(.6 2.4)) xlabel(1(1)6) xscale(range(1 6)) ///
    xtitle("Yield (t/ha)") ytitle("") legend(off) name(`intervals',replace) scheme(s2color)
graph combine `hist_i' `hist_r' `intervals', cols(1) xsize(6) ysize(9) ///
    imargin(small) name(`panels',replace) graphregion(color(white))
graph export `"`output'/ch10_stata.png"', name(`panels') replace width(1400)
graph drop `hist_i' `hist_r' `intervals' `panels'

* Chapter 11. Fixed-draw parity and independent simulation.
import delimited using `"`input'/fixed_draws.csv"', clear varnames(1) stringcols(1) asdouble
isid design n replicate draw
assert !missing(x) & inlist(n,8,32) & inlist(design,"normal","skewed")
bysort design n replicate (draw): assert _N==n & draw==_n
collapse (mean) mean=x (sd) sd=x, by(design n replicate)
gen double lower_t=mean-invttail(n-1,.025)*sd/sqrt(n)
gen double upper_t=mean+invttail(n-1,.025)*sd/sqrt(n)
gen double lower_z=mean-invnormal(.975)*sd/sqrt(n)
gen double upper_z=mean+invnormal(.975)*sd/sqrt(n)
gen byte cover_t=inrange(1,lower_t,upper_t)
gen byte cover_z=inrange(1,lower_z,upper_z)
order design n replicate mean sd lower_t upper_t lower_z upper_z cover_t cover_z
sort design n replicate
format mean sd lower_t upper_t lower_z upper_z %24.17g
export delimited using `"`output'/fixed.csv"', replace datafmt

set rng mt64
forvalues scenario=1/4 {
    clear
    local n=cond(mod(`scenario',2)==1,8,32)
    local shape=cond(`scenario'<=2,"normal","skewed")
    local seed=851000+`scenario'
    set seed `seed'
    local rows=2000*`n'
    set obs `rows'
    gen long replicate=ceil(_n/`n')
    if "`shape'"=="normal" {
        gen double x=rnormal(1,1)
    }
    else {
        gen double x=-ln(1-runiform())
    }
    collapse (mean) mean=x (sd) sd=x, by(replicate)
    gen int n=`n'
    gen str6 design="`shape'"
    gen long seed=`seed'
    if `scenario'>1 append using `"`sim'"'
    save `"`sim'"', replace
}
gen double lower_t=mean-invttail(n-1,.025)*sd/sqrt(n)
gen double upper_t=mean+invttail(n-1,.025)*sd/sqrt(n)
gen double lower_z=mean-invnormal(.975)*sd/sqrt(n)
gen double upper_z=mean+invnormal(.975)*sd/sqrt(n)
gen byte cover_t=inrange(1,lower_t,upper_t)
gen byte cover_z=inrange(1,lower_z,upper_z)
order design n replicate mean sd lower_t upper_t lower_z upper_z cover_t cover_z seed
sort design n replicate
format mean sd lower_t upper_t lower_z upper_z %24.17g
export delimited using `"`output'/simulation.csv"', replace datafmt

import delimited using `"`input'/bootstrap_draws.csv"', clear varnames(1) asdouble
isid replicate draw
bysort replicate (draw): assert _N==4 & draw==_n
assert inrange(original_index,1,4)
assert x==2^(original_index-1)
collapse (mean) x, by(replicate)
sort x replicate
forvalues j=1/`=_N' {
    post `p' ("CH11") ("bootstrap_mean") (string(replicate[`j'])) (x[`j'])
}
* Compute both endpoints explicitly for the local Stata batch runner.
local hlow=1+(_N-1)*.025
local hhigh=1+(_N-1)*.975
local ilo=floor(`hlow')
local ihi=floor(`hhigh')
local nlo=min(`ilo'+1,_N)
local nhi=min(`ihi'+1,_N)
post `p' ("CH11") ("bootstrap_type7") ("lower") ///
    (x[`ilo']+(`hlow'-`ilo')*(x[`nlo']-x[`ilo']))
post `p' ("CH11") ("bootstrap_type7") ("upper") ///
    (x[`ihi']+(`hhigh'-`ihi')*(x[`nhi']-x[`ihi']))
local klo=ceil(_N*.025)
local khi=ceil(_N*.975)
post `p' ("CH11") ("bootstrap_type1") ("lower") (x[`klo'])
post `p' ("CH11") ("bootstrap_type1") ("upper") (x[`khi'])
display as text "Bootstrap endpoint checks completed."

* Chapter 12. Fit joint survey means, then apply the analytic ratio Jacobian.
import delimited using `"`input'/survey.csv"', clear varnames(1) stringcols(1) asdouble
isid hh_id
assert inlist(eligible,0,1) & inlist(rural,0,1)
post `p' ("CH12") ("count") ("source") (_N)
keep if eligible==1
assert !missing(welfare,weight,stratum,psu,fpc_n) & weight>0
post `p' ("CH12") ("count") ("eligible") (_N)
forvalues j=1/`=_N' {
    post `p' ("CH12") ("universe_id") (hh_id[`j']) (1)
}
egen long cluster=group(stratum psu)
egen byte tag=tag(cluster)
quietly count if tag
post `p' ("CH12") ("count") ("psus") (r(N))
drop tag
egen byte tag=tag(stratum)
quietly count if tag
post `p' ("CH12") ("count") ("strata") (r(N))
drop tag
gen byte urban=1-rural
gen double ry=rural*welfare
gen double uy=urban*welfare
gen double weighted=weight*welfare
quietly summarize welfare,meanonly
post `p' ("CH12") ("unweighted_mean") ("all") (r(mean))
foreach domain in rural urban {
    quietly summarize weight if `domain',meanonly
    post `p' ("CH12") ("domain_n") ("`domain'") (r(N))
    post `p' ("CH12") ("denominator") ("`domain'") (r(sum))
    quietly summarize weighted if `domain',meanonly
    post `p' ("CH12") ("weighted_total") ("`domain'") (r(sum))
    quietly summarize welfare if `domain',meanonly
    post `p' ("CH12") ("unweighted_mean") ("`domain'") (r(mean))
}
quietly summarize weight,meanonly
post `p' ("CH12") ("denominator") ("all") (r(sum))
quietly summarize weighted,meanonly
post `p' ("CH12") ("weighted_total") ("all") (r(sum))

foreach design in wr fpc {
    if "`design'"=="wr" {
        svyset cluster [pweight=weight], strata(stratum) singleunit(missing)
    }
    else {
        svyset cluster [pweight=weight], strata(stratum) fpc(fpc_n) singleunit(missing)
    }
    quietly svy: mean ry rural uy urban
    local df=e(df_r)
    post `p' ("CH12") ("design_df") ("`design'") (`df')
    matrix `b'=e(b)
    matrix `V'=e(V)
    matrix `J'=(1/`b'[1,2],-`b'[1,1]/(`b'[1,2]^2),0,0 \ ///
                0,0,1/`b'[1,4],-`b'[1,3]/(`b'[1,4]^2))
    matrix `C'=`J'*`V'*`J''
    scalar `a'=`b'[1,1]/`b'[1,2]
    scalar `xbar'=`b'[1,3]/`b'[1,4]
    post `p' ("CH12") ("mean") ("`design'/rural") (`a')
    post `p' ("CH12") ("mean") ("`design'/urban") (`xbar')
    post `p' ("CH12") ("mean") ("`design'/gap") (`xbar'-`a')
    post `p' ("CH12") ("se") ("`design'/rural") (sqrt(`C'[1,1]))
    post `p' ("CH12") ("se") ("`design'/urban") (sqrt(`C'[2,2]))
    post `p' ("CH12") ("se") ("`design'/gap") (sqrt(`C'[1,1]+`C'[2,2]-2*`C'[1,2]))
    post `p' ("CH12") ("domain_covariance") ("`design'") (`C'[1,2])
    quietly svy: mean welfare
    post `p' ("CH12") ("mean") ("`design'/all") (_b[welfare])
    post `p' ("CH12") ("se") ("`design'/all") (_se[welfare])
}

svyset cluster [pweight=weight], strata(stratum) singleunit(missing)
foreach domain in rural urban {
    quietly svy, subpop(`domain'): mean welfare
    post `p' ("CH12") ("subpop_mean") ("`domain'") (_b[welfare])
    post `p' ("CH12") ("subpop_se") ("`domain'") (_se[welfare])
    preserve
    keep if `domain'
    egen byte tag=tag(cluster)
    quietly count if tag
    post `p' ("CH12") ("trimmed_psus") ("`domain'") (r(N))
    svyset cluster [pweight=weight], strata(stratum) singleunit(certainty)
    quietly svy: mean welfare
    post `p' ("CH12") ("trimmed_se") ("`domain'") (_se[welfare])
    restore
}

postclose `p'
use `"`metrics'"',clear
isid chapter metric key
assert !missing(value)
sort chapter metric key
tempname file
file open `file' using `"`output'/metrics.csv"', write text replace
file write `file' "chapter,metric,key,value" _n
forvalues j=1/`=_N' {
    file write `file' (chapter[`j']) "," (metric[`j']) "," (key[`j']) "," ///
        %24.17g (value[`j']) _n
}
file close `file'
display as result "Part III generated in Stata `c(stata_version)' `c(flavor)'."
