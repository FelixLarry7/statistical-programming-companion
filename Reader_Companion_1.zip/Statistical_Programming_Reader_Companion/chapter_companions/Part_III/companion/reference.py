"""Hand-derived checks independent of the engine calculations."""

from fractions import Fraction as Q
from math import sqrt


def anchors():
    m = {}

    def add(chapter, metric, entries):
        for key, value in entries.items():
            m[(chapter, metric, key)] = float(value)

    add("CH09", "count", {"source": 12, "yield": 11})
    add("CH09", "missing", {"yield_t_ha": 1, "fert": 1, "labour": 2})
    add("CH09", "moment", {"mean": Q(36,11), "population_variance": Q(178,121),
                           "sample_variance": Q(89,55), "raw_mad": 1})
    add("CH09", "quantile7", {"p25": Q(9,4), "p50": 3, "p75": 4})
    add("CH09", "quantile1", {"p25": 2, "p50": 3, "p75": 4})
    add("CH09", "pair_n", {"available/yf": 10, "available/yl": 9, "available/fl": 9,
                          "common/yf": 8, "common/yl": 8, "common/fl": 8})
    add("CH09", "group_slope", {"Irrigated": Q(9,100), "Rainfed": Q(7,100), "pooled": -Q(13,450)})
    for g, counts in (("Irrigated", (0,0,2,2,2)), ("Rainfed", (1,3,1,0,0))):
        add("CH10", "bin", {f"{g}/{j}": n for j,n in enumerate(counts,1)})
    add("CH10", "shifted_rainfed", dict(zip("12345", (3,2,0,0,0))))
    add("CH10", "interval_mean", {"Irrigated": Q(25,6), "Rainfed": Q(11,5)})
    add("CH10", "interval_n", {"Irrigated": 6, "Rainfed": 5})
    add("CH11", "bootstrap_type7", {"lower": Q(209,160), "upper": Q(533,80)})
    add("CH11", "bootstrap_type1", {"lower": Q(5,4), "upper": 7})
    add("CH12", "count", {"source": 26, "eligible": 24, "psus": 6, "strata": 3})
    add("CH12", "design_df", {"wr": 3, "fpc": 3})
    add("CH12", "domain_n", {"rural": 12, "urban": 12})
    add("CH12", "trimmed_psus", {"rural": 5, "urban": 5})

    # Control totals transcribed by hand. Each tuple is (rural N, rural D, urban N, urban D).
    clusters = [(10200,220,11610,175), (0,0,28890,420),
                (8810,235,12500,195), (21585,440,0,0),
                (10920,245,12075,185), (10745,235,14880,210)]
    totals = [sum(row[i] for row in clusters) for i in range(4)]
    assert totals == [62260,1375,79955,1185]
    nr, dr, nu, du = totals
    ar, au, aa = Q(nr,dr), Q(nu,du), Q(nr+nu,dr+du)
    add("CH12", "denominator", {"rural": dr, "urban": du, "all": dr+du})
    add("CH12", "weighted_total", {"rural": nr, "urban": nu, "all": nr+nu})
    z = [((r-ar*w)/dr, (u-au*v)/du, (r+u-aa*(w+v))/(dr+du)) for r,w,u,v in clusters]
    deltas = [tuple(a-b for a,b in zip(z[j],z[j+1])) for j in (0,2,4)]
    for design, f in (("wr",[1,1,1]), ("fpc",[Q(3,4),Q(4,5),Q(5,6)])):
        add("CH12", "mean", {f"{design}/{d}": v for d,v in zip(
            ("rural","urban","all","gap"), (ar,au,aa,au-ar))})
        add("CH12", "se", {f"{design}/{d}": sqrt(sum(w*ds[k]**2 for w,ds in zip(f,deltas)))
                          for k,d in enumerate(("rural","urban","all"))})
        add("CH12", "se", {design+"/gap": sqrt(sum(w*(b-a)**2 for w,(a,b,c) in zip(f,deltas)))})
        add("CH12", "domain_covariance", {design: sum(w*a*b for w,(a,b,c) in zip(f,deltas))})
    return m
