"""Independent NumPy/SciPy implementation of the four Part III cases."""

import csv
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import norm, t


INPUTS, OUTPUT = map(Path, sys.argv[1:])
METRICS = []
FIELDS = "design n replicate mean sd lower_t upper_t lower_z upper_z cover_t cover_z".split()


def read(name):
    with (INPUTS / f"{name}.csv").open(newline="") as stream:
        return list(csv.DictReader(stream))


def write(name, columns, rows):
    with (OUTPUT / f"{name}.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(columns)
        writer.writerows(rows)


def add(ch, metric, key, value):
    METRICS.append((f"CH{ch:02d}", metric, key, float(value)))


def float_or_nan(value):
    return float(value) if value else np.nan


def plots():
    rows = read("plots")
    ids = np.array([r["plot_id"] for r in rows])
    regime = np.array([r["regime"] for r in rows])
    assert len(set(ids)) == len(ids)
    assert set(regime) == {"Irrigated", "Rainfed"}
    v = {k: np.array([float_or_nan(r[k]) for r in rows])
         for k in ("yield_t_ha", "fert", "labour")}
    y = v["yield_t_ha"]
    good = np.isfinite(y)
    add(9, "count", "source", len(y))
    add(9, "count", "yield", good.sum())
    for name, values in v.items():
        add(9, "missing", name, np.isnan(values).sum())
    for row_id in ids[good]:
        add(9, "yield_id", row_id, 1)
    x = y[good]
    m2 = ((x - x.mean()) ** 2).mean()
    m3 = ((x - x.mean()) ** 3).mean()
    moments = {"mean": x.mean(), "sample_variance": x.var(ddof=1),
               "population_variance": m2, "third_central": m3,
               "moment_skewness": m3 / m2**1.5,
               "raw_mad": np.median(np.abs(x - np.median(x)))}
    for key, value in moments.items():
        add(9, "moment", key, value)
    for p in (25, 50, 75):
        add(9, "quantile7", f"p{p}", np.quantile(x, p/100, method="linear"))
        add(9, "quantile1", f"p{p}", np.quantile(x, p/100, method="inverted_cdf"))
    common = np.all(np.isfinite(list(v.values())), axis=0)
    for pair, names in {"yf": ("yield_t_ha", "fert"), "yl": ("yield_t_ha", "labour"),
                        "fl": ("fert", "labour")}.items():
        a, b = (v[name] for name in names)
        available = np.isfinite(a) & np.isfinite(b)
        for scope, use in (("available", available), ("common", common)):
            key = f"{scope}/{pair}"
            add(9, "pair_n", key, use.sum())
            add(9, "covariance", key, np.cov(a[use], b[use], ddof=1)[0, 1])
            add(9, "correlation", key, np.corrcoef(a[use], b[use])[0, 1])
            for row_id in ids[use]:
                add(9, "pair_id", f"{key}/{row_id}", 1)
    fert = v["fert"]
    for group in ("Irrigated", "Rainfed", "pooled"):
        use = good & ((regime == group) | (group == "pooled"))
        values = y[use]
        n = len(values)
        paired = use & np.isfinite(fert)
        add(9, "group_n", group, n)
        add(9, "group_mean", group, values.mean())
        add(9, "group_slope", group, np.cov(fert[paired], y[paired], ddof=1)[0, 1]
            / fert[paired].var(ddof=1))
        if group == "pooled":
            continue
        bins, _ = np.histogram(values, bins=np.arange(1, 7))
        for i, count in enumerate(bins, 1):
            add(10, "bin", f"{group}/{i}", count)
        df = n - 1
        se = values.std(ddof=1) / np.sqrt(n)
        margin = t.ppf(.975, df) * se
        for field, val in {"n": n, "df": df, "mean": values.mean(), "se": se,
                           "lower": values.mean()-margin, "upper": values.mean()+margin}.items():
            add(10, f"interval_{field}", group, val)
        if group == "Rainfed":
            shifted, _ = np.histogram(values, bins=np.arange(1.5, 7.5))
            for i, count in enumerate(shifted, 1):
                add(10, "shifted_rainfed", str(i), count)


def interval_rows(design, n, means, sd):
    se = sd / np.sqrt(n)
    m_t = t.ppf(.975, n-1) * se
    m_z = norm.ppf(.975) * se
    lt, ut, lz, uz = means-m_t, means+m_t, means-m_z, means+m_z
    for i, values in enumerate(zip(means, sd, lt, ut, lz, uz), 1):
        _, _, lo, hi, zl, zu = values
        yield (design, n, i, *values, int(lo <= 1 <= hi), int(zl <= 1 <= zu))


def simulations():
    fixed = defaultdict(list)
    for row in read("fixed_draws"):
        fixed[(row["design"], int(row["n"]))].append(
            (int(row["replicate"]), int(row["draw"]), float(row["x"])))
    fixed_out, random_out = [], []
    for i, ((design, n), rows) in enumerate(sorted(fixed.items()), 1):
        rows.sort()
        assert [(r, j) for r, j, _ in rows] == [(r, j) for r in range(1, 65) for j in range(1, n+1)]
        matrix = np.array([x for _, _, x in rows]).reshape(64, n)
        fixed_out.extend(interval_rows(design, n, matrix.mean(axis=1), matrix.std(axis=1, ddof=1)))
        seed = 619000+i
        rng = np.random.Generator(np.random.PCG64(seed))
        draws = (rng.normal(1, 1, (2000, n)) if design == "normal"
                 else rng.exponential(1, (2000, n)))
        random_out.extend((*row, seed) for row in
                          interval_rows(design, n, draws.mean(axis=1), draws.std(axis=1, ddof=1)))
    write("fixed", FIELDS, fixed_out)
    write("simulation", FIELDS + ["seed"], random_out)
    boot = defaultdict(list)
    for row in read("bootstrap_draws"):
        x = float(row["x"])
        assert x == 2**(int(row["original_index"])-1)
        boot[int(row["replicate"])].append((int(row["draw"]), x))
    means = []
    assert set(boot) == set(range(1, 11))
    for replicate, draws in sorted(boot.items()):
        assert sorted(j for j, _ in draws) == [1, 2, 3, 4]
        means.append(np.mean([x for _, x in draws]))
        add(11, "bootstrap_mean", str(replicate), means[-1])
    for key, prob in (("lower", .025), ("upper", .975)):
        add(11, "bootstrap_type7", key, np.quantile(means, prob, method="linear"))
        add(11, "bootstrap_type1", key, np.quantile(means, prob, method="inverted_cdf"))


def cov_psu(score, psu, stratum, fpc=None):
    covariance = np.zeros((score.shape[1], score.shape[1]))
    for h in sorted(set(stratum)):
        ix = stratum == h
        clusters = sorted(set(psu[ix]))
        m = len(clusters)
        if m == 1:  # Explicit zero-variance rule for the trimming demonstration.
            continue
        sums = np.vstack([score[ix & (psu == cluster)].sum(axis=0) for cluster in clusters])
        centred = sums - sums.mean(axis=0)
        correction = 1 if fpc is None else 1 - m / fpc[ix][0]
        covariance += correction * m/(m-1) * (centred.T @ centred)
    return covariance


def survey():
    rows = read("survey")
    assert len({r["hh_id"] for r in rows}) == len(rows)
    assert all(r["eligible"] in {"0", "1"} and r["rural"] in {"0", "1"} for r in rows)
    add(12, "count", "source", len(rows))
    use = [r for r in rows if r["eligible"] == "1"]
    add(12, "count", "eligible", len(use))
    for row in use:
        add(12, "universe_id", row["hh_id"], 1)
    stratum, psu, fpc, rural, y, w = (np.array([float(r[k]) for r in use])
                                     for k in ("stratum", "psu", "fpc_n", "rural", "welfare", "weight"))
    assert np.all(np.isfinite([stratum, psu, fpc, rural, y, w])) and (w > 0).all()
    for h in set(stratum):
        ix = stratum == h
        assert len(set(fpc[ix])) == 1 and len(set(psu[ix])) <= fpc[ix][0]
    masks = np.column_stack((rural == 1, rural == 0, np.ones(len(use), dtype=bool)))
    dnames = ("rural", "urban", "all")
    denominators = w @ masks
    totals = (w * y) @ masks
    mu = totals / denominators
    score = (w[:, None] * masks * (y[:, None] - mu)) / denominators
    npsu = len(set(zip(stratum, psu)))
    nh = len(set(stratum))
    add(12, "count", "psus", npsu)
    add(12, "count", "strata", nh)
    for j, name in enumerate(dnames):
        keep = masks[:, j]
        add(12, "denominator", name, denominators[j])
        add(12, "weighted_total", name, totals[j])
        add(12, "unweighted_mean", name, y[keep].mean())
        if name == "all":
            continue
        add(12, "domain_n", name, keep.sum())
        add(12, "subpop_mean", name, mu[j])
        add(12, "subpop_se", name, np.sqrt(cov_psu(score, psu, stratum)[j, j]))
        subvar = cov_psu(score[keep], psu[keep], stratum[keep])[j, j]
        add(12, "trimmed_se", name, np.sqrt(subvar))
        add(12, "trimmed_psus", name, len(set(zip(stratum[keep], psu[keep]))))
    for design, f in (("wr", None), ("fpc", fpc)):
        C = cov_psu(score, psu, stratum, f)
        add(12, "design_df", design, npsu-nh)
        add(12, "domain_covariance", design, C[0, 1])
        add(12, "mean", design+"/gap", mu[1]-mu[0])
        add(12, "se", design+"/gap", np.sqrt(C[0, 0]+C[1, 1]-2*C[0, 1]))
        for j, name in enumerate(dnames):
            add(12, "mean", f"{design}/{name}", mu[j])
            add(12, "se", f"{design}/{name}", np.sqrt(C[j, j]))


OUTPUT.mkdir(parents=True, exist_ok=True)
plots()
simulations()
survey()
write("metrics", ("chapter", "metric", "key", "value"), sorted(METRICS))
print(f"Python {sys.version.split()[0]}, NumPy {np.__version__}")
