# Part III local Stata verification, revision 2

Use the licensed Stata 16 or 17 installed on your computer. The revised
driver computes the two bootstrap endpoints explicitly and prints
`Bootstrap endpoint checks completed.` before entering the survey example.
This revision uses the same seven input CSVs and statistical definitions.

1. Extract this ZIP into a fresh folder.
2. In Stata, set the working directory to the inner folder
   `Part_III_Stata_Local_Run`, containing `run_part3.do` and `inputs`.
3. Run `do run_part3.do`. Let Stata finish and report its return code.
4. Return the generated `Stata_Verification_Part_III_R2_*.zip` for verification.
   Keep the evidence ZIP if Stata prints a nonzero code, since it contains
   the diagnostic log. Success is return code 0 and includes `metrics.csv`.

The driver uses a separate frame and requires no internet connection or
additional Stata packages.
