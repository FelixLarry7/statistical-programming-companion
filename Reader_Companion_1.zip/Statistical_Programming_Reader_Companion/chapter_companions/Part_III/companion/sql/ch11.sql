-- Replication grain: (design, n, replicate); rows within a draw use draw ID.
CREATE TEMP VIEW fixed11 AS
WITH sample AS (
  SELECT design,n,replicate,avg(x) AS mean,stddev_samp(x) AS sd
  FROM fixed_draws GROUP BY design,n,replicate
), endpoints AS (
  SELECT design,n,replicate,mean,sd,
         mean-t975*sd/sqrt(n) AS lower_t, mean+t975*sd/sqrt(n) AS upper_t,
         mean-1.959963984540054*sd/sqrt(n) AS lower_z,
         mean+1.959963984540054*sd/sqrt(n) AS upper_z
  FROM sample JOIN critical_values ON df=n-1
)
SELECT *, (1 BETWEEN lower_t AND upper_t)::INT AS cover_t,
          (1 BETWEEN lower_z AND upper_z)::INT AS cover_z
FROM endpoints;

CREATE TEMP VIEW metrics11 AS
WITH b AS (
  SELECT replicate,avg(x) AS mean FROM bootstrap_draws GROUP BY replicate
), q AS (
  SELECT quantile_cont(mean,.025) AS low7, quantile_cont(mean,.975) AS high7,
         quantile_disc(mean,.025) AS low1, quantile_disc(mean,.975) AS high1 FROM b
)
SELECT 'bootstrap_mean' AS metric,replicate::VARCHAR AS key,mean AS value FROM b
UNION ALL SELECT 'bootstrap_type7','lower',low7 FROM q
UNION ALL SELECT 'bootstrap_type7','upper',high7 FROM q
UNION ALL SELECT 'bootstrap_type1','lower',low1 FROM q
UNION ALL SELECT 'bootstrap_type1','upper',high1 FROM q;
