CREATE TEMP VIEW universe12 AS
SELECT hh_id, stratum, psu, fpc_n, rural, welfare, weight
FROM survey WHERE eligible=1;

CREATE TEMP VIEW domains12 AS
SELECT CASE WHEN GROUPING(rural)=1 THEN 'all' WHEN rural=1 THEN 'rural'
            ELSE 'urban' END AS domain,
       count(*) AS n, sum(weight) AS denominator, sum(weight*welfare) AS total,
       avg(welfare) AS unweighted_mean, sum(weight*welfare)/sum(weight) AS mean
FROM universe12 GROUP BY GROUPING SETS ((rural),());

-- All clusters enter. FILTER changes only the numerator contributions.
CREATE TEMP VIEW psu_scores12 AS
SELECT stratum,psu,any_value(fpc_n) AS fpc_n,
       count(*) FILTER (rural=1) AS rural_n, count(*) FILTER (rural=0) AS urban_n,
       coalesce(sum(weight*(welfare-r.mean)) FILTER (rural=1),0)/r.denominator AS zr,
       coalesce(sum(weight*(welfare-u.mean)) FILTER (rural=0),0)/u.denominator AS zu,
       sum(weight*(welfare-a.mean))/a.denominator AS za
FROM universe12
CROSS JOIN (SELECT mean,denominator FROM domains12 WHERE domain='rural') r
CROSS JOIN (SELECT mean,denominator FROM domains12 WHERE domain='urban') u
CROSS JOIN (SELECT mean,denominator FROM domains12 WHERE domain='all') a
GROUP BY stratum,psu,r.denominator,u.denominator,a.denominator;

CREATE TEMP VIEW design12 AS
WITH scores AS (
  SELECT *,count(*) OVER w AS m,zr-avg(zr) OVER w AS dr,
           zu-avg(zu) OVER w AS du,za-avg(za) OVER w AS da
  FROM psu_scores12 WINDOW w AS (PARTITION BY stratum)
), cells AS (
  SELECT design, (m/(m-1))*CASE WHEN design='fpc' THEN 1-m/fpc_n ELSE 1 END AS factor,
         dr,du,da
  FROM scores CROSS JOIN (VALUES ('wr'),('fpc')) d(design)
)
SELECT design,sum(factor*dr^2) AS vr,sum(factor*du^2) AS vu,
       sum(factor*da^2) AS va,sum(factor*dr*du) AS c,
       sum(factor*(du-dr)^2) AS vg
FROM cells GROUP BY design;

CREATE TEMP VIEW trimmed12 AS
WITH score AS (
  SELECT 'rural' AS domain,stratum,psu,zr AS z FROM psu_scores12 WHERE rural_n>0
  UNION ALL
  SELECT 'urban',stratum,psu,zu FROM psu_scores12 WHERE urban_n>0
), centred AS (
  SELECT domain, stratum, count(*) AS m, var_samp(z) AS variance
  FROM score GROUP BY domain,stratum
)
SELECT domain,sum(m) AS psus,sqrt(sum(coalesce(m*variance,0))) AS se
FROM centred GROUP BY domain;

CREATE TEMP VIEW metrics12 AS
WITH df AS (
  SELECT count(*)-count(DISTINCT stratum) AS df FROM psu_scores12
), gap AS (
  SELECT max(mean) FILTER (domain='urban')-max(mean) FILTER (domain='rural') AS gap
  FROM domains12
)
SELECT 'count' AS metric,'source' AS key,count(*)::DOUBLE AS value FROM survey
UNION ALL SELECT 'count','eligible',count(*) FROM universe12
UNION ALL SELECT 'count','psus',count(*) FROM psu_scores12
UNION ALL SELECT 'count','strata',count(DISTINCT stratum) FROM psu_scores12
UNION ALL SELECT 'universe_id',hh_id,1 FROM universe12
UNION ALL SELECT 'domain_n',domain,n FROM domains12 WHERE domain!='all'
UNION ALL SELECT 'denominator',domain,denominator FROM domains12
UNION ALL SELECT 'weighted_total',domain,total FROM domains12
UNION ALL SELECT 'unweighted_mean',domain,unweighted_mean FROM domains12
UNION ALL SELECT 'design_df',design,df FROM design12 CROSS JOIN df
UNION ALL SELECT 'mean',design || '/' || domain,mean FROM design12 CROSS JOIN domains12
UNION ALL SELECT 'mean',design || '/gap',gap FROM design12 CROSS JOIN gap
UNION ALL SELECT 'se',design || '/rural',sqrt(vr) FROM design12
UNION ALL SELECT 'se',design || '/urban',sqrt(vu) FROM design12
UNION ALL SELECT 'se',design || '/all',sqrt(va) FROM design12
UNION ALL SELECT 'se',design || '/gap',sqrt(vg) FROM design12
UNION ALL SELECT 'domain_covariance',design,c FROM design12
UNION ALL SELECT 'subpop_mean',domain,mean FROM domains12 WHERE domain!='all'
UNION ALL SELECT 'subpop_se','rural',sqrt(vr) FROM design12 WHERE design='wr'
UNION ALL SELECT 'subpop_se','urban',sqrt(vu) FROM design12 WHERE design='wr'
UNION ALL SELECT 'trimmed_psus',domain,psus FROM trimmed12
UNION ALL SELECT 'trimmed_se',domain,se FROM trimmed12;
