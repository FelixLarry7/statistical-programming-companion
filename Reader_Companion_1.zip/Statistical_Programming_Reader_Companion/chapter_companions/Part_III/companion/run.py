"""Execute Part III and verify separately computed results by their declared keys."""

import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile, ZIP_DEFLATED

import duckdb
from scipy.stats import norm, t

from reference import anchors


ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data/raw"
R1_DRIVER = "f0d1c03029f52ba1d480c322deff5614920c48962b0357db7d5c2fe63af76414"
ABS_TOL = 1e-8
REL_TOL = 1e-10
FIXED_FIELDS = "mean sd lower_t upper_t lower_z upper_z cover_t cover_z".split()
SCENARIOS = list(itertools.product(("normal", "skewed"), (8,32)))
EXACT_METRICS = set("count missing yield_id pair_n pair_id group_n bin interval_n interval_df shifted_rainfed universe_id domain_n denominator weighted_total design_df trimmed_psus".split())
ENGINE_SEEDS = {"python":619000,"r":317000,"stata":851000}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compare(a, b, label, exact=False):
    tolerance = 0 if exact else ABS_TOL + REL_TOL*max(abs(a),abs(b))
    error = abs(a-b)
    if not math.isfinite(error) or error > tolerance:
        raise ValueError(f"{label}: observed {a}, expected {b}, tolerance {tolerance}")
    return error


def rows(path):
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def write_rows(path, fields, data):
    with path.open("w", newline="") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(fields)
        writer.writerows(data)


def execute(args, log):
    with log.open("w") as f:
        subprocess.run([str(a) for a in args], check=True, stdout=f, stderr=subprocess.STDOUT)


def require_unique(values, label):
    values = list(values)
    if len(values) != len(set(values)):
        raise ValueError(f"Duplicate key in {label}.")


def validate_inputs():
    for name,key in [("plots",["plot_id"]),("survey",["hh_id"]),
                     ("fixed_draws",["design","n","replicate","draw"]),
                     ("bootstrap_draws",["replicate","draw"])]:
        data = rows(RAW/f"{name}.csv")
        require_unique((tuple(r[k] for k in key) for r in data), name)
    if len(rows(RAW/"fixed_draws.csv")) != 5120 or len(rows(RAW/"bootstrap_draws.csv")) != 40:
        raise ValueError("Draw counts changed.")
    for r in rows(RAW/"critical_values.csv"):
        compare(float(r["t975"]),t.ppf(.975,int(r["df"])),"t lookup")


def run_duckdb(db, out):
    for p in sorted(RAW.glob("*.csv")):
        db.execute(f"CREATE TABLE {p.stem} AS SELECT * FROM read_csv(?,header=true)",[str(p)])
    queries = []
    for j in range(9,13):
        db.execute((ROOT/"sql"/f"ch{j:02d}.sql").read_text())
        queries.append(f"SELECT 'CH{j:02d}' AS chapter, metric,key,value FROM metrics{j:02d}")
    for name, query in (
        ("metrics", " UNION ALL ".join(queries)+" ORDER BY chapter,metric,key"),
        ("fixed", "SELECT * FROM fixed11 ORDER BY design,n,replicate"),
        ("figure_bins", "SELECT * FROM bins10 ORDER BY regime,bin"),
        ("figure_intervals", "SELECT * FROM intervals10 ORDER BY regime"),
        ("survey_psu_scores", "SELECT * FROM psu_scores12 ORDER BY stratum,psu"),
    ):
        db.sql(query).write_csv(str(out/f"{name}.csv"))
    for name, keys in (("figure_bins", ("regime","bin")), ("figure_intervals", ("regime",))):
        expected = rows(RAW/f"{name}.csv")
        observed = rows(out/f"{name}.csv")
        if len(observed)!=len(expected):
            raise ValueError(f"{name}: figure data row count changed.")
        for a,b in zip(observed,expected):
            for col in b:
                if col == "regime":
                    if a[col] != b[col]:
                        raise ValueError(f"{name}: category order changed.")
                else:
                    compare(float(a[col]),float(b[col]),f"{name}/{col}",col in keys or col in {"n","df","frequency"})
    (out/"environment.txt").write_text(f"DuckDB {duckdb.__version__}\n")


def read_metrics(p):
    result = {}
    for r in rows(p):
        key = (r["chapter"],r["metric"],r["key"])
        if key in result:
            raise ValueError(f"Duplicate metric {key} in {p}.")
        result[key] = float(r["value"])
    return result


def read_fixed(p):
    result = {}
    for r in rows(p):
        key = (r["design"],int(r["n"]),int(r["replicate"]))
        if key in result:
            raise ValueError(f"Duplicate replicate {key} in {p}.")
        result[key] = [float(r[f]) for f in FIXED_FIELDS]
    expected = {(d,n,r) for d,n in SCENARIOS for r in range(1,65)}
    if set(result)!=expected:
        raise ValueError(f"Fixed-draw keys differ in {p}.")
    return result


def numeric_audit(evidence, engines, include_stata_metrics):
    reference = read_metrics(evidence/"duckdb/metrics.csv")
    fixed = read_fixed(evidence/"duckdb/fixed.csv")
    if len(reference) != 215:
        raise ValueError("The scalar comparison ledger must contain 215 keys.")
    control = anchors()
    scalar_count, fixed_count = 0,0
    with (evidence/"comparisons.csv").open("w",newline="") as f:
        w = csv.writer(f,lineterminator="\n")
        w.writerow(("group","engine","key","observed","reference","abs_error"))
        for k,v in sorted(control.items()):
            error = compare(reference[k],v,k,k[1] in EXACT_METRICS)
            w.writerow(("anchor","duckdb","/".join(k),reference[k],v,error))
        for engine in engines:
            directory = evidence/engine
            if engine != "stata" or include_stata_metrics:
                candidate = read_metrics(directory/"metrics.csv")
                if candidate.keys()!=reference.keys():
                    raise ValueError(f"{engine}: missing {reference.keys()-candidate.keys()}, excess {candidate.keys()-reference.keys()}.")
                for k,v in sorted(reference.items()):
                    error = compare(candidate[k],v,(engine,k),k[1] in EXACT_METRICS)
                    w.writerow(("scalar",engine,"/".join(k),candidate[k],v,error))
                    scalar_count += 1
            for k,values in sorted(read_fixed(directory/"fixed.csv").items()):
                for field,a,b in zip(FIXED_FIELDS,values,fixed[k]):
                    key = "/".join(map(str, (*k,field)))
                    error = compare(a,b,(engine,key),field.startswith("cover"))
                    w.writerow(("fixed",engine,key,a,b,error))
                    fixed_count += 1
    return {"scalar":scalar_count,"fixed":fixed_count,"manual":len(control),
            "total":scalar_count+fixed_count+len(control)}


def import_stata(path, out):
    out.mkdir()
    with ZipFile(path) as archive:
        info = dict(line.split("=",1) for line in archive.read("run_info.txt").decode().splitlines())
        if info["stata_version"] not in {"16","17"}:
            raise ValueError("Expected execution evidence from Stata 16 or 17.")
        rc = int(info["part3_rc"])
        driver = archive.read("part3_driver.do")
        driver_sha = digest(driver)
        r2 = driver == (ROOT/"stata/part3_driver.do").read_bytes()
        if not r2 and not (driver_sha == R1_DRIVER and rc != 0):
            raise ValueError("Stata evidence uses a different driver.")
        for p in sorted(RAW.glob("*.csv")):
            if p.read_bytes()!=archive.read("input_"+p.name):
                raise ValueError(f"Stata ran a different copy of {p.name}.")
        outputs = ["fixed.csv","simulation.csv","ch10_stata.png"]
        if rc == 0:
            outputs.append("metrics.csv")
        for name in outputs+["run_info.txt","part3_driver.do"]:
            (out/name).write_bytes(archive.read(name))
        if not (out/"ch10_stata.png").read_bytes().startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Expected a native Stata PNG.")
        raw_log = archive.read("part3_run.log").decode("utf-8","replace")
        if rc == 0 and ("Bootstrap endpoint checks completed." not in raw_log
                        or "Part III generated in Stata" not in raw_log):
            raise ValueError("Stata completion messages are absent.")
        if rc != 0 and ("--Break--" not in raw_log or f"r({rc});" not in raw_log):
            raise ValueError("Incomplete Stata run has a new error. Inspect its original log before importing.")
        log = []
        for line in raw_log.splitlines():
            if re.search(r"(?i)(/Users/|/var/folders/|[A-Z]:\\|/home/|/private/)",line):
                log.append("[Local path removed]")
            elif not (line.startswith("> ") and log and log[-1]=="[Local path removed]"):
                log.append(line)
        (out/"part3_run.log").write_text("\n".join(log)+"\n")
        meta = dict(info,driver_sha256=driver_sha,
                    run_revision=2 if r2 else 1,original_zip_sha256=digest(path.read_bytes()))
        (out/"environment.json").write_text(json.dumps(meta,indent=2)+"\n")
        with ZipFile(out/"evidence_replay.zip","w",ZIP_DEFLATED) as replay:
            for name in outputs+["run_info.txt","part3_driver.do","part3_run.log"]:
                replay.write(out/name,name)
            for p in sorted(RAW.glob("*.csv")):
                replay.write(p,"input_"+p.name)
    return meta


def simulation_audit(db, out, engines):
    parts = []
    critical = {n: {"t": t.ppf(.975,n-1), "z": norm.ppf(.975)} for n in (8,32)}
    for engine in engines:
        data = rows(out/engine/"simulation.csv")
        seen = set()
        for row in data:
            d,n,r = row["design"],int(row["n"]),int(row["replicate"])
            key = (d,n,r)
            if key in seen or (d,n) not in SCENARIOS or not 1<=r<=2000:
                raise ValueError(f"{engine}: invalid simulation key {key}")
            seen.add(key)
            if int(row["seed"]) != ENGINE_SEEDS[engine]+SCENARIOS.index((d,n))+1:
                raise ValueError(f"{engine}: seed mismatch at {key}.")
            mean,sd = float(row["mean"]),float(row["sd"])
            if not (math.isfinite(mean) and math.isfinite(sd) and sd>0):
                raise ValueError(f"{engine}: invalid sampling summary at {key}.")
            for method,crit in critical[n].items():
                lower, upper = mean-crit*sd/math.sqrt(n), mean+crit*sd/math.sqrt(n)
                for field,expected in [(f"lower_{method}",lower),(f"upper_{method}",upper),
                                       (f"cover_{method}",int(lower<=1<=upper))]:
                    compare(float(row[field]),expected,(engine,key,field),field.startswith("cover"))
        if len(seen)!=8000:
            raise ValueError(f"{engine}: incomplete independent simulation.")
        db.execute(f"CREATE TABLE sim_{engine} AS SELECT * FROM read_csv(?,header=true)",
                   [str(out/engine/"simulation.csv")])
        parts.append(f"SELECT '{engine}' AS engine, * FROM sim_{engine}")
    db.execute("CREATE TEMP VIEW streams AS "+" UNION ALL ".join(parts))
    summary = db.sql("""
        WITH aggregate AS (
          SELECT engine,design,n,count(*) AS reps,sum(cover_t)::INT AS t_hits,sum(cover_z)::INT AS z_hits,
                 avg(cover_t) AS t_cover,avg(cover_z) AS z_cover,
                 stddev_samp(cover_t-cover_z)/sqrt(count(*)) AS paired_mcse
          FROM streams GROUP BY engine,design,n
        )
        SELECT *,sqrt(t_cover*(1-t_cover)/reps) AS t_mcse,
                 sqrt(z_cover*(1-z_cover)/reps) AS z_mcse
        FROM aggregate ORDER BY design,n,engine
    """)
    summary.write_csv(str(out/"simulation_summary.csv"))
    aggs = rows(out/"simulation_summary.csv")
    diagnostics = []
    for d,n in SCENARIOS:
        group = [r for r in aggs if r["design"]==d and int(r["n"])==n]
        for left,right in itertools.combinations(group,2):
            for method in ("t","z"):
                delta = abs(float(left[method+"_cover"])-float(right[method+"_cover"]))
                pooled = math.hypot(float(left[method+"_mcse"]),float(right[method+"_mcse"]))
                diagnostics.append((d,n,method,left["engine"],right["engine"],delta,
                                    pooled,delta <= 4*pooled))
    write_rows(out/"stream_diagnostics.csv",("design","n","method","left","right",
               "absolute_coverage_difference","pooled_mcse","within_4_mcse"),diagnostics)
    return {"rows":8000*len(engines),"engines":engines,"stream_checks":len(diagnostics),
            "within_4_mcse":sum(row[-1] for row in diagnostics)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--rscript",default="Rscript")
    parser.add_argument("--stata-evidence",type=Path)
    parser.add_argument("--require-four",action="store_true")
    args = parser.parse_args()
    evidence = args.output.resolve()
    if evidence.exists() and any(evidence.iterdir()):
        parser.error("Choose a new or empty evidence folder to avoid mixing runs.")
    evidence.mkdir(parents=True,exist_ok=True)
    validate_inputs()
    db = duckdb.connect()
    for engine in ("duckdb","python","r"):
        (evidence/engine).mkdir()
    run_duckdb(db,evidence/"duckdb")
    execute([sys.executable, ROOT/"python/part3.py",RAW,evidence/"python"],
            evidence/"python/environment.txt")
    execute([args.rscript,"--vanilla",ROOT/"r/part3.R",RAW,evidence/"r"],evidence/"r/environment.txt")
    stata = import_stata(args.stata_evidence,evidence/"stata") if args.stata_evidence else None
    full = bool(stata and int(stata["part3_rc"])==0)
    if args.require_four and not full:
        raise ValueError("Full verification requires a completed local Stata 16 or 17 run (code 0).")
    engines = ["python","r"] + (["stata"] if stata else [])
    numeric = numeric_audit(evidence,engines,full)
    simulation = simulation_audit(db,evidence,engines)
    report = {
        "status":"VERIFIED" if full else ("PARTIALLY VERIFIED" if stata else "THREE ENGINES VERIFIED"),
        "complete_engines":["duckdb","python","r"]+(["stata"] if full else []),
        "scalar_keys_per_engine":215,"fixed_replicates":256,
        "numeric_comparisons":numeric,"failed_numeric_comparisons":0,
        "simulation":simulation,"tolerance":{"absolute":ABS_TOL,"relative":REL_TOL},
        "stata":stata,"stata_partial_scope":["figure","fixed replicates","independent simulation"] if stata and not full else [],
        "inputs_sha256":{p.name:digest(p.read_bytes()) for p in sorted(RAW.glob("*.csv"))},
    }
    (evidence/"verification.json").write_text(json.dumps(report,indent=2)+"\n")
    print(report["status"],numeric,simulation)


if __name__=="__main__":
    main()
