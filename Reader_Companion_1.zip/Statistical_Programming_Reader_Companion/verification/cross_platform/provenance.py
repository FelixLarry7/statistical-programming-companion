"""Bind licensed Stata outputs to their original successful run and exact inputs."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile

from contracts import EXPECTED_COMPARISONS, ROOT, digest


def checksum(blob):
    return sha256(blob).hexdigest()


def read_run_info(data):
    return dict(line.split("=", 1) for line in data.decode().splitlines() if "=" in line)


def relative(path):
    return path.relative_to(ROOT).as_posix()


def licensed_row(scope, metadata, rc, driver, inputs, output, record, archive_sha, log_digest):
    if (metadata["stata_version"], metadata["edition"], metadata[rc]) != ("17", "IC", "0"):
        raise ValueError(f"Unverified licensed execution record for {scope}")
    assert log_digest and inputs
    return dict(scope=scope, engine="Stata 17 IC", operating_system=metadata["platform"],
                run_date=metadata["run_date"], run_time=metadata["run_time"], status="Licensed run verified",
                driver=relative(driver), driver_sha256=digest(driver), evidence=relative(record),
                package_archive_sha256=archive_sha, log_sha256=log_digest, inputs_checked=len(inputs),
                input_sha256=json.dumps(inputs,sort_keys=True), output=relative(output), output_sha256=digest(output))


def audit_licensed(evidence):
    rows = []
    for number, part in enumerate(EXPECTED_COMPARISONS, 1):
        case = f"Part_{part}"
        companion = ROOT / f"chapter_companions/{case}/companion"
        build = evidence / case
        driver_name = f"part{number}_driver.do"
        driver = companion / "stata" / ("labs.do" if part == "I" else driver_name)
        output = build / ("stata.csv" if part in {"I","II"} else "stata/metrics.csv")
        log_name = f"part{number}_run.log"
        rc = f"part{number}_rc"
        if part == "I":
            record = companion / "evidence/local_stata"
            info = read_run_info((record/"run_info.txt").read_bytes())
            files = [(record/f"part1_{item.name}", item) for item in sorted((build/"canonical").glob("*.csv"))]
            carry = {expected.name:digest(expected) for archived,expected in files if digest(archived)==digest(expected)}
            assert len(files) == len(carry) == 10
            assert digest(record/driver_name) == digest(driver)
            assert digest(record/"part1_metrics.csv") == digest(output)
            assert digest(record/log_name) == digest(build/"stata-local.log")
            rows.append(licensed_row(case, info, rc, driver, carry, output, record/"run_info.txt", "",
                                     digest(record/log_name)))
            continue
        record = companion/"evidence"/("stata_evidence_replay.zip" if part=="II" else "stata/evidence_replay.zip")
        data = build/"input" if part=="II" else companion/"data"
        with ZipFile(record) as archive:
            members = archive.namelist()
            assert len(members) == len(set(members)) and archive.testzip() is None
            info = read_run_info(archive.read("run_info.txt"))
            assert checksum(archive.read(driver_name)) == digest(driver), case
            archive_metrics = "part2_metrics.csv" if part=="II" else "metrics.csv"
            assert checksum(archive.read(archive_metrics)) == digest(output), case
            carry = {}
            for name in sorted(n for n in members if n.startswith("input_") and n.endswith(".csv")):
                candidate, = data.rglob(name.removeprefix("input_"))
                checksum_value = checksum(archive.read(name))
                assert checksum_value == digest(candidate), case
                carry[relative(candidate)] = checksum_value
            if part != "II":
                record_info = json.loads((build/"stata/environment.json").read_text())
                assert info.items() <= record_info.items(), case
                assert record_info["driver_sha256"] == digest(driver)
            if part == "III":
                for additional in ("fixed.csv","simulation.csv"):
                    assert checksum(archive.read(additional)) == digest(build/"stata"/additional)
            log_digest = checksum(archive.read(log_name))
        rows.append(licensed_row(case, info, rc, driver, carry, output, record, digest(record), log_digest))
    pilot = ROOT/"companion/pilot"
    record = pilot/"stata/evidence/provenance.json"
    metadata = json.loads(record.read_text())
    driver = pilot/"stata/pilot/fit_ols.do"
    assert digest(driver) == metadata["driver_sha256"] == digest(record.parent/"driver.do")
    analytical = evidence/"pilot_licensed/duckdb/analytical.csv"
    assert digest(analytical) == metadata["input_sha256"] == digest(record.parent/"analytical.csv")
    for file in (record.parent/"outputs").iterdir():
        if file.is_file():
            assert digest(file) == digest(evidence/"pilot_licensed/stata"/file.name), file.name
    rows.append(licensed_row("Chapter 13 and tagged pilot", metadata, "stage2_rc", driver,
                             {relative(analytical):digest(analytical)}, evidence/"pilot_licensed/stata/coefficients.csv",
                             record, "", digest(record.parent/"stage2_run.log")))
    cap = evidence/"capstone_replay/stata/metrics.csv"
    assert digest(cap) == rows[-2]["output_sha256"]
    rows.append(rows[-2] | {"scope":"Chapter 40 tagged Part IX replay","output":relative(cap),"output_sha256":digest(cap)})
    return rows
