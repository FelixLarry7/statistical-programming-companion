"""Reconstruct the frozen analytical samples by key and disposition with SQL."""
from collections import Counter
from decimal import Decimal
import json

import duckdb

from comparisons import ENGINES, metrics, pilot_tables
from contracts import ROOT, digest, table


def register(db, name, folder):
    path, = folder.rglob(f"{name}.csv")
    db.read_csv(str(path), header=True, all_varchar=True).create_view(name)


def sql_cases(db):
    for part, names in {
        "III": "survey",
        "V": "households17 rollout18",
        "VIII": "births30 bank_filings31 bank_ids31 households32 plots32",
        "IX": "roster33 assignment33 wdi35 map35 pwt35 welfare36",
    }.items():
        for name in names.split():
            register(db, name, ROOT / f"chapter_companions/Part_{part}/companion/data")
    for name in ("plots", "season_records"):
        register(db, name, ROOT / "companion/pilot/data/raw")
    db.execute("""
        CREATE TEMP VIEW pilot AS
        SELECT plot_id, season, CAST(sessions AS INT) AS sessions,
               CAST(harvest_kg AS DECIMAL(16,6))*10000 AS harvest_scaled,
               CAST(area_m2 AS DECIMAL(16,6)) AS area,
               CASE WHEN season <> '2025' THEN 'outside_season'
                    WHEN area_m2 IS NULL OR CAST(area_m2 AS DOUBLE) <= 0 THEN 'invalid_area'
                    WHEN harvest_kg IS NULL THEN 'missing_harvest'
                    WHEN sessions IS NULL THEN 'missing_sessions'
                    ELSE 'included' END AS disposition
        FROM season_records JOIN plots USING (plot_id)
        """)
    db.execute("""
        CREATE TEMP VIEW bank_quarters AS
        SELECT i.bank, f.quarter, i.segment
        FROM bank_filings31 f JOIN bank_ids31 i USING (source, quarter)
        WHERE CAST(f.release AS INT) <= CAST(f.quarter AS INT) + 1
        QUALIFY ROW_NUMBER() OVER (PARTITION BY f.source, f.quarter ORDER BY CAST(release AS INT) DESC) = 1
        """)
    db.execute("""
        CREATE TEMP VIEW expanded AS
        SELECT w.economy, w.year,
               CASE WHEN m.include <> '1' THEN 'aggregate_out_of_scope'
                    WHEN p.economy IS NULL THEN 'no_pwt_match'
                    WHEN w.life IS NULL OR COALESCE(CAST(w.population AS DOUBLE), 0) <= 0
                      OR COALESCE(CAST(p.rgdpe AS DOUBLE), 0) <= 0
                      OR COALESCE(CAST(p.pop AS DOUBLE), 0) <= 0 THEN 'missing_or_nonpositive_input'
                    ELSE 'included' END AS disposition
        FROM wdi35 w JOIN map35 m USING (economy)
        LEFT JOIN pwt35 p USING (economy, year)
        """)
    return {
        "ch13_pilot": "SELECT plot_id, season, disposition FROM pilot",
        "ch12_survey_universe": """SELECT hh_id, CASE WHEN eligible='1' THEN 'included'
                                            ELSE 'out_of_scope' END FROM survey""",
        "ch17_trial_universe": """SELECT household, CASE WHEN eligible='1' THEN 'included'
                                            ELSE 'out_of_scope' END FROM households17""",
        "ch18_rollout": """SELECT unit, period, CASE WHEN in_scope='1' THEN 'included'
                                      ELSE 'out_of_scope' END FROM rollout18""",
        "ch30_facility_delivery": """
            SELECT person, CASE WHEN live <> '1' THEN 'not_live_birth'
              WHEN CAST(months AS INT) >= 24 THEN 'outside_24_months'
              WHEN facility IN ('0','1') THEN 'included' ELSE 'unknown_place' END FROM births30
            """,
        "ch31_comparable_filings": """
            SELECT q.bank, q.quarter, CASE WHEN n.quarter IS NULL THEN 'no_next_quarter'
              WHEN n.segment <> q.segment THEN 'segment_break' ELSE 'included' END
            FROM bank_quarters q LEFT JOIN bank_quarters n ON q.bank=n.bank
                 AND CAST(n.quarter AS INT)=CAST(q.quarter AS INT)+1
            """,
        "ch32_meal_shortfall": """SELECT household, CASE WHEN meal_shortfall IN ('0','1') THEN 'included'
                                         ELSE 'unknown_response' END FROM households32""",
        "ch32_maize_yield": """
            SELECT plot, season, CASE WHEN maize <> '1' THEN 'other_crop'
                WHEN CAST(harvest AS DOUBLE) < 0 THEN 'missing_harvest'
                WHEN CAST(gps AS DOUBLE) <= 0 OR CAST(reported AS DOUBLE) <= 0 OR unit NOT IN ('1','2')
                     THEN 'invalid_area_or_unit' ELSE 'included' END FROM plots32
            """,
        "ch33_followup": """
            SELECT household, CASE WHEN eligible='0' THEN 'out_of_scope'
             WHEN observed='1' THEN 'included' ELSE 'followup_missing' END FROM roster33
            """,
        "ch35_expanded_panel": "SELECT economy, year, disposition FROM expanded",
        "ch35_balanced_panel": """
            SELECT economy, year, CASE WHEN COUNT(*) OVER (PARTITION BY economy)=24 THEN 'included'
                                       ELSE 'incomplete_economy_window' END
            FROM expanded WHERE disposition='included'
            """,
        "ch36_care_domain": """
            SELECT household, CASE WHEN need <> '1' THEN 'outside_care_need_domain'
              WHEN unmet IN ('0','1') THEN 'included' ELSE 'unknown_care_outcome' END FROM welfare36
            """,
    }


def audit_samples(evidence, pilot_folder=None):
    pilot_folder = pilot_folder or evidence / "pilot_licensed"
    counts = {
        "ch13_pilot": (16,12), "ch12_survey_universe": (26,24), "ch17_trial_universe": (108,96),
        "ch18_rollout": (400,390), "ch30_facility_delivery": (600,374), "ch31_comparable_filings": (568,543),
        "ch32_meal_shortfall": (240,231), "ch32_maize_yield": (320,267), "ch33_followup": (1152,831),
        "ch35_expanded_panel": (312,256), "ch35_balanced_panel": (256,240), "ch36_care_domain": (600,269),
    }
    certificates = []
    included = {}
    with duckdb.connect() as db:
        for case, query in sql_cases(db).items():
            sql = db.execute(query).fetchall()
            folder = ROOT / "data/ledgers"
            dispositions = folder / f"{case}.csv"
            keys_path = folder / f"{case}_included.csv"
            columns, entries = table(dispositions)
            _, key_entries = table(keys_path)
            archived = [tuple(row[key] for key in columns) for row in entries]
            key_set = {r[:-1] for r in sql if r[-1] == "included"}
            if (len(sql), len(key_set)) != counts[case] or len({r[:-1] for r in sql}) != len(sql):
                raise ValueError(f"{case}: sample counts or source-key uniqueness fail")
            if sorted(sql) != sorted(archived) or sorted(key_set) != sorted(tuple(row[k] for k in columns[:-1]) for row in key_entries):
                raise ValueError(f"{case}: analytical IDs or dispositions differ")
            included[case] = key_set
            certificates.append(dict(case=case, grain=", ".join(columns[:-1]), source_records=len(sql),
                                     included=len(key_set), excluded=len(sql)-len(key_set),
                                     dispositions=json.dumps(dict(sorted(Counter(r[-1] for r in sql).items()))),
                                     source_ledger=dispositions.relative_to(ROOT).as_posix(),
                                     include_sha256=digest(keys_path), comparison="Exact keys and dispositions"))
        evidence_hooks = verify_engine_samples(db, evidence, pilot_folder, included)
    for row in certificates:
        row["engine_evidence"] = evidence_hooks[row["case"]]
    return certificates


def verify_engine_samples(db, evidence, pilot, included):
    quantities = db.execute("""SELECT plot_id, season, sessions, harvest_scaled, area
                               FROM pilot WHERE disposition='included'""").fetchall()
    pilot_points = {f"{key}/{season}": (Decimal(sessions), harvest / area) for key, season, sessions, harvest, area in quantities}
    correction = evidence / "reporting/scenario_analytical.csv"
    _, corrected_rows = table(correction)
    _, baseline_rows = table(evidence / "pilot_licensed/duckdb/analytical.csv")
    key = lambda r: (r["plot_id"], r["season"])
    changed = []
    assert len(baseline_rows) == len(corrected_rows) == 12
    for initial, updated in zip(baseline_rows, corrected_rows, strict=True):
        assert key(initial) == key(updated)
        for field in ("sessions", "area_ha"):
            assert Decimal(initial[field]) == Decimal(updated[field])
        if Decimal(initial["harvest_kg"]) != Decimal(updated["harvest_kg"]):
            changed.append(updated["plot_id"])
            assert Decimal(updated["harvest_kg"]) - Decimal(initial["harvest_kg"]) == Decimal(10)
    assert changed == ["P011"]
    for engine in ENGINES:
        predictions = pilot_tables(pilot / engine)["predictions"]
        values = {k: (Decimal(r["sessions"].strip()), Decimal(r["yield_kg_ha"].strip())) for k,r in predictions.items()}
        assert values == pilot_points, engine
    hooks = {
        "ch13_pilot": "Four prediction ledgers agree exactly on plot-season, sessions and yield. The corrected extract retains the same twelve keys.",
        "ch12_survey_universe": "Four ledgers agree on all eligible household IDs and the exact eligible count.",
        "ch17_trial_universe": "Four ledgers agree on roster and eligible counts and eligible members by arm.",
        "ch18_rollout": "Exact row dispositions checked against the frozen source and Stage 4 ledger. Engine ledgers compare cohort-time target and control counts.",
        "ch30_facility_delivery": "Four ledgers agree on source, recent live births, missing location and observed delivery counts.",
        "ch31_comparable_filings": "Four ledgers agree on filing, bank-quarter and comparable following-quarter counts. The sample audit compares bank-quarter IDs.",
        "ch32_meal_shortfall": "Four ledgers agree on source households and observed responses.",
        "ch32_maize_yield": "Four ledgers agree on all exported plot IDs and the usable count. The sample audit compares plot-season keys.",
        "ch33_followup": "Four ledgers agree on screened, eligible and observed counts by assigned arm.",
        "ch35_expanded_panel": "Four ledgers agree on eligible economy-year totals. The sample audit compares the economy-year keys.",
        "ch35_balanced_panel": "Four ledgers agree on retained rows and economies. The sample audit compares the complete economy-year windows.",
        "ch36_care_domain": "Four ledgers agree on source, care need and observed outcome counts.",
    }
    trial = dict(db.execute("""SELECT v.offer, COUNT(*) FROM households17 h
                  JOIN (SELECT village, offer FROM read_csv_auto(?) ) v USING (village)
                  WHERE h.eligible='1' GROUP BY v.offer""",
                  [str(next((ROOT / "chapter_companions/Part_V/companion/data").rglob("villages17.csv")))]).fetchall())
    flow33 = db.execute("""SELECT a.offer, COUNT(*), COUNT(*) FILTER (WHERE eligible='1'),
                               COUNT(*) FILTER (WHERE eligible='1' AND observed='1')
                          FROM roster33 r JOIN assignment33 a USING (village) GROUP BY a.offer""").fetchall()
    part8_fields = {
        ("CH30","flow","scalar","records"): 600, ("CH30","flow","scalar","window"): 395,
        ("CH30","flow","scalar","missing"): 21, ("CH30","flow","scalar","observed"): 374,
        ("CH31","flow","scalar","filings"): 1136, ("CH31","flow","scalar","quarter_rows"): 568,
        ("CH31","flow","scalar","outcome_rows"): 543, ("CH32","flow","scalar","households"): 240,
        ("CH32","all_food","scalar","n"): 231, ("CH32","flow","scalar","usable"): 267,
    }
    part9_fields = {
        ("CH35","common","scalar","n"): 240,
        ("CH35","common","scalar","countries"): 10, ("CH36","flow","scalar","households"): 600,
        ("CH36","flow","scalar","need"): 277, ("CH36","flow","scalar","known"): 269,
    } | {("CH33",f"arm{arm}","scalar",label): n for arm,*rest in flow33
         for label,n in zip(("screened","eligible","observed"), rest, strict=True)}
    for engine in ENGINES:
        iii = metrics("III", evidence / "Part_III", engine)
        assert {k for (c,q,k),v in iii.items() if c == "CH12" and q == "universe_id" and v == 1} == {k for k, in included["ch12_survey_universe"]}
        assert iii["CH12","count","eligible"] == 24
        v = metrics("V", evidence / "Part_V", engine)
        assert v["CH17","trial","scalar","roster"] == 108 and v["CH17","trial","scalar","n"] == 96
        for arm, count in trial.items():
            assert v["CH17","trial","arm_n",str(arm)] == count
        viii = metrics("VIII", evidence / "Part_VIII", engine)
        ix = metrics("IX", evidence / "Part_IX", engine)
        count35 = sum(v for (c,m,q,k),v in ix.items()
                      if c == "CH35" and m.startswith("country") and (q,k) == ("scalar","good"))
        assert count35 == 256 and ix.get(("CH35","expanded","scalar","n"), count35) == count35
        for fields, data in ((part8_fields,viii),(part9_fields,ix)):
            for k, value in fields.items():
                assert data[k] == value, (engine, k)
        assert {k for (c,m,q,k) in viii if (c,m,q) == ("CH32","flow","gps_ha")} == {k for k,_ in included["ch32_maize_yield"]}, engine
    return hooks
