"""Audit the Stage 6 evidence and produce a portable reviewer register."""
import argparse
from collections import Counter
import csv
from decimal import Decimal
from itertools import chain
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from comparisons import RULES, all_comparisons, audit_pilot, audit_primary, result
from contracts import EXPECTED_COMPARISONS, ROOT, digest, json_value, part10_checks, table, verify_part
from design_checks import audit_formulas, audit_streams
from displays import verify_displays
from provenance import audit_licensed
from samples import audit_samples


DIRECTORY = Path(__file__).resolve().parent
FROZEN = ROOT / "verification/evidence"


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def stage5_integrity(evidence):
    _, rows = table(evidence / "artifacts.csv")
    recorded = {r["path"] for r in rows}
    observed = {p.relative_to(evidence).as_posix() for p in evidence.rglob("*")
                if p.is_file() and p.name != "artifacts.csv"}
    if recorded != observed or len(recorded) != len(rows):
        raise ValueError("Stage 5 execution evidence inventory differs")
    for row in rows:
        file = evidence / row["path"]
        if int(row["bytes"]) != file.stat().st_size or row["sha256"] != digest(file):
            raise ValueError(f"Stage 5 execution evidence fingerprint differs: {row['path']}")
    assert json_value(evidence / "run_summary.json")["status"] == "PASSED"
    return len(rows)


def stage6_fresh():
    folder = DIRECTORY / "fresh"
    scopes = dict(zip(("I", "II"), (449,1720), strict=True))
    for part,count in scopes.items():
        name = f"Part_{part}"
        audit_primary(part,folder,name,count)
        historical = verify_part(part,folder/name,FROZEN/name)
        assert historical["failures"] == 0
    pilots = audit_pilot(folder)
    assert [len(rows) for rows in pilots.values()] == [364,510]
    assert "test_hc0_substitution_is_detected" in (folder/"fresh_pilot.log").read_text()
    manifest = json_value(folder/"pilot_licensed/run_manifest.json")
    assert manifest["status"] == "VERIFIED"
    for name, checksum in manifest["artifacts_sha256"].items():
        assert digest(folder/"pilot_licensed"/name) == checksum, name
    return {"Part I":449,"Part II":1720,"Chapter 13 pilot":874}


def summary_rows(comparisons):
    rows = []
    for scope,data in comparisons.items():
        exact = sum(r["rule"] == "exact" for r in data)
        closest = max(data, key=lambda r: Decimal(r["fraction_of_limit"]))
        max_abs = max(data, key=lambda r: r["abs_error"])
        rows.append(dict(scope=scope, comparisons=len(data), exact=exact, approximate=len(data)-exact,
                         nonzero=sum(r["abs_error"]!=0 for r in data), max_abs_error=max_abs["abs_error"],
                         max_abs_key="/".join(str(max_abs[f]) for f in ("chapter","model","quantity","key") if max_abs[f]),
                         closest_to_bound=closest["fraction_of_limit"],
                         closest_key="/".join(str(closest[f]) for f in ("chapter","model","quantity","key") if closest[f]),
                         closest_engine=closest["candidate"], failed=0))
    return rows


def coverage(comparisons, printed, evidence):
    counts_by_chapter = Counter(r["chapter"] for scope,rows in comparisons.items()
                                if scope.startswith("Part_") for r in rows)
    counts_by_display = Counter(r["chapter"] for r in printed)
    _, baseline = table(evidence/"chapter_coverage.csv")
    records = []
    for row in baseline:
        chapter = int(row["chapter"])
        if chapter <= 36:
            number = counts_by_chapter[f"CH{chapter:02}"]
            measure = "Primary cross-platform comparisons"
        elif chapter == 37:
            number = len(comparisons["pilot_reference_checks"]) + len(comparisons["pilot_cross_environment"])
            measure = "Pilot design-reference and pairwise checks"
        else:
            number = int(row["primary_comparisons"])
            measure = {38:"Corrected-scenario numerical comparisons",
                       39:"Deliberate disclosure faults rejected",40:"Corrected report fields reconciled"}[chapter]
        assert int(row["primary_comparisons"]) == number and counts_by_display[chapter] >= 1, chapter
        assert (evidence / row["review_output"]).is_file()
        records.append({"chapter":chapter,"part":row["part"],"title":row["case"],"measure":measure,"checked":number,
                        "displays_checked":counts_by_display[chapter],"python":row["python"],"r":row["r"],
                        "duckdb":row["duckdb"],"stata":row["stata"],"source":row["source"],
                        "evidence":(evidence/row["review_output"]).relative_to(ROOT).as_posix(),
                        "evidence_sha256":digest(evidence/row["review_output"]),"status":"Passed"})
    assert [r["chapter"] for r in records] == list(range(1,41))
    return records


def supporting_claims(evidence):
    previous = part10_checks(evidence)
    scenario = json_value(evidence/"reporting/scenario.json")
    assert len(scenario["comparisons"]) == 10 and all(r["passed"] for r in scenario["comparisons"])
    public = evidence/"disclosure/CH39_Public_Teaching_Release.zip"
    disclosure = json_value(evidence/"disclosure/disclosure_audit.json")
    with ZipFile(public) as package:
        assert package.testzip() is None and len(package.namelist()) == 6
        assert sorted(package.namelist()) == sorted(disclosure["public_members"])
    assert digest(public) == disclosure["archive_sha256"][public.name]
    stable = json_value(evidence/"pilot_stability.json")
    for name, fingerprint in stable.items():
        for route in ("pilot_first","pilot_second"):
            assert digest(evidence/route/name) == fingerprint, (route,name)
    assert previous["capstone_replay_comparisons"] == 20215
    return previous


def regression_controls(evidence):
    results = []
    for observed, rule in (("96.0001","exact"),("5.4","part_V")):
        identity = ("CH17","trial","scalar","n" if rule=="exact" else "itt")
        try:
            result("deliberate defect",identity,"expected","altered",Decimal("96" if rule=="exact" else "5.3125"),
                   Decimal(observed),rule,"test input")
        except ValueError as error:
            if "exceeds the frozen limit" not in str(error):
                raise
            results.append(str(error))
        else:
            raise ValueError(f"Deliberately altered {rule} field was accepted")
    # The keyed audit must catch a fabricated passing row even if both displayed
    # numbers and the displayed error in that row appear mutually consistent.
    with TemporaryDirectory() as work:
        base = Path(work)
        target = base/"Part_I"
        target.mkdir()
        for name in ("python.csv","r.csv","duckdb.csv","stata.csv"):
            (target/name).symlink_to(evidence/"Part_I"/name)
        _, rows = table(evidence/"Part_I/comparisons.csv")
        index = next(i for i,r in enumerate(rows) if r["comparison"]=="DuckDB vs anchors"
                     and r["metric"]=="invoices")
        rows[index] |= {"expected":"91","observed":"91"}
        write_csv(target/"comparisons.csv",rows)
        try:
            audit_primary("I",base,"Part_I",449)
        except ValueError as error:
            if "recorded values differ from the keyed outputs" not in str(error):
                raise
            results.append(str(error))
        else:
            raise ValueError("Fabricated passing row was accepted")
    return results


def dispositions(comparisons, streams):
    cases = []
    for part in summary_rows(comparisons):
        cases.append(dict(scope=part["scope"],classification="Recorded numerical gaps",
                          observation=f"{part['nonzero']} nonzero differences across {part['comparisons']:,} checks. "
                                      f"Largest fraction of limit {Decimal(part['closest_to_bound']):.3%}.",
                          disposition="Accepted under the original rule. Key, difference and bound retained.",
                          evidence="comparisons.csv"))
    mixed, = [r for r in comparisons["Part_IV"] if
              (r["chapter"],r["model"],r["quantity"],r["key"],r["candidate"])==("CH16","unbalanced","scalar","tau2","stata")]
    stream = max(streams,key=lambda r:r["fraction_of_limit"])
    for scope,classification,observation,disposition,path in (
        ("Chapter 16","Independent ML fits",
         f"Unbalanced random-intercept variance differs by {mixed['abs_error']:.3E}. The bound is {mixed['limit']:.3E}.",
         "Accepted. The shared maximum-likelihood target permits a predeclared optimiser tolerance.","comparisons.csv"),
        ("Part IV","SQL method scope","DuckDB evaluates the model at shared coefficients. Its normal CDF uses a polynomial approximation.",
         "Accepted at the declared Part IV allowance. Native estimation is recorded for the statistical engines.",
         "verification/evidence/Part_IV/verification.json"),
        ("Chapter 11","Independent random streams",
         f"24 comparisons passed. Largest gap consumed {stream['fraction_of_limit']:.1%} of four pooled MCSE.",
         "Accepted as compatible simulation performance under the stated rule.","stochastic_checks.csv"),
        ("Chapter 22","Different estimation objectives","The conditional MA grid and native state-space likelihoods use distinct initialisation and search rules.",
         "Retained as separate estimates. The four-engine verification claim uses the conditional recursion.",
         "manuscript/chapters/ch22.qmd"),
        ("Chapter 26","Different learner implementations","Published Python and R forest scores differ on the shared holdout.",
         "Retained as separate learners. The common checks apply to ridge and to scoring the frozen ensemble predictions.",
         "manuscript/chapters/ch26.qmd"),
        ("Chapters 13 and 37","Deliberate covariance substitution",
         "The same slope has an HC1 SE of 4.65679 and an HC0 SE of 4.25105.",
         "Rejected under the HC1 label. HC0 retained as a teaching sensitivity.",
         "verification/cross_platform/fresh/fresh_pilot.log"),
        ("Chapter 38","Deliberate scenario substitution","The corrected harvest yields 81.43 under its scenario.",
         "Rejected when placed in the original 80.00 row. Both scenario keys and digests retained.",
         "verification/evidence/reporting/audit.json"),
        ("Chapter 39","Deliberate disclosure contamination","Seeded notebook and log changes failed the approved-content check.",
         "Rejected. Corrected six-file public teaching release passed its checks.",
         "verification/evidence/disclosure/disclosure_audit.json"),
        ("Chapter 40","Deliberate model-key substitution","The weighted estimate 2.98 was placed under the equal-weight key.",
         "Restored the equal-weight estimate of −1.33 and checked all 24 corrected fields.",
         "verification/evidence/capstone_report/review_record.json"),
    ):
        cases.append(dict(scope=scope,classification=classification,observation=observation,disposition=disposition,evidence=path))
    return cases


def audit(output):
    if output.exists():
        raise FileExistsError("Use a new audit output directory.")
    files_checked = stage5_integrity(FROZEN)
    comparisons = all_comparisons(FROZEN)
    fresh = stage6_fresh()
    samples = audit_samples(FROZEN,DIRECTORY/"fresh/pilot_licensed")
    formula = audit_formulas(FROZEN,DIRECTORY/"fresh/pilot_licensed")
    streams = audit_streams(FROZEN)
    displays = verify_displays(FROZEN)
    licensed = audit_licensed(FROZEN)
    claims = coverage(comparisons,displays,FROZEN)
    other = supporting_claims(FROZEN)
    controls = regression_controls(FROZEN)
    summaries = summary_rows(comparisons)
    primary = sum(r["comparisons"] for r in summaries if r["scope"].startswith("Part_"))
    assert primary == 81910
    limit = max(Decimal(r["closest_to_bound"]) for r in summaries if r["scope"].startswith("Part_"))
    output.mkdir(parents=True)
    registers = {
        "comparisons": list(chain.from_iterable(comparisons.values())),
        "comparison_summary": summaries,"sample_verification": samples,"independent_formulas": formula,
        "stochastic_checks": streams,"published_values": displays,"engine_evidence": licensed,
        "chapter_claims": claims,"discrepancies":dispositions(comparisons,streams),
        "tolerance_rules": [dict(rule=id,absolute=a,relative=b,scale=scale) for id,(a,b,scale) in RULES.items()],
    }
    for name, rows in registers.items():
        write_csv(output/f"{name}.csv",rows)
    record = dict(status="Passed",primary_comparisons=primary,chapters=len(claims),analytical_samples=len(samples),
                  checked_table_cells=len(displays),independent_formula_checks=len(formula),
                  independent_stream_checks=len(streams),maximum_primary_fraction_of_limit=str(limit),
                  primary_exact_comparisons=sum(r["exact"] for r in summaries if r["scope"].startswith("Part_")),
                  primary_nonzero_comparisons=sum(r["nonzero"] for r in summaries if r["scope"].startswith("Part_")),
                  checked_frozen_evidence_files=files_checked,stata_evidence_routes=len(licensed),
                  fresh_execution=fresh,additional_checks=other,negative_controls=controls,
                  sha256={f"{key}.csv":digest(output/f"{key}.csv") for key in registers})
    (output/"summary.json").write_text(json.dumps(record,indent=2,ensure_ascii=False)+"\n")
    print(f"Passed: {primary:,} primary comparisons, {len(claims)} chapters, {len(samples)} sample ledgers, {len(displays)} published cells.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    audit(parser.parse_args().output)
