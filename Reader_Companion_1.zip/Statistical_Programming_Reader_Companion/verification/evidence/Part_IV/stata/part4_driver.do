*! Part IV native regressions and likelihood audits for Stata 16 or 17.
version 16.0
args input output
if `"`input'"'=="" | `"`output'"'=="" {
    display as error "Provide the input and output folders."
    exit 198
}
tempname p b v tmean tsig
tempfile collected
postfile `p' str4 chapter str18 model str20 quantity str48 key ///
    double value using `"`collected'"'

* Chapter 13. Coefficients, two covariance matrices and observation diagnostics.
foreach model in pilot multiple {
    if "`model'"=="pilot" {
        import delimited using `"`input'/pilot13.csv"', clear varnames(1) stringcols(1) asdouble
        local terms sessions
    }
    else {
        import delimited using `"`input'/regression13.csv"', clear varnames(1) stringcols(1) asdouble
        local terms sessions irrigated
    }
    isid plot_id
    quietly regress yield_kg_ha `terms'
    assert e(sample)
    post `p' ("CH13") ("`model'") ("scalar") ("n") (e(N))
    post `p' ("CH13") ("`model'") ("scalar") ("rank") (e(rank))
    post `p' ("CH13") ("`model'") ("scalar") ("df") (e(df_r))
    post `p' ("CH13") ("`model'") ("scalar") ("rss") (e(rss))
    post `p' ("CH13") ("`model'") ("scalar") ("r2") (e(r2))
    quietly predict double fitted, xb
    quietly predict double residual, residuals
    quietly predict double leverage, hat
    quietly predict double cook, cooksd
    forvalues i=1/`=_N' {
        post `p' ("CH13") ("`model'") ("fit") (plot_id[`i']) (fitted[`i'])
        post `p' ("CH13") ("`model'") ("residual") (plot_id[`i']) (residual[`i'])
        post `p' ("CH13") ("`model'") ("leverage") (plot_id[`i']) (leverage[`i'])
        post `p' ("CH13") ("`model'") ("cook") (plot_id[`i']) (cook[`i'])
    }
    foreach cov in classical hc1 {
        if "`cov'"=="hc1" quietly regress yield_kg_ha `terms', vce(robust)
        matrix `b'=e(b)
        matrix `v'=e(V)
        foreach a in _cons `terms' {
            local ia=colnumb(`b',"`a'")
            local namea=cond("`a'"=="_cons","intercept","`a'")
            if "`cov'"=="classical" {
                post `p' ("CH13") ("`model'") ("beta") ("`namea'") (`b'[1,`ia'])
            }
            foreach c in _cons `terms' {
                local ic=colnumb(`b',"`c'")
                local namec=cond("`c'"=="_cons","intercept","`c'")
                post `p' ("CH13") ("`model'") ("`cov'") ("`namea'/`namec'") (`v'[`ia',`ic'])
            }
        }
    }
}

* Chapter 14. Native maximum likelihood with a shared design and offset.
foreach model in logit probit poisson nb2 {
    local binary=inlist("`model'","logit","probit")
    if `binary' {
        import delimited using `"`input'/delivery14.csv"', clear varnames(1) stringcols(1) asdouble
        isid case_id
        assert inlist(event,0,1)
        local x contacts
        local id case_id
        quietly `model' event contacts rural, nolog
    }
    else {
        import delimited using `"`input'/appointments14.csv"', clear varnames(1) stringcols(1) asdouble
        isid count_id
        assert days>0 & days<. & appointments==floor(appointments) & appointments>=0
        gen double log_exposure=ln(days/30)
        local x capacity
        local id count_id
        if "`model'"=="poisson" quietly poisson appointments capacity rural, offset(log_exposure) nolog
        if "`model'"=="nb2" quietly nbreg appointments capacity rural, offset(log_exposure) dispersion(mean) nolog
    }
    assert e(sample)
    assert e(converged)==1
    post `p' ("CH14") ("`model'") ("scalar") ("n") (e(N))
    post `p' ("CH14") ("`model'") ("scalar") ("ll") (e(ll))
    matrix `b'=e(b)
    if "`model'"=="nb2" {
        local k=colsof(`b')
        assert `k'==4
        post `p' ("CH14") ("`model'") ("scalar") ("alpha") (exp(`b'[1,`k']))
    }
    scalar `tmean'=_b[_cons]
    scalar `tsig'=_b[`x']
    tempname bz
    scalar `bz'=_b[rural]
    post `p' ("CH14") ("`model'") ("beta") ("intercept") (`tmean')
    post `p' ("CH14") ("`model'") ("beta") ("`x'") (`tsig')
    post `p' ("CH14") ("`model'") ("beta") ("rural") (`bz')
    gen double eta0=`tmean'+`tsig'*`x'
    if !`binary' replace eta0=eta0+log_exposure
    gen double eta=eta0+`bz'*rural
    gen double mu=.
    gen double slope=.
    gen double delta=.
    if "`model'"=="logit" {
        replace mu=invlogit(eta)
        replace slope=`tsig'*mu*(1-mu)
        replace delta=invlogit(eta0+`bz')-invlogit(eta0)
    }
    else if "`model'"=="probit" {
        replace mu=normal(eta)
        replace slope=`tsig'*normalden(eta)
        replace delta=normal(eta0+`bz')-normal(eta0)
    }
    else {
        replace mu=exp(eta)
        replace slope=`tsig'*mu
        replace delta=exp(eta0)*(exp(`bz')-1)
    }
    forvalues i=1/`=_N' {
        post `p' ("CH14") ("`model'") ("eta") (`id'[`i']) (eta[`i'])
        post `p' ("CH14") ("`model'") ("mean") (`id'[`i']) (mu[`i'])
    }
    quietly summarize slope, meanonly
    post `p' ("CH14") ("`model'") ("ame") ("`x'") (r(mean))
    quietly summarize delta, meanonly
    post `p' ("CH14") ("`model'") ("ame") ("rural") (r(mean))
    import delimited using `"`input'/prediction14.csv"', clear varnames(1) stringcols(1) asdouble
    isid scenario_id
    gen double eta=`tmean'+`tsig'*`x'+`bz'*rural
    if !`binary' replace eta=eta+ln(days/30)
    gen double mu=exp(eta)
    if "`model'"=="logit" replace mu=invlogit(eta)
    if "`model'"=="probit" replace mu=normal(eta)
    forvalues i=1/`=_N' {
        post `p' ("CH14") ("`model'") ("grid_eta") (scenario_id[`i']) (eta[`i'])
        post `p' ("CH14") ("`model'") ("grid_mean") (scenario_id[`i']) (mu[`i'])
    }
}

* Chapter 15. Censored-normal log likelihood and scores at a fixed parameter.
import delimited using `"`input'/censor15.csv"', clear varnames(1) stringcols(1) asdouble
isid case_id
assert inlist(censored,0,1) & ((expenditure==0)==censored)
gen double m=.9+.8*resources
gen double a=-m/1.2
gen double z=(expenditure-m)/1.2
gen double ratio=normalden(a)/normal(a)
gen double ll=cond(censored,ln(normal(a)),ln(normalden(z))-ln(1.2))
gen double intercept=cond(censored,-ratio/1.2,z/1.2)
gen double beta=resources*intercept
gen double logsig=cond(censored,-a*ratio,z^2-1)
foreach item in ll intercept beta logsig {
    forvalues i=1/`=_N' {
        post `p' ("CH15") ("tobit_eval") ("`item'") (case_id[`i']) (`item'[`i'])
    }
    quietly summarize `item', meanonly
    post `p' ("CH15") ("tobit_eval") ("`item'") ("total") (r(sum))
}

* Cox fits and tie-rule checks with common time origin and no delayed entry.
import delimited using `"`input'/duration15.csv"', clear varnames(1) stringcols(1) asdouble
isid person_id
assert duration>0 & duration<. & inlist(event,0,1)
quietly stset duration, failure(event==1)
assert _st==1 & _d==event & _t==duration
foreach model in breslow efron {
    quietly stcox risk supported, `model' nolog
    assert e(sample)
    post `p' ("CH15") ("`model'") ("scalar") ("n") (e(N))
    post `p' ("CH15") ("`model'") ("scalar") ("ll") (e(ll))
    post `p' ("CH15") ("`model'") ("beta") ("risk") (_b[risk])
    post `p' ("CH15") ("`model'") ("beta") ("supported") (_b[supported])
    gen double eta=_b[risk]*risk+_b[supported]*supported
    forvalues i=1/`=_N' {
        post `p' ("CH15") ("`model'") ("eta") (person_id[`i']) (eta[`i'])
    }
    drop eta
}
gen double point=.30*risk-.25*supported
gen double w=exp(point)
gen double wx=w*risk
gen double wz=w*supported
quietly levelsof duration if event==1, local(times)
scalar `tmean'=1
foreach time of local times {
    quietly count if duration>=`time'
    local riskn=r(N)
    quietly count if duration==`time' & event
    local d=r(N)
    quietly count if duration==`time' & !event
    local cens=r(N)
    local key=strtrim(string(`time',"%9.0g"))
    scalar `tmean'=`tmean'*(1-`d'/`riskn')
    post `p' ("CH15") ("riskset") ("risk") ("`key'") (`riskn')
    post `p' ("CH15") ("riskset") ("events") ("`key'") (`d')
    post `p' ("CH15") ("riskset") ("censored") ("`key'") (`cens')
    post `p' ("CH15") ("riskset") ("km") ("`key'") (`tmean')
    foreach a in w wx wz {
        quietly summarize `a' if duration>=`time', meanonly
        local r_`a'=r(sum)
        quietly summarize `a' if duration==`time' & event, meanonly
        local e_`a'=r(sum)
    }
    quietly summarize point if duration==`time' & event, meanonly
    local base=r(sum)
    foreach model in breslow efron {
        local term=`base'
        forvalues j=1/`d' {
            local frac=cond("`model'"=="efron",(`j'-1)/`d',0)
            local term=`term'-ln(`r_w'-`frac'*`e_w')
        }
        post `p' ("CH15") ("`model'") ("fixed_ll") ("`key'") (`term')
    }
}

* Chapter 16. Gaussian random intercept, maximum likelihood.
foreach model in balanced unbalanced {
    import delimited using `"`input'/facilities16.csv"', clear varnames(1) stringcols(1 2) asdouble
    isid patient_id
    keep if `model'==1
    egen long facility=group(facility_id)
    quietly mixed outcome baseline || facility:, mle variance nolog
    assert e(sample) & e(converged)==1
    matrix `b'=e(b)
    local k=colsof(`b')
    assert `k'==4
    post `p' ("CH16") ("`model'") ("scalar") ("n") (e(N))
    post `p' ("CH16") ("`model'") ("scalar") ("ll") (e(ll))
    post `p' ("CH16") ("`model'") ("beta") ("intercept") (_b[_cons])
    post `p' ("CH16") ("`model'") ("beta") ("baseline") (_b[baseline])
    post `p' ("CH16") ("`model'") ("scalar") ("tau2") (exp(2*`b'[1,3]))
    post `p' ("CH16") ("`model'") ("scalar") ("sigma2") (exp(2*`b'[1,4]))
    quietly predict double effect, reffects
    gen double fit=_b[_cons]+_b[baseline]*baseline+effect
    forvalues i=1/`=_N' {
        post `p' ("CH16") ("`model'") ("fit") (patient_id[`i']) (fit[`i'])
    }
    bysort facility_id (patient_id): gen byte first=_n==1
    quietly count if first
    post `p' ("CH16") ("`model'") ("scalar") ("groups") (r(N))
    forvalues i=1/`=_N' {
        if first[`i'] post `p' ("CH16") ("`model'") ("effect") (facility_id[`i']) (effect[`i'])
    }
}
postclose `p'
use `"`collected'"', clear
isid chapter model quantity key
assert !missing(value)
sort chapter model quantity key
tempname file
file open `file' using `"`output'/metrics.csv"', write text replace
file write `file' "chapter,model,quantity,key,value" _n
forvalues i=1/`=_N' {
    file write `file' (chapter[`i']) "," (model[`i']) "," (quantity[`i']) "," ///
        (key[`i']) "," %24.17g (value[`i']) _n
}
file close `file'
display as result "Part IV generated in Stata `c(stata_version)' `c(flavor)'."
