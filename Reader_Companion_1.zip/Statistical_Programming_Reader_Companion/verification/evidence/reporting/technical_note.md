# Technical note

Twelve eligible synthetic plot-seasons from 2025 support an unweighted OLS fit with intercept.
The revised scenario adds 10 kg to plot P011 at 0.5 ha. The eligible keys, area and sessions
are unchanged.

| Scenario | Rows | Slope | HC1 SE | Lower | Upper |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline | 12 | 80.00 | 4.66 | 69.62 | 90.38 |
| Corrected harvest | 12 | 81.43 | 3.84 | 72.88 | 89.98 |

The slope is in kg/ha per recorded session. Intervals use HC1 and a Student reference with
10 residual degrees of freedom. The original licensed Stata evidence covers the baseline.
Python, R and DuckDB independently check the revised result and its interval.

Baseline analytical SHA-256: d3da0ee0af84ddd977a332adfb0ab365e7af7bd72df4111e8ccb5a8359ea7b16.

Corrected analytical SHA-256: 068dc5490ca27e622f4efdc18a93f35aa2d5af2581a1464cc272b7c1d741bf9f.
